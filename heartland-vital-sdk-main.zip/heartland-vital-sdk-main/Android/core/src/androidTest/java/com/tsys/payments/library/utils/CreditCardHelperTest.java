package com.tsys.payments.library.utils;

import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.annotation.NonNull;
import androidx.test.runner.AndroidJUnit4;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class CreditCardHelperTest {

    private static final String VISA_CARD_NUMBER = "4012881888818888";
    private static final String VISA_CVV = "999";

    private static final String MASTERCARD_CARD_NUMBER = "5400060000000041";
    private static final String MASTERCARD_CARD_NUMBER_NEW_BIN = "2221000000000009";
    private static final String MASTERCARD_CVV = "998";

    private static final String AMEX_CARD_NUMBER = "371449635392376";
    private static final String AMEX_CVV = "9997";

    private static final String DISC_CARD_NUMBER = "6011000993026909";
    private static final String DISC_CARD_NUMBER_TWO = "6501000000000001";
    private static final String DISC_CVV = "996";
    private static final String DISC_REDACTED_CARD_NUMBER = "6501********1234";

    private static final String DINERS_CARD_NUMBER = "36004000400200";
    private static final String DINERS_CVV = "996";

    private static final String JCB_CARD_NUMBER = "3530142019945859";
    private static final String JCB_CVV = "995";

    private static final String DEBIT_CARD_NUMBER = "4017779999999016";

    @Test
    public void testIsVisa_PassesValidBin() throws Exception {
        assertTrue(CreditCardHelper.isVisa(VISA_CARD_NUMBER));
        assertTrue(CreditCardHelper.isVisa(DEBIT_CARD_NUMBER));
    }

    @Test
    public void testIsVisa_FailsInvalidBin() throws Exception {
        assertFalse(CreditCardHelper.isVisa(AMEX_CARD_NUMBER));
        assertFalse(CreditCardHelper.isVisa(MASTERCARD_CARD_NUMBER));
        assertFalse(CreditCardHelper.isVisa(DISC_CARD_NUMBER));
        assertFalse(CreditCardHelper.isVisa(DISC_CARD_NUMBER_TWO));
        assertFalse(CreditCardHelper.isVisa(DISC_REDACTED_CARD_NUMBER));
        assertFalse(CreditCardHelper.isVisa(DINERS_CARD_NUMBER));
        assertFalse(CreditCardHelper.isVisa(JCB_CARD_NUMBER));
    }

    @Test
    public void testIsMasterCard_PassesValidBin() throws Exception {
        assertTrue(CreditCardHelper.isMasterCard(MASTERCARD_CARD_NUMBER));
    }

    @Test
    public void testIsMasterCard_PassesNewBinRange() throws Exception {
        assertTrue(CreditCardHelper.isMasterCard(MASTERCARD_CARD_NUMBER_NEW_BIN));
    }

    @Test
    public void testIsMasterCard_FailsInvalidBin() throws Exception {
        assertFalse(CreditCardHelper.isMasterCard(VISA_CARD_NUMBER));
        assertFalse(CreditCardHelper.isMasterCard(AMEX_CARD_NUMBER));
        assertFalse(CreditCardHelper.isMasterCard(DISC_CARD_NUMBER));
        assertFalse(CreditCardHelper.isMasterCard(DISC_CARD_NUMBER_TWO));
        assertFalse(CreditCardHelper.isMasterCard(DISC_REDACTED_CARD_NUMBER));
        assertFalse(CreditCardHelper.isMasterCard(DINERS_CARD_NUMBER));
        assertFalse(CreditCardHelper.isMasterCard(JCB_CARD_NUMBER));
    }

    @Test
    public void testIsAmericanExpress_PassesValidBin() throws Exception {
        assertTrue(CreditCardHelper.isAmericanExpress(AMEX_CARD_NUMBER));
    }

    @Test
    public void testIsAmericanExpress_FailsInvalidBin() throws Exception {
        assertFalse(CreditCardHelper.isAmericanExpress(VISA_CARD_NUMBER));
        assertFalse(CreditCardHelper.isAmericanExpress(MASTERCARD_CARD_NUMBER));
        assertFalse(CreditCardHelper.isAmericanExpress(DISC_CARD_NUMBER));
        assertFalse(CreditCardHelper.isAmericanExpress(DISC_CARD_NUMBER_TWO));
        assertFalse(CreditCardHelper.isAmericanExpress(DISC_REDACTED_CARD_NUMBER));
        assertFalse(CreditCardHelper.isAmericanExpress(DINERS_CARD_NUMBER));
        assertFalse(CreditCardHelper.isAmericanExpress(JCB_CARD_NUMBER));
    }

    @Test
    public void testIsDiscover_PassesValidBin() throws Exception {
        assertTrue(CreditCardHelper.isDiscover(DISC_CARD_NUMBER));
        assertTrue(CreditCardHelper.isDiscover(DISC_CARD_NUMBER_TWO));
        assertTrue(CreditCardHelper.isDiscover(DISC_REDACTED_CARD_NUMBER));
    }

    @Test
    public void testIsDiscover_FailsInvalidBin() throws Exception {
        assertFalse(CreditCardHelper.isDiscover(VISA_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDiscover(AMEX_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDiscover(MASTERCARD_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDiscover(DINERS_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDiscover(JCB_CARD_NUMBER));
    }

    @Test
    public void testIsDinersClub_PassesValidBin() throws Exception {
        assertTrue(CreditCardHelper.isDinersClub(DINERS_CARD_NUMBER));
    }

    @Test
    public void testIsDinersClub_FailsInvalidBin() throws Exception {
        assertFalse(CreditCardHelper.isDinersClub(VISA_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDinersClub(AMEX_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDinersClub(MASTERCARD_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDinersClub(DISC_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDinersClub(DISC_CARD_NUMBER_TWO));
        assertFalse(CreditCardHelper.isDinersClub(DISC_REDACTED_CARD_NUMBER));
        assertFalse(CreditCardHelper.isDinersClub(JCB_CARD_NUMBER));
    }

    @Test
    public void testIsNumberValid_PassesValidNumber() throws Exception {
        assertTrue(CreditCardHelper.isNumberValid(VISA_CARD_NUMBER));
        assertTrue(CreditCardHelper.isNumberValid(AMEX_CARD_NUMBER));
        assertTrue(CreditCardHelper.isNumberValid(MASTERCARD_CARD_NUMBER));
        assertTrue(CreditCardHelper.isNumberValid(DISC_CARD_NUMBER));
        assertTrue(CreditCardHelper.isNumberValid(DISC_CARD_NUMBER_TWO));
        assertTrue(CreditCardHelper.isNumberValid(DINERS_CARD_NUMBER));
        assertTrue(CreditCardHelper.isNumberValid(JCB_CARD_NUMBER));
    }

    @Test
    public void testIsNumberValid_FailsInvalidNumber() throws Exception {
        assertFalse(CreditCardHelper.isNumberValid(DISC_REDACTED_CARD_NUMBER));
    }

    @Test
    public void testIsCvnValid_PassesValidCvn() throws Exception {
        assertTrue(CreditCardHelper.isCvnValid(VISA_CVV, VISA_CARD_NUMBER));
        assertTrue(CreditCardHelper.isCvnValid(AMEX_CVV, AMEX_CARD_NUMBER));
        assertTrue(CreditCardHelper.isCvnValid(MASTERCARD_CVV, MASTERCARD_CARD_NUMBER));
        assertTrue(CreditCardHelper.isCvnValid(DISC_CVV, DISC_CARD_NUMBER));
        assertTrue(CreditCardHelper.isCvnValid(DISC_CVV, DISC_CARD_NUMBER_TWO));
        assertTrue(CreditCardHelper.isCvnValid(DINERS_CVV, DINERS_CARD_NUMBER));
        assertTrue(CreditCardHelper.isCvnValid(JCB_CVV, JCB_CARD_NUMBER));
    }

    @Test
    public void testLuhnValidate_PassesValidNumber() throws Exception {
        assertTrue(CreditCardHelper.luhnValidate(VISA_CARD_NUMBER));
        assertTrue(CreditCardHelper.luhnValidate(AMEX_CARD_NUMBER));
        assertTrue(CreditCardHelper.luhnValidate(MASTERCARD_CARD_NUMBER));
        assertTrue(CreditCardHelper.luhnValidate(MASTERCARD_CARD_NUMBER_NEW_BIN));
        assertTrue(CreditCardHelper.luhnValidate(DISC_CARD_NUMBER));
        assertTrue(CreditCardHelper.luhnValidate(DISC_CARD_NUMBER_TWO));
        assertTrue(CreditCardHelper.luhnValidate(DINERS_CARD_NUMBER));
        assertTrue(CreditCardHelper.luhnValidate(JCB_CARD_NUMBER));
    }

    @Test
    public void testLuhnValidate_FailsValidNumber() throws Exception {
        assertFalse(CreditCardHelper.luhnValidate(DISC_REDACTED_CARD_NUMBER));
    }

    @Test
    public void test_obfuscateNumber_masksUpToLast4DigitsCorrectly() {
        // 16-digit PAN
        final String maskedVisaNumber = "************8888";

        String obfuscatedVisa =
                CreditCardHelper.obfuscateNumber(VISA_CARD_NUMBER, 0, 4, '*', false);
        assertEquals(maskedVisaNumber,obfuscatedVisa);

        // 15-digit PAN
        final String maskedAMEX = "***********2376";

        String obfuscatedAMEX =
                CreditCardHelper.obfuscateNumber(AMEX_CARD_NUMBER, 0, 4, '*', false);
        assertEquals(maskedAMEX,obfuscatedVisa);
    }
}
