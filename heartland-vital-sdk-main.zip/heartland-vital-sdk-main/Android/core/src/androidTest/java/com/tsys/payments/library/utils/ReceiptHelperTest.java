package com.tsys.payments.library.utils;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.Receipt;
import com.tsys.payments.library.tlv.ConstructedTlvObject;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvUtils;

import org.junit.Test;

import static org.junit.Assert.*;

public class ReceiptHelperTest {

    @Test
    public void test_buildEmvReceipt_appPreferredNameTakesPriorityOnRecept() {
        /* Verify that application preferred name is displayed as application label on receipt when
           present */
        final String visaTlvWithAppPreferredName =
                "4F07A0000000031010500B56495341204352454449545F201A56495341204143515549524552205445" +
                        "53542F434152442030315F24032212315F280208405F2A0208405F340101820258008407A0" +
                        "0000000310108A025A33950502800080009A032012039B02E8009C01009F02060000000002" +
                        "559F03060000000000009F0607A00000000310109F0702FF009F080200969F0902008C9F0D" +
                        "05F0400088009F0E0500100000009F0F05F0400098009F100706011203A000009F120F4352" +
                        "454449544F20444520564953419F1A0208409F1C0831313232333334349F1E083132333435" +
                        "3637389F2608809AFC0F7F9712399F2701809F33036028C89F34031E03009F3501219F3602" +
                        "0A029F3704568B8CF69F3901059F40057000A0A0019F410400000017";

        CardData cardData = new CardData();
        cardData.setEmvTlvData(ConstructedTlvObject.parse(visaTlvWithAppPreferredName));

        TlvObject appPreferredNameTlv =
                TlvUtils.findTlv(EmvTagDescriptor.APPLICATION_PREFERRED_NAME,
                        cardData.getEmvTlvData());
        TlvObject appLabelTlv = TlvUtils.findTlv(EmvTagDescriptor.APP_LABEL,
                cardData.getEmvTlvData());
        assertNotNull(appPreferredNameTlv);
        assertNotNull(appLabelTlv);

        String appPreferredNameTagValue =
                new String(ByteUtils.hexStringToByteArray(appPreferredNameTlv.getValueAsHexString(
                        false)));

        Receipt receipt = ReceiptHelper.buildEmvReceipt(null, cardData);

        assertNotNull(receipt);
        assertEquals(appPreferredNameTagValue, receipt.getApplicationLabel());
    }
}
