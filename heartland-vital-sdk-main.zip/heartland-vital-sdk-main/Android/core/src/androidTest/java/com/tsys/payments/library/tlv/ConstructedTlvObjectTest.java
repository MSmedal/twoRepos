package com.tsys.payments.library.tlv;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import androidx.test.runner.AndroidJUnit4;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ConstructedTlvObjectTest {

    @Test
    public void parseEmvScripts() {
        String issuerScriptsFullTlv = "720C9F18040001860580CA9F3600";
        List<TlvObject> tags = ConstructedTlvObject.parse(issuerScriptsFullTlv);
        for (TlvObject object : tags) {
            assertTrue(EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_2 == object.getTagDescriptor());
            assertTrue(object.mInnerTlvs == null);
            assertTrue(object.getValueLength() != null);
            assertEquals(0, object.getValueLength().getLength());
            object.asHexString();
        }
    }
}
