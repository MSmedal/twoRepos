package com.tsys.payments.library;

import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.Tag;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvUtils;
import com.tsys.payments.library.utils.ByteUtils;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RunWith(BlockJUnit4ClassRunner.class)
public class TlvUtilsTest {

    @Test
    public void testPorticoStripEmvTagDescriptors() {
        List<TlvObject> tlvObjectList = new ArrayList<>();

        tlvObjectList.add(new TlvObject(
                Tag.fromTagDescriptor(EmvTagDescriptor.BBPOS_ARQC_DECRYPTION_KSN),
                new byte[] {0x0001}));
        tlvObjectList
                .add(new TlvObject(Tag.fromTagDescriptor(EmvTagDescriptor.BBPOS_ONLINE_PIN_KSN),
                        new byte[] {0x0002}));

        tlvObjectList.add(new TlvObject(
                Tag.fromTagDescriptor(EmvTagDescriptor.APPLICATION_IDENTIFIER), ByteUtils
                .hexStringToByteArray(
                        "A0000000031010")));

        Set<EmvTagDescriptor> emvTagDescriptors = new HashSet<>();
        emvTagDescriptors.add(EmvTagDescriptor.BBPOS_ARQC_DECRYPTION_KSN);
        emvTagDescriptors.add(EmvTagDescriptor.BBPOS_ONLINE_PIN_KSN);

        List<TlvObject> resultList = TlvUtils
                .stripEmvTagDescriptorsFromTlvList(emvTagDescriptors, tlvObjectList);
        Assert.assertEquals(1, resultList.size());
        Assert.assertEquals(resultList.get(0).getTagDescriptor(),
                EmvTagDescriptor.APPLICATION_IDENTIFIER);
        Assert.assertEquals(3, tlvObjectList.size());
    }
}
