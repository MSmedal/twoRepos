package com.tsys.payments.library;

import com.tsys.payments.library.utils.CurrencyHelper;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class CurrencyHelperTest {

    @Test
    public void toStringOrNull_HandlesNull() {
        String actual = CurrencyHelper.toStringOrNull(null);
        assertNull(actual);
    }

    @Test
    public void toStringOrNull_HandlesZero() {
        String expected = "0.00";
        String actual = CurrencyHelper.toStringOrNull(0L);
        assertEquals(expected, actual);
    }

    @Test
    public void toStringOrNull_HandlesCents() {
        String expected = "0.01";
        String actual = CurrencyHelper.toStringOrNull(1L);
        assertEquals(expected, actual);
    }

    @Test
    public void toStringOrNull_HandlesDollars() {
        String expected = "1.00";
        String actual = CurrencyHelper.toStringOrNull(100L);
        assertEquals(expected, actual);
    }

    @Test
    public void toLong_HandlesNull() {
        long expected = 0;
        long actual = CurrencyHelper.toLong(null);
        assertEquals(expected, actual);
    }

    @Test
    public void toLong_HandlesNonDigits() {
        long expected = 0;
        long actual = CurrencyHelper.toLong("amount");
        assertEquals(expected, actual);
    }

    @Test
    public void toLong_HandlesZero() {
        long expected = 0;
        long actual = CurrencyHelper.toLong("0");
        assertEquals(expected, actual);
    }

    @Test
    public void toLong_HandlesCents() {
        long expected = 1;
        long actual = CurrencyHelper.toLong("0.01");
        assertEquals(expected, actual);
    }

    @Test
    public void toLong_HandlesDollars() {
        long expected = 100;
        long actual = CurrencyHelper.toLong("1.00");
        assertEquals(expected, actual);
    }

    @Test
    public void toLongOrNull_HandlesNull() {
        assertNull(CurrencyHelper.toLongOrNull(null));
    }

    @Test
    public void toLongOrNull_HandlesNonDigits() {
        assertNull(CurrencyHelper.toLongOrNull("amount"));
    }

    @Test
    public void toLongOrNull_HandlesZero() {
        Long expected = 0L;
        Long actual = CurrencyHelper.toLongOrNull("0");
        assertEquals(expected, actual);
    }

    @Test
    public void toLongOrNull_HandlesCents() {
        Long expected = 1L;
        Long actual = CurrencyHelper.toLongOrNull("0.01");
        assertEquals(expected, actual);
    }
}
