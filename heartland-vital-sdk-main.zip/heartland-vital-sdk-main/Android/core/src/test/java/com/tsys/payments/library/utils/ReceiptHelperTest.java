package com.tsys.payments.library.utils;

import com.tsys.payments.library.domain.Receipt;
import com.tsys.payments.library.enums.TransactionType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class ReceiptHelperTest {

    @Test
    public void test_buildMsrReceipt_withAuthGatewayRequestGatewayResponses_producesCorrectReceiptTransactionType() {
        GatewayRequest request = new GatewayRequest.Builder(GatewayAction.AUTH).build();

        Receipt receipt = ReceiptHelper.buildMsrReceipt(request, null);
        assertNotNull(receipt);
        Assert.assertNotNull(receipt.getTransactionType());
        Assert.assertEquals(TransactionType.AUTH, receipt.getTransactionType());
    }

    @Test
    public void test_buildMsrReceipt_withSaleGatewayRequestGatewayResponses_producesCorrectReceiptTransactionType() {
        GatewayRequest request = new GatewayRequest.Builder(GatewayAction.SALE).build();

        Receipt receipt = ReceiptHelper.buildMsrReceipt(request, null);
        assertNotNull(receipt);
        Assert.assertNotNull(receipt.getTransactionType());
        Assert.assertEquals(TransactionType.SALE, receipt.getTransactionType());
    }
}
