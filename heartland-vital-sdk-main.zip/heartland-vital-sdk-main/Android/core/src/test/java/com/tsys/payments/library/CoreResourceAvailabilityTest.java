package com.tsys.payments.library;

import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.net.URL;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Unit tests that should be run after ./gradlew assemble is run to validate the presence of all resources that are
 * needed for packaging the module into a separate AAR file that combines resources from other modules. The resources
 * are located in the <project_root>/build/intermediates folder.
 */
public class CoreResourceAvailabilityTest {
    // FIXME: Tests are for verifying presence of artifacts needed for building jar for the module.
    // Re-write or scrap the tests altogether. This is not a sustainable way of building the jar as the
    // structures change with updates to gradle or android plugins.
    //    private static final String BUILD_PATH = "Android/core/build/";
    //    private static final String JNILIBS_PATH =
    //            "intermediates/jniLibs/" + BuildConfig.FLAVOR + BuildConfig.BUILD_TYPE;
    //    private static final String CLASSES_JAR_PATH =
    //            "intermediates/packaged-classes/" + BuildConfig.FLAVOR + BuildConfig.BUILD_TYPE +
    //                    "/classes.jar";
    //
    //    /**
    //     * Library path created only after 'gradle assemble' has been run to completion. As a
    //     * precondition for running the unit tests, this path must exist. Otherwise, return without
    //     * failing the test.
    //     */
    //    private static final String JNILIBS_DIRECTORY_PATH = "intermediates/jniLibs/";
    //
    //    /**
    //     * Library path created only after 'gradle assemble' has been run to completion. As a
    //     * precondition for running the unit tests, this path must exist. Otherwise, return without
    //     * failing the test.
    //     */
    //    private static final String PACKAGED_CLASSES_DIRECTORY_PATH = "intermediates/packaged-classes/";
    //
    //    @Before
    //    public void testPreconditions() {
    //        Assume.assumeTrue(verifyTestingPreconditions());
    //    }
    //
    //    @Test
    //    public void test_intermediatesDirContainsJniLibsFolder() {
    //        URL resource = getTestClassFilePath();
    //        assertNotNull(resource);
    //        assertTrue(resource.getPath().contains(BUILD_PATH));
    //
    //        String jniLibsPathBuilder = resource.getPath().substring(0,
    //                resource.getPath().indexOf(BUILD_PATH) +
    //                        BUILD_PATH.length()) + JNILIBS_PATH;
    //        File targetPath = new File(
    //                jniLibsPathBuilder);
    //        assertTrue(targetPath.isDirectory());
    //    }
    //
    //    @Test
    //    public void test_intermediatesDirContainsClassesJarPath() {
    //        URL resource = getTestClassFilePath();
    //        assertNotNull(resource);
    //        assertTrue(resource.getPath().contains(BUILD_PATH));
    //
    //        String classesJarPath = resource.getPath().substring(0,
    //                resource.getPath().indexOf(BUILD_PATH) +
    //                        BUILD_PATH.length()) + CLASSES_JAR_PATH;
    //        File targetPath = new File(
    //                classesJarPath);
    //        assertTrue(targetPath.isFile());
    //    }
    //
    //    /**
    //     * Retrieves the path on the file system to the current test class being executed. This path
    //     * includes the path to the project root, from which a traversal can then be made to the
    //     * build/intermediates
    //     * folder that contains paths to resources needed for the AAR.
    //     *
    //     * @return {@link URL} to the current unit test class being executed.
    //     */
    //    private URL getTestClassFilePath() {
    //        ClassLoader loader = getClass().getClassLoader();
    //        String name = getClass().getCanonicalName();
    //        assertNotNull(loader);
    //        assertNotNull(name);
    //        return loader.getResource(name.replace(".", "/") + ".class");
    //    }
    //
    //    /**
    //     * Check that 'gradlew assemble' was run by verifying that one of the artifact directories
    //     * was created.
    //     *
    //     * @return True if output directories were created.
    //     */
    //    private boolean verifyTestingPreconditions() {
    //        URL resource = getTestClassFilePath();
    //        File jniLibsDirectory = new File(resource.getPath().substring(0,
    //                resource.getPath().indexOf(BUILD_PATH) +
    //                        BUILD_PATH.length()) + JNILIBS_DIRECTORY_PATH);
    //        File packagedClassesDirectory = new File(resource.getPath().substring(0,
    //                resource.getPath().indexOf(BUILD_PATH) +
    //                        BUILD_PATH.length()) + PACKAGED_CLASSES_DIRECTORY_PATH);
    //        if (!jniLibsDirectory.exists()) {
    //            System.out.println("Intermediate build directory path : " + JNILIBS_DIRECTORY_PATH +
    //                    " was not created. Please run 'gradlew assemble' before running unit tests.");
    //            return false;
    //        }
    //        if (!packagedClassesDirectory.exists()) {
    //            System.out.println(
    //                    "Intermediate build directory path : " + PACKAGED_CLASSES_DIRECTORY_PATH +
    //                            " was not created. Please run 'gradlew assemble' before running unit tests.");
    //            return false;
    //        }
    //
    //        return true;
    //    }
}
