package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.enums.CountryCode;
import com.tsys.payments.library.enums.CurrencyCode;
import com.tsys.payments.library.enums.CvmResult;
import com.tsys.payments.library.enums.PinStatementType;
import com.tsys.payments.library.enums.TransactionType;
import java.util.Date;

public class Receipt {

    private Date mTransactionDateTime;
    private TransactionType mTransactionType;
    private String mInvoiceNumber;
    private CurrencyCode mCurrencyCode;
    private Long mTransactionAmount;
    private String mAuthorizationCode;
    private CardType mCardType;
    private String mMaskedPan;
    private String mPosReferenceNumber;
    private String mTransactionId;
    private String mCardholderName;

    private String mAid;
    private String mApplicationLabel;
    private String mApplicationExpiryDate;
    private String mApplicationEffectiveDate;
    private String mApplicationInterchangeProfile;
    private String mApplicationVersionNumber;
    private String mApplicationTransactionCounter;
    private String mPanSequenceNumber;
    private String mCryptogram;
    private CvmResult mCvmResult;
    private String mIssuerApplicationData;
    private String mIssuerAuthenticationData;
    private String mTerminalVerificationResult;
    private String mUnpredictableNumber;
    private Long mCashBackAmount;
    private CardDataSourceType mPosEntryMode;
    private String mTerminalType;
    private String mIfdSerialNumber;
    private String mTerminalSerialNumber;
    private CountryCode mTerminalCountryCode;
    private String mCryptogramInformationData;
    private PinStatementType mPinStatement;
    private String mTerminalTransactionDate;
    private String mEmvAuthorizationResponseCode;
    private String mTerminalStatusIndicator;

    private Receipt() {

    }

    public Date getTransactionDateTime() {
        return mTransactionDateTime;
    }

    public TransactionType getTransactionType() {
        return mTransactionType;
    }

    public String getInvoiceNumber() {
        return mInvoiceNumber;
    }

    public CurrencyCode getCurrencyCode() {
        return mCurrencyCode;
    }

    public Long getTransactionAmount() {
        return mTransactionAmount;
    }

    public String getAuthorizationCode() {
        return mAuthorizationCode;
    }

    public CardType getCardType() {
        return mCardType;
    }

    public String getMaskedPan() {
        return mMaskedPan;
    }

    public String getTransactionId() {
        return mTransactionId;
    }

    public String getCardholderName() {
        return mCardholderName;
    }

    public String getAid() {
        return mAid;
    }

    public String getApplicationLabel() {
        return mApplicationLabel;
    }

    public String getApplicationExpiryDate() {
        return mApplicationExpiryDate;
    }

    public String getApplicationEffectiveDate() {
        return mApplicationEffectiveDate;
    }

    public String getApplicationInterchangeProfile() {
        return mApplicationInterchangeProfile;
    }

    public String getApplicationVersionNumber() {
        return mApplicationVersionNumber;
    }

    public String getApplicationTransactionCounter() {
        return mApplicationTransactionCounter;
    }

    public String getPanSequenceNumber() {
        return mPanSequenceNumber;
    }

    public String getCryptogram() {
        return mCryptogram;
    }

    public String getIssuerApplicationData() {
        return mIssuerApplicationData;
    }

    public String getIssuerAuthenticationData() {
        return mIssuerAuthenticationData;
    }

    public String getTerminalVerificationResult() {
        return mTerminalVerificationResult;
    }

    public String getUnpredictableNumber() {
        return mUnpredictableNumber;
    }

    public Long getCashBackAmount() {
        return mCashBackAmount;
    }

    public CardDataSourceType getPosEntryMode() {
        return mPosEntryMode;
    }

    public String getTerminalType() {
        return mTerminalType;
    }

    public String getIfdSerialNumber() {
        return mIfdSerialNumber;
    }

    public String getTerminalSerialNumber() {
        return mTerminalSerialNumber;
    }

    public CountryCode getTerminalCountryCode() {
        return mTerminalCountryCode;
    }

    public String getCryptogramInformationData() {
        return mCryptogramInformationData;
    }

    public PinStatementType getPinStatement() {
        return mPinStatement;
    }

    public CvmResult getCvmResult() {
        return mCvmResult;
    }

    public String getPosReferenceNumber() {
        return mPosReferenceNumber;
    }

    public String getTerminalTransactionDate() {
        return mTerminalTransactionDate;
    }

    public String getEmvAuthorizationResponseCode() {
        return mEmvAuthorizationResponseCode;
    }

    public String getTerminalStatusIndicator() {
        return mTerminalStatusIndicator;
    }

    public static class Builder {

        private Receipt mReceipt;

        public Builder() {
            mReceipt = new Receipt();
        }

        public Builder setTransactionDateTime(Date transactionDateTime) {
            mReceipt.mTransactionDateTime = transactionDateTime;
            return this;
        }

        public Builder setTransactionType(TransactionType transactionType) {
            mReceipt.mTransactionType = transactionType;
            return this;
        }

        public Builder setInvoiceNumber(String invoiceNumber) {
            mReceipt.mInvoiceNumber = invoiceNumber;
            return this;
        }

        public Builder setCurrencyCode(CurrencyCode currencyCode) {
            mReceipt.mCurrencyCode = currencyCode;
            return this;
        }

        public Builder setTransactionAmount(Long transactionAmount) {
            mReceipt.mTransactionAmount = transactionAmount;
            return this;
        }

        public Builder setAuthorizationCode(String authorizationCode) {
            mReceipt.mAuthorizationCode = authorizationCode;
            return this;
        }

        public Builder setCardType(CardType cardType) {
            mReceipt.mCardType = cardType;
            return this;
        }

        public Builder setMaskedPan(String maskedPan) {
            mReceipt.mMaskedPan = maskedPan;
            return this;
        }

        public Builder setTransactionId(String transactionId) {
            mReceipt.mTransactionId = transactionId;
            return this;
        }

        public Builder setCardholderName(String cardholderName) {
            mReceipt.mCardholderName = cardholderName;
            return this;
        }

        public Builder setAid(String aid) {
            mReceipt.mAid = aid;
            return this;
        }

        public Builder setApplicationLabel(String applicationLabel) {
            mReceipt.mApplicationLabel = applicationLabel;
            return this;
        }

        public Builder setApplicationExpiryDate(String applicationExpiryDate) {
            mReceipt.mApplicationExpiryDate = applicationExpiryDate;
            return this;
        }

        public Builder setApplicationEffectiveDate(String applicationEffectiveDate) {
            mReceipt.mApplicationEffectiveDate = applicationEffectiveDate;
            return this;
        }

        public Builder setApplicationInterchangeProfile(String applicationInterchangeProfile) {
            mReceipt.mApplicationInterchangeProfile = applicationInterchangeProfile;
            return this;
        }

        public Builder setApplicationVersionNumber(String applicationVersionNumber) {
            mReceipt.mApplicationVersionNumber = applicationVersionNumber;
            return this;
        }

        public Builder setApplicationTransactionCounter(String applicationTransactionCounter) {
            mReceipt.mApplicationTransactionCounter = applicationTransactionCounter;
            return this;
        }

        public Builder setPanSequenceNumber(String panSequenceNumber) {
            mReceipt.mPanSequenceNumber = panSequenceNumber;
            return this;
        }

        public Builder setCryptogram(String cryptogram) {
            mReceipt.mCryptogram = cryptogram;
            return this;
        }

        public Builder setCvmResult(CvmResult cvmResult) {
            mReceipt.mCvmResult = cvmResult;
            return this;
        }

        public Builder setIssuerApplicationData(String issuerApplicationData) {
            mReceipt.mIssuerApplicationData = issuerApplicationData;
            return this;
        }

        public Builder setIssuerAuthenticationData(String issuerAuthenticationData) {
            mReceipt.mIssuerAuthenticationData = issuerAuthenticationData;
            return this;
        }

        public Builder setTerminalVerificationResult(String terminalVerificationResult) {
            mReceipt.mTerminalVerificationResult = terminalVerificationResult;
            return this;
        }

        public Builder setUnpredictableNumber(String unpredictableNumber) {
            mReceipt.mUnpredictableNumber = unpredictableNumber;
            return this;
        }

        public Builder setCashBackAmount(Long cashBackAmount) {
            mReceipt.mCashBackAmount = cashBackAmount;
            return this;
        }

        public Builder setPosEntryMode(CardDataSourceType posEntryMode) {
            mReceipt.mPosEntryMode = posEntryMode;
            return this;
        }

        public Builder setTerminalType(String terminalType) {
            mReceipt.mTerminalType = terminalType;
            return this;
        }

        public Builder setIfdSerialNumber(String ifdSerialNumber) {
            mReceipt.mIfdSerialNumber = ifdSerialNumber;
            return this;
        }

        public Builder setTerminalSerialNumber(String serialNumber) {
            mReceipt.mTerminalSerialNumber = serialNumber;
            return this;
        }

        public Builder setTerminalCountryCode(CountryCode terminalCountryCode) {
            mReceipt.mTerminalCountryCode = terminalCountryCode;
            return this;
        }

        public Builder setCryptogramInformationData(String cryptogramInformationData) {
            mReceipt.mCryptogramInformationData = cryptogramInformationData;
            return this;
        }

        public Builder setPinStatement(PinStatementType pinStatement) {
            mReceipt.mPinStatement = pinStatement;
            return this;
        }

        public Builder setPosReferenceNumber(String terminalNumber) {
            mReceipt.mPosReferenceNumber = terminalNumber;
            return this;
        }

        public Builder setTerminalTransactionDate(String terminalTransactionDate) {
            mReceipt.mTerminalTransactionDate = terminalTransactionDate;
            return this;
        }

        public Builder setEmvAuthorizationResponseCode(String emvAuthorizationResponseCode) {
            mReceipt.mEmvAuthorizationResponseCode = emvAuthorizationResponseCode;
            return this;
        }

        public Builder setTerminalStatusIndicator(String terminalStatusIndicator) {
            mReceipt.mTerminalStatusIndicator = terminalStatusIndicator;
            return this;
        }

        public Receipt build() {
            return mReceipt;
        }
    }
}
