package com.tsys.payments.library.exceptions;

import com.tsys.payments.library.enums.ErrorType;

public interface Error {

    ErrorType getType();

    String getMessage();

}
