package com.tsys.payments.library.utils;

import java.math.BigDecimal;

public class CurrencyHelper {

    private static final int CURRENCY_SCALE = 2;

    private CurrencyHelper() {
        //no instance
    }

    public static String toStringOrNull(Long amount) {
        return toStringOrNull(amount, false);
    }

    public static String toStringOrNull(Long amount, boolean showSymbol) {
        if (amount == null) return null;

        try {
            BigDecimal decimal = new BigDecimal(amount).movePointLeft(CURRENCY_SCALE);

            if (showSymbol) {
                return "$" + decimal.toString();
            } else {
                return decimal.toString();
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static long toLong(String amount) {
        Long result = toLongOrNull(amount);
        if (result == null) {
            return 0;
        } else {
            return result;
        }
    }

    public static Long toLongOrNull(String amount) {
        if (amount == null || amount.isEmpty()) {
            return null;
        }

        try {
            BigDecimal decimal = new BigDecimal(amount);
            if (decimal.scale() > 0 || decimal.signum() != 0) {
                return decimal.movePointRight(decimal.scale()).longValue();
            } else {
                return decimal.longValue();
            }
        } catch (Exception e) {
            return null;
        }
    }
}
