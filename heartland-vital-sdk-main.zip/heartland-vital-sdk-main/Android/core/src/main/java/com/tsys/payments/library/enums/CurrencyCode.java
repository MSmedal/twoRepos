package com.tsys.payments.library.enums;

public enum CurrencyCode {
    /**
     * US Dollar
     */
    USD("0840");

    public final String currencyCode;

    CurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }
}
