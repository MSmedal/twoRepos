package com.tsys.payments.library.gateway;

import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.enums.GatewayType;

import androidx.annotation.Nullable;

/**
 * Factory interface used to build a new instance of a {@link GatewayController} implementation.
 */
public interface GatewayControllerFactory {

    /**
     * Returns an array of {@link GatewayType}'s managed by this controller.
     */
    @Nullable
    GatewayType[] getSupportedGateways();

    /**
     * Returns an array of {@link TerminalType}'s managed by this controller.
     */
    @Nullable
    TerminalType[] getSupportedTerminals();

    /**
     * @param gatewayConfiguration {@link GatewayConfiguration} to be followed when processing a
     * transaction.
     * @param listener {@link GatewayListener} that will received callbacks when the host responds.
     * @return Concrete host implementation matching the provided {@param hostConfiguration}.
     */
    @Nullable
    GatewayController create(GatewayConfiguration gatewayConfiguration, GatewayListener listener) throws
            InitializationException;
}
