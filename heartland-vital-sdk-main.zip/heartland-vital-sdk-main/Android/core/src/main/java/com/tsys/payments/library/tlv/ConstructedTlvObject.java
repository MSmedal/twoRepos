package com.tsys.payments.library.tlv;

import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Represents a {@link TlvObject} made up of manny {@link TlvObject}s.
 * <p>
 * Can contain both primitive {@link TlvObject}s and {@link ConstructedTlvObject}s.
 */
public class ConstructedTlvObject {
    public static final String TAG = ConstructedTlvObject.class.getSimpleName();

    private List<TlvObject> mTlvList;

    public ConstructedTlvObject() {
        mTlvList = new ArrayList<>();
    }

    public void addTlv(TlvObject tlv) {
        if (mTlvList == null) {
            mTlvList = new ArrayList<>();
        }
        mTlvList.add(tlv);
    }

    public void removeTlv(TlvObject tlv) {
        if (mTlvList == null) {
            return;
        }
        mTlvList.remove(tlv);
    }

    public void setTlvList(List<TlvObject> tlvList) {
        mTlvList = tlvList;
    }

    public List<TlvObject> getTlvList() {
        return mTlvList;
    }

    public TlvObject find(EmvTagDescriptor emvTagDescriptor) {
        if (mTlvList != null && mTlvList.size() > 0) {
            for (TlvObject tlv : mTlvList) {
                TlvObject tlvResult = tlv.find(emvTagDescriptor);
                if (tlvResult != null) {
                    return tlvResult;
                }
            }
        }
        return null;
    }

    public TlvObject find(Tag tag) {
        if (mTlvList != null && mTlvList.size() > 0) {
            for (TlvObject tlv : mTlvList) {
                TlvObject tlvResult = tlv.find(tag);
                if (tlvResult != null) {
                    return tlvResult;
                }
            }
        }
        return null;
    }

    public static List<TlvObject> parse(String hexString) {
        byte[] data = TlvUtils.hexStringToByteArray(hexString);
        return parse(data, 0, data.length);
    }

    public static List<TlvObject> parse(final byte[] source, int start, int end) {
        try {
            List<TlvObject> berList = new ArrayList<>();
            int index = start;
            while (index < end) {
                Tag tag;

                tag = new Tag(source, index);
                index += tag.getTagLength();

                Length length = Length.decodeLength(source, index);
                index += length.getNumOfBytesToEncodedLength();

                TlvObjectBuilder tlvBuilder = TlvObjectBuilder.create(tag);

                if (tag.isConstructed()) {
                    //Let recursion do the job
                    tlvBuilder.setInnerTlvList(parse(source, index, index + length.getLength()));
                } else {
                    tlvBuilder.setValue(Arrays.copyOfRange(source, index, index + length.getLength()));
                }

                berList.add(tlvBuilder.build());
                index += length.getLength();
            }
            return berList;
        } catch (Exception e) {
            Log.e(TAG, "parse: " + e.getMessage(), e);
            return null;
        }
    }

    public static List<TlvObject> getAllPrimitiveTagAsList(List<TlvObject> tlvObjectList) {
        List<TlvObject> list = new ArrayList<>();
        for (TlvObject tlv : tlvObjectList) {
            list.addAll(getAllPrimitiveTagAsList(tlv));
        }
        return list;
    }

    public static List<TlvObject> getAllPrimitiveTagAsList(TlvObject tlv) {
        List<TlvObject> list = new ArrayList<>();
        if (tlv.isConstructed()) {
            list.addAll(getAllPrimitiveTagAsList(tlv.getInnerTlvs()));
        } else {
            list.add(tlv);
        }
        return list;
    }

    public static HashMap<EmvTagDescriptor, byte[]> getAllPrimitiveTagAsMap(List<TlvObject> tlvObjectList) {
        HashMap<EmvTagDescriptor, byte[]> mapResult = new LinkedHashMap<>();
        for (TlvObject tlv : tlvObjectList) {
            mapResult.putAll(getAllPrimitiveTagAsMap(tlv));
        }
        return mapResult;
    }

    public static HashMap<EmvTagDescriptor, byte[]> getAllPrimitiveTagAsMap(TlvObject tlv) {
        HashMap<EmvTagDescriptor, byte[]> mapResult = new LinkedHashMap<>();
        if (tlv.isConstructed()) {
            mapResult.putAll(getAllPrimitiveTagAsMap(tlv.getInnerTlvs()));
        } else {
            mapResult.put(tlv.getTagDescriptor(), tlv.getValue());
        }
        return mapResult;
    }
}
