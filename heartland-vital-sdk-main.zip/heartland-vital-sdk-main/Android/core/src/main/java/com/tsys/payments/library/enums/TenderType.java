package com.tsys.payments.library.enums;

/**
 * Forms of tender accepted by the payment library.
 */
public enum TenderType {

    CREDIT,

    DEBIT

}
