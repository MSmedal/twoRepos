package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.TerminalType;

import androidx.annotation.Nullable;

import java.util.Objects;

/**
 * Represents detailed information for a specific terminal.
 */
public class TerminalInfo {

    @Nullable
    private TerminalType mTerminalType;
    @Nullable
    private String mSerialNumber;
    @Nullable
    private String mAppName;
    @Nullable
    private String mAppVersion;
    @Nullable
    private String mFirmwareVersion;
    @Nullable
    private String mModel;
    @Nullable
    private String mManufacturer;
    @Nullable
    private String mKernelVersion;

    @Nullable
    private Integer mBatteryLevel;

    public TerminalType getTerminalType() {
        return mTerminalType;
    }

    public void setTerminalType(TerminalType terminalType) {
        mTerminalType = terminalType;
    }

    public String getSerialNumber() {
        return mSerialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        mSerialNumber = serialNumber;
    }

    public String getAppName() {
        return mAppName;
    }

    public void setAppName(String appName) {
        mAppName = appName;
    }

    public String getAppVersion() {
        return mAppVersion;
    }

    public void setAppVersion(String appVersion) {
        mAppVersion = appVersion;
    }

    @Nullable
    public Integer getBatteryLevel() {
        return mBatteryLevel;
    }

    public void setBatteryLevel(@Nullable Integer batteryLevel) {
        mBatteryLevel = batteryLevel;
    }

    public String getFirmwareVersion() {
        return mFirmwareVersion;
    }

    public void setFirmwareVersion(String firmwareVersion) {
        mFirmwareVersion = firmwareVersion;
    }

    @Nullable
    public String getModel() {
        return mModel;
    }

    public void setModel(@Nullable String model) {
        mModel = model;
    }

    @Nullable
    public String getManufacturer() {
        return mManufacturer;
    }

    public void setManufacturer(@Nullable String manufacturer) {
        mManufacturer = manufacturer;
    }

    @Nullable
    public String getKernelVersion() {
        return mKernelVersion;
    }

    public void setKernelVersion(@Nullable String kernelVersion) {
        mKernelVersion = kernelVersion;
    }

    @Override
    public String toString() {
        return "TerminalInfo{" +
                "mTerminalType=" + mTerminalType +
                ", mSerialNumber='" + mSerialNumber + '\'' +
                ", mAppName='" + mAppName + '\'' +
                ", mAppVersion='" + mAppVersion + '\'' +
                ", mFirmwareVersion='" + mFirmwareVersion + '\'' +
                ", mModel='" + mModel + '\'' +
                ", mManufacturer='" + mManufacturer + '\'' +
                ", mKernelVersion=" + mKernelVersion + '\'' +
                ", mBatteryLevel=" + mBatteryLevel +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TerminalInfo that = (TerminalInfo)o;
        return mTerminalType == that.mTerminalType && Objects.equals(mSerialNumber, that.mSerialNumber) &&
                Objects.equals(mAppName, that.mAppName) &&
                Objects.equals(mAppVersion, that.mAppVersion) &&
                Objects.equals(mFirmwareVersion, that.mFirmwareVersion) &&
                Objects.equals(mModel, that.mModel) &&
                Objects.equals(mManufacturer, that.mManufacturer) &&
                Objects.equals(mKernelVersion, that.mKernelVersion) &&
                Objects.equals(mBatteryLevel, that.mBatteryLevel);
    }

    @Override
    public int hashCode() {
        return Objects
                .hash(mTerminalType, mSerialNumber, mAppName, mAppVersion, mFirmwareVersion,
                        mModel, mManufacturer, mKernelVersion, mBatteryLevel);
    }
}
