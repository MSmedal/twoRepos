package com.tsys.payments.library.tlv;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class TlvObjectBuilder {

    private final Tag mTemplate;
    private TlvObject mTlv;

    private TlvObjectBuilder(@NonNull Tag template) {
        mTemplate = template;
    }

    private TlvObjectBuilder(byte[] tagBytes) {
        mTemplate = new Tag(tagBytes, 0, tagBytes.length);
    }

    public static TlvObjectBuilder create(Tag template) {
        return new TlvObjectBuilder(template);
    }

    public static TlvObjectBuilder create(byte[] tagBytes) {
        return new TlvObjectBuilder(tagBytes);
    }

    public static TlvObjectBuilder create(EmvTagDescriptor emvTagDescriptor) {
        return new TlvObjectBuilder(Tag.fromTagDescriptor(emvTagDescriptor));
    }

    public TlvObjectBuilder setValue(byte[] value) {
        mTlv = new TlvObject(mTemplate, value);
        return this;
    }

    public TlvObjectBuilder setValue(byte b) {
        mTlv = new TlvObject(mTemplate, b);
        return this;
    }

    public TlvObjectBuilder addInnerTlv(TlvObject innerTlv) {
        if (mTlv == null) {
            List<TlvObject> subTlvs = new ArrayList<>();
            mTlv = new TlvObject(mTemplate, subTlvs);
        }
        mTlv.addTlv(innerTlv);
        return this;
    }

    public TlvObjectBuilder setInnerTlvList(List<TlvObject> innerTlvList) {
        mTlv = new TlvObject(mTemplate, innerTlvList);
        return this;
    }

    public TlvObject build() {
        return mTlv;
    }
}
