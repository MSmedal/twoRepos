package com.tsys.payments.library.gateway.enums;

/**
 * Common operations that may be supported by host implementations.
 */
public enum GatewayAction {
    AUTHENTICATE,
    SALE,
    TIP_ADJUST,
    AUTH,
    CAPTURE,
    REFUND,
    PARTIAL_REFUND,
    VOID,
    FORCE_AUTH,
    BALANCE_INQUIRY,
    TOKENIZE_CARD,
    TRANSACTION_ADJUSTMENT,
    BATCH_CLOSE,
    VERIFY
}
