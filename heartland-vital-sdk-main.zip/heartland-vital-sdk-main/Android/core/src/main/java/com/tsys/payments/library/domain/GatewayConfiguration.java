package com.tsys.payments.library.domain;

import com.tsys.payments.library.gateway.enums.GatewayType;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class GatewayConfiguration {

    @SuppressWarnings("WeakerAccess")
    public static final long DEFAULT_GATEWAY_TIMEOUT = TimeUnit.SECONDS.toMillis(90);
    @SuppressWarnings("WeakerAccess")
    public static final int DEFAULT_MAX_RETRY_ATTEMPTS = 3;

    private Map<String, String> mCredentials;
    private GatewayType mGatewayType;
    private String mPosAppName;
    private String mPosAppVersion;
    private long mGatewayTimeout = DEFAULT_GATEWAY_TIMEOUT;
    private int mMaxRetryAttempts = DEFAULT_MAX_RETRY_ATTEMPTS;

    public Map<String, String> getCredentials() {
        return mCredentials;
    }

    public void setCredentials(Map<String, String> credentials) {
        mCredentials = credentials;
    }

    public String getPosAppName() {
        return mPosAppName;
    }

    public void setPosAppName(String posAppName) {
        mPosAppName = posAppName;
    }

    public String getPosAppVersion() {
        return mPosAppVersion;
    }

    public void setPosAppVersion(String posAppVersion) {
        mPosAppVersion = posAppVersion;
    }

    /**
     * @return Time to wait, in seconds, for a response from the host before a timeout is raised.
     */
    public long getGatewayTimeout() {
        return mGatewayTimeout;
    }

    /**
     * Optional. If not set {@link #DEFAULT_GATEWAY_TIMEOUT} will be used.
     *
     * @param gatewayTimeout Time to wait, in seconds, for a response from the host before a timeout is
     * raised.
     */
    public void setGatewayTimeout(long gatewayTimeout) {
        mGatewayTimeout = gatewayTimeout;
    }

    public int getMaxRetryAttempts() {
        return mMaxRetryAttempts;
    }

    public void setMaxRetryAttempts(int maxRetryAttempts) {
        mMaxRetryAttempts = maxRetryAttempts;
    }

    public GatewayType getGatewayType() {
        return mGatewayType;
    }

    public void setGatewayType(GatewayType gatewayType) {
        mGatewayType = gatewayType;
    }

    @Override
    public String toString() {
        return "GatewayConfiguration{" +
                "mCredentials=" + mCredentials +
                ", mGatewayType=" + mGatewayType +
                ", mPosAppName='" + mPosAppName + '\'' +
                ", mPosAppVersion='" + mPosAppVersion + '\'' +
                ", mGatewayTimeout=" + mGatewayTimeout +
                ", mMaxRetryAttempts=" + mMaxRetryAttempts +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GatewayConfiguration)) return false;
        GatewayConfiguration that = (GatewayConfiguration)o;
        return mGatewayTimeout == that.mGatewayTimeout &&
                mMaxRetryAttempts == that.mMaxRetryAttempts &&
                Objects.equals(mCredentials, that.mCredentials) &&
                mGatewayType == that.mGatewayType &&
                Objects.equals(mPosAppName, that.mPosAppName) &&
                Objects.equals(mPosAppVersion, that.mPosAppVersion);
    }

    @Override
    public int hashCode() {

        return Objects
                .hash(mCredentials, mGatewayType, mPosAppName, mPosAppVersion, mGatewayTimeout, mMaxRetryAttempts);
    }
}
