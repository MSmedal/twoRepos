package com.tsys.payments.library.exceptions;

public class InitializationException extends Exception {

    public InitializationException(String message, Object... args) {
        super(String.format(message, args));
    }

    public InitializationException(Throwable cause, String message, Object... args) {
        super(String.format(message, args), cause);
    }
}
