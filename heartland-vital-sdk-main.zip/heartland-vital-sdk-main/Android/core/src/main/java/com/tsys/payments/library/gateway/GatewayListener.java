package com.tsys.payments.library.gateway;

import com.tsys.payments.library.gateway.domain.GatewayResponse;

/**
 * Internal listener interface used to receive host results.
 */
public interface GatewayListener {

    /**
     * Invoked when a response or error is received from host.
     *
     * @param gatewayResponse {@link GatewayResponse} received.
     */
    void onGatewayResponse(GatewayResponse gatewayResponse);
}
