package com.tsys.payments.library.terminal;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.CardholderInteractionResult;
import com.tsys.payments.library.enums.TerminalSettingType;
import com.tsys.payments.library.enums.TerminalUpdateType;
import com.tsys.payments.library.terminal.domain.TerminalInteractionRequest;
import com.tsys.payments.library.terminal.domain.TerminalInteractionResult;
import com.tsys.payments.library.terminal.domain.TerminalRequest;
import com.tsys.payments.library.terminal.domain.TerminalResponse;
import com.tsys.payments.library.terminal.enums.TerminalStatus;

import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public interface TerminalController {

    /**
     * Attempts to connect to the configured terminal.
     */
    void connect();

    /**
     * @param terminalRequest {@link TerminalRequest} containing details of the transaction being processed.
     */
    void sendRequest(TerminalRequest terminalRequest);

    /**
     * Called in response to {@link TerminalListener#onTerminalInteractionRequested(TerminalInteractionRequest)} after
     * the cardholder has made their selection.
     *
     * @param terminalInteractionResult {@link CardholderInteractionResult} with details of the cardholders selection.
     */
    void sendTerminalInteractionResult(TerminalInteractionResult terminalInteractionResult);

    /**
     * Attempts to cancel the current transaction. If the terminal is busy processing another command, {@link
     * TerminalListener#onTerminalStatusUpdate(TerminalStatus)} will broadcast the {@link TerminalStatus#DEVICE_BUSY}
     * status update. If the terminal is not busy, a command will be issued to stop the current transaction. An
     * appropriate response will be broadcast in {@link TerminalListener#onTerminalResponseReceived(TerminalResponse)}
     * indicating that the transaction was cancelled.
     */
    void cancel();

    /**
     * Attempts to disconnect from the configured terminal.
     */
    void disconnect();

    /**
     * Update terminal settings for a connected terminal
     *
     * @param terminalSettingsType new settings type
     * @param terminalSettingsValue new settings values
     * @param terminalUpdateSettingListener callback for reporting the results
     */
    void updateTerminalSetting(TerminalSettingType terminalSettingsType, String terminalSettingsValue,
            TerminalUpdateSettingListener terminalUpdateSettingListener);

    /**
     * Read terminal settings for a connected terminal.
     *
     * @param terminalSettingsType setting type to be queried
     * @param terminalReadSettingListener callback for reporting the results
     */
    void readTerminalSetting(TerminalSettingType terminalSettingsType,
            TerminalReadSettingListener terminalReadSettingListener);

    /**
     * Get available terminal versions for a connected terminal.
     *
     * @param terminalUpdateType type to be updated
     * @param credentials {@link Map} containing any credentials needed for authentication for the terminal *
     * version access to succeed.
     * @param availableVersionsListener callback for reporting available terminal versions
     */
    void getAvailableTerminalVersions(@NonNull TerminalUpdateType terminalUpdateType,
            @Nullable Map<String, String> credentials,
            @NonNull AvailableVersionsListener availableVersionsListener);

    /**
     * Updates connected terminal software.
     *
     * @param terminalUpdateType type to be updated
     * @param version Represents the version to update to. If missing, logic must be implemented in the {@link
     * TerminalController} implementation to determine the update version or an error should be returned.
     * @param credentials {@link Map} containing any credentials needed for authentication for the terminal update to
     * succeed.
     * @param updateListener callback for reporting the update result
     */
    void updateTerminal(@NonNull TerminalUpdateType terminalUpdateType, @Nullable Map<String, String> credentials,
            @Nullable String version,
            @NonNull UpdateListener updateListener);

    void setCardData(@NonNull CardData cardData);
}
