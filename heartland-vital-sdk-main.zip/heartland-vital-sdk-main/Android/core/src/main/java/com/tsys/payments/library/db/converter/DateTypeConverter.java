package com.tsys.payments.library.db.converter;

import androidx.room.TypeConverter;

import java.util.Date;

public class DateTypeConverter {
    @TypeConverter
    public static Date toDate(long epoch) {
        return new Date(epoch);
    }

    @TypeConverter
    public static Long toLong(Date date) {
        if (date != null) {
            return date.getTime();
        } else {
            return null;
        }
    }
}
