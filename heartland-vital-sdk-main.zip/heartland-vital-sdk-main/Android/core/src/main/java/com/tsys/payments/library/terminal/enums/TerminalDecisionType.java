package com.tsys.payments.library.terminal.enums;

public enum TerminalDecisionType {

    /**
     * The transaction was approved by the host and the terminal.
     */
    APPROVED_ONLINE,

    /**
     * The transaction was approved offline by the terminal without host processing.
     */
    APPROVED_OFFLINE,

    /**
     * The transaction was declined online by the host.
     */
    DECLINED_ONLINE,

    /**
     * The transaction was declined offline by the terminal or chip.
     */
    DECLINED_OFFLINE,

    /**
     * The transaction was declined by the terminal or chip after being approved by the host.
     * <p>
     * In these scenarios a reversal should be performed on the host approved transaction ID.
     */
    REVERSAL_REQUIRED,

    /**
     * The transaction was cancelled either by the consumer or the merchant.
     */
    TRANSACTION_CANCELLED,

    /**
     * A host response was never received.
     * <p>
     * The transaction should be treated as a decline.
     */
    HOST_UNREACHABLE,

}
