package com.tsys.payments.library.enums;

public enum HttpStatusCode {
    OK(200),
    CREATED(201),
    ACCEPTED(202),
    NOT_MODIFIED(304),
    BAD_REQUEST(400),
    UNAUTHORIZED(401),
    PAYMENT_REQUIRED(402),
    FORBIDDEN(403),
    NOT_FOUND(404),
    METHOD_NOT_ALLOWED(405),
    CONFLICT(409),
    INTERNAL_SERVER_ERROR(500),
    NOT_IMPLEMENTED(501);

    public int key;

    HttpStatusCode(int key) {
        this.key = key;
    }

    public static HttpStatusCode fromKey(int key) {
        for (HttpStatusCode type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
