package com.tsys.payments.library.utils;

import android.text.TextUtils;
import android.util.SparseArray;

import androidx.annotation.Nullable;

import java.io.UnsupportedEncodingException;

public class ByteUtils {
    public static final String TAG = ByteUtils.class.getSimpleName();

    private static SparseArray<String> sControlCharacters = new SparseArray<>();
    private static final String REGEX_HEX_STRING = "^[0-9A-Fa-f]+$";

    private ByteUtils() {
        sControlCharacters.append(0x02, "STX");
        sControlCharacters.append(0x03, "ETX");
        sControlCharacters.append(0x06, "ACK");
        sControlCharacters.append(0x15, "NAK");
        sControlCharacters.append(0x1C, "FS");
        sControlCharacters.append(0x1A, "SUB");
        sControlCharacters.append(0x1E, "RS");
        sControlCharacters.append(0x04, "EOT");
        sControlCharacters.append(0x10, "DLE");
    }

    public static String bytesToHex(byte[] in, int len) {
        final StringBuilder builder = new StringBuilder();
        for (int i = 0; i < len; i++) {
            if (in[i] > 0x20 && in[i] <= 0x7F) {
                builder.append(
                        sControlCharacters.get(in[i], String.format("%c (%02x)", in[i], in[i])))
                        .append(" ");
            } else {
                builder.append(sControlCharacters.get(in[i], String.format("(%02x)", in[i])))
                        .append(" ");
            }
        }
        return builder.toString();
    }

    public static String bytesToHex(final byte[] array, boolean addSpaces) {
        if (array == null) return null;
        return bytesToHex(array, 0, array.length, addSpaces);
    }

    public static String bytesToHex(final byte[] array, final int offset, final int length,
            boolean addSpaces) {
        if (array == null) return null;

        final StringBuilder hexString = new StringBuilder();
        for (int i = 0; i < length; i++) {
            final String hex = Integer.toHexString(0xFF & array[i + offset]);
            if (hex.length() == 1) {
                hexString.append("0");
            }
            hexString.append(hex);
            if (addSpaces) {
                hexString.append(" ");
            }
        }
        return hexString.toString().toUpperCase();
    }

    public static boolean isHexString(@Nullable String value) {
        if (!TextUtils.isEmpty(value)) {
            return value.matches(REGEX_HEX_STRING);
        }

        return false;
    }

    /**
     * Convert hex string to short array.
     */
    public static short[] hexStringToShortArray(@Nullable final String input) {
        if (TextUtils.isEmpty(input)) {
            return null;
        }

        byte[] bytes = input.getBytes();

        short[] result = new short[bytes.length / 2];
        int j = 0;
        for (int i = 0; i < bytes.length; j++) {
            // combine the two nibbles (hex characters) into one byte
            byte b = (byte)((Character.digit(input.charAt(i++), 16) << 4) + Character.digit(
                    input.charAt(i++), 16));

            // convert the byte to an int (because java doesn't have the concept
            // of 'unsigned' byte
            result[j] = (short)(b & 0xFF);
        }

        return result;
    }

    public static String bytesToUtf8String(byte[] bytes) {
        try {
            return new String(bytes, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String bytesToHex(byte b) {
        return bytesToHex(new byte[] {b}, false);
    }

    @Nullable
    public static byte[] hexStringToByteArray(@Nullable String hex) {
        if (hex == null) return null;

        if (hex.startsWith("0x") || hex.startsWith("0X")) {
            hex = hex.substring(2);
        }
        int len = hex.length();
        if (len == 0 || hex.isEmpty() || len % 2 != 0) return null;

        final byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte)((Character.digit(hex.charAt(i), 16) << 4) +
                    Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}
