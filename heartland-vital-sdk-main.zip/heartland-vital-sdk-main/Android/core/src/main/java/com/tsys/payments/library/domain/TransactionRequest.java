package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.TaxCategory;
import com.tsys.payments.library.enums.TaxIndicator;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.enums.TransactionType;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Arrays;
import java.util.Objects;

/**
 * Simple class representing elements needed to authorize a payment.
 */
public class TransactionRequest {

    private TenderType mTenderType;
    private TransactionType mTransactionType;
    private CardData mKeyedCardData;
    private Long mTotal;
    private Long mTax;
    private Long mRefundTax;
    private Long mTip;
    private Long mRefundTip;
    private Long mCashBack;
    private Long mSurcharge;
    private String mGatewayTransactionId;
    private String mPosReferenceNumber;
    private String mForcedAuthCode;
    private String mInvoiceNumber;
    private Address mAddress;
    private String mEmailAddress;

    private TaxIndicator mTaxIndicator;
    private TaxCategory mTaxCategory;

    private String mOperatingUserId;
    private boolean mGenerateToken;
    private String mToken;
    private String mCardBrandTxnId;
    private String mCardHolderId;
    private boolean mSaf;
    private boolean mNetworkUnavailable;
    private boolean mAllowDuplicates;

    private AutoSubstantiation mAutoSubstantiation;

    private int[] mSignatureBitmap;

    /**
     * @return {@link TenderType} selected for this transaction.
     */
    public TenderType getTenderType() {
        return mTenderType;
    }

    /**
     * @param tenderType {@link TenderType} selected for this transaction.
     */
    public void setTenderType(TenderType tenderType) {
        mTenderType = tenderType;
    }

    public TransactionType getTransactionType() {
        return mTransactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        mTransactionType = transactionType;
    }

    public CardData getKeyedCardData() {
        return mKeyedCardData;
    }

    public void setKeyedCardData(CardData keyedCardData) {
        mKeyedCardData = keyedCardData;
    }

    /**
     * @return Total amount to be charged for this transaction, less any cash back amount. This
     * value may be null for contactless pre-tap transactions if the transaction amount is not known
     * at the beginning of the transaction.
     */
    @Nullable
    public Long getTotal() {
        return mTotal;
    }

    /**
     * Required.
     * <p>
     * This should be equal to the sum of Subtotal + Tax + Gratuity + Fee + ServiceCharge.
     *
     * @param total Total amount to be charged for this transaction, less any cash back amount.
     */
    public void setTotal(long total) {
        mTotal = total;
    }

    /**
     * @return Tax amount being applied to the subtotal.
     */
    public Long getTax() {
        return mTax;
    }

    /**
     * Optional.
     *
     * @param tax Tax amount being applied to the subtotal.
     */
    public void setTax(@Nullable Long tax) {
        mTax = tax;
    }

    /**
     * @return Tax amount being applied to open amount refund request.
     */
    public Long getRefundTax() {
        return mRefundTax;
    }

    /**
     * Optional.
     *
     * @param refundTax Tax amount being applied to open amount refund request.
     */
    public void setRefundTax(@Nullable Long refundTax) {
        mRefundTax = refundTax;
    }

    /**
     * @return Gratuity amount to apply on top of the subtotal and taxes.
     */
    public Long getTip() {
        return mTip;
    }

    /**
     * Optional.
     *
     * @param tip Gratuity amount to apply on top of the subtotal and taxes.
     */
    public void setTip(@Nullable Long tip) {
        mTip = tip;
    }

    /**
     * @return Gratuity amount to apply to open amount refund request.
     */
    public Long getRefundTip() {
        return mRefundTip;
    }

    /**
     * Optional.
     *
     * @param refundTip Gratuity amount to apply to open amount refund request.
     */
    public void setRefundTip(@Nullable Long refundTip) {
        mRefundTip = refundTip;
    }

    /**
     * @return Amount of cash requested back, irrespective of the total amount.
     */
    public Long getCashBack() {
        return mCashBack;
    }

    /**
     * Optional.
     *
     * @param cashBack Amount of cash requested back, irrespective of the total amount.
     */
    public void setCashBack(@Nullable Long cashBack) {
        mCashBack = cashBack;
    }

    public Long getSurcharge() {
        return mSurcharge;
    }

    public void setSurcharge(@Nullable Long surcharge) {
        mSurcharge = surcharge;
    }

    /**
     * @return Reference number for the transaction that a host can uniquely distinguish.
     */
    public String getGatewayTransactionId() {
        return mGatewayTransactionId;
    }

    /**
     * Conditional based on the {@link TransactionType}.
     * <p>
     * <ul>
     * <li>{@link TransactionType#SALE} - Not used.</li>
     * <li>{@link TransactionType#AUTH} - Not used.</li>
     * <li>{@link TransactionType#CAPTURE} - Required.</li>
     * <li>{@link TransactionType#VOID} - Required. </li>
     * <li>{@link TransactionType#REFUND} - Required.</li>
     * <li>{@link TransactionType#TIP_ADJUST} - Required.</li>
     * </ul>
     *
     * @param gatewayTransactionId Host transaction ID from a successful transaction.
     * @see TransactionResponse#getGatewayTransactionId()
     */
    public void setGatewayTransactionId(@Nullable String gatewayTransactionId) {
        mGatewayTransactionId = gatewayTransactionId;
    }

    /**
     * @return Identifier provided by the consuming POS.
     */
    public String getPosReferenceNumber() {
        return mPosReferenceNumber;
    }

    /**
     * Optional. If provided this value will be echoed back in the {@link TransactionResponse}
     *
     * @param posReferenceNumber Identifier provided by the consuming POS.
     */
    public void setPosReferenceNumber(@Nullable String posReferenceNumber) {
        mPosReferenceNumber = posReferenceNumber;
    }

    public String getForcedAuthCode() {
        return mForcedAuthCode;
    }

    public void setForcedAuthCode(String forcedAuthCode) {
        mForcedAuthCode = forcedAuthCode;
    }

    /**
     * @return {@link #mInvoiceNumber} to the gateway for host processing.
     */
    public String getInvoiceNumber() {
        return mInvoiceNumber;
    }

    /**
     * As part of an interchange requirement,
     *
     * @param invoiceNumber allows a merchant to receive the best possible rate for processing a
     * transaction.
     */
    public void setInvoiceNumber(String invoiceNumber) {
        mInvoiceNumber = invoiceNumber;
    }

    /**
     * @return {@link TaxIndicator} specifying the type of tax provided for the payment SDK,
     */
    public TaxIndicator getTaxIndicator() {
        return mTaxIndicator;
    }

    /**
     * Set the type of tax mode that the payment SDK should use for the tax applied to this
     * request.
     *
     * @param taxIndicator {@link TaxIndicator} provided by the consuming POS.
     */
    public void setTaxIndicator(TaxIndicator taxIndicator) {
        mTaxIndicator = taxIndicator;
    }

    public TaxCategory getTaxCategory() {
        return mTaxCategory;
    }

    public void setTaxCategory(TaxCategory taxCategory) {
        mTaxCategory = taxCategory;
    }

    /**
     * @return {@link String} specifying the id of the user performing actions in the consuming POS.
     */
    public String getOperatingUserId() {
        return mOperatingUserId;
    }

    /**
     * Set the id of the user performing actions in the consuming POS. Required when {@link
     * TransactionType#BATCH_CLOSE} is being processed.
     *
     * @param operatingUserId {@link String} provided by the consuming POS.
     */
    public void setOperatingUserId(String operatingUserId) {
        mOperatingUserId = operatingUserId;
    }

    public boolean isGenerateToken() {
        return mGenerateToken;
    }

    /**
     * @param generateToken Indicates to the host that a token must be generated for the current
     * payment transaction
     */
    public void setGenerateToken(boolean generateToken) {
        mGenerateToken = generateToken;
    }

    public String getToken() {
        return mToken;
    }

    /**
     * @param token Represents a value that can be used as a substitute to payment card data for
     * processing transactions. see {@link TransactionResponse.Builder#setToken(String)}
     */
    public void setToken(@NonNull String token) {
        mToken = token;
    }

    public String getCardBrandTxnId() {
        return mCardBrandTxnId;
    }

    public void setCardBrandTxnId(@NonNull String cardBrandTxnId) {
        mCardBrandTxnId = cardBrandTxnId;
    }

    public String getCardHolderId() {
        return mCardHolderId;
    }

    /**
     * @param cardHolderId Represents a value that can be used as a substitute to payment card data
     * for processing transactions. see {@link TransactionResponse.Builder#setCardHolderId(String)}
     */
    public void setCardHolderId(@NonNull String cardHolderId) {
        mCardHolderId = cardHolderId;
    }

    /**
     * @return {@link Address} for address details independent of card data
     */
    public Address getAddress() {
        return mAddress;
    }

    /**
     * @param address information provided by consumer
     */
    public void setAddress(Address address) {
        mAddress = address;
    }

    /**
     * @return boolean if transaction should be saved to local database as store and forward (SAF)
     * transaction if device is offline and processed later when connectivity is established
     */
    public boolean isSaf() {
        return mSaf;
    }

    /**
     * @param saf Indicates to {@link com.tsys.payments.library.transaction.ITransactionManager} if
     * transaction should be saved to database as store and forward (SAF) transaction and
     * processed later when connectivity is established
     */
    public void setSaf(boolean saf) {
        mSaf = saf;
    }

    public String getEmailAddress() {
        return mEmailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        mEmailAddress = emailAddress;
    }

    /**
     * Returns the integer representing the pixels in a {@link android.graphics.Bitmap} that stores
     * the customer's signature.
     *
     * @return Array of bitmap values representing the signature image.
     */
    public int[] getSignatureBitmap() {
        return mSignatureBitmap;
    }

    /**
     * Set the array of values representing the pixels in a {@link android.graphics.Bitmap} that
     * stores the customer's signature.
     *
     * @param signatureBitmap Array of integer-encoded pixels representing the signature image.
     */
    public void setSignatureBitmap(int[] signatureBitmap) {
        mSignatureBitmap = signatureBitmap;
    }

    /**
     * @return True if there is no network connectivity to process this request if the request
     * requires interaction with a payment gateway.
     */
    public boolean isNetworkUnavailable() {
        return mNetworkUnavailable;
    }

    /**
     * Set by the payment application to indicate that there is no network connectivity.
     *
     * @param networkUnavailable Set to true when network is unavailable.
     */
    public void setNetworkUnavailable(boolean networkUnavailable) {
        mNetworkUnavailable = networkUnavailable;
    }

    public boolean isAllowDuplicates() {
        return mAllowDuplicates;
    }

    public void setAllowDuplicates(boolean allowDuplicates) {
        mAllowDuplicates = allowDuplicates;
    }

    public void setAutoSubstantiation(AutoSubstantiation autoSubstantiation) {
        mAutoSubstantiation = autoSubstantiation;
    }

    public AutoSubstantiation getAutoSubstantiation() {
        return mAutoSubstantiation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransactionRequest that = (TransactionRequest)o;
        return mGenerateToken == that.mGenerateToken &&
                mSaf == that.mSaf &&
                mNetworkUnavailable == that.mNetworkUnavailable &&
                mTenderType == that.mTenderType &&
                mTransactionType == that.mTransactionType &&
                Objects.equals(mKeyedCardData, that.mKeyedCardData) &&
                Objects.equals(mTotal, that.mTotal) &&
                Objects.equals(mTax, that.mTax) &&
                Objects.equals(mRefundTax, that.mRefundTax) &&
                Objects.equals(mTip, that.mTip) &&
                Objects.equals(mRefundTip, that.mRefundTip) &&
                Objects.equals(mCashBack, that.mCashBack) &&
                Objects.equals(mSurcharge, that.mSurcharge) &&
                Objects.equals(mGatewayTransactionId, that.mGatewayTransactionId) &&
                Objects.equals(mPosReferenceNumber, that.mPosReferenceNumber) &&
                Objects.equals(mForcedAuthCode, that.mForcedAuthCode) &&
                Objects.equals(mInvoiceNumber, that.mInvoiceNumber) &&
                Objects.equals(mAddress, that.mAddress) &&
                Objects.equals(mEmailAddress, that.mEmailAddress) &&
                mTaxIndicator == that.mTaxIndicator &&
                mTaxCategory == that.mTaxCategory &&
                Objects.equals(mOperatingUserId, that.mOperatingUserId) &&
                Objects.equals(mToken, that.mToken) &&
                Objects.equals(mCardHolderId, that.mCardHolderId) &&
                Objects.equals(mAutoSubstantiation, that.mAutoSubstantiation) &&
                Arrays.equals(mSignatureBitmap, that.mSignatureBitmap);
    }

    @Override
    public int hashCode() {
        int result =
                Objects.hash(mTenderType, mTransactionType, mKeyedCardData, mTotal, mTax,
                        mRefundTax,
                        mTip, mRefundTip, mCashBack, mSurcharge, mGatewayTransactionId,
                        mPosReferenceNumber, mForcedAuthCode, mInvoiceNumber, mAddress,
                        mEmailAddress,
                        mTaxIndicator, mTaxCategory, mOperatingUserId, mGenerateToken, mToken,
                        mCardHolderId, mSaf, mAutoSubstantiation, mNetworkUnavailable);
        result = 31 * result + Arrays.hashCode(mSignatureBitmap);
        return result;
    }

    @Override
    public String toString() {
        return "TransactionRequest{" +
                "mTenderType=" + mTenderType +
                ", mTransactionType=" + mTransactionType +
                ", mKeyedCardData=" + mKeyedCardData +
                ", mTotal=" + mTotal +
                ", mTax=" + mTax +
                ", mRefundTax=" + mRefundTax +
                ", mTip=" + mTip +
                ", mRefundTip=" + mRefundTip +
                ", mCashBack=" + mCashBack +
                ", mSurcharge=" + mSurcharge +
                ", mGatewayTransactionId='" + mGatewayTransactionId + '\'' +
                ", mPosReferenceNumber='" + mPosReferenceNumber + '\'' +
                ", mForcedAuthCode='" + mForcedAuthCode + '\'' +
                ", mInvoiceNumber='" + mInvoiceNumber + '\'' +
                ", mAddress=" + mAddress +
                ", mEmailAddress='" + mEmailAddress + '\'' +
                ", mTaxIndicator=" + mTaxIndicator +
                ", mTaxCategory=" + mTaxCategory +
                ", mOperatingUserId='" + mOperatingUserId + '\'' +
                ", mGenerateToken=" + mGenerateToken +
                ", mToken='" + mToken + '\'' +
                ", mCardHolderId='" + mCardHolderId + '\'' +
                ", mSaf=" + mSaf +
                ", mNetworkUnavailable=" + mNetworkUnavailable +
                ", mSignatureBitmap=" + Arrays.toString(mSignatureBitmap) +
                ", mAutoSubstantiation=" + mAutoSubstantiation +
                '}';
    }
}
