package com.tsys.payments.library.enums;

public enum TransactionStatus {

    /**
     * The configured terminal is ready for the cardholder to present their card.
     */
    WAITING_FOR_CARD,

    /**
     * The presented card could not be read successfully. The cardholder shall be prompted to
     * present their card again.
     */
    BAD_READ,

    /**
     * A chip was detected on the swiped card. The cardholder shall be prompted to insert their
     * card or present another card.
     */
    ICC_SWIPED,

    /**
     * The chip on a card could not be read successfully after several attempts. The cardholder
     * shall be prompted to swipe their card or present another card.
     */
    FALLBACK_INITIATED,

    /**
     * Multiple cards were detected within the NFC Field. The cardholder should be prompted to
     * present a single card.
     */
    MULTIPLE_CARDS_DETECTED,

    /**
     * Data was successfully captured from a card.
     */
    CARD_READ,

    /**
     * The ICC chip could not be read by the terminal.
     * <p>
     * The cardholder shall be prompted to remove the card and swipe instead of inserting.
     */
    TECHNICAL_FALLBACK_INITIATED,

    /**
     * The terminal is unable to read the card data and the error is irrecoverable. The transaction
     * should be restarted.
     */
    CARD_READ_ERROR,

    /**
     * The terminal detected that the card has been removed after the transaction completed.  The
     * customer-facing display should be updated to reflect this.
     */
    CARD_REMOVED_AFTER_TRANSACTION_COMPLETE,

    /**
     * The terminal has finished processing the contactless card and the customer should be prompted
     * to remove the card from the RFID field.
     */
    CONTACTLESS_CARD_STILL_IN_FIELD,

    /**
     * The terminal is unable to use the RFID field to capture card data. The customer should be
     * prompted to use the contact interface.
     */
    CONTACTLESS_INTERFACE_FAILED_TRY_CONTACT,

    /**
     * Indicates that the contactless card is not accepted. The user should swipe, insert or try
     * another contactless card.
     */
    INSERT_SWIPE_OR_TRY_ANOTHER_CARD,

    /**
     * The cardholder should be prompted to leave the card in the ICC slot or RFID field while
     * processing.
     */
    DO_NOT_REMOVE_CARD,

    /**
     * The cardholder is notified that the current request cannot be fulfilled because the terminal
     * is processing.
     */
    DEVICE_BUSY,

    /**
     * The cardholder should be prompted to enter their PIN.
     */
    ENTER_PIN,

    /**
     * The cardholder should be notified that only one more PIN entry attempt is allowed.
     */
    LAST_PIN_ATTEMPT,

    /**
     * The cardholder should be notified that PIN entry succeeded.
     */
    PIN_ACCEPTED,

    /**
     * The cardholder should be notified that PIN entry failed and should be prompted to try again.
     */
    RETRY_PIN,

    /**
     * The cardholder should be prompted to remove the card.
     */
    REMOVE_CARD,

    /**
     * The cardholder should be prompted to wait while the terminal is being configured.
     */
    CONFIGURING,

    /**
     * The cardholder should be referred to their phone for further instructions.
     */
    SEE_PHONE,

    /**
     * The cardholder should be notified that the transaction is being processed.
     */
    PROCESSING
}