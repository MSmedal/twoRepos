package com.tsys.payments.library.enums;

public enum ConnectionType {
    AUDIO_JACK,
    BLUETOOTH,
    TCP_IP,
    USB
}
