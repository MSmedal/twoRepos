package com.tsys.payments.library.domain;

import android.bluetooth.BluetoothDevice;

import com.tsys.payments.library.connection.LedMobyPairingListener;
import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.TerminalAuthenticationCapability;
import com.tsys.payments.library.enums.TerminalInputCapability;
import com.tsys.payments.library.enums.TerminalOperatingEnvironment;
import com.tsys.payments.library.enums.TerminalOutputCapability;
import com.tsys.payments.library.enums.TerminalType;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Simple class representing configurations that can be applied to a supported payment terminal.
 */
public class TerminalConfiguration {

    /**
     * Lowest number of PIN digits supported by any configuration.
     */
    private static final int MIN_PIN_LENGTH_FLOOR = 4;

    /**
     * Highest number of PIN digits supported by any configuration.
     */
    private static final int MAX_PIN_LENGTH_CEILING = 12;

    private static final int DEFAULT_TIMEOUT = 1000 * 10; // 10 seconds
    private static final int DEFAULT_MIN_PIN_LENGTH = MIN_PIN_LENGTH_FLOOR;
    private static final int DEFAULT_MAX_PIN_LENGTH = MAX_PIN_LENGTH_CEILING;

    private TerminalType mTerminalType;
    private ConnectionType mConnectionType;
    private String mHost;
    private String mOtaServerUrl;
    private Integer mPort;
    private long mTimeout = DEFAULT_TIMEOUT;
    private int mMinPinLength = DEFAULT_MIN_PIN_LENGTH;
    private int mMaxPinLength = DEFAULT_MAX_PIN_LENGTH;
    private Integer mEnergySaverModeDelay;
    private Integer mShutdownDelay;
    private Integer mScreenTurnOffDelay;
    private Boolean mSupportsOtaUpdate;
    private TerminalOperatingEnvironment mOperatingEnvironment;
    private TerminalAuthenticationCapability mAuthenticationCapability;
    private TerminalOutputCapability mOutputCapability;
    private TerminalInputCapability mCapability;
    private LedMobyPairingListener mPairingListener;

    private List<AidConfiguration> mContactAids;
    private List<AidConfiguration> mContactlessAids;
    private Map<String, TerminalActionCodes> mTacMap;
    private List<Capk> mCapks;

    /**
     * @return {@link TerminalType} to use for this transaction.
     */
    public TerminalType getTerminalType() {
        return mTerminalType;
    }

    /**
     * <b>Required</b>
     *
     * @param terminalType {@link TerminalType} to use for this transaction
     */
    public void setTerminalType(@NonNull TerminalType terminalType) {
        mTerminalType = terminalType;
    }

    /**
     * @return {@link ConnectionType} to use when communicating with the selected
     * {@link TerminalType}
     */
    public ConnectionType getConnectionType() {
        return mConnectionType;
    }

    /**
     * <b>Required</b>
     *
     * @param connectionType {@link ConnectionType} to use when communicating with the selected
     * {@link TerminalType}.
     */
    public void setConnectionType(@NonNull ConnectionType connectionType) {
        mConnectionType = connectionType;
    }

    /**
     * @return Address of the {@link TerminalType} to connect to.
     */
    public String getHost() {
        return mHost;
    }

    /**
     * Conditional based on the selected {@link ConnectionType}.
     * <p>
     * <ul>
     * <li>{@link ConnectionType#AUDIO_JACK} - Not Used</li>
     * <li>{@link ConnectionType#BLUETOOTH} - Required. The {@link BluetoothDevice#getAddress()}
     * should be used.</li>
     * <li>{@link ConnectionType#TCP_IP} - Required. The IP Address or resolvable host name should
     * be used.</li>
     * </ul>
     *
     * @param host Address of the {@link TerminalType} to connect to.
     */
    public void setHost(@Nullable String host) {
        mHost = host;
    }

    /**
     @return Server url for performing OTA(Over-the-Air) updates.
     */
    public String getOtaServerUrl() {
        return mOtaServerUrl;
    }

    /**
     * @param otaServerUrl to perform OTA(Over-the-Air) updates to the terminal software
     */
    public void setOtaServerUrl(@Nullable String otaServerUrl) {
        mOtaServerUrl = otaServerUrl;
    }

    /**
     * OTA stands for Over The Air
     * @return whether the OTA update is supported or not for connected terminal.
     */
    public Boolean getSupportsOtaUpdate() {
        return mSupportsOtaUpdate;
    }

    public void setSupportsOtaUpdate(@Nullable Boolean supportsOtaUpdate) {
        mSupportsOtaUpdate = supportsOtaUpdate;
    }
    /**
     * @return Port to use when connection to a terminal via {@link ConnectionType#TCP_IP}
     */
    public Integer getPort() {
        return mPort;
    }

    /**
     * Conditional based on the selected {@link ConnectionType}.
     * <p>
     * <ul>
     * <li>{@link ConnectionType#AUDIO_JACK} - Not used</li>
     * <li>{@link ConnectionType#BLUETOOTH} - Not used.</li>
     * <li>{@link ConnectionType#TCP_IP} - Optional if a non-standard port should be appended to the
     * host address.</li>
     * </ul>
     *
     * @param port Port to use when connection to a terminal via {@link ConnectionType#TCP_IP}
     */
    public void setPort(Integer port) {
        mPort = port;
    }

    /**
     * @return Terminal timeout period, in milliseconds
     */
    public long getTimeout() {
        return mTimeout;
    }

    public void setTimeout(long timeout) {
        mTimeout = timeout;
    }

    /**
     * @return The duration in seconds after which the device will go into energy saving mode following
     * the last communication with the application.
     */
    @Nullable
    public Integer getEnergySaverModeDelay() {
        return mEnergySaverModeDelay;
    }

    /**
     * Set the time in seconds after which the device will go into energy saving mode following
     * the last communication with the application.
     *
     * @param energySaverModeDelay Duration in seconds.
     */
    public void setEnergySaverModeDelay(Integer energySaverModeDelay) {
        mEnergySaverModeDelay = energySaverModeDelay;
    }

    /**
     * @return The duration in seconds after which the device will shut down following it's time in
     * energy saving mode.
     */
    @Nullable
    public Integer getShutdownDelay() {
        return mShutdownDelay;
    }

    /**
     * Set the duration in seconds after which the device will shut down following it's time in
     * energy saving mode.
     *
     * @param shutdownDelay Duration in seconds.
     */
    public void setShutdownDelay(Integer shutdownDelay) {
        mShutdownDelay = shutdownDelay;
    }

    /**
     * @return The duration in seconds after which the screen LED will turn off following the last
     * communication between the application and terminal.
     */
    @Nullable
    public Integer getScreenTurnOffDelay() {
        return mScreenTurnOffDelay;
    }

    /**
     * Set the duration in seconds after which the screen LED will turn off following the last
     * communication between the application and the terminal. If not set, the default settings
     * for the particular hardware will be used.
     *
     * @param screenTurnOffDelay Duration in seconds.
     */
    public void setScreenTurnOffDelay(Integer screenTurnOffDelay) {
        mScreenTurnOffDelay = screenTurnOffDelay;
    }

    public List<AidConfiguration> getContactAids() {
        return mContactAids;
    }

    public void setContactAids(List<AidConfiguration> contactAids) {
        mContactAids = contactAids;
    }

    public List<AidConfiguration> getContactlessAids() {
        return mContactlessAids;
    }

    public void setContactlessAids(List<AidConfiguration> contactlessAids) {
        mContactlessAids = contactlessAids;
    }

    public Map<String, TerminalActionCodes> getTacMap() {
        return mTacMap;
    }

    public void setTacMap(Map<String, TerminalActionCodes> tacMap) {
        mTacMap = tacMap;
    }

    public List<Capk> getCapks() {
        return mCapks;
    }

    public void setCapks(List<Capk> capks) {
        mCapks = capks;
    }

    public int getMinPinLength() {
        return mMinPinLength;
    }

    public void setMinPinLength(int minPinLength) {
        mMinPinLength = minPinLength;
    }

    public int getMaxPinLength() {
        return mMaxPinLength;
    }

    public void setMaxPinLength(int maxPinLength) {
        mMaxPinLength = maxPinLength;
    }

    public TerminalOperatingEnvironment getOperatingEnvironment() {
        return mOperatingEnvironment;
    }

    public void setOperatingEnvironment(TerminalOperatingEnvironment operatingEnvironment) {
        mOperatingEnvironment = operatingEnvironment;
    }

    public TerminalAuthenticationCapability getAuthenticationCapability() {
        return mAuthenticationCapability;
    }

    public void setAuthenticationCapability(
            TerminalAuthenticationCapability authenticationCapability) {
        mAuthenticationCapability = authenticationCapability;
    }

    public TerminalOutputCapability getOutputCapability() {
        return mOutputCapability;
    }

    public void setOutputCapability(TerminalOutputCapability outputCapability) {
        mOutputCapability = outputCapability;
    }

    public TerminalInputCapability getCapability() {
        return mCapability;
    }

    public void setCapability(TerminalInputCapability capability) {
        mCapability = capability;
    }

    public LedMobyPairingListener getPairingListener() {
        return mPairingListener;
    }

    public void setPairingListener(LedMobyPairingListener mPairingListener) {
        this.mPairingListener = mPairingListener;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TerminalConfiguration)) return false;
        TerminalConfiguration that = (TerminalConfiguration)o;
        return mTimeout == that.mTimeout &&
                mMinPinLength == that.mMinPinLength &&
                mMaxPinLength == that.mMaxPinLength &&
                mTerminalType == that.mTerminalType &&
                mConnectionType == that.mConnectionType &&
                Objects.equals(mHost, that.mHost) &&
                Objects.equals(mOtaServerUrl, that.mOtaServerUrl) &&
                Objects.equals(mPort, that.mPort) &&
                Objects.equals(mEnergySaverModeDelay, that.mEnergySaverModeDelay) &&
                Objects.equals(mShutdownDelay, that.mShutdownDelay) &&
                Objects.equals(mScreenTurnOffDelay, that.mScreenTurnOffDelay) &&
                Objects.equals(mSupportsOtaUpdate, that.mSupportsOtaUpdate) &&
                mOperatingEnvironment == that.mOperatingEnvironment &&
                mAuthenticationCapability == that.mAuthenticationCapability &&
                mOutputCapability == that.mOutputCapability &&
                mCapability == that.mCapability &&
                Objects.equals(mContactAids, that.mContactAids) &&
                Objects.equals(mContactlessAids, that.mContactlessAids) &&
                Objects.equals(mTacMap, that.mTacMap) &&
                Objects.equals(mCapks, that.mCapks);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mTerminalType, mConnectionType, mHost, mOtaServerUrl, mPort, mTimeout,
                mMinPinLength, mMaxPinLength, mEnergySaverModeDelay, mShutdownDelay,
                mScreenTurnOffDelay, mSupportsOtaUpdate, mOperatingEnvironment,
                mAuthenticationCapability, mOutputCapability, mCapability, mContactAids,
                mContactlessAids, mTacMap, mCapks);
    }

    @Override
    public String toString() {
        return "TerminalConfiguration{" +
                "mTerminalType=" + mTerminalType +
                ", mConnectionType=" + mConnectionType +
                ", mHost='" + mHost + '\'' +
                ", mOtaServerUrl='" + mOtaServerUrl + '\'' +
                ", mPort=" + mPort +
                ", mTimeout=" + mTimeout +
                ", mMinPinLength=" + mMinPinLength +
                ", mMaxPinLength=" + mMaxPinLength +
                ", mEnergySaverModeDelay=" + mEnergySaverModeDelay +
                ", mShutdownDelay=" + mShutdownDelay +
                ", mScreenTurnOffDelay=" + mScreenTurnOffDelay +
                ", mSupportsOtaUpdate=" + mSupportsOtaUpdate +
                ", mOperatingEnvironment=" + mOperatingEnvironment +
                ", mAuthenticationCapability=" + mAuthenticationCapability +
                ", mOutputCapability=" + mOutputCapability +
                ", mCapability=" + mCapability +
                ", mContactAids=" + mContactAids +
                ", mContactlessAids=" + mContactlessAids +
                ", mTacMap=" + mTacMap +
                ", mCapks=" + mCapks +
                '}';
    }
}
