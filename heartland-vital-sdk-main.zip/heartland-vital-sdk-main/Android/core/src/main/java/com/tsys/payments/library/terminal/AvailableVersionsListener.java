package com.tsys.payments.library.terminal;

import com.tsys.payments.library.enums.TerminalError;
import com.tsys.payments.library.enums.TerminalUpdateType;
import com.tsys.payments.library.exceptions.Error;

import java.util.List;

public interface AvailableVersionsListener {
    /**
     * Callback fired when information about the available terminal versions is successfully
     * received.
     */
    void onAvailableTerminalVersionsReceived(TerminalUpdateType type,
            List<String> versions);

    /**
     * Callback fired when an error is encountered when trying to get terminal version info.
     *
     * @param error {@link Error}
     * @param message Description of the error
     */
    void onTerminalVersionInfoError(TerminalError error, String message);
}
