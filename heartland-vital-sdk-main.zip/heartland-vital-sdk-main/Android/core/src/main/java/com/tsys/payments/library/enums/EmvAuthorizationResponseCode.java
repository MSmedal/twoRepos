package com.tsys.payments.library.enums;

import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvObjectBuilder;
import com.tsys.payments.library.utils.ByteUtils;

/**
 * Common values returned in EMV tag {@link EmvTagDescriptor#AUTHORIZATION_RESPONSE_CODE} indicating the general
 * disposition of a transaction. The value is 2 bytes long and is sourced from the issuer/terminal.
 */
public enum EmvAuthorizationResponseCode {
    APPROVAL("3030"),
    DENIAL("3035"),
    UNABLE_TO_GO_ONLINE("5A33");

    public final String value;

    EmvAuthorizationResponseCode(String value) {
        this.value = value;
    }

    public static TlvObject getAsTlvObject(EmvAuthorizationResponseCode code) {
        TlvObjectBuilder builder = TlvObjectBuilder.create(EmvTagDescriptor.AUTHORIZATION_RESPONSE_CODE);
        builder.setValue(ByteUtils.hexStringToByteArray(code.value));
        return builder.build();
    }
}
