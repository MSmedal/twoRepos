package com.tsys.payments.library.utils;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.Receipt;
import com.tsys.payments.library.domain.TransactionRequest;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CountryCode;
import com.tsys.payments.library.enums.CurrencyCode;
import com.tsys.payments.library.enums.CvmResult;
import com.tsys.payments.library.enums.PinStatementType;
import com.tsys.payments.library.enums.TransactionType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvUtils;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import timber.log.Timber;

public class ReceiptHelper {
    private static final String TAG = ReceiptHelper.class.getName();

    /**
     * Returns information that must be presented to the customer on the receipt for an MSR transaction.
     *
     * @param transactionRequest {@link TransactionRequest} containing information about the {@link TransactionType}
     * @param gatewayResponse    {@link GatewayResponse} containing information about the approved amounts, transaction
     *                           id,and authorization code.
     * @param cardData           {@link CardData} containing information about the payment method and cardholder
     *                           information.
     * @return {@link Receipt} containing required MSR transaction data if present.
     */
    @Nullable
    public static Receipt buildMsrReceipt(@NonNull TransactionRequest transactionRequest,
            @Nullable GatewayRequest gatewayRequest,
            @Nullable GatewayResponse gatewayResponse, @NonNull CardData cardData) {
        Receipt.Builder builder = new Receipt.Builder();
        if (gatewayResponse != null) {
            builder.setAuthorizationCode(gatewayResponse.getAuthCode());
            builder.setTransactionId(gatewayResponse.getGatewayTransactionId());
            builder.setTransactionAmount(gatewayResponse.getApprovedAmount());
        } else {
            Timber.w(
                    "Unable to populate required MSR receipt fields: auth code, transaction id, and approved amount.");
        }

        if (cardData != null) {
            builder.setCardType(CreditCardHelper.typeFromCardData(cardData));
            builder.setCardholderName(cardData.getCardholderName());
            builder.setPosEntryMode(cardData.getCardDataSource());
            String pan = CreditCardHelper.getPanFromCardData(cardData);
            if (!TextUtils.isEmpty(pan)) {
                builder.setMaskedPan(CreditCardHelper.obfuscateNumber(pan, 0,
                        4, 'x', false));
            }
        }

        builder.setCurrencyCode(CurrencyCode.USD);
        builder.setTransactionType(transactionRequest.getTransactionType());
        builder.setTransactionDateTime(new Date());
        if (!TextUtils.isEmpty(transactionRequest.getPosReferenceNumber())) {
            builder.setPosReferenceNumber(transactionRequest.getPosReferenceNumber());
        }

        if (gatewayRequest != null && gatewayRequest.getTerminalInfo() != null
                && !TextUtils.isEmpty(gatewayRequest.getTerminalInfo().getSerialNumber())) {
            builder.setTerminalSerialNumber(gatewayRequest.getTerminalInfo().getSerialNumber());
        }
        return builder.build();
    }

    /**
     * Returns information that must be presented to the customer on the receipt for an MSR transaction.
     *
     * @param gatewayRequestRequest {@link TransactionRequest} containing information about the transaction
     *                              corresponding to the {@link com.tsys.payments.library.gateway.enums.GatewayAction}
     * @param gatewayResponse       {@link GatewayResponse} containing information about the approved amounts,
     *                              transaction id,and authorization code.
     * @return {@link Receipt} containing required MSR transaction data if present.
     */
    public static Receipt buildMsrReceipt(@NonNull GatewayRequest gatewayRequestRequest,
            @Nullable GatewayResponse gatewayResponse) {
        Receipt.Builder builder = new Receipt.Builder();
        if (gatewayResponse != null) {
            builder.setAuthorizationCode(gatewayResponse.getAuthCode());
            builder.setTransactionId(gatewayResponse.getGatewayTransactionId());
            builder.setTransactionAmount(gatewayResponse.getApprovedAmount());
        } else {
            Timber.w(
                    "Unable to populate required MSR receipt fields: auth code, transaction id, and approved amount.");
        }

        CardData cardData = gatewayRequestRequest.getCardData();
        if (cardData != null) {
            builder.setCardType(CreditCardHelper.typeFromCardData(cardData));
            builder.setCardholderName(cardData.getCardholderName());
            builder.setPosEntryMode(cardData.getCardDataSource());
            String pan = CreditCardHelper.getPanFromCardData(cardData);
            if (!TextUtils.isEmpty(pan)) {
                builder.setMaskedPan(CreditCardHelper.obfuscateNumber(pan, 0,
                        4, 'x', false));
            }
        } else {
            Timber.w(
                    "Unable to populate required MSR receipt fields: card type, cardholder name, entry method and masked PAN");
        }

        builder.setCurrencyCode(CurrencyCode.USD);
        builder.setTransactionType(
                TransactionType.fromGatewayAction(gatewayRequestRequest.getGatewayAction()));
        builder.setTransactionDateTime(new Date());
        if (!TextUtils.isEmpty(gatewayRequestRequest.getPosReferenceNumber())) {
            builder.setPosReferenceNumber(gatewayRequestRequest.getPosReferenceNumber());
        }
        return builder.build();
    }

    /**
     * Returns information that must be presented to the customer on the receipt for an EMV transaction.
     *
     * @param gatewayResponse {@link GatewayResponse} containing information about the approved amounts, transaction id,
     *                        and authorization code.
     * @param cardData        {@link CardData} containing information about the payment method and cardholder
     *                        information.
     * @return {@link Receipt} containing required EMV and transaction data if present.
     */
    @Nullable
    public static Receipt buildEmvReceipt(@Nullable TransactionRequest transactionRequest,
            @Nullable GatewayRequest gatewayRequest,
            @Nullable GatewayResponse gatewayResponse,
            @NonNull CardData cardData) {
        Receipt.Builder builder = new Receipt.Builder();
        if (gatewayResponse != null) {
            builder.setAuthorizationCode(gatewayResponse.getAuthCode());
            builder.setTransactionId(gatewayResponse.getGatewayTransactionId());
            builder.setTransactionAmount(gatewayResponse.getApprovedAmount());
        }
        builder.setPosEntryMode(cardData.getCardDataSource());
        builder.setCardType(CreditCardHelper.typeFromCardData(cardData));
        builder.setCardholderName(cardData.getCardholderName());
        String pan = CreditCardHelper.getPanFromCardData(cardData);
        if (!TextUtils.isEmpty(pan)) {
            builder.setMaskedPan(CreditCardHelper.obfuscateNumber(pan, 4,
                    4, 'x', false));
        }

        if (validateEmvTagsPresent(cardData.getEmvTlvData())) {
            for (TlvObject tag : cardData.getEmvTlvData()) {
                if (tag.getTagDescriptor() == EmvTagDescriptor.APPLICATION_IDENTIFIER) {
                    builder.setAid(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.APP_LABEL) {

                    // Application Preferred name takes precedence over app label if present
                    TlvObject appPreferredName =
                            TlvUtils.findTlv(EmvTagDescriptor.APPLICATION_PREFERRED_NAME,
                                    cardData.getEmvTlvData());
                    byte[] appLabelBytes;
                    if (appPreferredName != null &&
                            !TextUtils.isEmpty(appPreferredName.getValueAsHexString(false))) {
                        appLabelBytes =
                                ByteUtils.hexStringToByteArray(appPreferredName.getValueAsHexString(
                                        false));
                    } else {
                        appLabelBytes = ByteUtils.hexStringToByteArray(tag.getValueAsHexString(
                                false));
                    }

                    if (appLabelBytes != null) {
                        builder.setApplicationLabel(new String(appLabelBytes));
                    }
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.APPLICATION_EXPIRATION_DATE) {
                    builder.setApplicationExpiryDate(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.APPLICATION_EFFECTIVE_DATE) {
                    builder.setApplicationEffectiveDate(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() ==
                        EmvTagDescriptor.APPLICATION_INTERCHANGE_PROFILE) {
                    builder.setApplicationInterchangeProfile(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.APPLICATION_VERSION_NUMBER) {
                    builder.setApplicationVersionNumber(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() ==
                        EmvTagDescriptor.APPLICATION_TRANSACTION_COUNTER) {
                    builder.setApplicationTransactionCounter(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.PAN_SEQUENCE_NUMBER) {
                    builder.setPanSequenceNumber(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.APPLICATION_CRYPTOGRAM) {
                    builder.setCryptogram(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.CVM_RESULT) {
                    CvmResult cvmResult = CvmResult.fromTlv(tag.getValueAsHexString(false));
                    builder.setCvmResult(cvmResult);
                    if (cvmResult != null) {
                        switch (cvmResult) {
                            case PIN_ONLINE:
                            case PIN_OFFLINE_ENCR:
                            case PIN_OFFLINE_PLAIN:
                                builder.setPinStatement(PinStatementType.PIN_VERIFIED);
                                break;
                        }
                    }
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.ISSUER_APP_DATA) {
                    builder.setIssuerApplicationData(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.ISSUER_AUTHENTICATION_DATA) {
                    builder.setIssuerAuthenticationData(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() ==
                        EmvTagDescriptor.TERMINAL_VERIFICATION_RESULTS) {
                    builder.setTerminalVerificationResult(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.UNPREDICTABLE_NUMBER) {
                    builder.setUnpredictableNumber(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.IFD_SERIAL_NUMBER) {
                    builder.setIfdSerialNumber(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.TERMINAL_COUNTRY_CODE) {
                    String code = tag.getValueAsHexString(false);
                    for (CountryCode countryCode : CountryCode.values()) {
                        if (countryCode.currencyCode.equals(code)) ;
                        builder.setTerminalCountryCode(countryCode);
                        break;
                    }
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.TRANSACTION_CURRENCY_CODE) {
                    String code = tag.getValueAsHexString(false);
                    for (CurrencyCode currencyCode : CurrencyCode.values()) {
                        if (currencyCode.currencyCode.equals(code)) ;
                        builder.setCurrencyCode(currencyCode);
                        break;
                    }
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.CRYPTOGRAM_INFORMATION_DATA) {
                    builder.setCryptogramInformationData(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.CARDHOLDER_NAME) {
                    byte[] cardholderNameBytes = ByteUtils
                            .hexStringToByteArray(tag.getValueAsHexString(false));
                    if (cardholderNameBytes != null) {
                        builder.setCardholderName(new String(cardholderNameBytes));
                    }
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.TRANSACTION_DATE) {
                    builder.setTerminalTransactionDate(tag.getValueAsHexString(false));
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.AMOUNT_OTHER_NUMERIC) {
                    String cashBackAmount = String.valueOf(new BigDecimal(tag.getValueAsHexString(false)));
                    if (!TextUtils.isEmpty(cashBackAmount)) {
                        builder.setCashBackAmount(Long.parseLong(cashBackAmount));
                    }
                } else if (tag.getTagDescriptor() == EmvTagDescriptor.AUTHORIZATION_RESPONSE_CODE) {
                    builder.setEmvAuthorizationResponseCode(tag.getValueAsHexString(false));
                } else if(tag.getTagDescriptor() == EmvTagDescriptor.TRANSACTION_STATUS_INFORMATION) {
                    builder.setTerminalStatusIndicator(tag.getValueAsHexString(false));
                }
            }
        }

        if (gatewayRequest != null) {
            builder.setTransactionType(
                    TransactionType.fromGatewayAction(gatewayRequest.getGatewayAction()));
            if (!TextUtils.isEmpty(gatewayRequest.getPosReferenceNumber())) {
                builder.setPosReferenceNumber(gatewayRequest.getPosReferenceNumber());
            }

            if (gatewayRequest.getTerminalInfo() != null &&
                    !TextUtils.isEmpty(gatewayRequest.getTerminalInfo().getSerialNumber())) {
                builder.setTerminalSerialNumber(gatewayRequest
                        .getTerminalInfo().getSerialNumber());
            }
        } else if (transactionRequest != null) {
            builder.setTransactionType(transactionRequest.getTransactionType());
        }
        builder.setTransactionDateTime(new Date());
        return builder.build();
    }

    private static boolean validateEmvTagsPresent(@Nullable List<TlvObject> emvTags) {
        if (emvTags == null) {
            Timber.w("All expected EMV data needed for the receipt is missing.");
            return false;
        }

        boolean foundAid = false;
        boolean foundAppLabel = false;

        for (TlvObject tag : emvTags) {
            if (tag.getTagDescriptor() == EmvTagDescriptor.APPLICATION_IDENTIFIER) {
                foundAid = true;
            } else if (tag.getTagDescriptor() == EmvTagDescriptor.APP_LABEL) {
                foundAppLabel = true;
            }
        }

        if (!foundAid && !foundAppLabel) {
            Timber.w("AID and Application Label are missing from EMV tags.");
            return false;
        }
        if (!foundAid) {
            Timber.w("AID missing from EMV tags.");
            return false;
        }
        if (!foundAppLabel) {
            Timber.w("Application Label missing from EMV tags.");
            return false;
        }

        return true;
    }

    @NonNull
    public static String getPosEntryMode(@Nullable CardDataSourceType type) {
        if (type == null) return "N/A";
        switch (type) {
            case MSR:
                return "MAGSTRIPE";
            case SCR:
                return "CHIP READ";
            case KEYED:
                return "MANUAL";
            default:
                return type.name().toUpperCase();
        }
    }
}
