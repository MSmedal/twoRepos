package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardholderInteractionType;
import com.tsys.payments.library.enums.CommercialCardDataField;

/**
 * Represents a request from the terminal that requires interaction from the cardholder.
 */
public class CardholderInteractionRequest {

    private CardholderInteractionType mCardholderInteractionType;
    private String[] mSupportedApplications;
    private Long mFinalTransactionAmount;
    private long mFinalSurchargeAmount;
    private CommercialCardDataField[] mCommercialCardDataFields;
    private CardDataSourceType mCardDataSourceType;

    /**
     * @return {@link CardholderInteractionType} requested by the terminal.
     */
    public CardholderInteractionType getCardholderInteractionType() {
        return mCardholderInteractionType;
    }

    /**
     * @param cardholderInteractionType {@link CardholderInteractionType} requested by the terminal
     */
    public void setCardholderInteractionType(CardholderInteractionType cardholderInteractionType) {
        mCardholderInteractionType = cardholderInteractionType;
    }

    /**
     * Provided when {@link CardholderInteractionType#EMV_APPLICATION_SELECTION}
     *
     * @return Array of supported Application (AID) names that can be used to complete the
     * transaction.
     */
    public String[] getSupportedApplications() {
        return mSupportedApplications;
    }

    /**
     * @param supportedApplications Array of supported Application (AID) names that can be used to
     * complete the transaction.
     */
    public void setSupportedApplications(String[] supportedApplications) {
        mSupportedApplications = supportedApplications;
    }

    /**
     * Provided when {@link CardholderInteractionType#FINAL_AMOUNT_CONFIRMATION}
     *
     * @return Final amount to be authorized with the cardholders confirmation.
     */
    public Long getFinalTransactionAmount() {
        return mFinalTransactionAmount;
    }

    /**
     * @param finalTransactionAmount Final amount to be authorized with the cardholders
     * confirmation.
     */
    public void setFinalTransactionAmount(Long finalTransactionAmount) {
        mFinalTransactionAmount = finalTransactionAmount;
    }

    /**
     *
     * @return Final Surcharge amount confirmed by the cardholder.
     */
    public long getFinalSurchargeAmount(){
        return mFinalSurchargeAmount;
    }

    /**
     *
     * @param finalSurchargeAmount for cardholder confirmation.
     */
    public void setSurchargeAmount(Long finalSurchargeAmount){
        mFinalSurchargeAmount = finalSurchargeAmount;
    }

    /**
     * Provided when {@link CardholderInteractionType#COMMERCIAL_CARD_DATA_ENTRY}
     *
     * @return {@link CommercialCardDataField} necessary commercial data requested when in presence
     * of commercial card transaction.
     *
     * @see CommercialCardDataField
     */
    public CommercialCardDataField[] getCommercialCardDataFields() {
        return mCommercialCardDataFields;
    }

    /**
     * @param commercialCardDataFields Necessary fields to request when we are in presence of
     * commercial card transaction.
     * @see CommercialCardDataField
     */
    public void setCommercialCardDataFields(
            CommercialCardDataField[] commercialCardDataFields) {
        mCommercialCardDataFields = commercialCardDataFields;
    }

    /**
     * Provided when {@link CardholderInteractionType#REQUEST_PROCEED_HOST_PROCESSING}
     *
     * @return {@link CardDataSourceType} method used to capture card data for host processing.
     */
    public CardDataSourceType getCardDataSourceType() {
        return mCardDataSourceType;
    }

    /**
     * @param cardDataSourceType {@link CardDataSourceType} used to capture card data for host processing.
     */
    public void setCardDataSourceType(CardDataSourceType cardDataSourceType) {
        mCardDataSourceType = cardDataSourceType;
    }
}
