package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.enums.TransactionResultType;
import com.tsys.payments.library.enums.TransactionType;

import androidx.annotation.Nullable;

import java.util.Map;
import java.util.Objects;

public class TransactionResponse {

    private TransactionResultType mTransactionResult;
    private String mGatewayTransactionId;
    private String mPosReferenceNumber;
    private String mGatewayAuthCode;
    private Long mApprovedAmount;
    private Long mTipAmount;
    private CardType mCardType;
    private TenderType mTenderType;
    private TransactionType mTransactionType;
    private CardDataSourceType mCardDataSourceType;
    private String mMaskedPan;
    private Receipt mReceipt;
    private Map<TransactionType, String> mResponseMessages;
    private Map<TransactionType, String> mResponseCodes;
    private String mToken;
    private String mCardBrandTxnId;
    private String mCardHolderId;
    private String mSafLocalId;
    private String mOriginalGatewayTxnId;
    private String mOriginalRspDT;
    private String mOriginalClientTxnId;
    private String mOriginalAuthCode;
    private String mOriginalRefNbr;
    private long mOriginalAuthAmt;
    private String mOriginalCardType;
    private String mOriginalCardNbrLast4;
    private Map<String, String> mSvaData;

    public String getMaskedPan() {
        return mMaskedPan;
    }

    public TransactionResultType getTransactionResult() {
        return mTransactionResult;
    }

    public String getGatewayTransactionId() {
        return mGatewayTransactionId;
    }

    public String getPosReferenceNumber() {
        return mPosReferenceNumber;
    }

    public String getGatewayAuthCode() {
        return mGatewayAuthCode;
    }

    public Long getApprovedAmount() {
        return mApprovedAmount;
    }

    public CardType getCardType() {
        return mCardType;
    }

    public TenderType getTenderType() {
        return mTenderType;
    }

    public TransactionType getTransactionType() {
        return mTransactionType;
    }

    public Receipt getReceipt() {
        return mReceipt;
    }

    public CardDataSourceType getCardDataSourceType() {
        return mCardDataSourceType;
    }

    public Long getTipAmount() {
        return mTipAmount;
    }

    public Map<TransactionType, String> getResponseMessages() {
        return mResponseMessages;
    }

    public Map<TransactionType, String> getResponseCodes() {
        return mResponseCodes;
    }

    public String getOriginalGatewayTxnId() {
        return mOriginalGatewayTxnId;
    }

    public String getOriginalRspDT() {
        return mOriginalRspDT;
    }

    public String getOriginalClientTxnId() {
        return mOriginalClientTxnId;
    }

    public String getOriginalAuthCode() {
        return mOriginalAuthCode;
    }

    public String getOriginalRefNbr() {
        return mOriginalRefNbr;
    }

    public long getOriginalAuthAmt() {
        return mOriginalAuthAmt;
    }

    public String getOriginalCardType() {
        return mOriginalCardType;
    }

    public String getOriginalCardNbrLast4() {
        return mOriginalCardNbrLast4;
    }

    @Nullable
    public String getToken() {
        return mToken;
    }

    @Nullable
    public String getCardBrandTxnId() {
        return mCardBrandTxnId;
    }

    @Nullable
    public String getCardHolderId() {
        return mCardHolderId;
    }

    public String getSafLocalId() {
        return mSafLocalId;
    }

    /**
     * Get the SVA(Gift Card) Data.
     * @return
     */
    public Map<String, String> getSvaData(){
        return mSvaData;
    }


    public static class Builder {
        private TransactionResponse mTransactionResponse;

        public Builder() {
            mTransactionResponse = new TransactionResponse();
        }

        public Builder setTransactionResult(TransactionResultType transactionResult) {
            mTransactionResponse.mTransactionResult = transactionResult;
            return this;
        }

        public Builder setHostTransactionId(String hostTransactionId) {
            mTransactionResponse.mGatewayTransactionId = hostTransactionId;
            return this;
        }

        public Builder setPosReferenceNumber(String posReferenceNumber) {
            mTransactionResponse.mPosReferenceNumber = posReferenceNumber;
            return this;
        }

        public Builder setReceipt(Receipt receipt) {
            mTransactionResponse.mReceipt = receipt;
            return this;
        }

        public Builder setHostAuthCode(String hostAuthCode) {
            mTransactionResponse.mGatewayAuthCode = hostAuthCode;
            return this;
        }

        public Builder setCardType(CardType cardType) {
            mTransactionResponse.mCardType = cardType;
            return this;
        }

        public Builder setApprovedAmount(Long approvedAmount) {
            mTransactionResponse.mApprovedAmount = approvedAmount;
            return this;
        }

        public TransactionResponse build() {
            return mTransactionResponse;
        }

        public Builder setTenderType(TenderType tenderType) {
            mTransactionResponse.mTenderType = tenderType;
            return this;
        }

        public Builder setTransactionType(TransactionType transactionType) {
            mTransactionResponse.mTransactionType = transactionType;
            return this;
        }

        public Builder setCardDataSourceType(CardDataSourceType cardDataSourceType) {
            mTransactionResponse.mCardDataSourceType = cardDataSourceType;
            return this;
        }

        public Builder setMaskedPan(String maskedPan) {
            mTransactionResponse.mMaskedPan = maskedPan;
            return this;
        }

        public Builder setTipAmount(Long tipAmount) {
            mTransactionResponse.mTipAmount = tipAmount;
            return this;
        }

        public Builder setResponseMap(Map<TransactionType, String> map) {
            mTransactionResponse.mResponseMessages = map;
            return this;
        }

        public Builder setResponseCodeMap(Map<TransactionType, String> map) {
            mTransactionResponse.mResponseCodes = map;
            return this;
        }

        /**
         * @param token
         * Can be used later for subsequent transactions as a substitute for the associated
         * customer's payment data
         */
        public Builder setToken(@Nullable String token) {
            mTransactionResponse.mToken = token;
            return this;
        }

        /**
         * @param cardBrandTxnId
         * Used later for subsequent transactions in conjunction with token.
         */
        public Builder setCardBrandTxnId(@Nullable String cardBrandTxnId) {
            mTransactionResponse.mCardBrandTxnId = cardBrandTxnId;
            return this;
        }

        /**
         * @param cardHolderId
         * Can be used later for subsequent transactions as a substitute for the associated
         * customer's payment data
         */
        public Builder setCardHolderId(@Nullable String cardHolderId) {
            mTransactionResponse.mCardHolderId = cardHolderId;
            return this;
        }

        public Builder setSafLocalId(String safLocalId) {
            mTransactionResponse.mSafLocalId = safLocalId;
            return this;
        }

        public Builder setOriginalGatewayTxnId(String originalGatewayTxnId) {
            mTransactionResponse.mOriginalGatewayTxnId = originalGatewayTxnId;
            return this;
        }

        public Builder setOriginalRspDT(String originalRspDT) {
            mTransactionResponse.mOriginalRspDT = originalRspDT;
            return this;
        }

        public Builder setOriginalClientTxnId(String originalClientTxnId) {
            mTransactionResponse.mOriginalClientTxnId = originalClientTxnId;
            return this;
        }

        public Builder setOriginalAuthCode(String originalAuthCode) {
            mTransactionResponse.mOriginalAuthCode = originalAuthCode;
            return this;
        }

        public Builder setOriginalRefNbr(String originalRefNbr) {
            mTransactionResponse.mOriginalRefNbr = originalRefNbr;
            return this;
        }

        public Builder setOriginalAuthAmt(long originalAuthAmt) {
            mTransactionResponse.mOriginalAuthAmt = originalAuthAmt;
            return this;
        }

        public Builder setOriginalCardType(String originalCardType) {
            mTransactionResponse.mOriginalCardType = originalCardType;
            return this;
        }

        public Builder setOriginalCardNbrLast4(String originalCardNbrLast4) {
            mTransactionResponse.mOriginalCardNbrLast4 = originalCardNbrLast4;
            return this;
        }

        public Builder setSvaData(Map<String, String> map){
            mTransactionResponse.mSvaData = map;
            return this;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransactionResponse that = (TransactionResponse)o;
        return mTransactionResult == that.mTransactionResult &&
                Objects.equals(mGatewayTransactionId, that.mGatewayTransactionId) &&
                Objects.equals(mPosReferenceNumber, that.mPosReferenceNumber) &&
                Objects.equals(mGatewayAuthCode, that.mGatewayAuthCode) &&
                Objects.equals(mApprovedAmount, that.mApprovedAmount) &&
                Objects.equals(mTipAmount, that.mTipAmount) &&
                mCardType == that.mCardType &&
                mTenderType == that.mTenderType &&
                mTransactionType == that.mTransactionType &&
                mCardDataSourceType == that.mCardDataSourceType &&
                Objects.equals(mMaskedPan, that.mMaskedPan) &&
                Objects.equals(mReceipt, that.mReceipt) &&
                Objects.equals(mResponseMessages, that.mResponseMessages) &&
                Objects.equals(mResponseCodes, that.mResponseCodes) &&
                Objects.equals(mToken, that.mToken) &&
                Objects.equals(mCardHolderId, that.mCardHolderId) &&
                Objects.equals(mSafLocalId, that.mSafLocalId);
    }

    @Override
    public int hashCode() {
        return Objects
                .hash(mTransactionResult, mGatewayTransactionId, mPosReferenceNumber,
                        mGatewayAuthCode,
                        mApprovedAmount, mTipAmount, mCardType, mTenderType, mTransactionType,
                        mCardDataSourceType, mMaskedPan, mReceipt, mResponseMessages,
                        mResponseCodes,
                        mToken, mCardHolderId, mSafLocalId);
    }

    @Override
    public String toString() {
        return "TransactionResponse{" +
                "mTransactionResult=" + mTransactionResult +
                ", mGatewayTransactionId='" + mGatewayTransactionId + '\'' +
                ", mPosReferenceNumber='" + mPosReferenceNumber + '\'' +
                ", mGatewayAuthCode='" + mGatewayAuthCode + '\'' +
                ", mApprovedAmount=" + mApprovedAmount +
                ", mTipAmount=" + mTipAmount +
                ", mCardType=" + mCardType +
                ", mTenderType=" + mTenderType +
                ", mTransactionType=" + mTransactionType +
                ", mCardDataSourceType=" + mCardDataSourceType +
                ", mMaskedPan='" + mMaskedPan + '\'' +
                ", mReceipt=" + mReceipt +
                ", mResponseMessages=" + mResponseMessages +
                ", mResponseCodes=" + mResponseCodes +
                ", mToken='" + mToken + '\'' +
                ", mCardHolderId='" + mCardHolderId + '\'' +
                ", mSafLocalId='" + mSafLocalId + '\'' +
                ", mOriginalGatewayTxnId ='" + mOriginalGatewayTxnId + '\'' +
                ", mOriginalRspDT ='" + mOriginalRspDT + '\'' +
                ", mOriginalClientTxnId ='" + mOriginalClientTxnId + '\'' +
                ", mOriginalAuthCode ='" + mOriginalAuthCode + '\'' +
                ", mOriginalRefNbr ='" + mOriginalRefNbr + '\'' +
                ", mOriginalAuthAmt ='" + mOriginalAuthAmt + '\'' +
                ", mOriginalCardType ='" + mOriginalCardType + '\'' +
                ", mOriginalCardNbrLast4 ='" + mOriginalCardNbrLast4 + '\'' +
                '}';
    }
}
