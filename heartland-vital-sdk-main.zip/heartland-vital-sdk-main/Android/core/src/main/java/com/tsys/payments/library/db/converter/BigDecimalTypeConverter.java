package com.tsys.payments.library.db.converter;

import android.text.TextUtils;

import androidx.annotation.Nullable;
import androidx.room.TypeConverter;

import java.math.BigDecimal;

public class BigDecimalTypeConverter {

    @TypeConverter
    @Nullable
    public static BigDecimal toBigDecimal(String value) {
        if (!TextUtils.isEmpty(value)) {
            return new BigDecimal(value);
        } else {
            return null;
        }
    }

    @TypeConverter
    @Nullable
    public static String toString(BigDecimal value) {
        if (value != null) {
            return value.toString();
        } else {
            return null;
        }
    }
}
