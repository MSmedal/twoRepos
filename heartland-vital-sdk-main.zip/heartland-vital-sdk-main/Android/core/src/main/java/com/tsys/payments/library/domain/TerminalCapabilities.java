package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.TerminalAuthenticationCapability;
import com.tsys.payments.library.enums.TerminalInputCapability;
import com.tsys.payments.library.enums.TerminalOperatingEnvironment;
import com.tsys.payments.library.enums.TerminalOutputCapability;

import java.util.Objects;

/**
 * Describes the capabilities and usage of a payment terminal.
 */
public class TerminalCapabilities {

    private TerminalOperatingEnvironment mOperatingEnvironment;
    private TerminalAuthenticationCapability mAuthenticationCapability;
    private TerminalOutputCapability mOutputCapability;
    private TerminalInputCapability mCapability;

    public TerminalOperatingEnvironment getOperatingEnvironment() {
        return mOperatingEnvironment;
    }

    public void setOperatingEnvironment(TerminalOperatingEnvironment operatingEnvironment) {
        mOperatingEnvironment = operatingEnvironment;
    }

    public TerminalAuthenticationCapability getAuthenticationCapability() {
        return mAuthenticationCapability;
    }

    public void setAuthenticationCapability(
            TerminalAuthenticationCapability authenticationCapability) {
        mAuthenticationCapability = authenticationCapability;
    }

    public TerminalOutputCapability getOutputCapability() {
        return mOutputCapability;
    }

    public void setOutputCapability(TerminalOutputCapability outputCapability) {
        mOutputCapability = outputCapability;
    }

    public TerminalInputCapability getInputCapability() {
        return mCapability;
    }

    public void setInputCapability(TerminalInputCapability capability) {
        mCapability = capability;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TerminalCapabilities)) return false;
        TerminalCapabilities that = (TerminalCapabilities)o;
        return mOperatingEnvironment == that.mOperatingEnvironment &&
                mAuthenticationCapability == that.mAuthenticationCapability &&
                mOutputCapability == that.mOutputCapability &&
                mCapability == that.mCapability;
    }

    @Override
    public int hashCode() {

        return Objects.hash(mOperatingEnvironment, mAuthenticationCapability, mOutputCapability, mCapability);
    }

    @Override
    public String toString() {
        return "TerminalCapabilities{" +
                "mOperatingEnvironment=" + mOperatingEnvironment +
                ", mAuthenticationCapability=" + mAuthenticationCapability +
                ", mOutputCapability=" + mOutputCapability +
                ", mCapability=" + mCapability +
                '}';
    }
}
