package com.tsys.payments.library.terminal.domain;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.terminal.enums.TerminalInteractionType;

public class TerminalInteractionRequest {

    private final TerminalInteractionType mInteractionType;

    private String[] mApplicationNames;
    private Long mFinalAmount;
    private Long mFinalSurchargeAmount;
    private CardData mCardData;

    public TerminalInteractionRequest(TerminalInteractionType interactionType) {
        mInteractionType = interactionType;
    }

    public TerminalInteractionType getInteractionType() {
        return mInteractionType;
    }

    public String[] getApplicationNames() {
        return mApplicationNames;
    }

    public void setApplicationNames(String[] applicationNames) {
        mApplicationNames = applicationNames;
    }

    public Long getFinalAmount() {
        return mFinalAmount;
    }

    public void setFinalAmount(Long finalAmount) {
        mFinalAmount = finalAmount;
    }

    public void setFinalSurchargeAmount(Long surchargeAmount){
        mFinalSurchargeAmount = surchargeAmount;
    }

    public Long getFinalSurchargeAmount(){
        return mFinalSurchargeAmount;
    }

    public CardData getCardData() {
        return mCardData;
    }

    public void setCardData(CardData cardData) {
        mCardData = cardData;
    }
}
