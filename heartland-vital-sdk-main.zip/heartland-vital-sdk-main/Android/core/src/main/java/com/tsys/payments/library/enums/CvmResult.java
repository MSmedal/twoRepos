package com.tsys.payments.library.enums;

import android.text.TextUtils;

import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvUtils;
import com.tsys.payments.library.utils.ByteUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Describes the type of cardholder verification that was performed and the result.
 */
public enum CvmResult {
    /**
     * PIN Entry was performed and successfully verified by the gateway and/or host.
     */
    PIN_ONLINE(new byte[]{0x01,0x42,0x02}),

    /**
     * Encrypted PIN Entry was performed and successfully verified by the ICC and EMV kernel.
     */
    PIN_OFFLINE_ENCR(new byte[]{0x02}),

    /**
     * PIN Entry was performed and successfully verified by the ICC and EMV kernel.
     */
    PIN_OFFLINE_PLAIN(new byte[]{0x03}),

    /**
     * Signature should be captured either electronically or on a printed receipt.
     */
    SIGNATURE_REQUIRED(new byte[]{0x5E,0x1E}),

    /**
     * No cardholder verification was performed.
     */
    NO_CVM_REQUESTED(new byte[]{0x1F,0x5f}),

    /**
     * The cardholder verification method and result are not available.
     */
    NOT_AVAILABLE(new byte[]{0x00,0x40,0x3F});

    public final byte[] masks;

    CvmResult(byte[] masks) {
        this.masks = masks;
    }

    /**
     * Decode the CVM result from the hexadecimal {@link String} representing the contents
     * of tag {@link EmvTagDescriptor#CVM_RESULT}
     * Example: 5E0000 = Signature always required.
     */
    @Nullable
    public static CvmResult fromTlv(@NonNull String cvmResultTlv) {
        // Handle 3F0000
        if (TextUtils.isEmpty(cvmResultTlv) || !ByteUtils.isHexString(cvmResultTlv)) {
            return NOT_AVAILABLE;
        }

        final byte cvmTypeByte = TlvUtils.hexStringToByteArray(cvmResultTlv)[0];
        for (CvmResult result : CvmResult.values()) {

            for(byte mask: result.masks) {
                if (mask == cvmTypeByte) {
                    return result;
                }
            }
        }

        return NO_CVM_REQUESTED;
    }
}
