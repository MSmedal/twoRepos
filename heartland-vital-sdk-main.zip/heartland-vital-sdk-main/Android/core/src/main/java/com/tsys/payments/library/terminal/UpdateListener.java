package com.tsys.payments.library.terminal;

import com.tsys.payments.library.enums.TerminalError;

import androidx.annotation.Nullable;

public interface UpdateListener {

    /**
     * Callback fired when terminal update is in progress.
     */
    void onProgress(@Nullable Double completionPercentage, @Nullable String progressMessage);

    /**
     * Callback fired when terminal update is successfully completed.
     */
    void onTerminalUpdateSuccess();

    /**
     * Callback fired when an error is encountered when trying to update terminal.
     *
     * @param error {@link TerminalError}
     * @param message Description of the error
     */
    void onTerminalUpdateError(TerminalError error, String message);
}
