package com.tsys.payments.library.enums;

import androidx.annotation.Nullable;

/**
 * Represents standardized communication control characters used for IO operations.
 */
public enum IoControlChar {

    /**
     * The start of the transaction message request or response.
     */
    STX(0x02),

    /**
     * The end of the transaction message request or response.
     */
    ETX(0x03),

    /**
     * The acknowledge symbol informs that the message is received correctly
     */
    ACK(0x06),

    /**
     * The not acknowledge symbol informs that the message is not received correctly.
     */
    NAK(0x15),

    /**
     * A communication control character used in data communication systems as a request for a
     * response from a remote station.
     */
    ENQ(0x05),

    /**
     * The field separator that used to separate the data segments.
     */
    FS(0x1C),

    /**
     * The Unit separator that used to separate certain sub-fields In Extend Data.
     */
    US(0x1F),

    /**
     * The Group separator that used to separate a group field.
     */
    GS(0x1D),

    /**
     * Record Separator.
     */
    RS(0x1E),

    /**
     * The end of transmission symbol informs that the transaction is complete.
     */
    EOT(0x04),

    COMMA(0x2C),

    COLON(0x3A),

    /**
     * Group separator for PassThru Data.
     */
    PIPE(0x7C);

    public final int value;

    IoControlChar(int value) {
        this.value = value;
    }

    public byte asByte() {
        return (byte)value;
    }

    public static String toHexString(IoControlChar controlChar) {
        return Integer.toHexString(controlChar.value);
    }

    @Nullable
    public static IoControlChar fromHexString(String hexString) {
        int intVal = Integer.valueOf(hexString, 16);

        for (IoControlChar controlChar : values()) {
            if (controlChar.value == intVal) {
                return controlChar;
            }
        }

        return null;
    }

}
