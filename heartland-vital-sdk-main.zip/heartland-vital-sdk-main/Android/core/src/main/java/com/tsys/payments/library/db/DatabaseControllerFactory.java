package com.tsys.payments.library.db;

import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.enums.GatewayType;

import androidx.annotation.Nullable;

/**
 * Factory interface used to build a new instance of a {@link DatabaseController} implementation.
 */
public interface DatabaseControllerFactory {
    /**
     * @param databaseConfig {@link DatabaseConfig} to be followed when creating the database.
     * @return Concrete database implementation matching the provided {@param databaseConfiguration}.
     */
    @Nullable
    DatabaseController create(DatabaseConfig databaseConfig) throws
            InitializationException;

    GatewayType[] getSupportedGateways();
}
