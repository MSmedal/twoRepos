package com.tsys.payments.library.enums;

public enum CardholderInteractionType {
    /**
     * Multiple supported Applications (AIDs) are present on the inserted card and the cardholder
     * must select which Application to process the payment with.
     */
    EMV_APPLICATION_SELECTION,

    /**
     * Cardholder must submit the final transaction amount so that the terminal can continue
     * transaction processing.
     */
    FINAL_AMOUNT_REQUEST,

    /**
     * Cardholder must confirm the amount to be authorized prior to host processing takes place.
     */
    FINAL_AMOUNT_CONFIRMATION,

    /**
     * Cardholder must confirm intent to proceed with host processing after card detection and
     * processing is completed for MSR and EMV transactions.
     */
    REQUEST_PROCEED_HOST_PROCESSING,

    /**
     * Additional data was requested by the host because the processed card is a commercial card.
     */
    COMMERCIAL_CARD_DATA_ENTRY,

    /**
     * Cardholder must confirm the surcharge fee.
     */
    REQUEST_SURCHARGE_CONFIRMATION
}
