package com.tsys.payments.library.enums;

/**
 * Settings that can be queried and/or updated by the consumer.
 */
public enum TerminalSettingType {

    /**
     * Length of inactivity time that can elapse before the device is
     * put into Standby Mode.
     */
    NORMAL_MODE_TIMEOUT,

    /**
     * Length of inactivity time that can elapse before the device is
     * powered off.
     */
    STANDBY_MODE_TIMEOUT,

    /**
     * Length of time that can elapse before a Timeout error is thrown
     * during Bluetooth discovery.
     */
    BLUETOOTH_DISCOVERY_TIMEOUT

}
