package com.tsys.payments.library.enums;

import com.tsys.payments.library.gateway.enums.GatewayAction;

import androidx.annotation.Nullable;

public enum TransactionType {
    SALE,
    AUTH,
    CAPTURE,
    FORCED_AUTH,
    VOID,
    PARTIAL_REFUND,
    REFUND,
    TIP_ADJUST,
    BATCH_CLOSE,
    VERIFY,
    SVA,
    TOKENIZE;

    @Nullable
    public static TransactionType fromGatewayAction(@Nullable GatewayAction action) {
        if (action == null) return null;

        switch (action) {
            case SALE:
                return SALE;
            case TIP_ADJUST:
                return TIP_ADJUST;
            case AUTH:
                return AUTH;
            case CAPTURE:
                return CAPTURE;
            case REFUND:
                return REFUND;
            case PARTIAL_REFUND:
                return PARTIAL_REFUND;
            case VOID:
                return VOID;
            case FORCE_AUTH:
                return FORCED_AUTH;
            case TOKENIZE_CARD:
                return TOKENIZE;
            case BATCH_CLOSE:
                return BATCH_CLOSE;
            case VERIFY:
                return VERIFY;
            default:
                return null;
        }
    }
}
