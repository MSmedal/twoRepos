package com.tsys.payments.library.domain;

import com.google.gson.annotations.SerializedName;

public class AidConfiguration {

    @SerializedName("aid")
    private Aid mAid;

    @SerializedName("terminal_app_version")
    private String mTerminalAppVersion;

    @SerializedName("lowest_supported_icc_app_version")
    private String mLowestSupportedIccAppVersion;

    @SerializedName("priority_index")
    private Integer mPriorityIndex;

    @SerializedName("application_selection_flags")
    private String mApplicationSelectionFlags;

    @SerializedName("floor_limit")
    private Long mFloorLimit;

    @SerializedName("cvm_limit")
    private Long mCvmLimit;

    @SerializedName("transaction_limit")
    private Long mTransactionLimit;

    @SerializedName("terminal_capabilities")
    private String mTerminalCapabilities;

    @SerializedName("tlv_data")
    private String mTlvData;

    @SerializedName("terminal_action_codes")
    private TerminalActionCodes mTerminalActionCodes;

    public String getTerminalAppVersion() {
        return mTerminalAppVersion;
    }

    public AidConfiguration setTerminalAppVersion(String terminalAppVersion) {
        mTerminalAppVersion = terminalAppVersion;
        return this;
    }

    public String getLowestSupportedIccAppVersion() {
        return mLowestSupportedIccAppVersion;
    }

    public AidConfiguration setLowestSupportedIccAppVersion(String lowestSupportedIccAppVersion) {
        mLowestSupportedIccAppVersion = lowestSupportedIccAppVersion;
        return this;
    }

    public Integer getPriorityIndex() {
        return mPriorityIndex;
    }

    public AidConfiguration setPriorityIndex(Integer priorityIndex) {
        mPriorityIndex = priorityIndex;
        return this;
    }

    public String getApplicationSelectionFlags() {
        return mApplicationSelectionFlags;
    }

    public AidConfiguration setApplicationSelectionFlags(String applicationSelectionFlags) {
        mApplicationSelectionFlags = applicationSelectionFlags;
        return this;
    }

    public Long getFloorLimit() {
        return mFloorLimit;
    }

    public AidConfiguration setFloorLimit(Long floorLimit) {
        mFloorLimit = floorLimit;
        return this;
    }

    public Long getCvmLimit() {
        return mCvmLimit;
    }

    public AidConfiguration setCvmLimit(Long cvmLimit) {
        mCvmLimit = cvmLimit;
        return this;
    }

    public Long getTransactionLimit() {
        return mTransactionLimit;
    }

    public AidConfiguration setTransactionLimit(Long transactionLimit) {
        mTransactionLimit = transactionLimit;
        return this;
    }

    public String getTerminalCapabilities() {
        return mTerminalCapabilities;
    }

    public AidConfiguration setTerminalCapabilities(String terminalCapabilities) {
        mTerminalCapabilities = terminalCapabilities;
        return this;
    }

    public String getTlvData() {
        return mTlvData;
    }

    public AidConfiguration setTlvData(String tlvData) {
        mTlvData = tlvData;
        return this;
    }

    public Aid getAid() {
        return mAid;
    }

    public AidConfiguration setAid(Aid aid) {
        mAid = aid;
        return this;
    }

    public TerminalActionCodes getTerminalActionCodes() {
        return mTerminalActionCodes;
    }

    public AidConfiguration setTerminalActionCodes(TerminalActionCodes terminalActionCodes) {
        mTerminalActionCodes = terminalActionCodes;
        return this;
    }

    @Override
    public String toString() {
        return "AidConfiguration{" +
                "mAid=" + mAid +
                ", mTerminalAppVersion='" + mTerminalAppVersion + '\'' +
                ", mLowestSupportedIccAppVersion='" + mLowestSupportedIccAppVersion + '\'' +
                ", mPriorityIndex='" + mPriorityIndex + '\'' +
                ", mApplicationSelectionFlags='" + mApplicationSelectionFlags + '\'' +
                ", mFloorLimit='" + mFloorLimit + '\'' +
                ", mCvmLimit='" + mCvmLimit + '\'' +
                ", mTransactionLimit='" + mTransactionLimit + '\'' +
                ", mTerminalCapabilities='" + mTerminalCapabilities + '\'' +
                ", mTlvData='" + mTlvData + '\'' +
                ", mTerminalActionCodes=" + mTerminalActionCodes +
                '}';
    }
}
