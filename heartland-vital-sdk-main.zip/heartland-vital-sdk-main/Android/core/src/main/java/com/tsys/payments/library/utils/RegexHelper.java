package com.tsys.payments.library.utils;

public class RegexHelper {
    public static final String ALPHA_NUMERIC_SPACE_REGEX = "^[a-zA-Z0-9 <>]*$";
}
