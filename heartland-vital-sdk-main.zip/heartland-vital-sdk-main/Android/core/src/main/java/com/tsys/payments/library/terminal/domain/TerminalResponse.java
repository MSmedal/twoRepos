package com.tsys.payments.library.terminal.domain;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.terminal.TerminalController;
import com.tsys.payments.library.terminal.enums.TerminalAction;
import com.tsys.payments.library.terminal.enums.TerminalDecisionType;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Objects;

/**
 * Represents data returned from a concrete {@link TerminalController} implementation.
 */
public class TerminalResponse {

    @NonNull
    private final TerminalAction mTerminalAction;

    private TerminalDecisionType mTerminalDecisionType;
    private CardData mCardData;
    private String mMessage;

    public TerminalResponse(@NonNull TerminalAction terminalAction) {
        mTerminalAction = terminalAction;
    }

    /**
     * @return {@link TerminalAction} actually performed during processing. This may differ from the requested action.
     */
    @NonNull
    public TerminalAction getTerminalAction() {
        return mTerminalAction;
    }

    /**
     * @return {@link TerminalDecisionType} final decision made by the terminal after verifying the
     * hosts response.
     */
    public TerminalDecisionType getTerminalDecisionType() {
        return mTerminalDecisionType;
    }

    /**
     * @param terminalDecisionType {@link TerminalDecisionType} final decision made by the terminal
     * after verifying the hosts response.
     */
    public void setTerminalDecisionType(TerminalDecisionType terminalDecisionType) {
        mTerminalDecisionType = terminalDecisionType;
    }

    /**
     * @return Friendly message produced by the {@link TerminalController} during processing.
     */
    @Nullable
    public String getMessage() {
        return mMessage;
    }

    /**
     * @param message Friendly message produced by the {@link TerminalController} during processing.
     */
    public void setMessage(@NonNull String message) {
        mMessage = message;
    }

    public CardData getCardData() {
        return mCardData;
    }

    public void setCardData(CardData cardData) {
        mCardData = cardData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TerminalResponse)) return false;
        TerminalResponse that = (TerminalResponse)o;
        return mTerminalAction == that.mTerminalAction &&
                mTerminalDecisionType == that.mTerminalDecisionType &&
                Objects.equals(mCardData, that.mCardData) &&
                Objects.equals(mMessage, that.mMessage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mTerminalAction, mTerminalDecisionType, mCardData, mMessage);
    }

    @Override
    public String toString() {
        return "TerminalResponse{" +
                "mTerminalAction=" + mTerminalAction +
                ", mTerminalDecisionType=" + mTerminalDecisionType +
                ", mMessage='" + mMessage + '\'' +
                '}';
    }
}
