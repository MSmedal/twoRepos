package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.AvsType;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.enums.CvmResult;
import com.tsys.payments.library.enums.EncryptionType;
import com.tsys.payments.library.enums.FallbackReason;
import com.tsys.payments.library.enums.LastChipRead;
import com.tsys.payments.library.tlv.TlvObject;

import java.util.List;

public class CardData {

    private String mTrack1;
    private String mTrack2;
    private String mTrack3;
    private String mEncryptedData;
    private String mPackedEncryptedData;
    private String mKsn;
    private List<TlvObject> mEmvTlvData;
    private String mPinBlock;
    private String mPinKsn;

    private String mPan;
    private String mExpirationDate;
    private String mCvv2;
    private String mPostalCode;
    private String mCardholderName;

    private Address mCardholderAddress;
    private AvsType mAvsType;
    
    private CardDataSourceType mCardDataSource;
    private FallbackReason mFallbackReason;
    private EncryptionType mEncryptionType;
    private LastChipRead mLastChipRead;
    private CardType mCardType;
    private CvmResult mCvmResult;

    public String getTrack1() {
        return mTrack1;
    }

    public void setTrack1(String track1) {
        mTrack1 = track1;
    }

    public String getTrack2() {
        return mTrack2;
    }

    public void setTrack2(String track2) {
        mTrack2 = track2;
    }

    public String getTrack3() {
        return mTrack3;
    }

    public void setTrack3(String track3) {
        mTrack3 = track3;
    }

    /**
     * @return Data produced from an Encrypted Mag Stripe read.
     */
    public String getEncryptedData() {
        return mEncryptedData;
    }

    public void setEncryptedData(String encryptedData) {
        mEncryptedData = encryptedData;
    }

    /**
     * @return a shortened version of the encrypted data.
     */
    public String getPackedEncryptedData() {
        return mPackedEncryptedData;
    }

    public void setPackedEncryptedData(String packedEncryptedData) {
        mPackedEncryptedData = packedEncryptedData;
    }

    /**
     * @return Serial number of the key used to encrypt the Track or EMV data received from a
     * payment terminal.
     */
    public String getKsn() {
        return mKsn;
    }

    public void setKsn(String ksn) {
        mKsn = ksn;
    }

    public List<TlvObject> getEmvTlvData() {
        return mEmvTlvData;
    }

    public void setEmvTlvData(List<TlvObject> emvTlvData) {
        mEmvTlvData = emvTlvData;
    }

    /**
     * @return PIN Block produced from an EPP when Online PIN verification is required.
     */
    public String getPinBlock() {
        return mPinBlock;
    }

    public void setPinBlock(String pinBlock) {
        mPinBlock = pinBlock;
    }

    /**
     * @return Serial number of the key used to encrypt the PIN Block when Online PIN verification
     * is required.
     */
    public String getPinKsn() {
        return mPinKsn;
    }

    public void setPinKsn(String pinKsn) {
        mPinKsn = pinKsn;
    }

    public String getPan() {
        return mPan;
    }

    public void setPan(String pan) {
        mPan = pan;
    }

    public String getExpirationDate() {
        return mExpirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        mExpirationDate = expirationDate;
    }

    public String getCvv2() {
        return mCvv2;
    }

    public void setCvv2(String cvv2) {
        mCvv2 = cvv2;
    }

    public String getPostalCode() {
        return mPostalCode;
    }

    public void setPostalCode(String postalCode) {
        mPostalCode = postalCode;
    }

    public Address getCardholderAddress() {
        return mCardholderAddress;
    }

    public void setCardholderAddress(Address cardholderAddress) {
        mCardholderAddress = cardholderAddress;
    }

    public CardDataSourceType getCardDataSource() {
        return mCardDataSource;
    }

    public void setCardDataSource(CardDataSourceType cardDataSource) {
        mCardDataSource = cardDataSource;
    }

    public EncryptionType getEncryptionType() {
        return mEncryptionType;
    }

    public void setEncryptionType(EncryptionType encryptionType) {
        mEncryptionType = encryptionType;
    }

    public AvsType getAvsType() {
        return mAvsType;
    }

    public void setAvsType(AvsType avsType) {
        mAvsType = avsType;
    }

    public String getCardholderName() {
        return mCardholderName;
    }

    public void setCardholderName(String cardholderName) {
        mCardholderName = cardholderName;
    }

    public FallbackReason getFallbackReason() {
        return mFallbackReason;
    }

    public void setFallbackReason(FallbackReason fallbackReason) {
        mFallbackReason = fallbackReason;
    }

    public CardType getCardType() {
        return mCardType;
    }

    public void setCardType(CardType cardType) {
        mCardType = cardType;
    }

    public LastChipRead getLastChipRead() {
        return mLastChipRead;
    }

    public void setLastChipRead(LastChipRead lastChipRead) {
        mLastChipRead = lastChipRead;
    }

    public CvmResult getCvmResult() {
        return mCvmResult;
    }

    public void setCvmResult(CvmResult cvmResult) {
        mCvmResult = cvmResult;
    }
}
