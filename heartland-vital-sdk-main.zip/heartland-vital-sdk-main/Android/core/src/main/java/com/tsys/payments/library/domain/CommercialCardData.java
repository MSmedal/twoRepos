package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.CommercialCardDataField;

import java.util.Map;
import java.util.Objects;

/**
 * Represents Level 2 and Level 3 card data required by the host when processing commercial cards.
 */
public class CommercialCardData {

    private Map<CommercialCardDataField, String> mCommercialCardDataValues;

    public Map<CommercialCardDataField, String> getCommercialCardDataValues() {
        return mCommercialCardDataValues;
    }

    public void setCommercialCardDataValues(
            Map<CommercialCardDataField, String> commercialCardDataValues) {
        mCommercialCardDataValues = commercialCardDataValues;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CommercialCardData that = (CommercialCardData)o;
        return Objects.equals(mCommercialCardDataValues, that.mCommercialCardDataValues);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mCommercialCardDataValues);
    }

    @Override
    public String toString() {
        return "CommercialCardData{" +
                "mCommercialCardDataValues=" + mCommercialCardDataValues +
                '}';
    }
}
