package com.tsys.payments.library.enums;

public enum TerminalType {
    BBPOS_C2X(true),
    INGENICO_RP350(true),
    INGENICO_RP450C(true),
    INGENICO_RP45BT(true),
    ROAM_G5X_TSYS_DECRYPTION(false),
    INGENICO_MOBY_3000(true),
    INGENICO_MOBY_3000_PROPAY(true),
    INGENICO_MOBY_8500(true),
    INGENICO_MOBY_5500(true),
    MAGTEK_ADYNAMO(false);

    public final boolean emvCapable;

    TerminalType(boolean emvCapable) {
        this.emvCapable = emvCapable;
    }
}
