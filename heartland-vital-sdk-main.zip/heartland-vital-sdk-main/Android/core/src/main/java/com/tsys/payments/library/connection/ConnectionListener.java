package com.tsys.payments.library.connection;

import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.exceptions.Error;

public interface ConnectionListener {

    /**
     * Invoked when the configured terminal has successfully connected.
     *
     * @param terminalInfo Contains information regarding the connected terminal.
     */
    void onConnected(TerminalInfo terminalInfo);

    /**
     * Invoked when the terminal has disconnected.
     */
    void onDisconnected();

    /**
     * Invoked when an unrecoverable error is encountered while connecting.
     *
     * @param error {@link Error} containing details regarding the error encountered.
     */
    void onError(Error error);
}
