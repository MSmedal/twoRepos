package com.tsys.payments.library.terminal.domain;

import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.terminal.enums.TerminalInteractionType;

import androidx.annotation.Nullable;

import java.util.Objects;

public class TerminalInteractionResult {

    private TerminalInteractionType mInteractionType;
    private Integer mSelectedApplicationIndex;
    private Boolean mFinalAmountConfirmed;
    private Boolean mContinueHostProcessingConfirmed;
    private Long mFinalAmount;
    private Long mTipAmount;
    private Long mCashbackAmount;
    private Long mSurchargeAmount;

    private GatewayResponse mGatewayResponse;

    public TerminalInteractionType getInteractionType() {
        return mInteractionType;
    }

    public void setInteractionType(TerminalInteractionType interactionType) {
        mInteractionType = interactionType;
    }

    public Integer getSelectedApplicationIndex() {
        return mSelectedApplicationIndex;
    }

    public void setSelectedApplicationIndex(Integer selectedApplicationIndex) {
        mSelectedApplicationIndex = selectedApplicationIndex;
    }

    public Boolean getFinalAmountConfirmed() {
        return mFinalAmountConfirmed;
    }

    public void setFinalAmountConfirmed(Boolean finalAmountConfirmed) {
        mFinalAmountConfirmed = finalAmountConfirmed;
    }

    public GatewayResponse getGatewayResponse() {
        return mGatewayResponse;
    }

    public void setGatewayResponse(GatewayResponse gatewayResponse) {
        mGatewayResponse = gatewayResponse;
    }

    public Long getFinalAmount() {
        return mFinalAmount;
    }

    public void setFinalAmount(Long finalAmount) {
        mFinalAmount = finalAmount;
    }

    public Long getTipAmount() {
        return mTipAmount;
    }

    public void setTipAmount(Long tipAmount) {
        mTipAmount = tipAmount;
    }

    public Long getCashbackAmount() {
        return mCashbackAmount;
    }

    public void setCashbackAmount(Long cashbackAmount) {
        mCashbackAmount = cashbackAmount;
    }

    public Long getSurchargeAmount() {
        return mSurchargeAmount;
    }

    public void setSurchargeAmount(@Nullable Long surchargeAmount) {
        mSurchargeAmount = surchargeAmount;
    }

    public Boolean getContinueHostProcessingConfirmed() {
        return mContinueHostProcessingConfirmed;
    }

    public void setContinueHostProcessingConfirmed(Boolean continueHostProcessingConfirmed) {
        mContinueHostProcessingConfirmed = continueHostProcessingConfirmed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TerminalInteractionResult that = (TerminalInteractionResult)o;
        return mInteractionType == that.mInteractionType &&
                Objects.equals(mSelectedApplicationIndex, that.mSelectedApplicationIndex) &&
                Objects.equals(mFinalAmountConfirmed, that.mFinalAmountConfirmed) &&
                Objects.equals(mContinueHostProcessingConfirmed,
                        that.mContinueHostProcessingConfirmed) &&
                Objects.equals(mFinalAmount, that.mFinalAmount) &&
                Objects.equals(mTipAmount, that.mTipAmount) &&
                Objects.equals(mCashbackAmount, that.mCashbackAmount) &&
                Objects.equals(mSurchargeAmount, that.mSurchargeAmount) &&
                Objects.equals(mGatewayResponse, that.mGatewayResponse);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mInteractionType, mSelectedApplicationIndex, mFinalAmountConfirmed,
                mContinueHostProcessingConfirmed, mFinalAmount, mTipAmount, mCashbackAmount,
                mSurchargeAmount, mGatewayResponse);
    }

    @Override
    public String toString() {
        return "TerminalInteractionResult{" +
                "mInteractionType=" + mInteractionType +
                ", mSelectedApplicationIndex=" + mSelectedApplicationIndex +
                ", mFinalAmountConfirmed=" + mFinalAmountConfirmed +
                ", mContinueHostProcessingConfirmed=" + mContinueHostProcessingConfirmed +
                ", mFinalAmount=" + mFinalAmount +
                ", mTipAmount=" + mTipAmount +
                ", mCashbackAmount=" + mCashbackAmount +
                ", mSurchargeAmount=" + mSurchargeAmount +
                ", mGatewayResponse=" + mGatewayResponse +
                '}';
    }
}
