package com.tsys.payments.library.enums;

public enum CardType {

    VISA,

    MASTERCARD,

    AMERICAN_EXPRESS,

    DISCOVER,

    JCB,

    HPS_GIFT,

    UNKNOWN
}
