/*

 Copyright 2014 iMobile3, LLC. All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, is permitted provided that adherence to the following
 conditions is maintained. If you do not agree with these terms,
 please do not use, install, modify or redistribute this software.

 1. Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.

 2. Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY IMOBILE3, LLC "AS IS" AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 EVENT SHALL IMOBILE3, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

package com.tsys.payments.library.utils;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class CreditCardHelper {
    private static final String NUMERIC_STRING_PATTERN = "^[0-9]+$";

    private static List<Integer> sBinRangeVisa = new ArrayList<>();
    private static List<Integer> sBinRangeMastercard = new ArrayList<>();
    private static List<Integer> sBinRangeAmericanExpress = new ArrayList<>();
    private static List<Integer> sBinRangeDiscover = new ArrayList<>();
    private static List<Integer> sBinRangeDinersClub = new ArrayList<>();
    private static List<Integer> sBinRangeJCB = new ArrayList<>();
    private static List<Integer> sBinRangeHPSGiftCard = new ArrayList<>();

    static {
        sBinRangeVisa.add(4);

        sBinRangeMastercard.addAll(makeSequence(51, 55));
        sBinRangeMastercard.addAll(makeSequence(56, 58));
        sBinRangeMastercard.addAll(makeSequence(2221, 2720));

        sBinRangeAmericanExpress.add(34);
        sBinRangeAmericanExpress.add(37);

        sBinRangeDiscover.add(6011);
        sBinRangeDiscover.add(65);
        sBinRangeDiscover.addAll(makeSequence(622126, 622925));
        sBinRangeDiscover.addAll(makeSequence(644, 649));

        sBinRangeDinersClub.addAll(makeSequence(300, 305));
        sBinRangeDinersClub.add(309);
        sBinRangeDinersClub.add(36);

        sBinRangeJCB.addAll(makeSequence(3528, 3589));

        //For HPS Gift Cards
        sBinRangeHPSGiftCard.addAll(makeSequence(502244000, 502244999));
        sBinRangeHPSGiftCard.addAll(makeSequence(603359000, 603359999));
        sBinRangeHPSGiftCard.addAll(makeSequence(627720000, 627720999));
        sBinRangeHPSGiftCard.addAll(makeSequence(708355000, 708355999));
    }

    private CreditCardHelper() {
        // To prevent instantiation.
    }

    public static boolean isVisa(@Nullable String cardNumber) {
        if (!TextUtils.isEmpty(cardNumber)) {
            return inBinRange(sBinRangeVisa, cardNumber);
        }
        return false;
    }

    public static boolean isMasterCard(@Nullable String cardNumber) {
        if (!TextUtils.isEmpty(cardNumber)) {
            return inBinRange(sBinRangeMastercard, cardNumber);
        }
        return false;
    }

    public static boolean isAmericanExpress(@Nullable String cardNumber) {
        if (!TextUtils.isEmpty(cardNumber)) {
            return inBinRange(sBinRangeAmericanExpress, cardNumber);
        }
        return false;
    }

    public static boolean isDiscover(@Nullable String cardNumber) {
        if (!TextUtils.isEmpty(cardNumber)) {
            return inBinRange(sBinRangeDiscover, cardNumber);
        }
        return false;
    }

    public static boolean isDinersClub(@Nullable String cardNumber) {
        if (!TextUtils.isEmpty(cardNumber)) {
            return inBinRange(sBinRangeDinersClub, cardNumber);
        }
        return false;
    }

    public static boolean isJcb(@Nullable String cardNumber) {
        if (!TextUtils.isEmpty(cardNumber)) {
            return inBinRange(sBinRangeJCB, cardNumber);
        }
        return false;
    }

    public static boolean isHPSGiftCard(@Nullable String cardNumber) {
        if (!TextUtils.isEmpty(cardNumber)) {
            return inBinRange(sBinRangeHPSGiftCard, cardNumber);
        }
        return false;
    }

    public static boolean isNumberValid(@Nullable String cardNumber) {
        return cardNumber != null
                && cardNumber.length() == getNumberLengthBasedOnType(cardNumber)
                && luhnValidate(cardNumber);
    }

    public static boolean isCvnValid(@Nullable String cvnNumber, @Nullable String cardNumber) {
        return cvnNumber != null
                && cvnNumber.length() == getCvnLengthBasedOnType(cardNumber);
    }

    // TODO add override to accept a CreditCardType enum
    public static int getNumberLengthBasedOnType(@Nullable String cardNumber) {
        if (cardNumber != null) {
            if (isVisa(cardNumber)) {
                return 16;
            } else if (isMasterCard(cardNumber)) {
                return 16;
            } else if (isAmericanExpress(cardNumber)) {
                return 15;
            } else if (isDiscover(cardNumber)) {
                return 16;
            } else if (isDinersClub(cardNumber)) {
                return 14;
            }
        }

        return 16; // general maximum allowed for unknown cards
    }

    // TODO add override to accept a CreditCardType enum
    public static int getCvnLengthBasedOnType(@Nullable String cardNumber) {
        if (cardNumber != null) {
            if (isVisa(cardNumber)) {
                return 3;
            } else if (isMasterCard(cardNumber)) {
                return 3;
            } else if (isAmericanExpress(cardNumber)) {
                return 4;
            } else if (isDiscover(cardNumber)) {
                return 3;
            } else if (isDinersClub(cardNumber)) {
                return 3;
            }
        }

        return 3; // general maximum allowed for unknown cards
    }

    public static boolean luhnValidate(@Nullable String cardNumber) {
        if (cardNumber == null || !isNumericString(cardNumber)) {
            return false;
        }

        int sum = 0;
        boolean alternate = false;
        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(cardNumber.substring(i, i + 1));
            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }
        return (sum % 10 == 0);
    }

    public static boolean isNumericString(@NonNull String input) {
        Pattern numericPattern = Pattern.compile(NUMERIC_STRING_PATTERN);
        Matcher numericMatcher = numericPattern.matcher(input);
        return numericMatcher.matches();
    }

    public static boolean isCardExpDateValid(@Nullable String dateString) {
        // TODO this method should use isCardExpDateValid(String, String) instead of duplicating logic
        if (dateString == null) {
            return false;
        }

        int currentYearLast2Digits = Calendar.getInstance().get(Calendar.YEAR) - 2000;
        int currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1;
        if (dateString.length() < 5) {
            return false;
        } else if (Integer.parseInt(dateString.split("/")[0]) < 1) {
            return false;
        } else if (Integer.parseInt(dateString.split("/")[0]) > 12) {
            return false;
        } else if (Integer.parseInt(dateString.split("/")[1]) < currentYearLast2Digits) {
            return false;
        } else if (Integer.parseInt(dateString.split("/")[1]) > (currentYearLast2Digits + 10)) {
            return false;
        } else if (Integer.parseInt(dateString.split("/")[0]) < currentMonth
                && Integer.parseInt(dateString.split("/")[1]) <= currentYearLast2Digits) {
            return false;
        }
        return true;
    }

    private static List<Integer> makeSequence(int begin, int end) {
        List<Integer> sequence = new ArrayList<>();
        for (int i = begin; i <= end; i++) {
            sequence.add(i);
        }
        return sequence;
    }

    private static boolean inBinRange(List<Integer> binRange, String cardNumber) {
        for (int bin : binRange) {
            if (cardNumber.startsWith(String.valueOf(bin))) {
                return true;
            }
        }
        return false;
    }

    public static boolean isCardExpDateValid(@Nullable String monthString,
            @Nullable String yearString) {

        if (monthString == null || yearString == null) {
            return false;
        }

        int currentYearLast2Digits = Calendar.getInstance().get(Calendar.YEAR) - 2000;
        int currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1;
        if (monthString.trim().length() == 0) {
            return false;
        } else if (yearString.trim().length() == 0) {
            return false;
        } else if (Integer.parseInt(monthString) < 1) {
            return false;
        } else if (Integer.parseInt(monthString) > 12) {
            return false;
        } else if (Integer.parseInt(yearString) < currentYearLast2Digits) {
            return false;
        } else if (Integer.parseInt(yearString) > (currentYearLast2Digits + 10)) {
            return false;
        } else if (Integer.parseInt(monthString) < currentMonth
                && Integer.parseInt(yearString) <= currentYearLast2Digits) {
            return false;
        }
        return true;
    }

    public static String formatNumber(@NonNull String cardNumber, char spacerChar) {
        StringBuilder sb = new StringBuilder(cardNumber);
        if (isAmericanExpress(cardNumber)) {
            if (sb.length() >= 4) {
                sb.insert(4, spacerChar);
                if (sb.length() >= 11) {
                    sb.insert(11, spacerChar);
                }
            }
        } else {
            if (sb.length() >= 4) {
                sb.insert(4, spacerChar);
                if (sb.length() >= 9) {
                    sb.insert(9, spacerChar);
                    if (sb.length() >= 14) {
                        sb.insert(14, spacerChar);
                    }
                }
            }
        }

        return sb.toString();
    }

    public static String obfuscateNumber(@NonNull String cardNumber, int firstDigits,
            int lastDigits, char fillerChar, boolean showSpaces) {

        cardNumber = cardNumber.replaceAll("[^\\d]", String.valueOf(fillerChar));

        String first, last;
        int fillerLength;
        StringBuilder sb = new StringBuilder();

        if (cardNumber.length() < (firstDigits + lastDigits)) {
            first = "";
            if (cardNumber.length() <= lastDigits) {
                last = cardNumber;
            } else {
                last = cardNumber.substring(cardNumber.length() - lastDigits);
            }
            fillerLength = cardNumber.length() - lastDigits;
        } else {
            first = cardNumber.substring(0, firstDigits);
            last = cardNumber.substring(cardNumber.length() - lastDigits);
            fillerLength = cardNumber.length() - (firstDigits + lastDigits);
        }

        sb.append(first);
        for (int i = 0; i < fillerLength; i++) {
            sb.append(fillerChar);
        }
        sb.append(last);

        if (showSpaces) {
            if (isAmericanExpress(cardNumber)) {
                if (sb.length() >= 4) {
                    sb.insert(4, ' ');
                    if (sb.length() >= 11) {
                        sb.insert(11, ' ');
                    }
                }
            } else {
                if (sb.length() >= 4) {
                    sb.insert(4, ' ');
                    if (sb.length() >= 9) {
                        sb.insert(9, ' ');
                        if (sb.length() >= 14) {
                            sb.insert(14, ' ');
                        }
                    }
                }
            }
        }

        return sb.toString();
    }

    /**
     * Returns the card type from the PAN.
     *
     * @param pan {@link String} referencing the Personal Account Number associated with the card.
     * @return {@link CardType} indicating the card brand the account belongs to.
     */
    @NonNull
    public static CardType typeFromPan(@NonNull String pan) {
        if (TextUtils.isEmpty(pan)) return CardType.UNKNOWN;
        if (CreditCardHelper.isAmericanExpress(pan)) {
            return CardType.AMERICAN_EXPRESS;
        } else if (CreditCardHelper.isVisa(pan)) {
            return CardType.VISA;
        } else if (CreditCardHelper.isMasterCard(pan)) {
            return CardType.MASTERCARD;
        } else if (CreditCardHelper.isDinersClub(pan) ||
                CreditCardHelper.isDiscover(pan)) {
            return CardType.DISCOVER;
        } else if (CreditCardHelper.isHPSGiftCard(pan)) {
            return CardType.HPS_GIFT;
        } else {
            return CardType.UNKNOWN;
        }
    }

    /**
     * Examines the data from a card to determine the card type. Works with card data sourced from the chip on an ICC
     * card, magstripe or keyed card data.
     *
     * @param cardData {@link CardData} object containing the payment source information.
     * @return {@link CardType} indicating the card brand the data is associated with.
     */
    @NonNull
    public static CardType typeFromCardData(@NonNull CardData cardData) {
        if (cardData == null) return CardType.UNKNOWN;
        if (!TextUtils.isEmpty(cardData.getPan())) {
            return typeFromPan(cardData.getPan());
        } else if (cardData.getEmvTlvData() != null) {
            for (TlvObject tlvObject : cardData.getEmvTlvData()) {
                if (tlvObject != null && tlvObject.getTagDescriptor() == EmvTagDescriptor.PAN) {
                    if (!TextUtils.isEmpty(tlvObject.getValueAsHexString(false))) {
                        return typeFromPan(tlvObject.getValueAsHexString(false));
                    }
                }
            }
        }

        return CardType.UNKNOWN;
    }

    /**
     * Examines the data from a card to determine the PAN if available. The PAN could come from the object as a top
     * level member object or contained within the EMV tags.
     *
     * @param cardData {@link CardData} object containing the payment source information.
     * @return {@link String} indicating the PAN.
     */
    @NonNull
    public static String getPanFromCardData(@NonNull CardData cardData) {
        if (cardData == null) return "";
        if (!TextUtils.isEmpty(cardData.getPan())) {
            return cardData.getPan();
        } else if (cardData.getEmvTlvData() != null) {
            for (TlvObject tlvObject : cardData.getEmvTlvData()) {
                if (tlvObject != null && tlvObject.getTagDescriptor() == EmvTagDescriptor.PAN) {
                    if (!TextUtils.isEmpty(tlvObject.getValueAsHexString(false))) {
                        return tlvObject.getValueAsHexString(false).replaceAll("[^\\d]", "");
                    }
                }
            }
        }

        return "";
    }

    @NonNull
    public static String last4digits(@NonNull String cardNumber) {
        if (cardNumber.length() < 4) {
            return cardNumber;
        }
        return cardNumber.substring(cardNumber.length() - 4, cardNumber.length());
    }
}