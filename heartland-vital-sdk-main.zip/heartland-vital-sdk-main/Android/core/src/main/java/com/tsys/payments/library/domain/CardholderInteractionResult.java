package com.tsys.payments.library.domain;

import com.tsys.payments.library.enums.CardholderInteractionType;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Simple class that encapsulates possible interaction result data when cardholder interaction is
 * necessary.
 */
public class CardholderInteractionResult {

    private final CardholderInteractionType mCardholderInteractionType;

    private Integer mSelectedAidIndex;
    private Boolean mFinalAmountConfirmed;
    private Long mFinalAmount;
    private Long mTipAmount;
    private Long mCashbackAmount;
    private Boolean mContinueHostProcessingConfirmed;
    private Boolean mNetworkUnavailable;
    private CommercialCardData mCommercialCardData;
    private HostProcessingAdditionalData mHostProcessingAdditionalData;

    public CardholderInteractionResult(
            CardholderInteractionType cardholderInteractionType) {
        mCardholderInteractionType = cardholderInteractionType;
    }

    /**
     * @return {@link CardholderInteractionType} being responded to.
     */
    public CardholderInteractionType getCardholderInteractionType() {
        return mCardholderInteractionType;
    }

    /**
     * @return Index of the Application (AID) selected by the cardholder in response to {@link
     * CardholderInteractionType#EMV_APPLICATION_SELECTION}.
     */
    public Integer getSelectedAidIndex() {
        return mSelectedAidIndex;
    }

    /**
     * @param selectedAidIndex Index of the Application (AID) selected by the cardholder in response
     * to {@link CardholderInteractionType#EMV_APPLICATION_SELECTION}.
     */
    public void setSelectedAidIndex(Integer selectedAidIndex) {
        mSelectedAidIndex = selectedAidIndex;
    }

    /**
     * @return Final amount that the terminal will need to continue transaction processing. This is
     * sent in response to {@link CardholderInteractionType#FINAL_AMOUNT_REQUEST}
     */
    public Long getFinalAmount() {
        return mFinalAmount;
    }

    /**
     * @param finalAmount Final amount that the terminal will need to continue transaction
     * processing set by the cardholder in response to {@link
     * CardholderInteractionType#FINAL_AMOUNT_REQUEST}
     */
    public void setFinalAmount(Long finalAmount) {
        mFinalAmount = finalAmount;
    }

    /**
     * @return Tip amount that the terminal may use for transaction processing. This is sent in
     * response to {@link CardholderInteractionType#FINAL_AMOUNT_REQUEST}. The tip amount is not
     * required by the terminal and is an optional discretionary value.
     */
    public Long getTipAmount() {
        return mTipAmount;
    }

    /**
     * @param tipAmount Tip amount that the terminal may use for transaction processing. This is set
     * by the cardholder in response to {@link CardholderInteractionType#FINAL_AMOUNT_REQUEST}.
     * The tip amount is not required by the terminal and is an optional discretionary value.
     */
    public void setTipAmount(Long tipAmount) {
        mTipAmount = tipAmount;
    }

    /**
     * @return Cashback amount that the terminal may use for transaction processing. This is sent in
     * response to {@link CardholderInteractionType#FINAL_AMOUNT_REQUEST}. The cashback amount is
     * not required by the terminal and is an optional discretionary value. Cashback only applies
     * when processing with a debit card.
     */
    public Long getCashbackAmount() {
        return mCashbackAmount;
    }

    /**
     * @param cashbackAmount Cashback amount that the terminal may use for transaction processing.
     * This is set by the cardholder in response to {@link CardholderInteractionType#FINAL_AMOUNT_REQUEST}.
     * The cashback amount is not required by the terminal and is an optional discretionary value.
     * Cashback only applies when processing with a debit card.
     */
    public void setCashbackAmount(Long cashbackAmount) {
        mCashbackAmount = cashbackAmount;
    }

    /**
     * @return Whether the cardholder approved the final transaction amount or not in response to
     * {@link CardholderInteractionType#FINAL_AMOUNT_CONFIRMATION}
     */
    public Boolean getFinalAmountConfirmed() {
        return mFinalAmountConfirmed;
    }

    /**
     * @param finalAmountConfirmed Whether the cardholder approved the final transaction amount or
     * not in response to {@link CardholderInteractionType#FINAL_AMOUNT_CONFIRMATION}
     */
    public void setFinalAmountConfirmed(Boolean finalAmountConfirmed) {
        mFinalAmountConfirmed = finalAmountConfirmed;
    }

    /**
     * @return {@link CommercialCardData} provided by the merchant and cardholder when additional
     * Level 2 or Level 3 data is required by the processor.
     */
    public CommercialCardData getCommercialCardData() {
        return mCommercialCardData;
    }

    /**
     * @param commercialCardData {@link CommercialCardData} with additional data required for
     * commercial cards to receive Level 2 and/or Level 3 interchange processing rates.
     */
    public void setCommercialCardData(CommercialCardData commercialCardData) {
        mCommercialCardData = commercialCardData;
    }

    /**
     * @return {@link Boolean} indicating that the terminal shall proceed with host processing after
     * the card has been swiped for MSR transactions or an ARQC has been requested in the 1st GEN AC
     * step for EMV transactions.
     */
    public Boolean getContinueHostProcessingConfirmed() {
        return mContinueHostProcessingConfirmed;
    }

    /**
     * @param continueHostProcessingConfirmed {@link Boolean} provided by the merchant and
     * cardholder indicating that the terminal shall proceed with host processing after the card has
     * been swiped  for MSR transactions on an ARQC has been requested in 1st GEN AC for EMV
     * transactions.
     */
    public void setContinueHostProcessingConfirmed(Boolean continueHostProcessingConfirmed) {
        mContinueHostProcessingConfirmed = continueHostProcessingConfirmed;
    }

    /**
     * @return {@link HostProcessingAdditionalData} containing additional data supplied by the cardholder
     * before the transaction is sent online for authorization but after the card data has been read.
     */
    public HostProcessingAdditionalData getHostProcessingAdditionalData() {
        return mHostProcessingAdditionalData;
    }

    /**
     * @param hostProcessingAdditionalData {@link HostProcessingAdditionalData} optional extra
     * data provided by the cardholder in response to a {@link CardholderInteractionType#REQUEST_PROCEED_HOST_PROCESSING}
     * request. This allows the user to provide additional data that should be sent with the authorization
     * request after the card has been processed by the cardholder.
     */
    public void setHostProcessingAdditionalData(
            HostProcessingAdditionalData hostProcessingAdditionalData) {
        mHostProcessingAdditionalData = hostProcessingAdditionalData;
    }

    /**
     * @return True if the payment application has lost connectivity. This should be used in conjunction with
     * {@link CardholderInteractionType#REQUEST_PROCEED_HOST_PROCESSING} to indicate that there is no network available.
     * This will signal to the transaction manager to initiate the store offline transaction flow if the configuration
     * supports offline storage.
     */
    public Boolean getNetworkUnavailable() {
        return mNetworkUnavailable;
    }

    /**
     * @param networkUnavailable Set to true by the payment application to indicate that there is no network
     * connectivity. This is checked when the {@link CardholderInteractionType#REQUEST_PROCEED_HOST_PROCESSING}
     * is set as the type.
     */
    public void setNetworkUnavailable(Boolean networkUnavailable) {
        mNetworkUnavailable = networkUnavailable;
    }

    /**
     * Contains additional fields that can be captured as part of the authorization request for swipe
     * and EMV transactions before the transaction is sent online for authorization. This should be used
     * in conjunction with {@link CardholderInteractionType#REQUEST_PROCEED_HOST_PROCESSING}.
     */
    public static class HostProcessingAdditionalData {
        private String mEmail;
        private boolean mGenerateToken;
        private String mInvoiceNumber;
        private String mPostalCode;
        private String mRequestIdentifier;
        @Nullable
        private String mSignatureFileLocation;

        public String getEmail() {
            return mEmail;
        }

        public void setEmail(String email) {
            mEmail = email;
        }

        public boolean isGenerateToken() {
            return mGenerateToken;
        }

        public void setGenerateToken(boolean generateToken) {
            mGenerateToken = generateToken;
        }

        public String getInvoiceNumber() {
            return mInvoiceNumber;
        }

        public void setInvoiceNumber(String invoiceNumber) {
            mInvoiceNumber = invoiceNumber;
        }

        public String getPostalCode() {
            return mPostalCode;
        }

        public void setPostalCode(String postalCode) {
            mPostalCode = postalCode;
        }

        public String getRequestIdentifier() {
            return mRequestIdentifier;
        }

        public void setRequestIdentifier(String requestIdentifier) {
            mRequestIdentifier = requestIdentifier;
        }

        @Nullable
        public String getSignatureFileLocation() {
            return mSignatureFileLocation;
        }

        /**
         * Set the application-supplied location to the transaction's signature image file location
         * for applications that allow signature cardholder verification.
         *
         * @param signatureFileLocation {@link String} Full path to the signature on the device file
         *                              system.
         */
        public void setSignatureFileLocation(@Nullable String signatureFileLocation) {
            mSignatureFileLocation = signatureFileLocation;
        }
    }
}
