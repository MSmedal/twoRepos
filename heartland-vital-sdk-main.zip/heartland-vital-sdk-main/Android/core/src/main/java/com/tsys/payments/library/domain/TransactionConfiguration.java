package com.tsys.payments.library.domain;


import com.tsys.payments.library.enums.CountryCode;
import com.tsys.payments.library.enums.CurrencyCode;

import java.util.Objects;

/**
 * Simple class representing configurations applied to a Transaction.
 */
@SuppressWarnings({"WeakerAccess", "unused"})
public class TransactionConfiguration {

    public static final CurrencyCode DEFAULT_CURRENCY_CODE = CurrencyCode.USD;
    public static final CountryCode DEFAULT_COUNTRY_CODE = CountryCode.US;
    public static final int DEFAULT_CURRENCY_EXPONENT = 2;

    private boolean mSurchargeEnabled;
    private boolean mMagStripeEnabled;
    private boolean mChipEnabled;
    private boolean mQuickChipEnabled;
    private boolean mContactlessEnabled;
    private boolean mManualEntryEnabled;
    private boolean mUserConfirmationForHostProcessingEnabled;
    private CurrencyCode mCurrencyCode = DEFAULT_CURRENCY_CODE;
    private CountryCode mCountryCode = DEFAULT_COUNTRY_CODE;
    private Integer mCurrencyExponent = DEFAULT_CURRENCY_EXPONENT;

    /**
     *
     * @return {@code true} if Surcharge is enable for the transaction
     * otherwise false
     */
    public boolean isSurchargeEnabled(){
        return mSurchargeEnabled;
    }

    /**
     *
     * @param surchargeEnabled If the transaction should enable surcharge.
     */
    public void setSurchargeEnabled(boolean surchargeEnabled){
        mSurchargeEnabled = surchargeEnabled;
    }

    /**
     * @return {@code true} if the Mag Stripe Reader (MSR) should be enabled for this transaction,
     * otherwise false.
     */
    public boolean isMagStripeEnabled() {
        return mMagStripeEnabled;
    }

    /**
     * @param magStripeEnabled Whether the Mag Stripe Reader should be enabled for this transaction.
     */
    public void setMagStripeEnabled(boolean magStripeEnabled) {
        mMagStripeEnabled = magStripeEnabled;
    }

    /**
     * @return {@code true} if the Smart Card Reader (SCR) should be enabled for this transaction,
     * otherwise {@code false}.
     */
    public boolean isChipEnabled() {
        return mChipEnabled;
    }

    /**
     * @param chipEnabled Whether the Smart Card Reader (SCR) should be enabled for this
     * transaction.
     */
    public void setChipEnabled(boolean chipEnabled) {
        mChipEnabled = chipEnabled;
    }

    /**
     * @return true if quick chip is enabled for this transaction, false otherwise
     */
    public boolean isQuickChipEnabled() {
        return mQuickChipEnabled;
    }

    /**
     * @param quickChipEnabled if enabled,
     * After a request is sent to the host for online processing, the response received is not
     * validated on the terminal and is sent back to the consuming application
     */
    public void setQuickChipEnabled(boolean quickChipEnabled) {
        mQuickChipEnabled = quickChipEnabled;
    }

    /**
     * @return {@code true} if the Contactless Reader should be enabled for this transaction,
     * otherwise {@code false}.
     */
    public boolean isContactlessEnabled() {
        return mContactlessEnabled;
    }

    /**
     * @param contactlessEnabled Whether the Contactless Reader should be enabled for this
     * transaction.
     */
    public void setContactlessEnabled(boolean contactlessEnabled) {
        mContactlessEnabled = contactlessEnabled;
    }

    /**
     * @return {@code true} if the Keypad should be enabled for this transaction, otherwise
     * {@code false}
     */
    public boolean isManualEntryEnabled() {
        return mManualEntryEnabled;
    }

    /**
     * @param manualEntryEnabled Whether the Keypad should be enabled for this transaction.
     */
    public void setManualEntryEnabled(boolean manualEntryEnabled) {
        mManualEntryEnabled = manualEntryEnabled;
    }

    /**
     * @return {@link CurrencyCode} to use for this transaction.
     */
    public CurrencyCode getCurrencyCode() {
        return mCurrencyCode;
    }

    /**
     * @param currencyCode {@link CurrencyCode} to use for this transaction.
     */
    public void setCurrencyCode(CurrencyCode currencyCode) {
        mCurrencyCode = currencyCode;
    }

    /**
     * @return {@link CountryCode} to use for this transaction.
     */
    public CountryCode getCountryCode() {
        return mCountryCode;
    }

    /**
     * @param countryCode {@link CountryCode} to use for this transaction.
     */
    public void setCountryCode(CountryCode countryCode) {
        mCountryCode = countryCode;
    }

    /**
     * @return Number of digits expected to the right of the currency separator.
     */
    public Integer getCurrencyExponent() {
        return mCurrencyExponent;
    }

    /**
     * @param currencyExponent Number of digits expected to the right of the currency separator.
     */
    public void setCurrencyExponent(Integer currencyExponent) {
        mCurrencyExponent = currencyExponent;
    }

    public boolean isUserConfirmationForHostProcessingEnabled() {
        return mUserConfirmationForHostProcessingEnabled;
    }

    public void setUserConfirmationForHostProcessingEnabled(
            boolean userConfirmationForHostProcessingEnabled) {
        mUserConfirmationForHostProcessingEnabled = userConfirmationForHostProcessingEnabled;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransactionConfiguration that = (TransactionConfiguration)o;
        return mMagStripeEnabled == that.mMagStripeEnabled &&
                mChipEnabled == that.mChipEnabled &&
                mQuickChipEnabled == that.mQuickChipEnabled &&
                mContactlessEnabled == that.mContactlessEnabled &&
                mManualEntryEnabled == that.mManualEntryEnabled &&
                mUserConfirmationForHostProcessingEnabled ==
                        that.mUserConfirmationForHostProcessingEnabled &&
                mCurrencyCode == that.mCurrencyCode &&
                mCountryCode == that.mCountryCode &&
                Objects.equals(mCurrencyExponent, that.mCurrencyExponent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mMagStripeEnabled, mChipEnabled, mQuickChipEnabled, mContactlessEnabled,
                mManualEntryEnabled, mUserConfirmationForHostProcessingEnabled, mCurrencyCode,
                mCountryCode, mCurrencyExponent);
    }
}
