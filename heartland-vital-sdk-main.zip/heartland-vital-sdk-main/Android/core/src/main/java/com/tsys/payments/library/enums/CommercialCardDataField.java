package com.tsys.payments.library.enums;

import android.text.TextUtils;

import com.tsys.payments.library.utils.RegexHelper;

import androidx.annotation.Nullable;

/**
 * Indicates required or non-required fields that need to be provided by consumer application.
 * These fields will be requested by the sdk when we are in presence of a commercial card
 * transaction.
 */
public enum CommercialCardDataField {

    /**
     * Value used by the customer to identify an order. Issued by the buyer to the seller.
     */
    PURCHASE_ORDER_NUMBER("purchase_order_number", "Purchase Order #", "PO # (OPTIONAL)", 0, 17,
            RegexHelper.ALPHA_NUMERIC_SPACE_REGEX, false),

    /**
     * Used by {@link CardType#AMERICAN_EXPRESS} to obtain supportive information on a change from
     * a merchant.
     */
    SUPPLIER_REF_NUMBER("supplier_ref_number", "Supplier #", "Supplier # (OPTIONAL)", 0, 9,
            RegexHelper.ALPHA_NUMERIC_SPACE_REGEX, false),

    /**
     * Reference identifier supplied by the Commercial Card cardholder.
     */
    CUSTOMER_REF_ID("customer_ref_id", "Customer ID", "Customer ID (OPTIONAL)", 0, 17,
            RegexHelper.ALPHA_NUMERIC_SPACE_REGEX, false),

    /**
     * The postal code for the address to which the goods are being shipped.
     */

    SHIP_TO_ZIP("ship_to_zip", "Shipment ZIP", "Shipment ZIP (OPTIONAL)", 0, 10,
            null, false),

    /**
     * Displays descriptive information about a transaction on a customer's {@link
     * CardType#AMERICAN_EXPRESS} card statement.
     */
    CHARGE_DESCRIPTOR("charge_descriptor", "Charge Descriptor", "Charge Descriptor (OPTIONAL)", 0,
            40, RegexHelper.ALPHA_NUMERIC_SPACE_REGEX, false);

    public final String key;
    public final String name;
    public final String hint;
    public final int minLength;
    public final int maxLength;
    public final boolean required;
    public final String regex;

    CommercialCardDataField(String key, String name, String hint, int minLength, int maxLength,
            String regex, boolean required) {
        this.key = key;
        this.name = name;
        this.hint = hint;
        this.minLength = minLength;
        this.maxLength = maxLength;
        this.regex = regex;
        this.required = required;
    }

    @Nullable
    public static CommercialCardDataField fromKey(String key) {

        if (TextUtils.isEmpty(key)) {
            return null;
        }

        for (CommercialCardDataField field : values()) {
            if (field.key.equals(key)) {
                return field;
            }
        }
        return null;
    }
}
