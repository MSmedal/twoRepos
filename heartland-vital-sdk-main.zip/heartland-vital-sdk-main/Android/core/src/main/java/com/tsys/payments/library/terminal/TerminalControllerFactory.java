package com.tsys.payments.library.terminal;

import android.content.Context;

import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.TerminalType;

import androidx.annotation.Nullable;

/**
 * Simple Factory interface used to build concrete {@link TerminalController} implementations.
 */
public interface TerminalControllerFactory {

    /**
     * @return Array of supported {@link TerminalType}s supported by the concrete implementation, or
     * {@code null} if none are supported.
     */
    @Nullable
    TerminalType[] getSupportedTerminalTypes();

    /**
     * @param terminalType {@link TerminalType} to query for supported connection types.
     * @return Array of {@link ConnectionType}s supported by the provided {@param terminalType}.
     *
     * @throws IllegalArgumentException If the provided {@param terminalType} is not supported by
     * the concrete implementation.
     */
    @Nullable
    ConnectionType[] getSupportedConnectionTypes(TerminalType terminalType)
            throws IllegalArgumentException;

    /**
     * @param terminalConfiguration {@link TerminalConfiguration} used to initialize the desired
     * {@link TerminalController} implementation.
     * @param listener {@link TerminalListener} that will receive callbacks during processing.
     * @return Concrete {@link TerminalController} implementation matching the provided
     * {@param terminalConfiguration}.
     *
     * @throws IllegalArgumentException If any of the {@param terminalConfiguration} values are
     * invalid.
     */
    @Nullable
    TerminalController create(Context context, TerminalConfiguration terminalConfiguration,
            TransactionConfiguration transactionConfiguration,
            TerminalListener listener) throws IllegalArgumentException;
}
