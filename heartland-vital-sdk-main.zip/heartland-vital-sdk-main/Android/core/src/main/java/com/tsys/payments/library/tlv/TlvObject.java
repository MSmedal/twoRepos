package com.tsys.payments.library.tlv;

import android.util.Log;

import com.tsys.payments.library.utils.ByteUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Tag Length Value object as defined by ISO Standard.
 * <p>
 *
 * @see Tag
 * @see Length
 */
public class TlvObject {
    private static final String TAG = TlvObject.class.getSimpleName();
    private static final String ZERO_TAG_LENGTH = "00";

    private final Tag mTag;
    private Length mLen;
    private final byte[] mValue;
    protected final List<TlvObject> mInnerTlvs;

    /**
     * Creates constructed TLV
     *
     * @param tag tag
     * @param innerTlvs set of nested TLVs
     */
    public TlvObject(Tag tag, List<TlvObject> innerTlvs) {
        mTag = tag;
        mInnerTlvs = innerTlvs;
        mValue = null;
        if (mInnerTlvs == null) mLen = Length.newInstance(0);
    }

    /**
     * Creates primitive TLV
     *
     * @param tag tag
     * @param value value as byte[]
     */
    public TlvObject(Tag tag, byte[] value) {
        mTag = tag;
        mLen = Length.newInstance(value.length);
        mValue = value;
        mInnerTlvs = null;
    }

    public TlvObject(Tag tag, byte b) {
        this(tag, new byte[] {b});
    }

    public Tag getTag() {
        return mTag;
    }

    public EmvTagDescriptor getTagDescriptor() {
        EmvTagDescriptor emvTagDescriptor = EmvTagDescriptor.fromByteArray(mTag.asByteArray());
        return emvTagDescriptor;
    }

    public Length getValueLength() {
        return mLen;
    }

    public void addTlv(TlvObject tlvObject) {
        if (isPrimitive()) throw new IllegalStateException("addTlv non valid on PRIMITIVE Tag");
        mInnerTlvs.add(tlvObject);
    }

    public void removeTlv(TlvObject subTlv) {
        if (isPrimitive()) throw new IllegalStateException("removeTlv non valid on PRIMITIVE Tag");
        mInnerTlvs.remove(subTlv);
    }

    public List<TlvObject> getInnerTlvs() {
        return mInnerTlvs;
    }

    public byte[] getValue() {
        if (isPrimitive()) return mValue;
        throw new IllegalStateException("getLength() non valid on Constructed Tag");
    }

    public boolean isPrimitive() {
        return !mTag.isConstructed();
    }

    public boolean isConstructed() {
        return mTag.isConstructed();
    }

    public TlvObject find(EmvTagDescriptor emvTagDescriptor) {
        EmvTagDescriptor emvTagDescriptorResult = mTag.toTagDescriptor();
        if (emvTagDescriptorResult == emvTagDescriptor) {
            return this;
        }

        if (isConstructed() && mInnerTlvs != null) {
            for (TlvObject tlv : mInnerTlvs) {
                TlvObject tlvResult = tlv.find(emvTagDescriptor);
                if (tlvResult != null) return tlvResult;
            }
        }
        return null;
    }

    public List<TlvObject> findAll(EmvTagDescriptor emvTagDescriptor) {
        List<TlvObject> list = new ArrayList<>();
        if (isConstructed()) {
            if (emvTagDescriptor.equals(getTagDescriptor())) {
                list.add(this);
            } else {//We assume a Tag will never contain its same tagDescriptor. Otherwise this else would not exist
                for (TlvObject tlv : mInnerTlvs) {
                    list.addAll(tlv.findAll(emvTagDescriptor));
                }
            }
        } else if (emvTagDescriptor.equals(getTagDescriptor())) {
            list.add(this);
        }
        return list;
    }

    public TlvObject find(Tag tag) {
        if (tag.equals(getTag())) {
            return this;
        }

        if (isConstructed()) {
            for (TlvObject tlv : mInnerTlvs) {
                TlvObject ret = tlv.find(tag);
                if (ret != null) return ret;
            }
        }
        return null;
    }

    public List<TlvObject> findAll(Tag tag) {
        List<TlvObject> list = new ArrayList<>();
        if (isConstructed()) {
            if (tag.equals(mTag)) {
                list.add(this);
            } else {//We assume a Tag will never contain its same tag. Otherwise this else would not exist
                for (TlvObject tlv : mInnerTlvs) {
                    list.addAll(tlv.findAll(tag));
                }
            }
        } else if (tag.equals(mTag)) {
            list.add(this);
        }
        return list;
    }

    public byte[] getInnerTlvsAsByteArray() {
        byte[] innerTlvBytes = new byte[0];
        for (TlvObject tlv : mInnerTlvs) {
            //Let recursion do the job
            innerTlvBytes = TlvUtils.concatAll(innerTlvBytes, tlv.asByteArray());
        }
        return innerTlvBytes;
    }

    public byte[] asByteArray() {
        if (isPrimitive() || mInnerTlvs == null) {
            return TlvUtils.concatAll(mTag.asByteArray(), mLen.asByteArray(), mValue);
        }
        byte[] innerTlvBytes = getInnerTlvsAsByteArray();
        mLen = Length.newInstance(innerTlvBytes.length);
        return TlvUtils.concatAll(mTag.asByteArray(), mLen.asByteArray(), innerTlvBytes);
    }

    @Nullable
    public String asHexString() {
        if (mValue == null && mInnerTlvs == null) {
            if (mTag == null || mTag.toTagDescriptor() == null) {
                // An invalid EMV tag was returned. Treat it as if no tag is present and return an empty.
                return "";
            }
            StringBuilder malformedTag = new StringBuilder(mTag.toTagDescriptor().asHexString());
            malformedTag.append(ZERO_TAG_LENGTH);
            return malformedTag.toString();
        }
        return ByteUtils.bytesToHex(asByteArray(), false);
    }

    @NonNull
    public String getValueAsHexString(boolean addSpaces) {
        String value = "";
        if (mValue != null) {
            value = ByteUtils.bytesToHex(mValue, addSpaces);
        }

        return value;
    }

    public void logPretty() {
        logPretty(0);
    }

    private void logPretty(int space) {
        String margin = "";
        for (int i = 0; i < space; i++) {
            margin += margin.concat("    ");
        }
        if (isConstructed()) {
            Log.d(TAG, margin + ByteUtils.bytesToHex(mTag.asByteArray(), true));
            for (TlvObject tlv : mInnerTlvs) {
                tlv.logPretty(space + 1);
            }
        } else {
            Log.d(TAG, margin + ByteUtils.bytesToHex(mTag.asByteArray(), true) + " "
                    + ByteUtils.bytesToHex(mLen.asByteArray(), true) + " "
                    + ByteUtils.bytesToHex(mValue, true));
        }
    }
}
