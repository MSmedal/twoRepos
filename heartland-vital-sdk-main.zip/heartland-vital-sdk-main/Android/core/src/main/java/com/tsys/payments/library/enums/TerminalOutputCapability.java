package com.tsys.payments.library.enums;

public enum TerminalOutputCapability {
    PRINT_AND_DISPLAY,
    PRINT_ONLY,
    DISPLAY_ONLY,
    NO_CAPABILITY
}
