package com.tsys.payments.library.enums;

/**
 * Enumeration of acceptable "PIN Statement" values displayed on receipts
 */
public enum PinStatementType {

    /**
     * PIN is not supported by the terminal in the context of the current transaction.
     */
    PIN_NOT_SUPPORTED,

    /**
     * PIN was verified either locally by ICC or remotely by the host.
     */
    PIN_VERIFIED,

    /**
     * PIN entry was prompted, but the user bypassed it.
     */
    PIN_BYPASSED,

    /**
     * PIN could not be verified and is now locked.
     */
    PIN_LOCKED

}
