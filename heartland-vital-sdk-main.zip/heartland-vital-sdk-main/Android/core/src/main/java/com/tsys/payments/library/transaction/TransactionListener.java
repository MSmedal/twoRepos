package com.tsys.payments.library.transaction;

import com.tsys.payments.library.domain.CardholderInteractionRequest;
import com.tsys.payments.library.domain.TransactionResponse;
import com.tsys.payments.library.enums.TransactionStatus;
import com.tsys.payments.library.exceptions.Error;

public interface TransactionListener {

    /**
     * Invoked when the transaction state has updated.
     *
     * @param transactionStatus {@link TransactionStatus} representing the new state of the
     * transaction process.
     */
    void onStatusUpdate(TransactionStatus transactionStatus);

    /**
     * Invoked when cardholder interaction is required to continue normal transaction processing.
     *
     * @param request {@link CardholderInteractionRequest} containing details about the type of
     * interaction and any accompanying data that should be presented to the cardholder.
     */
    void onCardholderInteractionRequested(CardholderInteractionRequest request);

    /**
     * Invoked when a transaction has processed to completion.
     *
     * @param response {@link TransactionResponse} containing details regarding the final result of
     * the transaction.
     */
    void onTransactionComplete(TransactionResponse response);

    /**
     * Invoked when an unrecoverable error is encountered during transaction processing.
     *
     * @param error {@link Error} containing details regarding the error encountered.
     */
    void onError(Error error);
}
