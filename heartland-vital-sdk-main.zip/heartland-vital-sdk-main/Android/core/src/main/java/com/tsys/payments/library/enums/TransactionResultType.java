package com.tsys.payments.library.enums;

public enum TransactionResultType {

    APPROVED,

    DECLINED_OFFLINE,

    DECLINED_ONLINE,

    PARTIALLY_APPROVED,

    POST_AUTH_REVERSAL,

    CALL_ISSUER,

    CANCELLED,

    SAF
}
