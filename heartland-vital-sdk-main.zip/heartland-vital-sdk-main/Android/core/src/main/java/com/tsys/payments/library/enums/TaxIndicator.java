package com.tsys.payments.library.enums;

/**
 * Indicates the type of tax being applied to the transaction. Interchange rates for a transaction
 * can be affected based on the way the taxes are applied.
 */
public enum TaxIndicator {
    TOTAL,
    SALE,
    SERVICE,
    DUTY,
    VAT,
    ALTERNATE,
    NATIONAL,
    TAX_EXEMPT
}
