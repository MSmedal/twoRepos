package com.tsys.payments.library.terminal;

import com.tsys.payments.library.enums.TerminalSettingType;
import com.tsys.payments.library.exceptions.Error;

public interface TerminalReadSettingListener {
    /**
     * Invoked when a terminal setting has been read
     *
     * @param terminalSettingType The setting to read
     * @param value The value read for the setting
     */
    void onTerminalSettingRead(TerminalSettingType terminalSettingType, Object value);

    /**
     * Invoked when reading a terminal setting has caused an error
     *
     * @param error The error produced when trying to read setting
     */
    void onError(Error error);
}
