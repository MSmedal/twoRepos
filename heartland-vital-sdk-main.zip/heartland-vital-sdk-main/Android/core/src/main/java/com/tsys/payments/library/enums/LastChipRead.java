package com.tsys.payments.library.enums;

public enum LastChipRead {
    SUCCESSFUL,
    FAILED,
    NOT_A_CHIP_TRANSACTION,
    UNKNOWN
}
