package com.tsys.payments.library.terminal;

import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.exceptions.Error;

import androidx.annotation.Nullable;

/**
 * Callbacks fired in response to a request to retrieve information about the connected terminal.
 */
public interface TerminalInfoListener {

    /**
     * Callback fired when information about the terminal is successfully retrieved.
     *
     * @param terminalInfo {@link TerminalInfo} containing device info.
     */
    void onTerminalInfoReceived(@Nullable TerminalInfo terminalInfo);

    /**
     * Callback fired when an error is encountered when trying to get device info.
     *
     * @param error {@link Error}
     */
    void onError(Error error);
}
