package com.tsys.payments.library.terminal;

public interface TerminalConfigurationProviderListener {

    /**
     * Invoked when terminal configuration is successfully loaded. Upon successful load, the following methods will
     * provide data if it was available in the configuration:
     * {@link TerminalConfigurationProvider#getTacMap()}
     * {@link TerminalConfigurationProvider#getContactlessAids()}
     * {@link TerminalConfigurationProvider#getContactAids()}
     */
    void onConfigurationLoaded();

    /**
     * Invoked when an error occurs during the loading process.
     */
    void onError(String error);
}
