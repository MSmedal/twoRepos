package com.tsys.payments.library.gateway.enums;

public enum GatewayType {
    /**
     * Dummy gateway used for simulating different gateway request types. There is no network connectivity involved.
     * All responses are pre-determined based on the amount, payment type and validations of the requests.
     */
    MOCK,

    /**
     * Identifier for the ProPay gateway.
     */
    PROPAY,

    /**
     * Identifier for the TransIt gateway.
     */
    TRANSIT,

    /**
     * Identifier for the Portico gateway.
     */
    PORTICO
}
