package com.tsys.payments.library.enums;

public enum CountryCode {
    /**
     * United States
     */
    US("US", "0840");

    public final String countryCode;
    public final String currencyCode;

    CountryCode(String countryCode, String currencyCode) {
        this.countryCode = countryCode;
        this.currencyCode = currencyCode;
    }
}
