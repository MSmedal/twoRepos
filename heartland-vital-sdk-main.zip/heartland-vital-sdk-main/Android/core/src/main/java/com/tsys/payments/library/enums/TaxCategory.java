package com.tsys.payments.library.enums;

public enum TaxCategory {

    SERVICE,
    DUTY,
    VAT,
    ALTERNATE,
    NATIONAL,
    TAX_EXEMPT

}
