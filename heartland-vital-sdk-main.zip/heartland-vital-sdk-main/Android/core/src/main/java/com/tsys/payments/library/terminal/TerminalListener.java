package com.tsys.payments.library.terminal;

import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.enums.TerminalError;
import com.tsys.payments.library.terminal.domain.TerminalInteractionRequest;
import com.tsys.payments.library.terminal.domain.TerminalResponse;
import com.tsys.payments.library.terminal.enums.TerminalStatus;

public interface TerminalListener {

    /**
     * Invoked when the terminal has successfully connected.
     */
    void onConnected(TerminalInfo terminalInfo);

    /**
     * Invoked when information about the terminal is received.
     */
    void onTerminalInfo(TerminalInfo terminalInfo);

    /**
     * Invoked when the terminals status has changed.
     *
     * @param status {@link TerminalStatus} representing the current state of the terminal in this
     * transaction.
     */
    void onTerminalStatusUpdate(TerminalStatus status);

    /**
     * Invoked when a response is received from the concrete {@link TerminalController}
     * implementation.
     *
     * @param response {@link TerminalResponse} received when terminal processing is complete or an
     * error is encountered.
     */
    void onTerminalResponseReceived(TerminalResponse response);

    /**
     * Invoked when the terminal or card requires some interaction from the cardholder or POS.
     *
     * @param request {@link TerminalInteractionRequest} containing details of the interaction being
     * requested.
     */
    void onTerminalInteractionRequested(TerminalInteractionRequest request);

    /**
     * Invoked when the terminal has disconnected.
     */
    void onDisconnected();

    /**
     * Invoked when an unrecoverable error is encountered by the terminal.
     *
     * @param error {@link TerminalError} Error catetory that this error falls into.
     * @param message Friendly message with error details.
     */
    void onError(TerminalError error, String message);
}
