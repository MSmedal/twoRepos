package com.tsys.payments.library.domain;

import com.google.gson.annotations.SerializedName;

import java.util.Objects;

/**
 * Specification for a Certificate Authority Public Key (CAPK) used to verify that the transaction was performed
 * with a valid card signed by the issuer.
 */
public class Capk {

    @SerializedName("rid")
    private String mRid;

    @SerializedName("public_key_index")
    private String mPublicKeyIndex;

    @SerializedName("key")
    private String mKey;

    @SerializedName("exponent")
    private String mExponent;

    @SerializedName("checksum")
    private String mChecksum;

    /**
     * Returns the identify of the Registered Application Provider that this key is associated with.
     *
     * @return {@link String} containing the provider id.
     */
    public String getRid() {
        return mRid;
    }

    /**
     * Sets the identify of the Registered Application Provider that this key is associated with.
     *
     * @param rid {@link String} indicating the provider id.
     */
    public void setRid(String rid) {
        mRid = rid;
    }

    /**
     * Returns the index among the issuer's public keys that this key corresponds to. An issuer can have several public
     * keys.
     *
     * @return {@link String} indicating the position of this public key among the issuer's public keys.
     */
    public String getPublicKeyIndex() {
        return mPublicKeyIndex;
    }

    /**
     * Sets the index among the issuer's public keys that this key corresponds to. An issuer can have several public
     * keys.
     *
     * @param publicKeyIndex {@link String} indicating the position of this key among the issuer's public keys.
     */
    public void setPublicKeyIndex(String publicKeyIndex) {
        mPublicKeyIndex = publicKeyIndex;
    }

    public String getKey() {
        return mKey;
    }

    public void setKey(String key) {
        mKey = key;
    }

    public String getExponent() {
        return mExponent;
    }

    public void setExponent(String exponent) {
        mExponent = exponent;
    }

    /**
     * Returns a value indicating that the key value is the expected key value.
     *
     * @return {@link String} calculated value used to compare two keys without knowing their values.
     */
    public String getChecksum() {
        return mChecksum;
    }

    /**
     * Sets a calculated value that can be used to compare this key with another key to verify that they're identical.
     *
     * @param checksum {@link String} value calculated from the key value as input for comparison with other keys.
     */
    public void setChecksum(String checksum) {
        mChecksum = checksum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Capk)) return false;
        Capk capk = (Capk)o;
        return Objects.equals(mRid, capk.mRid) &&
                Objects.equals(mPublicKeyIndex, capk.mPublicKeyIndex) &&
                Objects.equals(mKey, capk.mKey) &&
                Objects.equals(mExponent, capk.mExponent) &&
                Objects.equals(mChecksum, capk.mChecksum);
    }

    @Override
    public int hashCode() {

        return Objects.hash(mRid, mPublicKeyIndex, mKey, mExponent, mChecksum);
    }

    @Override
    public String toString() {
        return "PublicKey{" +
                "mRid='" + mRid + '\'' +
                ", mPublicKeyIndex='" + mPublicKeyIndex + '\'' +
                ", mKey='" + mKey + '\'' +
                ", mExponent='" + mExponent + '\'' +
                ", mChecksum='" + mChecksum + '\'' +
                '}';
    }
}
