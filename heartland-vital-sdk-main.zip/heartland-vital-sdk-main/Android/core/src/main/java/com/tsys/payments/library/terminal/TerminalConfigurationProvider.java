package com.tsys.payments.library.terminal;

import android.content.Context;

import com.tsys.payments.library.domain.AidConfiguration;
import com.tsys.payments.library.domain.Capk;
import com.tsys.payments.library.domain.TerminalActionCodes;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.gateway.enums.GatewayType;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
import java.util.Map;

/**
 * Provides configuration information for a terminal. It varies for the respective terminals and gateways being used.
 */
public interface TerminalConfigurationProvider {

    /**
     * Load the configuration from the properties file utilized by this provider. The data needed for
     * {@link TerminalConfigurationProvider#getContactAids()},
     * {@link TerminalConfigurationProvider#getContactlessAids()} and
     * {@link TerminalConfigurationProvider#getTacMap()} is populated during this call.
     *
     * @param context {@link Context} used for loading configurations from sources requiring a context.
     * @param terminalType {@link TerminalType} specifying the terminal used.
     * @param gatewayType {@link GatewayType} specifying the gateway.
     * @param listener {@link TerminalConfigurationProviderListener} callback indicating the completion of the
     * configuration loading process.
     */
    void createConfig(@NonNull Context context, @NonNull TerminalType terminalType, @NonNull GatewayType gatewayType,
            @NonNull TerminalConfigurationProviderListener listener);

    /**
     * Returns a list of contactless AID's for a given terminal configuration.
     *
     * @return {@link List< AidConfiguration >} containing the contactless AID's.
     */
    @Nullable
    List<AidConfiguration> getContactlessAids();

    /**
     * Returns a list of contact AID's for a given terminal configuration.
     *
     * @return {@link List<AidConfiguration>} containing the contactless AID's.
     */
    @Nullable
    List<AidConfiguration> getContactAids();

    /**
     * Returns a mapping of {@link AidConfiguration} reference id's to a given {@link TerminalActionCodes}.
     *
     * @return {@link Map<String,TerminalActionCodes>} containing the contactless AIDs'.
     */
    @Nullable
    Map<String, TerminalActionCodes> getTacMap();

    /**
     * Returns the list of Certificate Authority Public Keys(CAPK's) for a given terminal configuration.
     *
     * @return {@link List< Capk >} indicating the CAPK's to use with this configuration.
     */
    List<Capk> getPublicKeys();
}
