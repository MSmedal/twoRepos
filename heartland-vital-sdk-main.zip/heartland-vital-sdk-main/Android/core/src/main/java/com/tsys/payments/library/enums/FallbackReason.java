package com.tsys.payments.library.enums;

public enum FallbackReason {
    EMPTY_CANDIDATE_LIST,
    ICC_ERROR,
    OTHER
}
