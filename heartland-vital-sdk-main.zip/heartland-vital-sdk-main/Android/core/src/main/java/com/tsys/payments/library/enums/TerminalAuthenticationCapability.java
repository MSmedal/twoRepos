package com.tsys.payments.library.enums;

public enum TerminalAuthenticationCapability {
    NO_CAPABILITY,
    PIN_ENTRY,
    ELECTRONIC_SIGNATURE,
    INOPERATIVE,
    OTHER;
}
