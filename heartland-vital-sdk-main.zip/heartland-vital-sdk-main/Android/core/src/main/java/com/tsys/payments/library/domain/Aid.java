package com.tsys.payments.library.domain;

import com.google.gson.annotations.SerializedName;

/**
 * Describes an application type provided by an Application Provider that is stored on the chip in an
 * Integrated Chip Card.
 */
public class Aid {

    @SerializedName("rid")
    private String mRid;

    @SerializedName("pix")
    private String mPix;

    @SerializedName("label")
    private String mLabel;

    @SerializedName("preferred_name")
    private String mPreferredName;

    /**
     * Identifies the Registered Application Provider, which identifies Application Providers offering international
     * IC card applications.
     * Ex. Visa Electron Credit: A000000003.
     *
     * @return {@link String} containing the provider id.
     */
    public String getRid() {
        return mRid;
    }

    /**
     * Sets the Registered Application Provider, which identifies Application Providers offering international
     * IC card applications.
     *
     * @param rid {@link String} containing the provider id.
     */
    public Aid setRid(String rid) {
        mRid = rid;
        return this;
    }

    /**
     * Returns the Proprietary Application Identifier Extension(PIX) which enables the Application Provider to
     * differentiate between the different international IC card applications offered.
     * Ex. Visa Electron Credit: 2010.
     *
     * @return {@link String} containing the PIX.
     */
    public String getPix() {
        return mPix;
    }

    /**
     * Sets the Proprietary Application Identifier Extension which enables the Application Provider to differentiate
     * between the different international IC card applications offered.
     *
     * @return {@link String} PIX extension.
     */
    public Aid setPix(String pix) {
        mPix = pix;
        return this;
    }

    /**
     * Returns the standard user-friendly label identifying the application.
     *
     * @return {@link String} identifying the application.
     */
    public String getLabel() {
        return mLabel;
    }

    /**
     * Set the standard user-friendly label identifying the application.
     *
     * @param label {@link String} identifying the application.
     */
    public Aid setLabel(String label) {
        mLabel = label;
        return this;
    }

    /**
     * Returns the application preferred name.
     *
     * @return {@link String} indicating the preferred name. This may differ from the label.
     */
    public String getPreferredName() {
        return mPreferredName;
    }

    /**
     * Sets the application preferred name.
     *
     * @param preferredName {@link String} indicating the application preferred name. This may differ from the label.
     */
    public Aid setPreferredName(String preferredName) {
        mPreferredName = preferredName;
        return this;
    }

    /**
     * Returns the standard format for describing an application, which is a concatenation of the RIX and PIX.
     *
     * @return {@link String} describing the application in the standard format.
     */
    public String getFullIdentifier() {
        return mRid + mPix;
    }
}
