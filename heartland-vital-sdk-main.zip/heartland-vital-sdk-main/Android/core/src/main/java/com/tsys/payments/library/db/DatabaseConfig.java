package com.tsys.payments.library.db;

import android.content.Context;

import com.tsys.payments.library.gateway.enums.GatewayType;

/**
 * Configuration for the SDK database.
 */
public class DatabaseConfig {
    /**
     * The context for the database (usually the application context)
     */
    final private Context mContext;

    /**
     * Name to give the database
     */
    final private String mDbName;

    /**
     * Password to encrypt the database with
     */
    final private String mEncryptionPassword;

    /**
     * Configuration for SAF related logic in the database
     */
    final private SafDatabaseConfig mSafDatabaseConfig;

    /**
     * Gateway type
     */
    final private GatewayType mGatewayType;

    public DatabaseConfig(Context context, String dbName, String encryptionPassword,
            SafDatabaseConfig safDatabaseConfig, GatewayType gatewayType) {
        mContext = context;
        mDbName = dbName;
        mEncryptionPassword = encryptionPassword;
        mSafDatabaseConfig = safDatabaseConfig;
        mGatewayType = gatewayType;
    }

    public Context getContext() {
        return mContext;
    }

    public String getDbName() {
        return mDbName;
    }

    public String getEncryptionPassword() {
        return mEncryptionPassword;
    }

    public SafDatabaseConfig getSafDatabaseConfig() {
        return mSafDatabaseConfig;
    }

    public GatewayType getGatewayType() {
        return mGatewayType;
    }
}
