package com.tsys.payments.library.db.entity;

import com.tsys.payments.library.db.converter.DateTypeConverter;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.Date;

@Entity(tableName = "saf_tokenized_card")
@TypeConverters({DateTypeConverter.class})
public class SafTokenizedCard {
    @ColumnInfo(name = "ID")
    private String mId;

    @ColumnInfo(name = "CAPTURE_TIME")
    @PrimaryKey
    private Date mCaptureTime;

    @ColumnInfo(name = "CARD_HOLDER_NAME")
    private String mCardHolderName;

    @ColumnInfo(name = "CARD_NUMBER")
    private String mCardNumber;

    /**
     * Card brand type (i.e. Visa, Mastercard, Discover, etc)
     */
    @ColumnInfo(name = "CARD_TYPE")
    private int mCardType;

    @ColumnInfo(name = "EXPIRATION_DATE")
    private String mExpDate;

    @ColumnInfo(name = "ZIP_CODE")
    private String mZipCode;

    @ColumnInfo(name = "TRACK1")
    private String mTrack1;

    @ColumnInfo(name = "TRACK2")
    private String mTrack2;

    @ColumnInfo(name = "TRACK3")
    private String mTrack3;

    @ColumnInfo(name = "EMULATED_TRACK")
    private String mEmulatedTrack;

    @ColumnInfo(name = "KSN")
    private String mKsn;

    /**
     * Payment Terminal encryption type (i.e. TDES, VOLTAGE, etc)
     */
    @ColumnInfo(name = "ENCRYPTION_TYPE")
    private int mEncryptionType;

    /**
     * Payment terminal type (i.e. RP350, RP457, Moby3000, etc)
     */
    @ColumnInfo(name = "TERMINAL_TYPE")
    private int mTerminalType;

    @ColumnInfo(name = "CAPTURE_OFFLINE")
    private boolean mCaptureOffline;

    @ColumnInfo(name = "CREDIT_CARD_TAG")
    private String mCreditCardTag;

    @ColumnInfo(name = "PAYER_ID")
    private int mPayerId;

    @ColumnInfo(name = "PAYMENT_METHOD_ID")
    private String mPaymentMethodId;

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public Date getCaptureTime() {
        return mCaptureTime;
    }

    public void setCaptureTime(Date captureTime) {
        mCaptureTime = captureTime;
    }

    public String getCardHolderName() {
        return mCardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        mCardHolderName = cardHolderName;
    }

    public String getCardNumber() {
        return mCardNumber;
    }

    public void setCardNumber(String cardNumber) {
        mCardNumber = cardNumber;
    }

    public int getCardType() {
        return mCardType;
    }

    public void setCardType(int cardType) {
        mCardType = cardType;
    }

    public String getExpDate() {
        return mExpDate;
    }

    public void setExpDate(String expDate) {
        mExpDate = expDate;
    }

    public String getZipCode() {
        return mZipCode;
    }

    public void setZipCode(String zipCode) {
        mZipCode = zipCode;
    }

    public String getTrack1() {
        return mTrack1;
    }

    public void setTrack1(String track1) {
        mTrack1 = track1;
    }

    public String getTrack2() {
        return mTrack2;
    }

    public void setTrack2(String track2) {
        mTrack2 = track2;
    }

    public String getTrack3() {
        return mTrack3;
    }

    public void setTrack3(String track3) {
        mTrack3 = track3;
    }

    public String getEmulatedTrack() {
        return mEmulatedTrack;
    }

    public void setEmulatedTrack(String emulatedTrack) {
        mEmulatedTrack = emulatedTrack;
    }

    public String getKsn() {
        return mKsn;
    }

    public void setKsn(String ksn) {
        mKsn = ksn;
    }

    public int getEncryptionType() {
        return mEncryptionType;
    }

    public void setEncryptionType(int encryptionType) {
        mEncryptionType = encryptionType;
    }

    public int getTerminalType() {
        return mTerminalType;
    }

    public void setTerminalType(int terminalType) {
        mTerminalType = terminalType;
    }

    public boolean isCaptureOffline() {
        return mCaptureOffline;
    }

    public void setCaptureOffline(boolean captureOffline) {
        mCaptureOffline = captureOffline;
    }

    public String getCreditCardTag() {
        return mCreditCardTag;
    }

    public void setCreditCardTag(String creditCardTag) {
        mCreditCardTag = creditCardTag;
    }

    public int getPayerId() {
        return mPayerId;
    }

    public void setPayerId(int payerId) {
        mPayerId = payerId;
    }

    public String getPaymentMethodId() {
        return mPaymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        mPaymentMethodId = paymentMethodId;
    }
}
