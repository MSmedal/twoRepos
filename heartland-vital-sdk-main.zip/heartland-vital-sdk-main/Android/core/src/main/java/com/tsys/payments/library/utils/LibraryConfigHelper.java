package com.tsys.payments.library.utils;

import androidx.annotation.NonNull;
import timber.log.Timber;

/**
 * Keeps track of the build configuration of the SDK. This allows the ability to distinguish between debug builds
 * and production builds.
 */
public final class LibraryConfigHelper {
    private static boolean sDebug;
    private static boolean sLoggingEnabled;
    private static String sSdkNameVersion;

    private LibraryConfigHelper() {
        // no instance
    }

    public static boolean isDebug() {
        return sDebug;
    }

    public static void setDebugMode(boolean debug) {
        sDebug = debug;
    }

    public static boolean isLoggingEnabled() {
        return sLoggingEnabled;
    }

    public static void setLoggingEnabled(boolean loggingEnabled) {
        sLoggingEnabled = loggingEnabled;
    }

    public static void addLogTree(@NonNull Timber.Tree tree) {
        if (!Timber.forest().contains(tree)) {
            Timber.plant(tree);
        }
    }

    public static void removeLogTree(Timber.Tree tree) {
        Timber.uproot(tree);
    }

    public static void setSdkNameVersion(String sdkNameVersion) {
        sSdkNameVersion = sdkNameVersion;
    }

    public static String getSdkNameVersion() {
        return sSdkNameVersion;
    }
}
