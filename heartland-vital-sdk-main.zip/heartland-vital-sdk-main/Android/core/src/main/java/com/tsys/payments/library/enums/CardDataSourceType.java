package com.tsys.payments.library.enums;

/**
 * Sources from which card data can be captured and processed.
 */
public enum CardDataSourceType {

    /**
     * Card data was captured from a Mag Stripe Read.
     */
    MSR,

    /**
     * Card data was captured from the Smart Card (ICC) Reader.
     */
    SCR,

    /**
     * Card data was captured via NFC, with Mag Stripe formatted data.
     */
    CONTACTLESS_MSR,

    /**
     * Card data was captured via NFC, with EMV formatted data.
     */
    CONTACTLESS_EMV,

    /**
     * Card data was entered manually on an Encrypted PIN Pad (EPP)
     */
    KEYED,

    /**
     * Card data was presented over a phone.
     */
    PHONE,

    /**
     * Card data was sent through parcel services.
     */
    MAIL,

    /**
     * Card data was captured via an E-commerce channel.
     */
    INTERNET,

    FALLBACK
}
