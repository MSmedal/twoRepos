package com.tsys.payments.library.terminal.enums;

public enum TerminalInteractionType {

    EMV_APPLICATION_SELECTION,

    FINAL_AMOUNT_REQUEST,

    FINAL_AMOUNT_CONFIRMATION,

    REQUEST_PROCEED_HOST_PROCESSING,

    HOST_PROCESSING,

    SURCHARGE_CONFIRMATION

}
