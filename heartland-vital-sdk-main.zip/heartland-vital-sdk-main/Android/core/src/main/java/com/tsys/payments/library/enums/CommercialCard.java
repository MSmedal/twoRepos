package com.tsys.payments.library.enums;

/**
 * Indicates if the card is a purchasing or commercial card and if so, what type.
 */
public enum CommercialCard {

    BUSINESS,

    VISA_COMMERCE,

    B2B_SETTLEMENT_ELIGIBLE,

    CORPORATE,

    PURCHASE,

    NON_COMMERCIAL

}
