package com.tsys.payments.library.terminal.enums;

import com.tsys.payments.library.terminal.TerminalController;

/**
 * Actions that may be supported by a given {@link TerminalController}.
 */
public enum TerminalAction {
    /**
     * Initiates a one-time terminal configuration to perform CAPK, AID, and TAC loading for
     * EMV-capable terminals.
     */
    SETUP,

    /**
     * Retrieves information about the terminal(i.e. serial number, battery status, etc).
     */
    INFO,

    /**
     * Starts a transaction that may or may not include a tip amount in the initial request.
     */
    TENDER_GOODS,

    /**
     * Starts a transaction that will not include a tip amount in the initial request, but may
     * be adjusted to include one.
     */
    TENDER_SERVICES,

    /**
     * Starts a transaction that will debit an amount to a cardholders account.
     */
    TENDER_REFUND,

    /**
     * Starts the Reader(Moby) for unencrypted PAN data from HPS Gift Card bin range.
     */
    START_CARD
}
