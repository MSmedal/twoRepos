package com.tsys.payments.library.enums;

public enum EncryptionType {
    TDES,

    DUKPT,

    VOLTAGE,

    NONE
}
