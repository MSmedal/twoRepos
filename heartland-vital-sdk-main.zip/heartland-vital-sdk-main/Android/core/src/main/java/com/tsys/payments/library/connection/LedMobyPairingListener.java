package com.tsys.payments.library.connection;

public interface LedMobyPairingListener {
    void onLedPairSequence(Object led, Object confirm);
    void onNotSupported();
    void onSuccess();
    void onFail();
    void onCanceled();
}
