package com.tsys.payments.library.db;

import com.tsys.payments.library.db.entity.SafTokenizedCard;
import com.tsys.payments.library.db.entity.SafTransaction;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import java.util.List;

public interface DatabaseController {
    /**
     * Initialize the Controller and create the local db
     */
    void init(DatabaseConfig dbConfig);

    long storeSafTransaction(SafTransaction safTransaction);

    List<SafTransaction> getAllSafTransactions();

    List<SafTransaction> getAllPendingSafTransactions();

    List<SafTransaction> getSafTransactionsByLocalIdList(List<Long> safLocalIds);

    List<SafTransaction> getAllSafTransactionsMetadata();

    void storeSafTokenizedCard(SafTokenizedCard safTokenizedCard);

    List<SafTokenizedCard> getAllSafTokenizedCards();

    SafTransaction convertGatewayRequestToSafTransaction(GatewayRequest gatewayRequest);

    GatewayRequest convertSafTransactionToGatewayRequest(SafTransaction safTransaction);

    GatewayAction[] getSupportedGatewayActions();

    SafTransaction getSafTransactionByLocalId(long safLocalId);

    void deleteSafTransactionByLocalId(long safLocalId);

    void updateSafTransactionId(SafTransaction safTransaction, String transactionId);

    void updateUniqueSafId(SafTransaction safTransaction, String uniqueSAFId);

    void deleteSafTransactionByUniqueId(String uniqueSAFId);
}
