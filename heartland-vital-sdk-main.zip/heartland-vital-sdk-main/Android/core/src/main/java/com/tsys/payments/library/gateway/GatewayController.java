package com.tsys.payments.library.gateway;

import com.tsys.payments.library.gateway.domain.GatewayRequest;

public interface GatewayController {

    /**
     * @param gatewayRequest Request data to be passed to the host implementation.
     */
    void sendRequest(GatewayRequest gatewayRequest);
}
