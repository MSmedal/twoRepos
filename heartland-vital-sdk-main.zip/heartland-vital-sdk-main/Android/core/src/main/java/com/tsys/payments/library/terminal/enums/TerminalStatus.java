package com.tsys.payments.library.terminal.enums;

/**
 * Represents the different states a terminal may enter while processing a request.
 */
public enum TerminalStatus {

    /**
     * The terminal readers have been initialized and are ready for the card to be presented.
     */
    WAITING_FOR_CARD,

    /**
     * The terminal detected a card but was unable to read the data successfully.
     * <p>
     * The cardholder shall be prompted to present the card again.
     */
    BAD_READ_DETECTED,

    /**
     * The terminal detected multiple cards within the RFID field.
     * <p>
     * The cardholder shall be prompted to try again and only present one card.
     */
    MULTIPLE_CARDS_DETECTED,

    /**
     * The terminal detected an ICC being swiped without technical fallback being triggered.
     */
    ICC_SWIPE_DETECTED,

    /**
     * The terminal has failed to read the chip of an ICC and has initiated technical fallback.
     * <p>
     * The cardholder shall be prompted to remove the card and swipe instead of inserting.
     */
    TECHNICAL_FALLBACK_INITIATED,

    /**
     * The terminal has successfully captured card data.
     */
    CARD_DETECTED,

    /**
     * The terminal is unable to read the card data and the error is irrecoverable. The transaction
     * should be restarted.
     */
    CARD_READ_ERROR,

    /**
     * The terminal detected that the card has been removed after the transaction completed.
     */
    CARD_REMOVED_AFTER_TRANSACTION_COMPLETE,

    /**
     * The terminal has finished processing the contactless card and indicates that the card should
     * be removed from the RFID field.
     */
    CONTACTLESS_CARD_STILL_IN_FIELD,

    /**
     * The terminal is unable to use the RFID field for the field and suggests using the contact
     * interface.
     */
    CONTACTLESS_INTERFACE_FAILED_TRY_CONTACT,

    /**
     * Indicates that the contactless card is not accepted. The user should swipe, insert or try
     * another contactless card.
     */
    INSERT_SWIPE_OR_TRY_ANOTHER_CARD,

    /**
     * The terminal requested that the card remain in the ICC slot or RFID field while processing.
     */
    DO_NOT_REMOVE_CARD,

    /**
     * The terminal is busy processing a command and is unable to fulfill the request to process
     * another command.
     */
    DEVICE_BUSY,

    /**
     * The terminal requested PIN entry.
     */
    ENTER_PIN,

    /**
     * The terminal indicates that only one more PIN entry attempt is allowed.
     */
    LAST_PIN_ATTEMPT,

    /**
     * The terminal indicates that PIN entry succeeded.
     */
    PIN_ACCEPTED,

    /**
     * The terminal indicates PIN entry failed and should be re-attempted.
     */
    RETRY_PIN,

    /**
     * The terminal indicates that the card should be removed.
     */
    REMOVE_CARD,

    /**
     * The terminal indicates that it is performing the configuration process.
     */
    CONFIGURING,

    /**
     * The terminal indicates that the cardholder should check their phone.
     */
    SEE_PHONE,

    /**
     * The terminal is processing the card data.
     */
    PROCESSING
}