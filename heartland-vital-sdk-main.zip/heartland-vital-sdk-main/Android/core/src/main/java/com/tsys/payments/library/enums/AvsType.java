package com.tsys.payments.library.enums;

/**
 * Indicates the components of the address needed for Address Verification System.
 */
public enum AvsType {
    ZIP,
    ZIP_ADDRESS,
    NONE
}
