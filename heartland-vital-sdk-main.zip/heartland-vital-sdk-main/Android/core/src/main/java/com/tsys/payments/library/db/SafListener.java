package com.tsys.payments.library.db;

import com.tsys.payments.library.db.entity.SafTransaction;
import com.tsys.payments.library.domain.TransactionResponse;
import com.tsys.payments.library.exceptions.Error;

import java.math.BigDecimal;
import java.util.List;

/**
 * Listener to be used when processing Store and Forward (SAF) transactions. Only used for retrieving and processing
 * transactions from local database. To store the transaction initially,
 * {@link com.tsys.payments.library.transaction.TransactionListener} will still be used.
 */
public interface SafListener {

    /**
     * Invoked when all {@link com.tsys.payments.library.db.entity.SafTransaction} requested have been processed.
     *
     * @param responses list of {@link TransactionResponse} for SAF transactions that were processed containing
     *                  details of final result of transaction.
     */
    void onProcessingComplete(List<TransactionResponse> responses);

    /**
     * Invoked when all {@link SafTransaction} have been retrieved from SAF database, to be returned to
     * consuming application.
     *
     * @param obfuscatedSafTransactions list of {@link SafTransaction} retrieved from database.
     */
    void onAllSafTransactionsRetrieved(List<SafTransaction> obfuscatedSafTransactions);

    /**
     * Invoked when error occurs retrieving SAF transactions, e.g. if SAF database is not configured or IDs requested
     * for processing did not match any transactions.
     *
     * @param error {@link Error} containing details of error.
     */
    void onError(Error error);

    /**
     * Invoked when a transaction is stored in the SAF database.
     * @param id The unique identifier of the transaction.
     * @param totalCount The current total number of transactions being stored in the database.
     * @param totalAmount The current total amount of transactions being stored in the database.
     */
    void onTransactionStored(String id, int totalCount, BigDecimal totalAmount);

    /**
     * Invoked when a transaction has been processed with success or failure and has been removed from the database.
     * @param id The unique identifier of the transaction.
     * @param transactionResponse The {@link TransactionResponse} received from processing the transaction.
     */
    void onStoredTransactionComplete(String id, TransactionResponse transactionResponse);
}
