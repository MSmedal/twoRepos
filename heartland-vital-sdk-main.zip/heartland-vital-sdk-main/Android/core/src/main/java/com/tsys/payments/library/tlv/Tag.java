package com.tsys.payments.library.tlv;

import com.tsys.payments.library.utils.ByteUtils;

import java.util.Arrays;

/**
 * Represents the Tag portion of a {@link TlvObject}.
 * <p>
 * Contains utility methods that perform operations commonly applied to the tag of a {@link TlvObject}.
 */
public class Tag {

    private final byte[] mTagBytes;

    //TODO: Validate Tag data for all constructors.
    public Tag(byte[] tagBytes) {
        mTagBytes = tagBytes;
    }

    public Tag(byte[] buf, int offset) {
        this(buf, offset, getTagBytesCount(buf, offset));
    }

    public Tag(byte[] buf, int offset, int length) {
        byte[] temp = new byte[length];
        System.arraycopy(buf, offset, temp, 0, length);
        mTagBytes = temp;
    }

    public Tag(byte firstByte) {
        mTagBytes = new byte[] {firstByte};
    }

    public Tag(byte firstByte, byte secondByte) {
        mTagBytes = new byte[] {firstByte, secondByte};
    }

    public Tag(byte firstByte, byte secondByte, byte firth) {
        mTagBytes = new byte[] {firstByte, secondByte, firth};
    }

    public Tag(int value) {
        mTagBytes = TlvUtils.intToByteArray(value);
    }

    public boolean isConstructed() {
        return (mTagBytes[0] & 0x20) != 0;
    }

    public boolean isLongTag() {
        return (mTagBytes[0] & 0x1F) == 0x1F;
    }

    public int getTagLength() {
        return mTagBytes.length;
    }

    public byte[] asByteArray() {
        return mTagBytes;
    }

    public static int getTagBytesCount(byte[] buf, int offset) {
        if ((buf[offset++] & 0x1F) == 0x1F) {
            int len = 2;
            while ((buf[offset++] & 0x80) == 0x80) {
                len++;
            }
            return len;
        }
        return 1;
    }

    public static boolean isLastTagByte(byte b) {
        return (b & 0x80) == 0x00;
    }

    public static boolean isValidTag(byte tag, int byteNumber) {
        switch (byteNumber) {
            case 0:
                // intentional fall-through
            case 1:
                if (tag == 0x00) return false;
                break;
            case 2:
                if (tag == 0x1E) return false;
                break;
            default:
                break;
        }

        return true;
    }

    public static Tag fromTagDescriptor(EmvTagDescriptor emvTagDescriptor) {
        byte[] tagBytes = TlvUtils.intToByteArray(emvTagDescriptor.getValue());
        return new Tag(tagBytes, 0, tagBytes.length);
    }

    public EmvTagDescriptor toTagDescriptor() {
        EmvTagDescriptor emvTagDescriptor = EmvTagDescriptor.fromByteArray(mTagBytes);
        if (emvTagDescriptor == EmvTagDescriptor.UNKNOWN) return null;
        return emvTagDescriptor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Tag tag = (Tag)o;

        return Arrays.equals(mTagBytes, tag.asByteArray());
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(mTagBytes);
    }

    @Override
    public String toString() {
        return (isConstructed() ? "+ " : "- ") + ByteUtils.bytesToHex(mTagBytes, true);
    }
}
