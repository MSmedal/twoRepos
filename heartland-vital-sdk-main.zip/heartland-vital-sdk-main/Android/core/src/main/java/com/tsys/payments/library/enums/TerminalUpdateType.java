package com.tsys.payments.library.enums;

/**
 * Represents type of terminal software that can be updated.
 */
public enum TerminalUpdateType {
    FIRMWARE,
    KERNEL,
    RKI
}
