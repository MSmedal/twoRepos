package com.tsys.payments.library.terminal.domain;


import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.enums.TransactionType;
import com.tsys.payments.library.terminal.enums.TerminalAction;
import com.tsys.payments.library.tlv.EmvTagDescriptor;

import androidx.annotation.Nullable;

import java.util.List;
import java.util.Objects;

import androidx.annotation.Nullable;

/**
 * Represents data consumed by a payment terminal to process a tender.
 */
public class TerminalRequest {

    private final TerminalAction mTerminalAction;
    private Long mTotalAmount;
    private Long mTipAmount;
    private Long mCashBackAmount;
    private Long mSurchargeAmount;
    private TenderType mTenderType;
    private TransactionType mTransactionType;
    private List<EmvTagDescriptor> mRequiredEmvTags;
    private TerminalConfiguration mTerminalConfiguration;

    public TerminalRequest(TerminalAction terminalAction) {
        mTerminalAction = terminalAction;
    }

    public TerminalAction getTerminalAction() {
        return mTerminalAction;
    }

    /**
     * Complete transaction amount to be authorized, including any taxes and/or fees.
     *
     * @return Transaction amount formatted in the smallest currency denomination. ie. $10.00 would
     * be 1000. In pre-tap transactions where the amount is not known at the beginning of the transaction
     * this value may be null.
     */
    @Nullable
    public Long getTotalAmount() {
        return mTotalAmount;
    }

    /**
     * Complete transaction amount to be authorized, including any taxes, fees, and/or gratuity.
     * <p>
     * <b>Required</b>
     *
     * @param totalAmount Transaction amount, formatted in the smallest currency denomination. ie.
     * $10.00 would be 1000
     */
    public void setTotalAmount(Long totalAmount) {
        mTotalAmount = totalAmount;
    }

    public Long getTipAmount() {
        return mTipAmount;
    }

    public void setTipAmount(Long tipAmount) {
        mTipAmount = tipAmount;
    }

    /**
     * @return Additional amount to charge over the {@code TotalAmount}, formatted in the smallest
     * currency denomination. ie. $10.00 would be 1000.
     */
    public Long getCashBackAmount() {
        return mCashBackAmount;
    }

    /**
     * @param cashBackAmount Additional amount to charge over the {@code TotalAmount}, formatted in
     * the smallest currency denomination. ie. $10.00 would be 1000.
     */
    public void setCashBackAmount(Long cashBackAmount) {
        mCashBackAmount = cashBackAmount;
    }

    public Long getSurchargeAmount() {
        return mSurchargeAmount;
    }

    /**
     * @param surchargeAmount
     * a merchant fee that is passed onto the customer that is applicable only for US credit
     * transactions.
     * If set, the selected AID determines whether or not this additional amount applies to the
     * current transaction
     */
    public void setSurchargeAmount(@Nullable Long surchargeAmount) {
        mSurchargeAmount = surchargeAmount;
    }

    /**
     * @return {@link TenderType} expected to be used for this transaction. This may not match the
     * {@link TenderType} returned in the {@link TerminalResponse} if the cardholder is prompted to
     * select a different AID or account.
     */
    public TenderType getTenderType() {
        return mTenderType;
    }

    /**
     * @param tenderType {@link TenderType} expected to be used for this transaction. This may not
     * match the {@link TenderType} returned in the {@link TerminalResponse} if the cardholder is
     * prompted to select a different AID or account during processing.
     */
    public void setTenderType(TenderType tenderType) {
        mTenderType = tenderType;
    }

    /**
     * @return {@link TransactionType} expected to be performed on the host.
     */
    public TransactionType getTransactionType() {
        return mTransactionType;
    }

    /**
     * @param transactionType {@link TransactionType} expected to be performed on the host.
     */
    public void setTransactionType(TransactionType transactionType) {
        mTransactionType = transactionType;
    }

    public List<EmvTagDescriptor> getRequiredEmvTags() {
        return mRequiredEmvTags;
    }

    public void setRequiredEmvTags(List<EmvTagDescriptor> requiredEmvTags) {
        mRequiredEmvTags = requiredEmvTags;
    }

    public TerminalConfiguration getTerminalConfiguration() {
        return mTerminalConfiguration;
    }


    public void setTerminalConfiguration(TerminalConfiguration terminalConfiguration) {
        mTerminalConfiguration = terminalConfiguration;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TerminalRequest that = (TerminalRequest)o;
        return mTerminalAction == that.mTerminalAction &&
                Objects.equals(mTotalAmount, that.mTotalAmount) &&
                Objects.equals(mTipAmount, that.mTipAmount) &&
                Objects.equals(mCashBackAmount, that.mCashBackAmount) &&
                Objects.equals(mSurchargeAmount, that.mSurchargeAmount) &&
                mTenderType == that.mTenderType &&
                mTransactionType == that.mTransactionType &&
                Objects.equals(mRequiredEmvTags, that.mRequiredEmvTags) &&
                Objects.equals(mTerminalConfiguration, that.mTerminalConfiguration);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mTerminalAction, mTotalAmount, mTipAmount, mCashBackAmount,
                mSurchargeAmount, mTenderType, mTransactionType, mRequiredEmvTags,
                mTerminalConfiguration);
    }

    @Override
    public String toString() {
        return "TerminalRequest{" +
                "mTerminalAction=" + mTerminalAction +
                ", mTotalAmount=" + mTotalAmount +
                ", mTipAmount=" + mTipAmount +
                ", mCashBackAmount=" + mCashBackAmount +
                ", mSurchargeAmount=" + mSurchargeAmount +
                ", mTenderType=" + mTenderType +
                ", mTransactionType=" + mTransactionType +
                ", mRequiredEmvTags=" + mRequiredEmvTags +
                ", mTerminalConfiguration=" + mTerminalConfiguration +
                '}';
    }
}
