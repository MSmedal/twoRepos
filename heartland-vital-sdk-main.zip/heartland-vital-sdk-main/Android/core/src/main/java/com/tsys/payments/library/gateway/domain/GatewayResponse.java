package com.tsys.payments.library.gateway.domain;

import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.enums.CommercialCard;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import androidx.annotation.Nullable;

/**
 * Represents information returned by a host after processing a transaction request.
 */
public class GatewayResponse {

    private GatewayAction mGatewayAction;
    private String mGatewayTransactionId;
    private boolean mApproved;
    private String mAuthCode;
    private String mCvvResponseCode;
    private String mAvsResponseCode;
    private String mGatewayResponseText;
    private String mGatewayResponseCode;
    private long mApprovedAmount;
    private Long mTipAmount;
    private String mEmvIssuerAuthCode;
    private String mEmvIssuerAuthenticationData;
    private String mEmvIssuerScripts;
    private boolean mError;
    private String mErrorMessage;
    private boolean mSafError;
    private boolean mPartialApproval;
    private String mMaskedPan;
    private String mAuthResponse;
    private String mStin;
    private String mPosReferenceId;
    private CardDataSourceType mCardDataSourceType;
    private CardType mCardType;
    private CommercialCard mCommercialCard;
    private String mCardholderName;
    private String mCardExpiryDate;
    private boolean mGatewayTimeout;
    private String mToken;
    private String mCardBrandTxnId;
    private String mCardHolderId;
    private String mOriginalGatewayTxnId;
    private String mOriginalRspDT;
    private String mOriginalClientTxnId;
    private String mOriginalAuthCode;
    private String mOriginalRefNbr;
    private long mOriginalAuthAmt;
    private String mOriginalCardType;
    private String mOriginalCardNbrLast4;

    public GatewayResponse(GatewayAction gatewayAction) {
        mGatewayAction = gatewayAction;
    }

    /**
     * @return {@link GatewayAction} that was performed. This may not match the action passed in to the
     * original {@link GatewayRequest}.
     */
    public GatewayAction getGatewayAction() {
        return mGatewayAction;
    }

    /**
     * @return Reference number for the transaction that a host can uniquely distinguish.
     */
    public String getGatewayTransactionId() {
        return mGatewayTransactionId;
    }

    /**
     * @param hostTransactionId Reference number for the transaction that a host can uniquely distinguish.
     */
    public void setGatewayTransactionId(String hostTransactionId) {
        mGatewayTransactionId = hostTransactionId;
    }

    /**
     * @return {@code true} if the requested action was approved by the host, {@code false}
     * otherwise.
     */
    public boolean isApproved() {
        return mApproved;
    }

    /**
     * @param approved Whether the host approved the requested action or not.
     */
    public void setApproved(boolean approved) {
        mApproved = approved;
    }

    /**
     * @return Auth Code received from the host when a transaction {@link #isApproved()}.
     */
    public String getAuthCode() {
        return mAuthCode;
    }

    /**
     * @param authCode Auth Code received from the host when a transaction {@link #isApproved()}.
     */
    public void setAuthCode(String authCode) {
        mAuthCode = authCode;
    }

    /**
     * @return Code indicating the result of CVV Verification, if performed by the host.
     */
    public String getCvvResponseCode() {
        return mCvvResponseCode;
    }

    /**
     * @param cvvResponseCode Code indicating the result of CVV Verification, if performed by the
     * host.
     */
    public void setCvvResponseCode(String cvvResponseCode) {
        mCvvResponseCode = cvvResponseCode;
    }

    /**
     * @return Code indicating the result of Address Verification, if performed by the host.
     */
    public String getAvsResponseCode() {
        return mAvsResponseCode;
    }

    /**
     * @param avsResponseCode Code indicating the result of Address Verification, if performed by the host.
     */
    public void setAvsResponseCode(String avsResponseCode) {
        mAvsResponseCode = avsResponseCode;
    }

    /**
     * @return Message provided from the host containing extra verbiage about the response.
     */
    public String getGatewayResponseText() {
        return mGatewayResponseText;
    }

    /**
     * @param gatewayResponseText Message provided from the host containing extra verbiage about the response.
     */
    public void setGatewayResponseText(String gatewayResponseText) {
        mGatewayResponseText = gatewayResponseText;
    }

    public String getGatewayResponseCode() {
        return mGatewayResponseCode;
    }

    public void setGatewayResponseCode(String gatewayResponseCode) {
        mGatewayResponseCode = gatewayResponseCode;
    }

    /**
     * @return Actual amount that was approved by the host. This may differ from the requested
     * transaction amount in partial approval scenarios.
     */
    public long getApprovedAmount() {
        return mApprovedAmount;
    }

    /**
     * @param approvedAmount Actual amount that was approved by the host. This may differ from the requested
     * transaction amount in partial approval scenarios.
     */
    public void setApprovedAmount(long approvedAmount) {
        mApprovedAmount = approvedAmount;
    }

    /**
     * @return Issuer Auth Code returned from the host during standard EMV transaction approvals.
     */
    public String getEmvIssuerAuthCode() {
        return mEmvIssuerAuthCode;
    }

    /**
     * @param emvIssuerAuthCode Issuer Auth Code returned from the host during contact EMV transaction approvals.
     */
    public void setEmvIssuerAuthCode(String emvIssuerAuthCode) {
        mEmvIssuerAuthCode = emvIssuerAuthCode;
    }

    /**
     * @return Data returned from the host during a contact EMV transaction for validation by the
     * chip.
     */
    public String getEmvIssuerAuthenticationData() {
        return mEmvIssuerAuthenticationData;
    }

    /**
     * @param emvIssuerAuthenticationData Data returned from the host during a contact EMV
     * transaction for validation by the chip.
     */
    public void setEmvIssuerAuthenticationData(String emvIssuerAuthenticationData) {
        mEmvIssuerAuthenticationData = emvIssuerAuthenticationData;
    }

    /**
     * @return Scripts that may be returned by the host that should be executed on the inserted chip
     * during contact EMV transactions.
     */
    public String getEmvIssuerScripts() {
        return mEmvIssuerScripts;
    }

    /**
     * @param emvIssuerScripts Scripts that may be returned by the host that should be executed on
     * the inserted chip during contact EMV transactions.
     */
    public void setEmvIssuerScripts(String emvIssuerScripts) {
        mEmvIssuerScripts = emvIssuerScripts;
    }

    public boolean isError() {
        return mError;
    }

    public void setError(boolean error) {
        mError = error;
    }

    public boolean isSafError() {
        return mSafError;
    }

    public void setSafError(boolean safError) {
        mSafError = safError;
    }

    public String getErrorMessage() {
        return mErrorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        mErrorMessage = errorMessage;
    }

    public void setPartialApproval(boolean partialApproval) {
        mPartialApproval = partialApproval;
    }

    public boolean isPartialApproval() {
        return mPartialApproval;
    }

    public void setMaskedPan(String maskedPan) {
        mMaskedPan = maskedPan;
    }

    public String getMaskedPan() {
        return mMaskedPan;
    }

    public void setAuthResponse(String authResponse) {
        mAuthResponse = authResponse;
    }

    public String getAuthResponse() {
        return mAuthResponse;
    }

    public void setStin(String stin) {
        mStin = stin;
    }

    public String getStin() {
        return mStin;
    }

    public void setPosReferenceId(String posReferenceId) {
        mPosReferenceId = posReferenceId;
    }

    public String getPosReferenceId() {
        return mPosReferenceId;
    }

    public CardType getCardType() {
        return mCardType;
    }

    public void setCardType(CardType cardType) {
        mCardType = cardType;
    }

    public CommercialCard getCommercialCard() {
        return mCommercialCard;
    }

    public void setCommercialCard(CommercialCard commercialCard) {
        mCommercialCard = commercialCard;
    }

    public CardDataSourceType getCardDataSourceType() {
        return mCardDataSourceType;
    }

    public void setCardDataSourceType(CardDataSourceType cardDataSourceType) {
        mCardDataSourceType = cardDataSourceType;
    }

    public void setCardholderName(String cardholderName) {
        mCardholderName = cardholderName;
    }

    public String getCardholderName() {
        return mCardholderName;
    }

    public void setCardExpiryDate(String cardExpiryDate) {
        mCardExpiryDate = cardExpiryDate;
    }

    public String getCardExpiryDate() {
        return mCardExpiryDate;
    }

    public boolean isGatewayTimeout() {
        return mGatewayTimeout;
    }

    public void setGatewayTimeout(boolean gatewayTimeout) {
        mGatewayTimeout = gatewayTimeout;
    }

    @Nullable
    public Long getTipAmount() {
        return mTipAmount;
    }

    public void setTipAmount(@Nullable Long tipAmount) {
        mTipAmount = tipAmount;
    }

    @Nullable
    public String getToken() {
        return mToken;
    }

    /**
     * @param token
     * Can be used later for subsequent transactions as a substitute for the associated
     * customer's payment data
     */
    public void setToken(@Nullable String token) {
        mToken = token;
    }

    @Nullable
    public String getCardBrandTxnId() {
        return mCardBrandTxnId;
    }

    /**
     * @param cardBrandTxnId
     * Used in conjunction with token for subsequent transactions.
     */
    public void setCardBrandTxnId(@Nullable String cardBrandTxnId) {
        mCardBrandTxnId = cardBrandTxnId;
    }

    @Nullable
    public String getCardHolderId() {
        return mCardHolderId;
    }

    /**
     * @param cardHolderId
     * Can be used later for subsequent transactions as a substitute for the associated
     * customer's payment data
     */
    public void setCardHolderId(@Nullable String cardHolderId) {
        mCardHolderId = cardHolderId;
    }

    public String getOriginalGatewayTxnId() {
        return mOriginalGatewayTxnId;
    }

    public void setOriginalGatewayTxnId(String originalGatewayTxnId) {
        mOriginalGatewayTxnId = originalGatewayTxnId;
    }

    public String getOriginalRspDT() {
        return mOriginalRspDT;
    }

    public void setOriginalRspDT(String originalRspDT) {
        mOriginalRspDT = originalRspDT;
    }

    public String getOriginalClientTxnId() {
        return mOriginalClientTxnId;
    }

    public void setOriginalClientTxnId(String originalClientTxnId) {
        mOriginalClientTxnId = originalClientTxnId;
    }

    public String getOriginalAuthCode() {
        return mOriginalAuthCode;
    }

    public void setOriginalAuthCode(String originalAuthCode) {
        mOriginalAuthCode = originalAuthCode;
    }

    public String getOriginalRefNbr() {
        return mOriginalRefNbr;
    }

    public void setOriginalRefNbr(String originalRefNbr) {
        mOriginalRefNbr = originalRefNbr;
    }

    public long getOriginalAuthAmt() {
        return mOriginalAuthAmt;
    }

    public void setOriginalAuthAmt(long originalAuthAmt) {
        mOriginalAuthAmt = originalAuthAmt;
    }

    public String getOriginalCardType() {
        return mOriginalCardType;
    }

    public void setOriginalCardType(String originalCardType) {
        mOriginalCardType = originalCardType;
    }

    public String getOriginalCardNbrLast4() {
        return mOriginalCardNbrLast4;
    }

    public void setOriginalCardNbrLast4(String originalCardNbrLast4) {
        mOriginalCardNbrLast4 = originalCardNbrLast4;
    }

}
