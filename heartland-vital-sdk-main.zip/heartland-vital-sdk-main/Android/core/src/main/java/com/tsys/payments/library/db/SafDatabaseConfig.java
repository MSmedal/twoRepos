package com.tsys.payments.library.db;

import java.util.concurrent.TimeUnit;

/**
 * Configuration for SAF (store and forward) related logic in the SDK database.
 */
public class SafDatabaseConfig {
    /**
     * Whether to store transactions when offline for SAF processing
     */
    final private boolean mSafEnabled;

    /**
     * The life span of SAF transactions before they are purged for being expired.
     */
    final private long mSafTransactionPurgeTime;

    /**
     * The time unit used for SAF transactions before they are purged for being expired.
     */
    final private TimeUnit mSafTransactionPurgeTimeUnit;

    public SafDatabaseConfig(boolean safEnabled, long safTransactionPurgeTime,
            TimeUnit safTransactionPurgeTimeUnit) {
        mSafEnabled = safEnabled;
        mSafTransactionPurgeTime = safTransactionPurgeTime;
        mSafTransactionPurgeTimeUnit = safTransactionPurgeTimeUnit;
    }

    public boolean isSafEnabled() {
        return mSafEnabled;
    }

    public long getSafTransactionPurgeTime() {
        return mSafTransactionPurgeTime;
    }

    public TimeUnit getSafTransactionPurgeTimeUnit() {
        return mSafTransactionPurgeTimeUnit;
    }
}
