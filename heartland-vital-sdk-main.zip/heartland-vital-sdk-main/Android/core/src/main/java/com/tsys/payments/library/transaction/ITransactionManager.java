package com.tsys.payments.library.transaction;

import android.content.Context;

import com.tsys.payments.library.connection.ConnectionListener;
import com.tsys.payments.library.db.SafListener;
import com.tsys.payments.library.domain.CardholderInteractionResult;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.domain.TransactionRequest;
import com.tsys.payments.library.domain.TransactionResponse;
import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.TerminalSettingType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.enums.TerminalUpdateType;
import com.tsys.payments.library.enums.TransactionStatus;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.enums.GatewayType;
import com.tsys.payments.library.terminal.AvailableTerminalVersionsListener;
import com.tsys.payments.library.terminal.TerminalController;
import com.tsys.payments.library.terminal.TerminalInfoListener;
import com.tsys.payments.library.terminal.TerminalReadSettingListener;
import com.tsys.payments.library.terminal.TerminalUpdateSettingListener;
import com.tsys.payments.library.terminal.UpdateTerminalListener;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
import java.util.Map;

public interface ITransactionManager {

    /**
     * @param gatewayType {@link GatewayType} against which the supported terminals are certified.
     * @return Array of supported {@link TerminalType} by the concrete implementation, or null if there are no terminals
     * supported.
     */
    @Nullable
    TerminalType[] getSupportedTerminalTypes(@Nullable GatewayType gatewayType);

    /**
     * @param terminalType Supported {@link TerminalType} whose connection types to return.
     * @return Array {@link ConnectionType}s supported by {@param terminalType}, or null if the {@link TerminalType} is
     * not recognized or supported.
     */
    @Nullable
    ConnectionType[] getSupportedTerminalConnectionTypes(TerminalType terminalType);

    void initialize(@NonNull Context context, @Nullable TerminalConfiguration terminalConfig,
            @NonNull TransactionConfiguration transactionConfig,
            @NonNull GatewayConfiguration hostConfig) throws InitializationException;

    void connect(@NonNull ConnectionListener listener);

    void getDeviceInfo(@NonNull TerminalInfoListener listener);

    void updateTransactionListener(@NonNull TransactionListener listener);

    void startTransaction(@NonNull TransactionRequest request,
            @NonNull TransactionListener listener, SafListener safListener);

    /**
     * Takes list of IDs to retrieve transactions from SAF database and begin processing. Requires {@link
     * com.tsys.payments.library.db.DatabaseController} and {@link com.tsys.payments.library.gateway.GatewayController}
     * to be initialized and SafTransactions stored in database. Should be called once device has network connection.
     *
     * @param safLocalIds list of IDs to retrieve from database
     * @param safListener {@link SafListener} listener to callback to app once processing is complete
     */
    void processSafTransactionsByPosReferenceIds(@NonNull final List<Long> safLocalIds,
            @NonNull SafListener safListener);

    /**
     * Takes all transactions from SAF database and begins processing. Requires {@link
     * com.tsys.payments.library.db.DatabaseController} and {@link com.tsys.payments.library.gateway.GatewayController}
     * to be initialized and SafTransactions stored in database. Should be called once device has network connection.
     *
     * @param safListener {@link SafListener} listener to callback to app once processing is complete
     */
    void processAllSafTransactions(@NonNull SafListener safListener);

    /**
     * Allows customer to retrieve list of {@link com.tsys.payments.library.db.entity.SafTransaction}, all non-expired
     * saf transactions in database, excluding sensitive information.
     *
     * @param safListener {@link SafListener} listener to callback to app once processing is complete
     * @see com.tsys.payments.library.db.SafDatabaseConfig for expiration configuration information.
     */
    void getAllValidSafTransactions(@NonNull SafListener safListener);

    void sendCardholderInteractionResult(
            @NonNull CardholderInteractionResult cardholderInteractionResult);

    /**
     * Invoke when the consumer wants to cancel a transaction. If a transaction is in progress and is in a cancellable
     * state, the current processing will be stopped and {@link TransactionListener#onTransactionComplete(TransactionResponse)}
     * will be triggered with a result indicating that the transaction was cancelled. If the transaction cannot be
     * cancelled, {@link TransactionListener#onStatusUpdate(TransactionStatus)} will be broadcast with a status
     * indicating that the terminal is busy.
     */
    void cancel();

    void disconnect();

    boolean isInitialized();

    /**
     * Check to see if the card reader is connected.
     *
     * @return true if connected, false otherwise.
     */
    boolean isConnected();

    /**
     * Update terminal settings for a connected terminal
     *
     * @param terminalSettingsType new settings type
     * @param terminalSettingsValue new settings values
     * @param terminalUpdateSettingListener callback for reporting the results
     */
    void updateTerminalSetting(TerminalSettingType terminalSettingsType, String terminalSettingsValue,
            TerminalUpdateSettingListener terminalUpdateSettingListener);

    /**
     * Read terminal settings for a connected terminal.
     *
     * @param terminalSettingsType setting type to be queried
     * @param terminalReadSettingListener callback for reporting the results
     */
    void readTerminalSetting(TerminalSettingType terminalSettingsType,
            TerminalReadSettingListener terminalReadSettingListener);

    /**
     * Get available terminal versions for a connected terminal.
     *
     * @param terminalUpdateType type to be updated
     * @param credentials {@link Map} containing any credentials needed for authentication for the terminal update to
     * succeed.
     * @param availableTerminalVersionsListener callback for reporting available terminal versions
     */
    void getAvailableTerminalVersions(@NonNull TerminalUpdateType terminalUpdateType,
            @Nullable Map<String, String> credentials,
            @NonNull AvailableTerminalVersionsListener availableTerminalVersionsListener);

    /**
     * Updates connected terminal software.
     *
     * @param terminalUpdateType type to be updated
     * @param version Represents the version to update to.
     * @param credentials {@link Map} containing any credentials needed for authentication for the terminal update to
     * succeed.
     * @param updateTerminalListener callback for reporting the update result
     */
    void updateTerminal(@NonNull TerminalUpdateType terminalUpdateType,
            @Nullable Map<String, String> credentials,
            @Nullable String version,
            @NonNull UpdateTerminalListener updateTerminalListener);
}
