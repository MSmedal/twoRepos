package com.tsys.payments.library.terminal;

import com.tsys.payments.library.enums.TerminalSettingType;
import com.tsys.payments.library.exceptions.Error;

public interface TerminalUpdateSettingListener {
    /**
     * Invoked when a terminal setting has been updated
     *
     * @param terminalSettingType The setting to update
     * @param value The value updated for the setting
     */
    void onTerminalSettingUpdated(TerminalSettingType terminalSettingType, Object value);

    /**
     * Invoked when updating a terminal setting has caused an error
     *
     * @param error The error produced when trying to update setting
     */
    void onError(Error error);
}
