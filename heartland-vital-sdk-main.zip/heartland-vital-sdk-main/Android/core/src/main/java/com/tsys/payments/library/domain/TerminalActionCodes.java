package com.tsys.payments.library.domain;

import com.google.gson.annotations.SerializedName;

public class TerminalActionCodes {
    @SerializedName("default_tac")
    private String mDefaultTac;
    @SerializedName("denial_tac")
    private String mDenialTac;
    @SerializedName("online_tac")
    private String mOnlineTac;

    public TerminalActionCodes(String defaultTAC, String denialTAC, String onlineTAC) {
        mDefaultTac = defaultTAC;
        mDenialTac = denialTAC;
        mOnlineTac = onlineTAC;
    }

    public String getDefaultTac() {
        return mDefaultTac;
    }

    public String getDenialTac() {
        return mDenialTac;
    }

    public String getOnlineTac() {
        return mOnlineTac;
    }
}
