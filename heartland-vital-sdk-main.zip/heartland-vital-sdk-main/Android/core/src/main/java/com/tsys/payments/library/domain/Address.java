package com.tsys.payments.library.domain;

import java.util.Objects;

public class Address {

    private String mAddressLine1;

    private String mAddressLine2;

    private String mPostalCode;

    private String mCity;

    private String mState;

    public String getAddressLine1() {
        return mAddressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        mAddressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return mAddressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        mAddressLine2 = addressLine2;
    }

    public String getPostalCode() {
        return mPostalCode;
    }

    public void setPostalCode(String postalCode) {
        mPostalCode = postalCode;
    }

    public String getCity() {
        return mCity;
    }

    public void setCity(String city) {
        mCity = city;
    }

    public String getState() {
        return mState;
    }

    public void setState(String state) {
        mState = state;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Address)) return false;
        Address address = (Address)o;
        return Objects.equals(mAddressLine1, address.mAddressLine1) &&
                Objects.equals(mAddressLine2, address.mAddressLine2) &&
                Objects.equals(mPostalCode, address.mPostalCode) &&
                Objects.equals(mCity, address.mCity) &&
                Objects.equals(mState, address.mState);
    }

    @Override
    public int hashCode() {

        return Objects.hash(mAddressLine1, mAddressLine2, mPostalCode, mCity, mState);
    }

    @Override
    public String toString() {
        return "Address{" +
                "mAddressLine1='" + mAddressLine1 + '\'' +
                ", mAddressLine2='" + mAddressLine2 + '\'' +
                ", mPostalCode='" + mPostalCode + '\'' +
                ", mCity='" + mCity + '\'' +
                ", mState='" + mState + '\'' +
                '}';
    }
}
