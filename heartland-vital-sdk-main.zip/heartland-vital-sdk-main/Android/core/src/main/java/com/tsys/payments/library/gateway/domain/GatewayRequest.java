package com.tsys.payments.library.gateway.domain;

import android.graphics.Bitmap;

import com.tsys.payments.library.domain.Address;
import com.tsys.payments.library.domain.AutoSubstantiation;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.CommercialCardData;
import com.tsys.payments.library.domain.Customer;
import com.tsys.payments.library.domain.TerminalCapabilities;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.enums.AvsType;
import com.tsys.payments.library.enums.CvmResult;
import com.tsys.payments.library.enums.ReversalReason;
import com.tsys.payments.library.enums.TaxCategory;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Represents data provided to a host to perform a transaction.
 */
public class GatewayRequest {

    @NonNull
    private GatewayAction mGatewayAction;
    private String mGatewayTransactionId;
    private long mSubtotal;
    private Long mTax;
    private Long mRefundTax;
    private Long mTip;
    private Long mRefundTip;
    private long mTotal;
    private Long mSurcharge;
    private String mPosReferenceNumber;
    private Bitmap mBase64EncodedSignature;
    private String mForceAuthCode;
    private TenderType mTenderType;
    private CvmResult mCvmResult;
    private String mInvoiceNumber;
    private ReversalReason mReversalReason;
    private TerminalInfo mTerminalInfo;
    private Customer mCustomer;
    private Address mCardholderAddress;
    private AvsType mAvsType;
    private CardData mCardData;
    private CommercialCardData mCommercialCardData;
    private TerminalCapabilities mTerminalCapabilities;
    private TaxCategory mTaxCategory;
    private String mOperatingUserId;
    private boolean mGenerateToken;
    private String mToken;
    private String mCardBrandTxnId;
    private String mCardHolderId;
    private AutoSubstantiation mAutoSubstantiation;
    private boolean mAllowDuplicates;
    private boolean mSAFIndicator;
    @Nullable
    private String mSAFOrigDT;
    @Nullable
    private String mSignatureFileLocation;

    private int[] mSignatureBitmap;

    private GatewayRequest(@NonNull GatewayAction action) {
        mGatewayAction = action;
    }

    /**
     * @return {@link GatewayAction} to perform.
     */
    @NonNull
    public GatewayAction getGatewayAction() {
        return mGatewayAction;
    }

    /**
     * @return Reference number for the transaction that a host can uniquely distinguish.
     */
    @Nullable
    public String getGatewayTransactionId() {
        return mGatewayTransactionId;
    }

    /**
     * @return Transaction amount less taxes, gratuity, fees, or cash back.
     */
    public long getSubtotal() {
        return mSubtotal;
    }

    /**
     * @return Tax amount being applied to the subtotal.
     */
    @Nullable
    public Long getTax() {
        return mTax;
    }

    /**
     * @return Tax amount being applied to open amount refund request.
     */
    @Nullable
    public Long getRefundTax() {
        return mRefundTax;
    }

    /**
     * @return Gratuity amount to apply on top of the subtotal and taxes.
     */
    @Nullable
    public Long getTip() {
        return mTip;
    }

    /**
     * @return Gratuity amount to apply to open amount refund request.
     */
    @Nullable
    public Long getRefundTip() {
        return mRefundTip;
    }

    /**
     * @return Total amount to be charged for this transaction, less any cash back amount.
     */
    public long getTotal() {
        return mTotal;
    }

    /**
     * @return surcharge amount to be charged for this transaction
     */
    public Long getSurcharge() {
        return mSurcharge;
    }

    /**
     * @return Identifier provided by the consuming POS.
     */
    @Nullable
    public String getPosReferenceNumber() {
        return mPosReferenceNumber;
    }

    /**
     * @return Cardholder signature as a Base64 Encoded {@link String}.
     */
    @Nullable
    public Bitmap getBase64EncodedSignature() {
        return mBase64EncodedSignature;
    }

    /**
     * @return Code received from the Issuer when performing a {@link GatewayAction#FORCE_AUTH}.
     */
    @Nullable
    public String getForceAuthCode() {
        return mForceAuthCode;
    }

    public CardData getCardData() {
        return mCardData;
    }

    /**
     * @return Extra information required for commercial cards LEVEL2 when performing a {@link
     * GatewayAction#TRANSACTION_ADJUSTMENT}
     */
    public CommercialCardData getCommercialCardData() {
        return mCommercialCardData;
    }

    /**
     * @return {@link TenderType} selected for this request.
     */
    @Nullable
    public TenderType getTenderType() {
        return mTenderType;
    }

    /**
     * @return {@link CvmResult} used to verify the cardholder.
     */
    @Nullable
    public CvmResult getCvmResult() {
        return mCvmResult;
    }

    public Address getCardholderAddress() {
        return mCardholderAddress;
    }

    public AvsType getAvsType() {
        return mAvsType;
    }

    /**
     * @return Method in which tax is applied to this request, if supported.
     */

    @Nullable
    public ReversalReason getReversalReason() {
        return mReversalReason;
    }

    @Nullable
    public Customer getCustomer() {
        return mCustomer;
    }

    @Nullable
    public TerminalCapabilities getTerminalCapabilities() {
        return mTerminalCapabilities;
    }

    public TerminalInfo getTerminalInfo() {
        return mTerminalInfo;
    }

    public void setTerminalInfo(TerminalInfo terminalInfo) {
        mTerminalInfo = terminalInfo;
    }

    public String getInvoiceNumber() {
        return mInvoiceNumber;
    }

    public TaxCategory getTaxCategory() {
        return mTaxCategory;
    }

    /**
     * @return {@link String} specifying the id of the user performing actions in the consuming POS.
     */
    public String getOperatingUserId() {
        return mOperatingUserId;
    }

    public boolean isGenerateToken() {
        return mGenerateToken;
    }

    public String getToken() {
        return mToken;
    }

    public String getCardBrandTxnId() {
        return mCardBrandTxnId;
    }

    public boolean isAllowDuplicates() {
        return mAllowDuplicates;
    }

    public boolean isSAFIndicator() {
        return mSAFIndicator;
    }

    public String getSAFOrigDT() {
        return mSAFOrigDT;
    }

    public AutoSubstantiation getAutoSubstantiation() {
        return mAutoSubstantiation;
    }

    public String getCardHolderId() {
        return mCardHolderId;
    }

    public int[] getSignatureBitmap() {
        return mSignatureBitmap;
    }

    public void setSignatureBitmap(int[] signatureBitmap) {
        mSignatureBitmap = signatureBitmap;
    }

    @Nullable
    public String getSignatureFileLocation() {
        return mSignatureFileLocation;
    }

    public static class Builder {

        private GatewayRequest mGatewayRequest;

        public Builder(GatewayAction action) {
            mGatewayRequest = new GatewayRequest(action);
        }

        /**
         * Conditional based on the {@link GatewayAction}.
         * <p>
         * <ul>
         * <li>{@link GatewayAction#SALE} - Not used.</li>
         * <li>{@link GatewayAction#AUTH} - Not used.</li>
         * <li>{@link GatewayAction#CAPTURE} - Required.</li>
         * <li>{@link GatewayAction#VOID} - Required. </li>
         * <li>{@link GatewayAction#REFUND} - Required.</li>
         * <li>{@link GatewayAction#TIP_ADJUST} - Required.</li>
         * <li>{@link GatewayAction#FORCE_AUTH} - Not used.</li>
         * <li>{@link GatewayAction#BALANCE_INQUIRY} - Not used.</li>
         * </ul>
         *
         * @param hostTransactionId Host transaction ID from a previous transaction.
         */
        public Builder setHostTransactionId(String hostTransactionId) {
            mGatewayRequest.mGatewayTransactionId = hostTransactionId;
            return this;
        }

        /**
         * @param subtotal Transaction amount less taxes, gratuity, fees, or cash back.
         * @return this {@link Builder} instance.
         */
        public Builder setSubtotal(long subtotal) {
            mGatewayRequest.mSubtotal = subtotal;
            return this;
        }

        /**
         * @param tax Tax amount being applied to the subtotal.
         * @return this {@link Builder} instance.
         */
        public Builder setTax(Long tax) {
            mGatewayRequest.mTax = tax;
            return this;
        }

        /**
         * @param refundTax Tax amount being applied to open amount refund request.
         * @return this {@link Builder} instance.
         */
        public Builder setRefundTax(Long refundTax) {
            mGatewayRequest.mRefundTax = refundTax;
            return this;
        }

        /***
         *
         * @param tip Gratuity amount to apply on top of the subtotal and taxes.
         * @return this {@link Builder} instance.
         */
        public Builder setTip(Long tip) {
            mGatewayRequest.mTip = tip;
            return this;
        }

        /***
         *
         * @param refundTip Gratuity amount to apply to open amount refund request.
         * @return this {@link Builder} instance.
         */
        public Builder setRefundTip(Long refundTip) {
            mGatewayRequest.mRefundTip = refundTip;
            return this;
        }

        /**
         * @param total Total amount to be charged for this transaction, less any cash back amount.
         * @return this {@link Builder} instance.
         */
        public Builder setTotal(long total) {
            mGatewayRequest.mTotal = total;
            return this;
        }

        /**
         * @param surcharge amount to be charged as surcharge for this transaction
         * @return this {@link Builder} instance
         */
        public Builder setSurcharge(@Nullable Long surcharge) {
            mGatewayRequest.mSurcharge = surcharge;
            return this;
        }

        /**
         * @param posReferenceNumber Identifier provided by the consuming POS.
         * @return this {@link Builder} instance.
         */
        public Builder setPosReferenceNumber(String posReferenceNumber) {
            mGatewayRequest.mPosReferenceNumber = posReferenceNumber;
            return this;
        }

        /**
         * @param base64EncodedSignature Cardholder signature as a Base64 Encoded {@link Bitmap}.
         * @return this {@link Builder} instance.
         */
        public Builder setBase64EncodedSignature(Bitmap base64EncodedSignature) {
            mGatewayRequest.mBase64EncodedSignature = base64EncodedSignature;
            return this;
        }

        /**
         * @param forceAuthCode Code received from the Issuer when performing a {@link
         *                      GatewayAction#FORCE_AUTH}.
         * @return this {@link Builder} instance.
         */
        public Builder setForceAuthCode(String forceAuthCode) {
            mGatewayRequest.mForceAuthCode = forceAuthCode;
            return this;
        }

        /**
         * @param cardData Container holding the encrypted data read from the card.'=
         * @return this {@link Builder} instance
         */
        public Builder setCardData(CardData cardData) {
            mGatewayRequest.mCardData = cardData;
            return this;
        }

        /**
         * @param commercialCardData Container holding the commercial card LEVEL2 information.
         * @return this {@link Builder} instance
         */
        public Builder setCommercialCardData(CommercialCardData commercialCardData) {
            mGatewayRequest.mCommercialCardData = commercialCardData;
            return this;
        }

        /**
         * @param tenderType {@link TenderType} the request should be processed as.
         * @return this {@link Builder} instance.
         */
        public Builder setTenderType(TenderType tenderType) {
            mGatewayRequest.mTenderType = tenderType;
            return this;
        }

        /**
         * @param cvmType {@link CvmResult} used to verify cardholder.
         * @return this {@link Builder} instance.
         */
        public Builder setCvmType(CvmResult cvmType) {
            mGatewayRequest.mCvmResult = cvmType;
            return this;
        }

        public Builder setAddress(Address address) {
            mGatewayRequest.mCardholderAddress = address;
            return this;
        }

        public Builder setAvsType(AvsType avsType) {
            mGatewayRequest.mAvsType = avsType;
            return this;
        }

        public Builder setTerminalInfo(TerminalInfo terminalInfo) {
            mGatewayRequest.mTerminalInfo = terminalInfo;
            return this;
        }

        public Builder setCustomerInfo(Customer customer) {
            mGatewayRequest.mCustomer = customer;
            return this;
        }

        public Builder setVoidReason(ReversalReason reversalReason) {
            mGatewayRequest.mReversalReason = reversalReason;
            return this;
        }

        public Builder setTerminalCapabilities(TerminalCapabilities terminalCapabilities) {
            mGatewayRequest.mTerminalCapabilities = terminalCapabilities;
            return this;
        }

        public Builder setInvoiceNumber(String invoiceNumber) {
            mGatewayRequest.mInvoiceNumber = invoiceNumber;
            return this;
        }

        public Builder setTaxCategory(TaxCategory taxCategory) {
            mGatewayRequest.mTaxCategory = taxCategory;
            return this;
        }

        /**
         * Set the id of the user performing actions in the consuming POS. Required when {@link
         * GatewayAction#BATCH_CLOSE} is being processed.
         *
         * @param operatingUserId {@link String} provided by the consuming POS.
         */
        public Builder setOperatingUserId(String operatingUserId) {
            mGatewayRequest.mOperatingUserId = operatingUserId;
            return this;
        }

        /**
         * @param generateToken Indicates to the host that a token must be generated for the current
         *                      payment transaction
         */
        public Builder setGenerateToken(boolean generateToken) {
            mGatewayRequest.mGenerateToken = generateToken;
            return this;
        }

        /**
         * @param token Represents a value that can be used as a substitute to payment card data for
         *              processing transactions. see {@link GatewayResponse#setToken(String)}
         */
        public Builder setToken(@NonNull String token) {
            mGatewayRequest.mToken = token;
            return this;
        }

        public Builder setCardBrandTxnId(@NonNull String cardBrandTxnId) {
            mGatewayRequest.mCardBrandTxnId = cardBrandTxnId;
            return this;
        }

        /**
         * @param cardHolderId Represents a value that can be used as a substitute to payment card
         *                     data for processing transactions. see {@link GatewayResponse#setCardHolderId(String)}
         */
        public Builder setCardHolderId(String cardHolderId) {
            mGatewayRequest.mCardHolderId = cardHolderId;
            return this;
        }

        public Builder setAllowDuplicates(boolean allowDuplicates) {
            mGatewayRequest.mAllowDuplicates = allowDuplicates;
            return this;
        }

        public Builder setAutoSubstantiation(AutoSubstantiation autoSubstantiation) {
            mGatewayRequest.mAutoSubstantiation = autoSubstantiation;
            return this;
        }

        public Builder setSAFIndicator(boolean safIndicator) {
            mGatewayRequest.mSAFIndicator = safIndicator;
            return this;
        }

        public Builder setSAFOrigDT(String safOrigDT) {
            mGatewayRequest.mSAFOrigDT = safOrigDT;
            return this;
        }

        /**
         * @param signatureBitmap Represents array of integer-encoded pixels comprising the
         *                        signature image.
         */
        public Builder setSignatureBitmap(int[] signatureBitmap) {
            mGatewayRequest.mSignatureBitmap = signatureBitmap;
            return this;
        }

        /**
         * @param signatureFileLocation {@link String} Represents the path to the signature for this
         *                              gateway request on the user's file system.
         */
        public Builder setSignatureFilelocation(@Nullable String signatureFileLocation) {
            mGatewayRequest.mSignatureFileLocation = signatureFileLocation;
            return this;
        }

        /**
         * @return Immutable {@link GatewayRequest} created using this {@link Builder} instance.
         */
        public GatewayRequest build() {
            return mGatewayRequest;
        }
    }
}
