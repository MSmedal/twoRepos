package com.tsys.payments.host.portico;

import com.global.api.entities.Address;
import com.global.api.entities.enums.AddressType;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayRequest.Builder;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.tlv.ConstructedTlvObject;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvUtils;

import java.util.List;

import androidx.annotation.NonNull;

import static com.tsys.payments.host.portico.Constants.PORTICO_CONTACTLESS_EMV_TLV_DATA;
import static com.tsys.payments.host.portico.Constants.PORTICO_CONTACTLESS_MSR_TLV_DATA;
import static com.tsys.payments.host.portico.Constants.TRACK_1_HEX;
import static com.tsys.payments.host.portico.Constants.TRACK_2_HEX;

final class PorticoRequestProvider {

    static GatewayRequest.Builder manualAuth(long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.PHONE);
        cardData.setPan("4111111111111111");
        cardData.setCvv2("999");
        cardData.setExpirationDate("112021");
        builder.setCardData(cardData).setTotal(amount);
        return builder;
    }

    static GatewayRequest.Builder manualAuthDecline(@NonNull String pan) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.PHONE);
        cardData.setPan(pan);
        cardData.setCvv2("999");
        cardData.setExpirationDate("112021");
        builder.setCardData(cardData).setTotal(0);
        return builder;
    }

    static GatewayRequest.Builder manualSale(long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.SALE);
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.PHONE);
        cardData.setPan("4111111111111111");
        cardData.setCvv2("999");
        cardData.setExpirationDate("112021");
        builder.setCardData(cardData).setTotal(amount);
        return builder;
    }

    static GatewayRequest.Builder msrTrack1Auth(long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);

        cardData.setTrack1(TRACK_1_HEX);
        cardData.setKsn(Constants.KSN_HEX);

        builder.setCardData(cardData).setTotal(amount);
        return builder;
    }

    static GatewayRequest.Builder msrTrack1AndTrack2Auth(long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);

        cardData.setTrack1(TRACK_1_HEX);
        cardData.setTrack2(TRACK_2_HEX);
        cardData.setKsn(Constants.KSN_HEX);

        builder.setCardData(cardData).setTotal(amount);
        return builder;
    }

    static GatewayRequest.Builder msrTrack1Sale(long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.SALE);
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);

        cardData.setTrack1(TRACK_1_HEX);
        cardData.setKsn(Constants.KSN_HEX);

        builder.setCardData(cardData).setTotal(amount);
        return builder;
    }

    static GatewayRequest.Builder msrTrack1AndTrack2Sale(long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);

        cardData.setTrack1(TRACK_1_HEX);
        cardData.setTrack2(TRACK_2_HEX);
        cardData.setKsn(Constants.KSN_HEX);

        builder.setCardData(cardData).setTotal(amount);
        return builder;
    }

    static GatewayRequest.Builder authCaptureRequest(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.CAPTURE);
        builder.setTip(400L);
        builder.setTotal(gatewayResponse.getApprovedAmount() + 400L);
        builder.setHostTransactionId(gatewayResponse.getGatewayTransactionId());
        return builder;
    }

    static GatewayRequest.Builder contactlessMsrAuthRequest(long amount) {
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.CONTACTLESS_MSR);
        List<TlvObject> tlvObjects = ConstructedTlvObject.parse(PORTICO_CONTACTLESS_MSR_TLV_DATA);
        cardData.setEmvTlvData(tlvObjects);
        cardData.setPan(extractMaskedPanFromTlv(tlvObjects));

        GatewayRequest.Builder builder = new Builder(GatewayAction.AUTH);
        builder.setTotal(amount)
                .setCardData(cardData);

        return builder;
    }

    static GatewayRequest.Builder contactlessEmvAuthRequest(long amount) {
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.CONTACTLESS_EMV);
        List<TlvObject> tlvObjects = ConstructedTlvObject.parse(PORTICO_CONTACTLESS_EMV_TLV_DATA);
        cardData.setEmvTlvData(tlvObjects);
        cardData.setPan(extractMaskedPanFromTlv(tlvObjects));

        GatewayRequest.Builder builder = new Builder(GatewayAction.AUTH);
        builder.setTotal(amount)
                .setCardData(cardData);

        return builder;
    }

    static String extractMaskedPanFromTlv(List<TlvObject> tlvObjects) {
        TlvObject maskedPan =
                TlvUtils.findTlv(EmvTagDescriptor.BBPOS_MASKED_PAN, tlvObjects);
        if (maskedPan != null) {
            return maskedPan.getValueAsHexString(false);
        }

        return null;
    }

    static GatewayRequest.Builder tipAdjustRequest(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.TIP_ADJUST);
        builder.setTip(10L);
        builder.setTotal(gatewayResponse.getApprovedAmount() + 10L);
        builder.setHostTransactionId(gatewayResponse.getGatewayTransactionId());
        return builder;
    }

    static GatewayRequest.Builder refundRequest(GatewayResponse gatewayResponse, long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.REFUND);
        builder.setHostTransactionId(gatewayResponse.getGatewayTransactionId());
        builder.setTotal(amount);
        return builder;
    }

    static GatewayRequest.Builder refundWithTipRequest(GatewayResponse gatewayResponse,
            long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.REFUND);
        builder.setHostTransactionId(gatewayResponse.getGatewayTransactionId());
        builder.setTip(10L);
        builder.setTotal(amount + 10L);
        return builder;
    }

    static Builder manualSaleWithTip(long amount, long tip) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.SALE);
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.PHONE);
        cardData.setPan("4111111111111111");
        cardData.setCvv2("999");
        cardData.setExpirationDate("112021");
        builder.setCardData(cardData).setTotal(amount);
        builder.setTip(tip);
        return builder;
    }

    static Builder authWithToken(GatewayResponse gatewayResponse, long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.AUTH);
        builder.setToken(gatewayResponse.getToken());
        builder.setTotal(amount);
        return builder;
    }

    static Builder saleWithToken(GatewayResponse gatewayResponse, long amount) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.SALE);
        builder.setToken(gatewayResponse.getToken());
        builder.setTotal(amount);
        return builder;
    }

    static Builder voidRequest(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.VOID);
        builder.setHostTransactionId(gatewayResponse.getGatewayTransactionId());
        return builder;
    }

    static Builder manualEntryVerify(CardData cardData, boolean requestToken) {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.VERIFY);

        builder.setCardData(cardData)
                .setTenderType(TenderType.CREDIT)
                .setGenerateToken(requestToken);
        return builder;
    }

    static Builder msrTrack1Verify(String track1, String ksn, boolean requestToken) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.VERIFY);

        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);
        cardData.setTrack1(track1);
        cardData.setKsn(ksn);

        builder.setCardData(cardData)
                .setTenderType(TenderType.CREDIT)
                .setGenerateToken(requestToken);
        return builder;
    }

    static Builder batchCloseRequest() {
        return new Builder(GatewayAction.BATCH_CLOSE);
    }

    static Address getTestAddress() {
        Address address = new Address();
        // Address line 1
        address.setStreetAddress1("6860");
        // Address line 2
        address.setStreetAddress2("Apt 220");
        // City
        address.setCity("Zoo");
        // Postal code
        address.setPostalCode("75024");
        // Address type
        address.setType(AddressType.Billing);
        return address;
    }
}
