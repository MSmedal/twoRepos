package com.tsys.payments.host.portico;

import android.util.Log;

import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayResponse;

import static org.junit.Assert.assertNotNull;

class ResponseHandler implements GatewayListener {
    private static final String TAG = ResponseHandler.class.getName();

    private ResponseProcessor mResponseProcessor;

    void setResponseProcessor(ResponseProcessor responseProcessor) {
        mResponseProcessor = responseProcessor;
    }

    @Override
    public void onGatewayResponse(GatewayResponse gatewayResponse) {
        Log.d(TAG, "onGatewayResponse() called");
        mResponseProcessor.processResponse(gatewayResponse);
    }
}
