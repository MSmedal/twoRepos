package com.tsys.payments.host.portico;

import android.icu.text.SimpleDateFormat;
import android.text.TextUtils;
import android.util.Log;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.Receipt;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.utils.CreditCardHelper;
import com.tsys.payments.library.utils.CurrencyHelper;
import com.tsys.payments.library.utils.ReceiptHelper;

import java.util.Arrays;
import java.util.Date;

import androidx.annotation.NonNull;

/**
 * Collection of methods for printing {@link com.tsys.payments.library.domain.Receipt}'s to console
 * in instrumented and unit tests.
 */
final class ReceiptUtils {
    private static final String TAG = ReceiptUtils.class.getName();
    static final int RECEIPT_LABEL_FIELD_LENGTH = 30;
    static final String RECEIPT_ELLPISIS = "...";
    static final String RECEIPT_LABEL_VALUE_DIVIDER = "----------------------------------";
    static final String RECEIPT_SIGNATURE_LINE =
            "Signature: ___________________________________________";
    static final String RECEIPT_SIGNATURE_DISCLAIMER =
            "I agree to pay above amount according to card issuer agreement.";
    private static final String CUSTOMER_COPY_DISCLAIMER =
            "Cardholder Copy";
    private static final String CUSTOMER_COPY_DISCLAIMER_LINE_TWO =
            "Retain this copy for statement verification";
    private static final String MERCHANT_COPY_DISCLAIMER = "Merchant Copy";
    private static final String RETURN_POLICY = "NO REFUNDS";

    private static final SimpleDateFormat DATE_FORMATTER =
            new SimpleDateFormat("yyyy-MM-dd h:mm:ss a");

    private static final String TEST_MERCHANT_NAME = "John Doe";
    private static final String TEST_MERCHANT_LOCATION = "Beverly Hills, CA 90210";
    private static final String TEST_BUSINESS_NUMBER = "111-111-1111";

    /**
     * Returns the line of a receipt with the label field taking up {@code
     * RECEIPT_LABEL_FIELD_LENGTH} spaces. The {@code RECEIPT_LABEL_VALUE_DIVIDER} is then appended
     * to the label field followed by the value.
     * <b><Example:</b>
     * <p>
     * <ul>
     * <li><Short label                                  ----------------------------------Short label value</li>
     * <li><Looooooooooooooooooooooooooonnnnnnnnnnggggggggg...----------------------------------long label value</li>
     * </ul>
     * </p>
     *
     * @param label {@link String} representing the line label.
     * @param value {@link String} representing line value.
     * @return Formatted receipt line.
     */
    static String getReceiptLine(@NonNull String label, @NonNull String value) {
        StringBuilder labelBuilder = new StringBuilder(label);

        if (labelBuilder.length() > RECEIPT_LABEL_FIELD_LENGTH) {
            /*
              If label length is longer than field length, truncate label field length
              so that ellipsis fill the remaining space.
              */
            labelBuilder.delete(RECEIPT_LABEL_FIELD_LENGTH - RECEIPT_ELLPISIS.length(),
                    labelBuilder.length());
            labelBuilder.append(RECEIPT_ELLPISIS);
        } else {
            /*
              If label length is shorter than field length, add spaces until field length
              is reached.
              */
            int paddingLength = RECEIPT_LABEL_FIELD_LENGTH - labelBuilder.length();
            char[] padSpaces = new char[paddingLength];
            Arrays.fill(padSpaces, ' ');
            labelBuilder.append(padSpaces);
        }

        return labelBuilder.append(RECEIPT_LABEL_VALUE_DIVIDER)
                .append(value).toString();
    }

    /**
     * Prints a copy of the customer and merchant receipts to the console.
     *
     * @param request  {@link GatewayRequest} object containing information about the transaction
     *                 request.
     * @param response {@link GatewayResponse} object containing information about the transaction
     *                 response.
     */
    static void printReceipts(GatewayRequest request, GatewayResponse response, CardData cardData) {
        ReceiptUtils.printReceipt(ReceiptHelper.buildMsrReceipt(request, response),cardData,
                false);
        ReceiptUtils.printReceipt(ReceiptHelper.buildMsrReceipt(request, response),cardData,
                true);
    }

    static void printReceipts(GatewayRequest request, GatewayResponse response) {
        printReceipts(request,response,request.getCardData());
    }

    /**
     * Prints the general receipt requirements for Heartland receipts.
     *
     * @param receipt {@link Receipt} object containing the receipt to print.
     * @param cardData
     */
    static void printReceipt(@NonNull Receipt receipt,
            CardData cardData, boolean isCustomerCopy) {
        Log.d(TAG, TEST_MERCHANT_NAME);
        Log.d(TAG, TEST_MERCHANT_LOCATION);
        Log.d(TAG, TEST_BUSINESS_NUMBER);
        Log.d(TAG, DATE_FORMATTER.format(new Date()));
        String pan = CreditCardHelper.getPanFromCardData(cardData);
        if (!TextUtils.isEmpty(pan)) {
            Log.d(TAG, getReceiptLine("PAN", CreditCardHelper.obfuscateNumber(pan, 0,
                    4, 'x', false)));
        }
        Log.d(TAG,
                getReceiptLine("Approved Amount", "USD " +
                        CurrencyHelper.toStringOrNull(receipt.getTransactionAmount(), true)));
        Log.d(TAG, getReceiptLine("Card Type", CreditCardHelper.typeFromCardData(cardData).toString()));
        Log.d(TAG, getReceiptLine("Transaction Type", "Credit " + receipt.getTransactionType().name()));
        Log.d(TAG, getReceiptLine("Auth Code", receipt.getAuthorizationCode()));
        Log.d(TAG, getReceiptLine("Entry Method", getPosEntryMode(cardData.getCardDataSource())));
        Log.d(TAG, RECEIPT_SIGNATURE_LINE);
        Log.d(TAG, RECEIPT_SIGNATURE_DISCLAIMER);
        Log.d(TAG, RETURN_POLICY);

        if (isCustomerCopy) {
            Log.d(TAG, CUSTOMER_COPY_DISCLAIMER);
            Log.d(TAG, CUSTOMER_COPY_DISCLAIMER_LINE_TWO);
        } else {
            Log.d(TAG, MERCHANT_COPY_DISCLAIMER);
        }
    }

    private static String getPosEntryMode(CardDataSourceType type) {
        switch (type) {
            case MSR:
                return "MAGSTRIPE";
            case SCR:
                return "CHIP READ";
            case KEYED:
                return "MANUAL";
            default:
                return type.name().toUpperCase();
        }
    }
}
