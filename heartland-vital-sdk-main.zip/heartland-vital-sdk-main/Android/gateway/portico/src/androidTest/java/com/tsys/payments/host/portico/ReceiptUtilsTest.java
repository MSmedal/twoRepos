package com.tsys.payments.host.portico;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;

import static org.junit.Assert.*;

public class ReceiptUtilsTest {

    @Test
    public void test_getReceiptLine_padsShortLabelToReceiptLabelFieldLength() {
        final String shortLabel = "ShortLabel";
        final String value = "Value";
        StringBuilder expectedReceiptLineBuilder = new StringBuilder(shortLabel);
        expectedReceiptLineBuilder.append(getEmptySpacesPadding(
                ReceiptUtils.RECEIPT_LABEL_FIELD_LENGTH - shortLabel.length()))
                .append(ReceiptUtils.RECEIPT_LABEL_VALUE_DIVIDER)
                .append(value);

        final String expectedValue = expectedReceiptLineBuilder.toString();
        Assert.assertEquals(expectedValue, ReceiptUtils.getReceiptLine(shortLabel, value));
    }

    @Test
    public void test_getReceiptLine_labelLengthMatchesLabelFieldLengthAddsNoExtraPadding() {
        final String maxLabel = "Label_12345_12345_12345_12345.";
        final String value = "Value";
        StringBuilder expectedReceiptLineBuilder = new StringBuilder(maxLabel);
        expectedReceiptLineBuilder
                .append(ReceiptUtils.RECEIPT_LABEL_VALUE_DIVIDER)
                .append(value);

        final String expectedValue = expectedReceiptLineBuilder.toString();
        Assert.assertEquals(expectedValue, ReceiptUtils.getReceiptLine(maxLabel, value));
    }

    @Test
    public void test_getReceiptLine_truncatesAndEllipsizesLongLabel() {
        final String oversizedLabel = "Label_12345_12345_12345_12345.12345.";
        final String value = "Value";
        StringBuilder expectedReceiptLineBuilder = new StringBuilder("" +
                "Label_12345_12345_12345_123...");
        expectedReceiptLineBuilder
                .append(ReceiptUtils.RECEIPT_LABEL_VALUE_DIVIDER)
                .append(value);

        final String expectedValue = expectedReceiptLineBuilder.toString();
        Assert.assertEquals(expectedValue, ReceiptUtils.getReceiptLine(oversizedLabel, value));
    }

    private String getEmptySpacesPadding(int spaceCount) {
        char[] chars = new char[spaceCount];
        Arrays.fill(chars, ' ');
        return new String(chars);
    }
}
