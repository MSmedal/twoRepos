package com.tsys.payments.host.portico;

import android.text.TextUtils;

import com.global.api.ServicesContainer;
import com.global.api.entities.Address;
import com.global.api.entities.EncryptionData;
import com.global.api.entities.Transaction;
import com.global.api.entities.TransactionSummary;
import com.global.api.entities.enums.AddressType;
import com.global.api.entities.exceptions.ApiException;
import com.global.api.paymentMethods.CreditCardData;
import com.global.api.paymentMethods.CreditTrackData;
import com.global.api.serviceConfigs.GatewayConfig;
import com.global.api.services.ReportingService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import java.math.BigDecimal;

import static com.tsys.payments.host.portico.Constants.PORTICO_DEVICE_ID;
import static com.tsys.payments.host.portico.Constants.PORTICO_LICENSE_ID;
import static com.tsys.payments.host.portico.Constants.PORTICO_PASSWORD;
import static com.tsys.payments.host.portico.Constants.PORTICO_SITE_ID;
import static com.tsys.payments.host.portico.Constants.PORTICO_USERNAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

@RunWith(BlockJUnit4ClassRunner.class)
public class PorticoSdkHostTest {

    private CreditCardData mCreditCardData;
    private CreditTrackData mCreditTrackData;

    @Before
    public void Setup() throws ApiException {
        GatewayConfig config = new GatewayConfig();
        config.setUsername(PORTICO_USERNAME);
        config.setPassword(PORTICO_PASSWORD);
        config.setDeviceId(Integer.parseInt(PORTICO_DEVICE_ID));
        config.setLicenseId(Integer.parseInt(PORTICO_LICENSE_ID));
        config.setSiteId(Integer.parseInt(PORTICO_SITE_ID));

        config.setServiceUrl(Constants.PORTICO_SERVICE_URL);
        config.setDeveloperId(Constants.PORTICO_DEVELOPER_ID);
        config.setVersionNumber(Constants.PORTICO_VERSION_NUMBER);
        config.setEnableLogging(true);

        ServicesContainer.configureService(config);

        mCreditCardData = new CreditCardData();
        mCreditCardData.setNumber(Constants.PORTICO_TEST_CARD_NUMBER);
        mCreditCardData.setExpMonth(Constants.PORTICO_TEST_CARD_EXP_MONTH);
        mCreditCardData.setExpYear(Constants.PORTICO_TEST_CARD_EXP_YEAR);
        mCreditCardData.setCvn(Constants.PORTICO_TEST_CARD_CVN);

        mCreditTrackData = new CreditTrackData();
        mCreditTrackData.setValue(Constants.PORTICO_TEST_TRACK_DATA_VALUE);
        mCreditTrackData.setEncryptionData(EncryptionData.version1());
    }

    @Test
    public void test_creditAuthorization() throws ApiException {
        Transaction response = mCreditCardData.authorize(new BigDecimal(14))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();

        assertNotNull(response);
        assertEquals("00", response.getResponseCode());

        Transaction capture =
                response.capture(new BigDecimal(16)).withGratuity(new BigDecimal(2)).execute();
        assertNotNull(capture);
        assertEquals("00", capture.getResponseCode());
    }

    @Test
    public void test_creditSale() throws ApiException {
        Transaction response = mCreditCardData.charge(new BigDecimal(15))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_creditRefund() throws ApiException {
        String invoiceNumber = Long.toString(System.currentTimeMillis());
        Transaction response = mCreditCardData.refund(new BigDecimal(16))
                .withCurrency("USD")
                .withInvoiceNumber(invoiceNumber)
                .withCustomerId("Customer7766")
                .withDescription("This is a good description")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());

        TransactionSummary report = ReportingService.transactionDetail(response.getTransactionId())
                .execute();
        assertEquals(invoiceNumber, report.getInvoiceNumber());
        assertEquals("Customer7766", report.getCustomerId());
        assertEquals("This is a good description", report.getDescription());
    }

    @Test
    public void test_creditSwipeAuthorization() throws ApiException {
        Transaction response = mCreditTrackData.authorize(new BigDecimal(14))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());

        Transaction capture =
                response.capture(new BigDecimal(16)).withGratuity(new BigDecimal(2)).execute();
        assertNotNull(capture);
        assertEquals("00", capture.getResponseCode());
    }

    @Test
    public void test_creditSwipeSale() throws ApiException {
        Transaction response = mCreditTrackData.charge(new BigDecimal(15))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    /**
     * Test regular MSR authorization with encrypted track1 data.
     * <p>
     * Note: Track data needs to be Base64 encoded together with the KSN.
     * <p>
     * EncryptionData :
     * - version = 05 (Decryption Service Version)
     * - trackNumber = 1 (track1)
     * - ksn = ksn received from reader with Base64 encoding.
     * <p>
     * Required data without Base64 encoding.
     * Track1:
     * 4B5546A15DAF7AE00776C6593028CF936EBC8517F69E8D71AFF3673460C32516E5FA9F506DE2FC3292B5B5436F5
     * F8E0534A978DEE2F31948C984B633CA654278585ACEAEBC1031EFE457617EABFF00ED
     * KSN:
     * FFFF3D3F81000060005D
     * <p>
     * Useful link for Base64 encoding: https://base64.guru/converter/encode/hex
     */
    @Test
    public void test_creditEncryptedTrack1SwipeSale() throws ApiException {
        EncryptionData encryptionData = new EncryptionData();

        encryptionData.setVersion("05");
        encryptionData.setTrackNumber("1");
        encryptionData.setKsn("//89P4EAAGAAXQ==");

        mCreditTrackData.setValue(
                "S1VGoV2veuAHdsZZMCjPk268hRf2no1xr/NnNGDDJRbl+p9QbeL8MpK1tUNvX44FNKl43uLzGUjJhLYzymVCeFhazq68EDHv5Fdhfqv/AO0=");
        mCreditTrackData.setEncryptionData(encryptionData);

        Transaction response = mCreditTrackData.charge(new BigDecimal(15))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    /**
     * Test regular MSR authorization with encrypted track1 & track2 data.
     * <p>
     * Note: Track data needs to be Base64 encoded together with the KSN.
     * <p>
     * EncryptionData :
     * - version = 05 (Decryption Service Version)
     * - trackNumber = 2 (track1&track2)
     * - ksn = ksn received from reader with Base64 encoding.
     * <p>
     * Required data without Base64 encoding.
     * Track1&Track2 HEX:
     * 4B5546A15DAF7AE00776C6593028CF936EBC8517F69E8D71AFF3673460C32516E5FA9F506DE2FC3292B5B5436F5
     * F8E0534A978DEE2F31948C984B633CA654278585ACEAEBC1031EFE457617EABFF00ED71A888C8FAEB0E5263EE843
     * 4A3933EC7735C5C80247C7DA1627829A3030F1A0974BA10252A8B3136
     * KSN:
     * FFFF3D3F81000060005D
     * <p>
     * Useful link for Base64 encoding: https://base64.guru/converter/encode/hex
     */
    @Test
    public void test_creditEncryptedTrack1AndTrack2SwipeSale() throws ApiException {
        EncryptionData encryptionData = new EncryptionData();

        encryptionData.setVersion("05");
        encryptionData.setTrackNumber("2");
        encryptionData.setKsn("//89P4EAAGAAXQ==");

        mCreditTrackData.setValue(
                "S1VGoV2veuAHdsZZMCjPk268hRf2no1xr/NnNGDDJRbl+p9QbeL8MpK1tUNvX44FNKl43uLzGUjJhLYzymVCeFhazq68EDHv5Fdhfqv/AO1xqIjI+usOUmPuhDSjkz7Hc1xcgCR8faFieCmjAw8aCXS6ECUqizE2");
        mCreditTrackData.setEncryptionData(encryptionData);

        Transaction response = mCreditTrackData.charge(new BigDecimal(15))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_creditSwipeRefund() throws ApiException {
        Transaction response = mCreditTrackData.refund(new BigDecimal(16))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_creditSwipeReverse() throws ApiException {
        Transaction response = mCreditTrackData.charge(new BigDecimal(19))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());

        Transaction reverseResponse = mCreditTrackData.reverse(new BigDecimal(19))
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(reverseResponse);
        assertEquals("00", reverseResponse.getResponseCode());
    }

    @Test
    public void test_creditVoidFromTransactionId() throws ApiException {
        Transaction response = mCreditCardData.authorize(new BigDecimal(10))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());

        Transaction voidResponse = Transaction.fromId(response.getTransactionId())
                .voidTransaction()
                .execute();
        assertNotNull(voidResponse);
        assertEquals("00", voidResponse.getResponseCode());
    }

    @Test
    public void test_VisaManualEntryCreditVerify() throws ApiException {
        CreditCardData cardData = new CreditCardData();
        cardData.setNumber(Constants.VISA_CARD_NUMBER);
        cardData.setExpMonth(Constants.VISA_CARD_EXPIRY_MONTH);
        cardData.setExpYear(Constants.VISA_CARD_EXPIRY_YEAR);
        cardData.setCvn(Constants.PORTICO_TEST_CARD_CVN);

        Transaction response = cardData.verify()
                .withCurrency("USD")
                .withAddress(getTestAddress())
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_MasterCardManualEntryCreditVerify() throws ApiException {
        CreditCardData cardData = new CreditCardData();
        cardData.setNumber(Constants.MASTERCARD_CARD_NUMBER);
        cardData.setExpMonth(Constants.MASTERCARD_CARD_EXPIRY_MONTH);
        cardData.setExpYear(Constants.MASTERCARD_CARD_EXPIRY_YEAR);
        cardData.setCvn(Constants.MASTERCARD_CARD_CVV);

        Transaction response = cardData.verify()
                .withCurrency("USD")
                .withAddress(getTestAddress())
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_AmexManualEntryCreditVerify() throws ApiException {
        CreditCardData cardData = new CreditCardData();
        cardData.setNumber(Constants.AMEX_CARD_NUMBER);
        cardData.setExpMonth(Constants.AMEX_CARD_EXPIRY_MONTH);
        cardData.setExpYear(Constants.AMEX_CARD_EXPIRY_YEAR);
        cardData.setCvn(Constants.AMEX_CARD_CVV);

        Transaction response = cardData.verify()
                .withCurrency("USD")
                .withAddress(getTestAddress())
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_DiscoverManualEntryCreditVerify() throws ApiException {
        CreditCardData cardData = new CreditCardData();
        cardData.setNumber(Constants.DISCOVER_CARD_NUMBER);
        cardData.setExpMonth(Constants.DISCOVER_CARD_EXPIRY_MONTH);
        cardData.setExpYear(Constants.DISCOVER_CARD_EXPIRY_YEAR);
        cardData.setCvn(Constants.DISCOVER_CARD_CVV);

        Transaction response = cardData.verify()
                .withCurrency("USD")
                .withAddress(getTestAddress())
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_VisaSwipeCreditVerify() throws ApiException {
        EncryptionData encryptionData = new EncryptionData();
        encryptionData.setVersion("05");
        encryptionData.setTrackNumber("1");
        encryptionData.setKsn(MsrScriptsConstants.SCRIPT_VISA_C2X_KSN_BASE64);

        CreditTrackData creditTrackData = new CreditTrackData();
        creditTrackData.setValue(MsrScriptsConstants.SCRIPT_VISA_C2X_TRACK_1_BASE64);
        creditTrackData.setEncryptionData(encryptionData);

        Transaction response = creditTrackData.verify()
                .withCurrency("USD")
                .withAddress(getTestAddress())
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_MasterCardSwipeCreditVerify() throws ApiException {
        EncryptionData encryptionData = new EncryptionData();
        encryptionData.setVersion("05");
        encryptionData.setTrackNumber("1");
        encryptionData.setKsn(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_C2X_KSN_BASE64);

        CreditTrackData creditTrackData = new CreditTrackData();
        creditTrackData.setValue(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_C2X_TRACK_1_BASE64);
        creditTrackData.setEncryptionData(encryptionData);

        Transaction response = creditTrackData.verify()
                .withCurrency("USD")
                .withAddress(getTestAddress())
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_AmexSwipeCreditVerify() throws ApiException {
        EncryptionData encryptionData = new EncryptionData();
        encryptionData.setVersion("05");
        encryptionData.setTrackNumber("1");
        encryptionData.setKsn(MsrScriptsConstants.SCRIPT_AMEX_C2X_KSN_BASE64);

        CreditTrackData creditTrackData = new CreditTrackData();
        creditTrackData.setValue(MsrScriptsConstants.SCRIPT_AMEX_C2X_TRACK_1_BASE64);
        creditTrackData.setEncryptionData(encryptionData);

        Transaction response = creditTrackData.verify()
                .withCurrency("USD")
                .withAddress(getTestAddress())
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    @Test
    public void test_DiscoverSwipeCreditVerify() throws ApiException {
        EncryptionData encryptionData = new EncryptionData();
        encryptionData.setVersion("05");
        encryptionData.setTrackNumber("1");
        encryptionData.setKsn(MsrScriptsConstants.SCRIPT_DISCOVER_C2X_KSN_BASE64);

        CreditTrackData creditTrackData = new CreditTrackData();
        creditTrackData.setValue(MsrScriptsConstants.SCRIPT_DISCOVER_C2X_TRACK_1_BASE64);
        creditTrackData.setEncryptionData(encryptionData);

        Transaction response = creditTrackData.verify()
                .withCurrency("USD")
                .withAddress(getTestAddress())
                .withAllowDuplicates(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
    }

    private static Address getTestAddress() {
        Address address = new Address();
        // Address line 1
        address.setStreetAddress1("6860");
        // Address line 2
        address.setStreetAddress2("Apt 220");
        // City
        address.setCity("Zoo");
        // Postal code
        address.setPostalCode("75024");
        // Address type
        address.setType(AddressType.Billing);
        return address;
    }

    @Test
    public void test_creditSaleRequestMultiUseTokenSuccess() throws ApiException {
        Transaction response = mCreditCardData.charge(new BigDecimal(15))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .withRequestMultiUseToken(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
        assertFalse(TextUtils.isEmpty(response.getToken()));
    }

    @Test
    public void test_creditAuthRequestMultiUseTokenSuccess() throws ApiException {
        Transaction response = mCreditCardData.authorize(new BigDecimal(15))
                .withCurrency("USD")
                .withAllowDuplicates(true)
                .withRequestMultiUseToken(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
        assertFalse(TextUtils.isEmpty(response.getToken()));
    }

    @Test
    public void test_creditVerifyRequestMultiUseTokenSuccess() throws ApiException {
        Transaction response = mCreditCardData.verify()
                .withCurrency("USD")
                .withAddress(PorticoRequestProvider.getTestAddress())
                .withAllowDuplicates(true)
                .withRequestMultiUseToken(true)
                .execute();
        assertNotNull(response);
        assertEquals("00", response.getResponseCode());
        assertFalse(TextUtils.isEmpty(response.getToken()));
    }
}
