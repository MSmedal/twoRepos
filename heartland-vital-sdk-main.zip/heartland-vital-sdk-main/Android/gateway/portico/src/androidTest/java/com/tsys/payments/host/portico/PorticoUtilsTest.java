package com.tsys.payments.host.portico;

import com.tsys.payments.host.portico.utils.PorticoUtils;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import static com.tsys.payments.host.portico.Constants.KSN_HEX;
import static com.tsys.payments.host.portico.Constants.TRACK_1_2_HEX;
import static com.tsys.payments.host.portico.Constants.TRACK_1_HEX;

@RunWith(BlockJUnit4ClassRunner.class)
public class PorticoUtilsTest {
    private static final String TRACK_1_BASE_64 =
            "S1VGoV2veuAHdsZZMCjPk268hRf2no1xr/NnNGDDJRbl+p9QbeL8MpK1tUNvX44FNKl43uLzGUjJhLYzymVCeFhazq68EDHv5Fdhfqv/AO0=";
    private static final String TRACK_1_2_BASE_64 =
            "S1VGoV2veuAHdsZZMCjPk268hRf2no1xr/NnNGDDJRbl+p9QbeL8MpK1tUNvX44FNKl43uLzGUjJhLYzymVCeFhazq68EDHv5Fdhfqv/AO1xqIjI+usOUmPuhDSjkz7Hc1xcgCR8faFieCmjAw8aCXS6ECUqizE2";
    private static final String KSN_BASE_64 = "//89P4EAAGAAXQ==";

    @Test
    public void encodeBase64HexTrack1() {
        Assert.assertEquals(TRACK_1_BASE_64, PorticoUtils.encodeHexStringToBase64(TRACK_1_HEX));
    }

    @Test
    public void encodeBase64HexTrack1AndTrack2() {
        Assert.assertEquals(TRACK_1_2_BASE_64, PorticoUtils.encodeHexStringToBase64(TRACK_1_2_HEX));
    }

    @Test
    public void encodeBase64EncryptedHexKsn() {
        Assert.assertEquals(KSN_BASE_64, PorticoUtils.encodeHexStringToBase64(KSN_HEX));
    }

    @Test
    public void decodeBase64Track1ToHex() {
        Assert.assertEquals(TRACK_1_HEX, PorticoUtils.decodeBase64ToHexString(TRACK_1_BASE_64));
    }

    @Test
    public void decodeBase64Track1AndTrack2ToHex() {
        Assert.assertEquals(TRACK_1_2_HEX, PorticoUtils.decodeBase64ToHexString(TRACK_1_2_BASE_64));
    }

    @Test
    public void decodeBase64KsnToHex() {
        Assert.assertEquals(KSN_HEX, PorticoUtils.decodeBase64ToHexString(KSN_BASE_64));
    }
}
