package com.tsys.payments.host.portico;

import android.text.TextUtils;

import com.global.api.entities.TransactionSummary;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(BlockJUnit4ClassRunner.class)
public class PorticoModelConverterTest {

    @Test
    public void testTransactionSummaryApprovalResponse() {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(10);

        TransactionSummary hostResponse = new TransactionSummary();
        hostResponse.setIssuerResponseMessage("APPROVAL");
        hostResponse.setGatewayResponseMessage("Success");
        hostResponse.setAuthCode("76795A");
        hostResponse.setTransactionId("1286675650");

        GatewayResponse gatewayResponse = PorticoModelConverter.toGatewayResponse(builder.build(),
                hostResponse);

        assertNotNull(gatewayResponse);
        assertTrue(gatewayResponse.isApproved());
        assertFalse(TextUtils.isEmpty(gatewayResponse.getAuthCode()));
        assertFalse(TextUtils.isEmpty(gatewayResponse.getGatewayTransactionId()));
    }

    @Test
    public void testTransactionSummaryPartialApprovalResponse() {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(10);

        TransactionSummary hostResponse = new TransactionSummary();
        hostResponse.setIssuerResponseMessage("APPROVAL");
        hostResponse.setGatewayResponseMessage("Success");
        hostResponse.setAuthorizedAmount(new BigDecimal(10));
        hostResponse.setAuthCode("76795A");
        hostResponse.setTransactionId("1286675650");

        GatewayResponse gatewayResponse = PorticoModelConverter.toGatewayResponse(builder.build(),
                hostResponse);

        assertNotNull(gatewayResponse);
        assertTrue(gatewayResponse.isApproved());
        assertEquals(gatewayResponse.getApprovedAmount(), 10);
        assertFalse(TextUtils.isEmpty(gatewayResponse.getAuthCode()));
        assertFalse(TextUtils.isEmpty(gatewayResponse.getGatewayTransactionId()));
    }


    @Test
    public void testTransactionSummaryDeclineResponse() {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(10);

        TransactionSummary hostResponse = new TransactionSummary();

        GatewayResponse gatewayResponse = PorticoModelConverter.toGatewayResponse(builder.build(),
                hostResponse);

        assertNotNull(gatewayResponse);
        assertFalse(gatewayResponse.isApproved());
        assertTrue(TextUtils.isEmpty(gatewayResponse.getAuthCode()));
        assertTrue(TextUtils.isEmpty(gatewayResponse.getGatewayTransactionId()));
    }

}
