package com.tsys.payments.host.portico;

import android.text.TextUtils;

import com.tsys.payments.library.domain.Address;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.utils.LibraryConfigHelper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import timber.log.Timber;

import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(BlockJUnit4ClassRunner.class)
public class PorticoGatewayControllerTest {
    private static final long GATEWAY_TIMEOUT = 10000;

    private GatewayController mGatewayController;
    private ResponseHandler mGatewayListener;
    private CountDownLatch mCountDownLatch;
    /**
     * To avoid duplicate error coming back from server.
     */
    private long mRandomAmount;

    @Before
    public void setUp() throws InitializationException {
        GatewayConfiguration gatewayConfiguration = new GatewayConfiguration();
        gatewayConfiguration.setGatewayTimeout(GATEWAY_TIMEOUT);

        LibraryConfigHelper.setDebugMode(true);

        HashMap<String, String> credentials = new HashMap<>();
        credentials.put(PorticoCredentialKeys.VERSION_NUMBER, Constants.PORTICO_VERSION_NUMBER);
        credentials.put(PorticoCredentialKeys.DEVELOPER_ID, Constants.PORTICO_DEVELOPER_ID);

        credentials.put(PorticoCredentialKeys.USER_NAME, Constants.PORTICO_USERNAME);
        credentials.put(PorticoCredentialKeys.PASSWORD, Constants.PORTICO_PASSWORD);
        credentials.put(PorticoCredentialKeys.SITE_ID, String.valueOf(Constants.PORTICO_SITE_ID));
        credentials.put(PorticoCredentialKeys.LICENSE_ID, String.valueOf(Constants.PORTICO_LICENSE_ID));
        credentials.put(PorticoCredentialKeys.DEVICE_ID, String.valueOf(Constants.PORTICO_DEVICE_ID));

        gatewayConfiguration.setCredentials(credentials);

        mGatewayListener = new ResponseHandler();
        mGatewayController =
                new PorticoGatewayControllerFactory()
                        .create(gatewayConfiguration, mGatewayListener);

        mCountDownLatch = new CountDownLatch(1);
        mRandomAmount = new Random().nextInt(50);
    }

    //region Manual Transactions
    @Test
    public void test_manualCreditAuthorization() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualAuth(mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualCreditAuthorizationVisaDecline() throws InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.manualAuthDecline(Constants.PORTICO_TEST_CARD_VISA);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertFalse(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualCreditAuthorizationMcDecline() throws InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.manualAuthDecline(Constants.PORTICO_TEST_CARD_MC);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertFalse(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualCreditAuthorizationDiscoverDecline() throws InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.manualAuthDecline(Constants.PORTICO_TEST_CARD_DISCOVER);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertFalse(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualCreditAuthorizationAmexDecline() throws InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.manualAuthDecline(Constants.PORTICO_TEST_CARD_AMEX);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertFalse(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void manualAuthForwardsPosReferenceNumber() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualAuth(mRandomAmount);
        builder.setPosReferenceNumber(Constants.CLIENT_TXN_ID);

        mGatewayListener.setResponseProcessor(response -> {
            assertNotNull(response);
            assertTrue(response.isApproved());
            assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            assertEquals(Constants.CLIENT_TXN_ID, response.getPosReferenceId());

            mCountDownLatch.countDown();
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void manualSaleForwardsPosReferenceNumber() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(mRandomAmount);
        builder.setPosReferenceNumber(Constants.CLIENT_TXN_ID);

        mGatewayListener.setResponseProcessor(response -> {
            assertNotNull(response);
            assertTrue(response.isApproved());
            assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            assertEquals(Constants.CLIENT_TXN_ID, response.getPosReferenceId());

            mCountDownLatch.countDown();
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }
    //endregion

    //region Msr Auth Transactions
    @Test
    public void test_msrTrack1CreditAuthorization() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Auth(mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrTrack1AndTrack2CreditAuthorization() throws InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.msrTrack1AndTrack2Auth(mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }
    //endregion

    //region Msr Sale
    @Test
    public void test_msrTrack1CreditSale() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Sale(mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrTrack1AndTrack2CreditSale() throws InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.msrTrack1AndTrack2Sale(mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }
    //endregion

    //region Contactless Auth
    @Test
    public void test_contactlessEmvCreditAuth() throws InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.contactlessEmvAuthRequest(mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    // TODO: Issues with track 2 data are being investigated. Commented out for now
    /*
    @Test
    public void test_contactlessMsrCreditAuth() throws InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.contactlessMsrAuthRequest(mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    } */
    //endregion

    //region Capture Transaction
    @Test
    public void test_manualAuthAndCapture() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualAuth(mRandomAmount);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed and capture previously authorized transaction
                captureAuthorization(response);
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void captureAuthorization(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = PorticoRequestProvider.authCaptureRequest(gatewayResponse);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    //endregion

    //region Tip Adjust Transaction
    @Test
    public void test_manualSaleAndTipAdjust() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(mRandomAmount);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed and capture previously authorized transaction
                tipAdjustSale(response);
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void tipAdjustSale(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = PorticoRequestProvider.tipAdjustRequest(gatewayResponse);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    //endregion

    //region Void Transactions
    @Test
    public void test_manualSaleAndVoid() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(mRandomAmount);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed and void previously Sale transaction
                voidSale(response);
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void voidSale(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = PorticoRequestProvider
                .voidRequest(gatewayResponse);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    //endregion

    //region Batch
    @Test
    public void test_manualSaleAndBatchClose() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(mRandomAmount);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed with a Batch Close
                closeBatch();
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void closeBatch() {
        GatewayRequest.Builder builder = PorticoRequestProvider
                .batchCloseRequest();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_manualAuthCaptureAndBatchClose() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualAuth(mRandomAmount);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed with a Capture and Batch close
                captureAuthorizationWithBatchClose(response);
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void captureAuthorizationWithBatchClose(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = PorticoRequestProvider.authCaptureRequest(gatewayResponse);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                closeBatch();
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    //endregion

    //region Refund Transactions
    @Test
    public void test_manualSaleAndRefund() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(mRandomAmount);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed and refund previously Sale transaction
                refundSale(response, mRandomAmount);
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualSaleWithTipAndRefund() throws InterruptedException {
        long total = mRandomAmount + 10;
        GatewayRequest.Builder builder =
                PorticoRequestProvider.manualSaleWithTip(total, 10);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed and refund previously Sale transaction
                refundSale(response, mRandomAmount);
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualAuthAndCaptureAndRefund() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(3);
        GatewayRequest.Builder builder = PorticoRequestProvider.manualAuth(mRandomAmount);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed and capture previously authorized transaction
                try {
                    captureAuthorizationAndRefund(response);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualAuthAndCaptureAndRefundWithTip() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(3);
        GatewayRequest.Builder builder = PorticoRequestProvider.manualAuth(mRandomAmount);
        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getAuthCode()));

                // Proceed and capture previously authorized transaction
                try {
                    captureAuthorizationAndRefundWithTip(response);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void captureAuthorizationAndRefund(GatewayResponse gatewayResponse)
            throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.authCaptureRequest(gatewayResponse);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());

                // Proceed and refund previously Sale transaction
                refundSale(response, mRandomAmount);
            }
        });
        mGatewayController.sendRequest(builder.build());

        mCountDownLatch.await();
    }

    private void captureAuthorizationAndRefundWithTip(GatewayResponse gatewayResponse)
            throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.authCaptureRequest(gatewayResponse);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());

                // Proceed and refund previously Sale transaction
                refundSaleWithTip(response, mRandomAmount);
            }
        });
        mGatewayController.sendRequest(builder.build());

        mCountDownLatch.await();
    }

    private void refundSale(GatewayResponse gatewayResponse, long total) {
        GatewayRequest.Builder builder = PorticoRequestProvider
                .refundRequest(gatewayResponse, total); // Same amount as the original total

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void refundSaleWithTip(GatewayResponse gatewayResponse, long total) {
        GatewayRequest.Builder builder = PorticoRequestProvider
                .refundWithTipRequest(gatewayResponse, total); // Same amount as the original total

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    //endregion

    //region Verify
    @Test
    public void test_manualEntryVisaVerify() throws InterruptedException {
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(MsrScriptsConstants.SCRIPT_VISA_PAN);
        cardData.setCvv2(MsrScriptsConstants.SCRIPT_VISA_CVV_CODE);
        cardData.setExpirationDate(String.valueOf(MsrScriptsConstants.SCRIPT_VISA_EXP_MONTH) +
                String.valueOf(MsrScriptsConstants.SCRIPT_VISA_EXP_YEAR));

        GatewayRequest.Builder builder = PorticoRequestProvider.manualEntryVerify(cardData, false);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL")
                        || response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualEntryVisaVerifyWithToken() throws InterruptedException {
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(MsrScriptsConstants.SCRIPT_VISA_PAN);
        cardData.setCvv2(MsrScriptsConstants.SCRIPT_VISA_CVV_CODE);
        cardData.setExpirationDate(String.valueOf(MsrScriptsConstants.SCRIPT_VISA_EXP_MONTH) +
                String.valueOf(MsrScriptsConstants.SCRIPT_VISA_EXP_YEAR));

        GatewayRequest.Builder builder = PorticoRequestProvider.manualEntryVerify(cardData, true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL")
                        || response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
                assertNotNull(response.getToken());
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualEntryMasterCardVerify() throws InterruptedException {
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_PAN);
        cardData.setCvv2(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_CVV_CODE);
        cardData.setExpirationDate(String.valueOf(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_EXP_MONTH) +
                String.valueOf(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_EXP_YEAR));

        GatewayRequest.Builder builder = PorticoRequestProvider.manualEntryVerify(cardData, false);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL")
                        || response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualEntryMasterCardVerifyWithToken() throws InterruptedException {
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_PAN);
        cardData.setCvv2(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_CVV_CODE);
        cardData.setExpirationDate(String.valueOf(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_EXP_MONTH) +
                String.valueOf(MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_EXP_YEAR));

        GatewayRequest.Builder builder = PorticoRequestProvider.manualEntryVerify(cardData, true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL")
                        || response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
                assertNotNull(response.getToken());
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualEntryDiscoverVerify() throws InterruptedException {
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(MsrScriptsConstants.SCRIPT_DISCOVER_PAN);
        cardData.setCvv2(MsrScriptsConstants.SCRIPT_DISCOVER_CVV_CODE);
        cardData.setExpirationDate(String.valueOf(MsrScriptsConstants.SCRIPT_DISCOVER_EXP_MONTH) +
                String.valueOf(MsrScriptsConstants.SCRIPT_DISCOVER_EXP_YEAR));

        GatewayRequest.Builder builder = PorticoRequestProvider.manualEntryVerify(cardData, false);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualEntryDiscoverVerifyWithToken() throws InterruptedException {
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(MsrScriptsConstants.SCRIPT_DISCOVER_PAN);
        cardData.setCvv2(MsrScriptsConstants.SCRIPT_DISCOVER_CVV_CODE);
        cardData.setExpirationDate(String.valueOf(MsrScriptsConstants.SCRIPT_DISCOVER_EXP_MONTH) +
                String.valueOf(MsrScriptsConstants.SCRIPT_DISCOVER_EXP_YEAR));

        GatewayRequest.Builder builder = PorticoRequestProvider.manualEntryVerify(cardData, true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
                assertNotNull(response.getToken());
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualEntryAmexVerify() throws InterruptedException {
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(MsrScriptsConstants.SCRIPT_AMEX_PAN);
        cardData.setCvv2(MsrScriptsConstants.SCRIPT_AMEX_CVV_CODE);
        cardData.setExpirationDate(String.valueOf(MsrScriptsConstants.SCRIPT_AMEX_EXP_MONTH) +
                String.valueOf(MsrScriptsConstants.SCRIPT_AMEX_EXP_YEAR));

        GatewayRequest.Builder builder = PorticoRequestProvider.manualEntryVerify(cardData, false);

        Address address = new Address();
        address.setAddressLine1("6860");
        // Address line 2
        address.setAddressLine2("Apt 220");
        // City
        address.setCity("Zoo");
        // Postal code
        address.setPostalCode("75024");

        builder.setAddress(address)
                .setTenderType(TenderType.CREDIT);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL"));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_manualEntryAmexVerifyWithToken() throws InterruptedException {
        CardData cardData = new CardData();
        cardData.setCardholderName("Johnathan Doe");
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(MsrScriptsConstants.SCRIPT_AMEX_PAN);
        cardData.setCvv2(MsrScriptsConstants.SCRIPT_AMEX_CVV_CODE);
        cardData.setExpirationDate(String.valueOf(MsrScriptsConstants.SCRIPT_AMEX_EXP_MONTH) +
                String.valueOf(MsrScriptsConstants.SCRIPT_AMEX_EXP_YEAR));

        GatewayRequest.Builder builder = PorticoRequestProvider.manualEntryVerify(cardData, true);

        Address address = new Address();
        address.setAddressLine1("6860");
        // Address line 2
        address.setAddressLine2("Apt 220");
        // City
        address.setCity("Zoo");
        // Postal code
        address.setPostalCode("75024");

        builder.setAddress(address)
                .setTenderType(TenderType.CREDIT);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL"));
                assertNotNull(response.getToken());
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrVisaVerify() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Verify(
                MsrScriptsConstants.SCRIPT_VISA_C2X_TRACK_1_HEX,
                MsrScriptsConstants.SCRIPT_VISA_C2X_KSN_HEX,
                false);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL")
                        || response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrVisaVerifyWithToken() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Verify(
                MsrScriptsConstants.SCRIPT_VISA_C2X_TRACK_1_HEX,
                MsrScriptsConstants.SCRIPT_VISA_C2X_KSN_HEX,
                true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL")
                        || response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
                assertNotNull(response.getToken());
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrMasterCardVerify() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Verify(
                MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_C2X_TRACK_1_HEX,
                MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_C2X_KSN_HEX,
                false);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL")
                        || response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
                ;
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrMasterCardVerifyWithToken() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Verify(
                MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_C2X_TRACK_1_HEX,
                MsrScriptsConstants.SCRIPT_MASTERCARD_SERIES_5_C2X_KSN_HEX,
                true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL")
                        || response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
                assertNotNull(response.getToken());
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrDiscoverVerify() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Verify(
                MsrScriptsConstants.SCRIPT_DISCOVER_C2X_TRACK_1_HEX,
                MsrScriptsConstants.SCRIPT_DISCOVER_C2X_KSN_HEX,
                false);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrDiscoverVerifyWithToken() throws InterruptedException {
        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Verify(
                MsrScriptsConstants.SCRIPT_DISCOVER_C2X_TRACK_1_HEX,
                MsrScriptsConstants.SCRIPT_DISCOVER_C2X_KSN_HEX,
                true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("CARD OK"));
                assertNotNull(response.getToken());
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrAmexVerify() throws InterruptedException {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.VERIFY);

        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);
        cardData.setTrack1(MsrScriptsConstants.SCRIPT_AMEX_C2X_TRACK_1_HEX);
        cardData.setKsn(MsrScriptsConstants.SCRIPT_AMEX_C2X_KSN_HEX);
        builder.setCardData(cardData);

        Address address = new Address();
        // Address line 1
        address.setAddressLine1("6860");
        // Address line 2
        address.setAddressLine2("Apt 220");
        // City
        address.setCity("Zoo");
        // Postal code
        address.setPostalCode("75024");

        builder.setAddress(address)
                .setTenderType(TenderType.CREDIT);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL"));
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void test_msrAmexVerifyWithToken() throws InterruptedException {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.VERIFY);

        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);
        cardData.setTrack1(MsrScriptsConstants.SCRIPT_AMEX_C2X_TRACK_1_HEX);
        cardData.setKsn(MsrScriptsConstants.SCRIPT_AMEX_C2X_KSN_HEX);
        builder.setCardData(cardData);

        Address address = new Address();
        // Address line 1
        address.setAddressLine1("6860");
        // Address line 2
        address.setAddressLine2("Apt 220");
        // City
        address.setCity("Zoo");
        // Postal code
        address.setPostalCode("75024");

        builder.setAddress(address)
                .setTenderType(TenderType.CREDIT)
                .setGenerateToken(true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.getGatewayResponseText().equalsIgnoreCase("APPROVAL"));
                assertNotNull(response.getToken());
            }
        });

        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }
    //endregion

    //region Tokenization
    @Test
    public void testTokenizationCreditAuthManualWithCardData() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = PorticoRequestProvider.manualAuth(mRandomAmount);
        builder.setGenerateToken(true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                // Process initial response
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getToken()));

                // Build request with initially processed response
                try {
                    testTokenizationCreditAuthManualWithToken(response);
                } catch (InterruptedException e) {
                    Timber.e(e.getMessage());
                }
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void testTokenizationCreditAuthManualWithToken(GatewayResponse response) throws
            InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.authWithToken(response, mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void testTokenizationCreditSaleManualWithCardData() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = PorticoRequestProvider.manualSale(mRandomAmount);
        builder.setGenerateToken(true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                // Process initial response
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getToken()));

                // Build request with initially processed response
                try {
                    testTokenizationCreditSaleManualWithToken(response);
                } catch (InterruptedException e) {
                    Timber.e(e.getMessage());
                }
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void testTokenizationCreditSaleManualWithToken(GatewayResponse response) throws
            InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.saleWithToken(response, mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void testTokenizationCreditAuthMsrWithCardData() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Auth(mRandomAmount);
        builder.setGenerateToken(true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                // Process initial response
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getToken()));

                // Build request with initially processed response
                try {
                    testTokenizationCreditAuthMsrWithToken(response);
                } catch (InterruptedException e) {
                    Timber.e(e.getMessage());
                }
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void testTokenizationCreditAuthMsrWithToken(GatewayResponse response) throws
            InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.authWithToken(response, mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void testTokenizationCreditSaleMsrWithCardData() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = PorticoRequestProvider.msrTrack1Sale(mRandomAmount);
        builder.setGenerateToken(true);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                // Process initial response
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getToken()));

                // Build request with initially processed response
                try {
                    testTokenizationCreditSaleMsrWithToken(response);
                } catch (InterruptedException e) {
                    Timber.e(e.getMessage());
                }
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void testTokenizationCreditSaleMsrWithToken(GatewayResponse response) throws
            InterruptedException {
        GatewayRequest.Builder builder =
                PorticoRequestProvider.saleWithToken(response, mRandomAmount);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }
    // TODO:.Add verify calls once changes are made in gateway controller
    //endregion

    private static class ResponseHandler implements GatewayListener {

        private ResponseProcessor mResponseProcessor;

        void setResponseProcessor(ResponseProcessor responseProcessor) {
            mResponseProcessor = responseProcessor;
        }

        @Override
        public void onGatewayResponse(GatewayResponse gatewayResponse) {
            assertNotNull(gatewayResponse);
            System.out.println(gatewayResponse);
            mResponseProcessor.processResponse(gatewayResponse);
        }
    }

    private interface ResponseProcessor {
        void processResponse(GatewayResponse response);
    }
}
