package com.tsys.payments.host.portico;

import com.tsys.payments.library.gateway.domain.GatewayResponse;

interface ResponseProcessor {
    void processResponse(GatewayResponse response);
}
