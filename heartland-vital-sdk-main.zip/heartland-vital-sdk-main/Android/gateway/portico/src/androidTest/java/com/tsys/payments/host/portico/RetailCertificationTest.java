package com.tsys.payments.host.portico;

import com.tsys.payments.host.portico.utils.PorticoUtils;
import com.tsys.payments.library.domain.Address;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.AvsType;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.utils.LibraryConfigHelper;
import com.tsys.payments.library.utils.ReceiptHelper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import java.util.HashMap;
import java.util.concurrent.CountDownLatch;

import androidx.annotation.Nullable;

import static org.junit.Assert.*;

@RunWith(BlockJUnit4ClassRunner.class)
public class RetailCertificationTest {
    private static final long GATEWAY_TIMEOUT = 10000;
    private static final String ADDRESS_LONG = "6860 Dallas Pkwy";
    private static final String ZIP_LONG = "750241234";
    private static final String ZIP_SHORT = "75024";
    private static final String ADDRESS_SHORT = "6860";

    private GatewayController mGatewayController;
    private ResponseHandler mGatewayListener;
    private CountDownLatch mCountDownLatch;

    @Before
    public void setUp() throws InitializationException {
        GatewayConfiguration gatewayConfiguration = new GatewayConfiguration();
        gatewayConfiguration.setGatewayTimeout(GATEWAY_TIMEOUT);

        LibraryConfigHelper.setDebugMode(true);

        HashMap<String, String> credentials = new HashMap<>();
        credentials.put(PorticoCredentialKeys.VERSION_NUMBER,
                MsrScriptsConstants.PORTICO_RETAIL_VERSION_NUMBER);
        credentials.put(PorticoCredentialKeys.DEVELOPER_ID,
                MsrScriptsConstants.PORTICO_RETAIL_DEVELOPER_ID);

        credentials
                .put(PorticoCredentialKeys.USER_NAME, MsrScriptsConstants.PORTICO_RETAIL_USERNAME);
        credentials
                .put(PorticoCredentialKeys.PASSWORD, MsrScriptsConstants.PORTICO_RETAIL_PASSWORD);
        credentials.put(PorticoCredentialKeys.SITE_ID, MsrScriptsConstants.PORTICO_RETAIL_SITE_ID);
        credentials.put(PorticoCredentialKeys.LICENSE_ID,
                MsrScriptsConstants.PORTICO_RETAIL_LICENSE_ID);
        credentials
                .put(PorticoCredentialKeys.DEVICE_ID, MsrScriptsConstants.PORTICO_RETAIL_DEVICE_ID);

        gatewayConfiguration.setCredentials(credentials);

        mGatewayListener = new ResponseHandler();
        mGatewayController =
                new PorticoGatewayControllerFactory()
                        .create(gatewayConfiguration, mGatewayListener);
    }

    //region CreditSale Transactions

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.01</li>
     * <li>Full Reversal</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale1() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1501,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                ReceiptUtils.printReceipts(gatewayRequest, response);
                performReversal(1501, response.getGatewayTransactionId(),
                        gatewayRequest.getCardData());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>MC Series 5</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.02</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale2() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1502,
                null,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.03</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale3() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1503,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>AMEX</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.04</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale4() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1504,
                null,
                MsrScriptsHelper.CardType.Amex,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>JCB</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.05</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale5() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1505,
                null,
                MsrScriptsHelper.CardType.Jcb,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.06</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale6() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1506,
                null,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 2</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.07</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale7() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1507,
                null,
                MsrScriptsHelper.CardType.MastercardSeries2,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                ReceiptUtils.printReceipts(gatewayRequest, response);
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.08</li>
     * <li>Partial Reversal Amount: 10.00</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale8() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1508,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                ReceiptUtils.printReceipts(gatewayRequest, response,gatewayRequest.getCardData());
                performReversal(1000,  response.getGatewayTransactionId(),
                        gatewayRequest.getCardData());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.01</li>
     * <li>Address Street: 6860 Dallas Pkwy</li>
     * <li>Address Zip: 750241234</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale9() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setAddressLine1(ADDRESS_LONG);
        address.setPostalCode(ZIP_LONG);

        final GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1601,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                ReceiptUtils.printReceipt(ReceiptHelper.buildMsrReceipt(gatewayRequest, response),
                        gatewayRequest.getCardData(), false);
                ReceiptUtils.printReceipt(ReceiptHelper.buildMsrReceipt(gatewayRequest, response),
                        gatewayRequest.getCardData(), true);
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.02</li>
     * <li>Address Street: 6860 Dallas Pkwy</li>
     * <li>Address Zip: 75024</li>
     * <li>Full Reversal</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale10() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        Address address = new Address();
        address.setAddressLine1(ADDRESS_LONG);
        address.setPostalCode(ZIP_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1602,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performReversal(1602, response.getGatewayTransactionId(),
                        gatewayRequest.getCardData());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.03</li>
     * <li>Address Zip: 750241234</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale11() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_LONG);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1603,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>AMEX</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.04</li>
     * <li>Address Street: 6860</li>
     * <li>Address Zip: 75024</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale12() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_SHORT);
        address.setAddressLine1(ADDRESS_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1604,
                null,
                MsrScriptsHelper.CardType.Amex,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>JCB</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.05</li>
     * <li>Address Zip: 75024</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale13() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1605,
                null,
                MsrScriptsHelper.CardType.Jcb,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.06</li>
     * <li>Address Zip: 750241234</li>
     * <li>Partial Reversal: 10.00</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale14() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        Address address = new Address();
        address.setPostalCode(ZIP_LONG);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1606,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performReversal(1000, response.getGatewayTransactionId(),
                        gatewayRequest.getCardData());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.01</li>
     * <li>Address Street: 6860 Dallas Pkwy</li>
     * <li>Address Zip: 750241234</li>
     * <li>CVV2: 123</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale15() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_LONG);
        address.setAddressLine1(ADDRESS_LONG);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1701,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.02</li>
     * <li>Address Street: 6860 Dallas Pkwy</li>
     * <li>Address Zip: 75024</li>
     * <li>Full Reversal</li>
     * <li>CVC2: 123</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale16() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        Address address = new Address();
        address.setPostalCode(ZIP_SHORT);
        address.setAddressLine1(ADDRESS_LONG);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1702,
                null,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performReversal(1702, response.getGatewayTransactionId(),
                        gatewayRequest.getCardData());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.03</li>
     * <li>Address Street: 6860</li>
     * <li>Address Zip: 75024</li>
     * <li>CID: 123</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale17() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_SHORT);
        address.setAddressLine1(ADDRESS_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1703,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Amex</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.04</li>
     * <li>Address Street: 6860</li>
     * <li>Address Zip: 750241234</li>
     * <li>CID: 1234</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale18() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_LONG);
        address.setAddressLine1(ADDRESS_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1704,
                null,
                MsrScriptsHelper.CardType.Amex,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 2</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.03</li>
     * <li>Address Street: 6860</li>
     * <li>Address Zip: 75024</li>
     * <li>CVC2: 123</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale19() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_SHORT);
        address.setAddressLine1(ADDRESS_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1703,
                null,
                MsrScriptsHelper.CardType.MastercardSeries2,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>JCB</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.05</li>
     * <li>Address Street: 6860 Dallas Pkwy</li>
     * <li>Address Zip: 75024</li>
     * <li>CID: 123</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSale20() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_SHORT);
        address.setAddressLine1(ADDRESS_LONG);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1705,
                null,
                MsrScriptsHelper.CardType.Jcb,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }
    //endregion

    //region Auth/ Add to Batch

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.16</li>
     * <li>Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture1() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1516,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.MSR,
                null,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                ReceiptUtils.printReceipts(gatewayRequest, response);
                performCapture(1516, null, response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.17</li>
     * <li>Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture2() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1517,
                null,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.MSR,
                null,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performCapture(1517, null, response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount: 15.18</li>
     * <li>Do Not Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture3() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1518,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.MSR,
                null,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.08</li>
     * <li>Address Street: 6860 Dallas Pkwy</li>
     * <li>Address Zip: 75024</li>
     * <li>CVV2: 123</li>
     * <li>Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture4() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        Address address = new Address();
        address.setAddressLine1(ADDRESS_LONG);
        address.setPostalCode(ZIP_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1608,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performCapture(1608, null, response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.09</li>
     * <li>Address Street: 6860</li>
     * <li>Address Zip: 75024</li>
     * <li>CVV2: 123</li>
     * <li>Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture5() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        Address address = new Address();
        address.setAddressLine1(ADDRESS_SHORT);
        address.setPostalCode(ZIP_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1609,
                null,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performCapture(1609, null, response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount: 16.10</li>
     * <li>Address Zip: 750241234</li>
     * <li>CID: 123</li>
     * <li>Do not Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture6() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_LONG);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1610,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP,
                address,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.08</li>
     * <li>6860 Dallas Pkwy</li>
     * <li>Address Zip: 750241234</li>
     * <li>CVV2: 123</li>
     * <li>Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture7() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        Address address = new Address();
        address.setAddressLine1(ADDRESS_LONG);
        address.setPostalCode(ZIP_LONG);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1708,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performCapture(1708, null, response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.09</li>
     * <li>Address Street: 6860</li>
     * <li>Address Zip: 75024</li>
     * <li>CVC: 123</li>
     * <li>Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture8() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        Address address = new Address();
        address.setAddressLine1(ADDRESS_SHORT);
        address.setPostalCode(ZIP_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1709,
                null,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performCapture(1709, null, response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Not Present</li>
     * <li>Manual - Phone</li>
     * <li>Amount: 17.10</li>
     * <li>Address Street: 6860</li>
     * <li>Address Zip: 750241234</li>
     * <li>CID: 123</li>
     * <li>Do Not Capture</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditAuthCapture9() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setAddressLine1(ADDRESS_SHORT);
        address.setPostalCode(ZIP_LONG);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1710,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.PHONE,
                "123",
                AvsType.ZIP_ADDRESS,
                address,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }
    //endregion


    //region Partially Approved Sales

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:130.00</li>
     * <li>Partial Approval: 110.00</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSalePartialApproval1() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(13000,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertEquals(11000, response.getApprovedAmount());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount:145.00</li>
     * <li>Address Zip: 75024</li>
     * <li>CID: 123</li>
     * <li>Partial Approval: 65.00</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSalePartialApproval2() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(14500,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.KEYED,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertEquals(6500, response.getApprovedAmount());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:155.00</li>
     * <li>Partial Approval: 100.00</li>
     * <li>Reversal: 100.00</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSalePartialApproval3() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(15500,
                null,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.KEYED,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertEquals(10000, response.getApprovedAmount());
                assertNotNull(response.getGatewayTransactionId());
                performReversal(response.getApprovedAmount(), response.getGatewayTransactionId(),
                        gatewayRequest.getCardData());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    //endregion

    //region Sale with Gratuity/Tip

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:15.12</li>
     * <li>Tip at Settlement: 3.00</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSaleEditTipAtSettlement1() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1512,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performTipAdjust(response.getApprovedAmount(), 300L,
                        response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount:15.13</li>
     * <li>Address Zip: 75024</li>
     * <li>CVC2: 123</li>
     * <li>Tip at Settlement: 3.00</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSaleEditTipAtSettlement2() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1513,
                null,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.KEYED,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                performTipAdjust(response.getApprovedAmount(), 300L,
                        response.getGatewayTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount:15.11</li>
     * <li>Tip Amount: 3.50</li>
     * <li>Address Zip: 75024</li>
     * <li>CVC2: 123</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSaleTipAtPurchase1() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        Address address = new Address();
        address.setPostalCode(ZIP_SHORT);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1861,
                350L,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.KEYED,
                null,
                AvsType.ZIP,
                address,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertEquals(1861, response.getApprovedAmount());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard Series 5</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:15.12</li>
     * <li>Tip Amount: 3.50</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditSaleTipAtPurchase2() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(1);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1862,
                350L,
                MsrScriptsHelper.CardType.MastercardSeries5,
                CardDataSourceType.KEYED,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertEquals(1862, response.getApprovedAmount());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    //endregion

    //region Return

    /**
     * Details
     * <p><ul>
     * <li>Amex</li>
     * <li>Card Present</li>
     * <li>Manual</li>
     * <li>Amount:15.18</li>
     * <li>Full Reversal</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditReturnByTransactionId1() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(3);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1518,
                null,
                MsrScriptsHelper.CardType.Amex,
                CardDataSourceType.KEYED,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                final CardData cardData = gatewayRequest.getCardData();
                final String gatewayTransactionId = response.getGatewayTransactionId();

                GatewayRequest closeBatchRequest =
                        new GatewayRequest.Builder(GatewayAction.BATCH_CLOSE).build();
                mGatewayListener.setResponseProcessor(new ResponseProcessor() {
                    @Override
                    public void processResponse(GatewayResponse response) {
                        mCountDownLatch.countDown();
                        try {
                            Thread.sleep(45000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        performReversal(1518, gatewayTransactionId,
                                gatewayRequest.getCardData());
                    }
                });
                mGatewayController.sendRequest(closeBatchRequest);
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Visa</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:15.19</li>
     * <li>Full Reversal</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditReturnByTransactionId2() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1519,
                null,
                MsrScriptsHelper.CardType.Visa,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();


        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                final CardData cardData = gatewayRequest.getCardData();
                final String gatewayTransactionId = response.getGatewayTransactionId();

                GatewayRequest closeBatchRequest =
                        new GatewayRequest.Builder(GatewayAction.BATCH_CLOSE).build();
                mGatewayListener.setResponseProcessor(new ResponseProcessor() {
                    @Override
                    public void processResponse(GatewayResponse response) {
                        mCountDownLatch.countDown();
                        try {
                            Thread.sleep(45000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        performReversal(1519, gatewayTransactionId,
                                gatewayRequest.getCardData());
                    }
                });
                mGatewayController.sendRequest(closeBatchRequest);
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:15.20</li>
     * <li>Full Reversal</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_creditReturnByTransactionId3() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1520,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.MSR,
                null,
                GatewayAction.SALE);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                final CardData cardData = gatewayRequest.getCardData();
                final String gatewayTransactionId = response.getGatewayTransactionId();

                GatewayRequest closeBatchRequest =
                        new GatewayRequest.Builder(GatewayAction.BATCH_CLOSE).build();
                mGatewayListener.setResponseProcessor(new ResponseProcessor() {
                    @Override
                    public void processResponse(GatewayResponse response) {
                        mCountDownLatch.countDown();
                        try {
                            Thread.sleep(45000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        performReversal(1520, gatewayTransactionId,
                                gatewayRequest.getCardData());
                    }
                });
                mGatewayController.sendRequest(closeBatchRequest);
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    //endregion

    //region Time-out-Reversal

    /**
     * Details
     * <p><ul>
     * <li>Discover</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:10.33</li>
     * <li>Timeout Reversal</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_timeoutReversal1() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(3);

        final GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1033,
                null,
                MsrScriptsHelper.CardType.Discover,
                CardDataSourceType.MSR,
                null,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isGatewayTimeout());
                performClientTransactionIdReversal(1033,
                        PorticoUtils.getMostRecentClientTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>Mastercard</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:10.33</li>
     * <li>Timeout Reversal</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_timeoutReversal2() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        final GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1033,
                null,
                MsrScriptsHelper.CardType.MastercardSeries2,
                CardDataSourceType.MSR,
                null,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isGatewayTimeout());
                performClientTransactionIdReversal(1033,
                        PorticoUtils.getMostRecentClientTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    /**
     * Details
     * <p><ul>
     * <li>JCB</li>
     * <li>Card Present</li>
     * <li>Swipe</li>
     * <li>Amount:10.33</li>
     * <li>Timeout Reversal</li>
     * </ul></p>
     *
     * @throws InterruptedException
     */
    @Test
    public void test_timeoutReversal3() throws InterruptedException {
        mCountDownLatch = new CountDownLatch(2);

        final GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(1033,
                null,
                MsrScriptsHelper.CardType.Jcb,
                CardDataSourceType.MSR,
                null,
                GatewayAction.AUTH);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isGatewayTimeout());
                performClientTransactionIdReversal(1033,
                        PorticoUtils.getMostRecentClientTransactionId());
            }
        });

        mGatewayController.sendRequest(gatewayRequest);
        mCountDownLatch.await();
    }

    //endregion

    //region Helper methods
    private void performClientTransactionIdReversal(long reversalAmount, String hostTransactionId) {
        performClientTransactionIdReversal(reversalAmount, hostTransactionId, null);
    }

    private void performClientTransactionIdReversal(long reversalAmount, String hostTransactionId,
            @Nullable CardData cardData) {
        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(reversalAmount,
                null, hostTransactionId, GatewayAction.REFUND);
        builder.setPosReferenceNumber(hostTransactionId)
                .setCardData(cardData);
        MsrScriptsHelper.performClientTransactionIdReversal(builder.build());
        mCountDownLatch.countDown();
    }

    private void performReversal(long reversalAmount, final String hostTransactionId,
            @Nullable final CardData cardData) {
        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(reversalAmount,
                null, hostTransactionId, GatewayAction.VOID);
        final GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                ReceiptUtils.printReceipts(gatewayRequest, response,cardData);
                if (!PorticoUtils.getMostRecentClientTransactionId().isEmpty()
                        &&
                        PorticoUtils.getMostRecentClientTransactionId().equals(hostTransactionId)) {
                    // This handles the exception test case where a reversal performed on the client
                    // transaction id will fail due to the test environment setup
                    return;
                }
             //   assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(gatewayRequest);
    }

    private void performCapture(long captureAmount, @Nullable Long tipAmount,
            String hostTransactionId) {
        performCapture(captureAmount, tipAmount, hostTransactionId, null);
    }

    private void performCapture(long captureAmount, @Nullable Long tipAmount,
            String hostTransactionId, @Nullable CardData cardData) {
        GatewayRequest.Builder builder =
                MsrScriptsHelper.getGatewayRequest(captureAmount, tipAmount,
                        hostTransactionId, GatewayAction.CAPTURE);
        builder.setCardData(cardData);
        GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(gatewayRequest);
    }

    private void performTipAdjust(long originalAmount, @Nullable Long tipAmount,
            String hostTransactionId) {
        performTipAdjust(originalAmount, tipAmount, hostTransactionId, null);
    }

    private void performTipAdjust(long originalAmount, @Nullable Long tipAmount,
            String hostTransactionId, @Nullable CardData cardData) {
        long amount = originalAmount + (tipAmount == null ? 0 : tipAmount);

        GatewayRequest.Builder builder =
                MsrScriptsHelper.getGatewayRequest(amount, tipAmount,
                        hostTransactionId, GatewayAction.TIP_ADJUST);
        builder.setCardData(cardData);
        GatewayRequest gatewayRequest = builder.build();

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(gatewayRequest);
    }
    //endregion
}
