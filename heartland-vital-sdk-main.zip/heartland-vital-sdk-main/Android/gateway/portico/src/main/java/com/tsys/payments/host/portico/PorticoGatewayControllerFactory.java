package com.tsys.payments.host.portico;

import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayControllerFactory;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.enums.GatewayType;

import androidx.annotation.Nullable;

import java.util.Map;

public class PorticoGatewayControllerFactory implements GatewayControllerFactory {
    @Nullable
    @Override
    public GatewayType[] getSupportedGateways() {
        return new GatewayType[] {GatewayType.PORTICO};
    }

    @Nullable
    @Override
    public TerminalType[] getSupportedTerminals() {
        return new TerminalType[] {TerminalType.BBPOS_C2X, TerminalType.INGENICO_MOBY_5500};
    }

    @Nullable
    @Override
    public GatewayController create(GatewayConfiguration gatewayConfiguration,
            GatewayListener listener) throws InitializationException {
        validateConfiguration(gatewayConfiguration);
        return new PorticoGatewayController(gatewayConfiguration, listener);
    }

    private void validateConfiguration(GatewayConfiguration configuration) {
        Map<String, String> hostCreds = configuration.getCredentials();
        if (hostCreds == null || hostCreds.isEmpty()) {
            throw new IllegalArgumentException("Invalid Configuration. Credentials are not " +
                    "provided but are required.");
        }
        if (!hostCreds.containsKey(PorticoCredentialKeys.USER_NAME)) {
            throw new IllegalArgumentException("Invalid configuration. Username is missing but " +
                    "required.");
        }
        if (!hostCreds.containsKey(PorticoCredentialKeys.PASSWORD)) {
            throw new IllegalArgumentException("Invalid configuration. Password is missing but " +
                    "required.");
        }
        if (!hostCreds.containsKey(PorticoCredentialKeys.SITE_ID)) {
            throw new IllegalArgumentException("Invalid configuration. Site id is missing but " +
                    "required.");
        }
        if (!hostCreds.containsKey(PorticoCredentialKeys.LICENSE_ID)) {
            throw new IllegalArgumentException("Invalid configuration. License id is missing but " +
                    "required.");
        }
        if (!hostCreds.containsKey(PorticoCredentialKeys.DEVICE_ID)) {
            throw new IllegalArgumentException("Invalid configuration. Device id is missing but " +
                    "required.");
        }
    }
}
