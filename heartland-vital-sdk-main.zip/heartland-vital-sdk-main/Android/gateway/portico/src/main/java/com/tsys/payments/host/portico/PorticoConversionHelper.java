package com.tsys.payments.host.portico;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.global.api.entities.Address;
import com.global.api.entities.EncryptionData;
import com.global.api.entities.enums.AddressType;
import com.global.api.entities.enums.EntryMethod;
import com.global.api.paymentMethods.Credit;
import com.global.api.paymentMethods.CreditCardData;
import com.global.api.paymentMethods.CreditTrackData;
import com.tsys.payments.host.portico.utils.PorticoUtils;
import com.tsys.payments.library.domain.AutoSubstantiation;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.Customer;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvUtils;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import timber.log.Timber;

class PorticoConversionHelper {
    // Transaction flow approval codes
    private static final String PORTICO_TRANSACTION_SUCCESS_APPROVAL = "00";
    private static final String PORTICO_TRANSACTION_SUCCESS_PARTIAL_APPROVAL = "10";
    private static final String PORTICO_RESPONSE_COMMUNICATION_ERROR = "91";
    private static final String PORTICO_TRANSACTION_APPROVAL = "APPROVAL";
    private static final String PORTICO_TRANSACTION_PARTIAL_APPROVAL = "PARTIAL APPROVAL";
    private static final String PORTICO_CARD_VERIFY_APPROVAL = "CARD OK";

    // Host approval codes
    private static final String PORTICO_GATEWAY_APPROVAL = "Success";

    private static final Set<EmvTagDescriptor> sBlackListEmvTagDescriptors = new HashSet<>();

    static {
        // BbPos Tags that are not supported by Portico gateway
        // C1....C8
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_ARQC_DECRYPTION_KSN);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_ONLINE_PIN_KSN);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_ENCRYPTED_ONLINE_MESSAGE);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_AAC_TC_DECRYPTION_KSN);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_MASKED_PAN);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_ENCRYPTED_BATCH_MESSAGE);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_ENCRYPTED_REVERSAL_MESSAGE);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_TRACK_2_EQUIVALENT_DATA_KSN);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_TRACK_2_EQUIVALENT_DATA);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.PAN);

        // Additional Tags
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_SERIAL_NUMBER);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_DEVICE_SERIAL_NUMBER);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_KERNEL_VERSION_NUMBER);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_BID);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_QUICK_CHIP_INDICATOR);

        // Unknown proprietary Tags also not supported
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_PROPRIETARY_TAG_1);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_PROPRIETARY_TAG_2);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.BBPOS_PROPRIETARY_TAG_3);

        //Ingenico Tags
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.TRACK_2_EQUIVALENT_DATA);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.INGENICO_ENCRYPTED_TRACK);
        sBlackListEmvTagDescriptors.add(EmvTagDescriptor.INGENICO_KSN);
    }

    static boolean isManualTransaction(CardDataSourceType type) {
        return (CardDataSourceType.KEYED == type ||
                CardDataSourceType.PHONE == type ||
                CardDataSourceType.INTERNET == type ||
                CardDataSourceType.MAIL == type);
    }

    static Credit populateCardData(@NonNull GatewayRequest request) {
        CardData cardData = request.getCardData();
        if (cardData != null) {
            CardDataSourceType type = cardData.getCardDataSource();

            if (type == CardDataSourceType.CONTACTLESS_MSR) {
                if (cardData.getEmvTlvData() == null || cardData.getEmvTlvData().isEmpty()) {
                    return buildMsrCardData(cardData);
                } else {
                    return buildEmvCardData(cardData);
                }
            }

            if (type != null) {
                switch (type) {
                    case MSR:
                    case FALLBACK:
                        return buildMsrCardData(cardData);
                    case SCR:
                    case CONTACTLESS_EMV:
                        return buildEmvCardData(cardData);
                    case KEYED:
                    case PHONE:
                    case MAIL:
                    case INTERNET:
                        return buildManualEntryCardData(request.getCardData());
                    default:
                        return null;
                }
            }
        }
        return null;
    }

    static Credit populateTokenData(@NonNull GatewayRequest request) {
        CreditCardData cardData = new CreditCardData();
        cardData.setToken(request.getToken());
        return cardData;
    }

    /**
     * * @return {@link EmvTagDescriptor#TRACK_2_EQUIVALENT_DATA}
     */
    private static String getTrack2EquivalentData(List<TlvObject> emvTags) {
        if (emvTags != null) {
            for (TlvObject tlvObject : emvTags) {
                if (tlvObject.getTagDescriptor() ==
                        EmvTagDescriptor.BBPOS_TRACK_2_EQUIVALENT_DATA) {
                    return tlvObject.getValueAsHexString(false);
                }
                if (tlvObject.getTagDescriptor() ==
                        EmvTagDescriptor.INGENICO_ENCRYPTED_TRACK) {
                    return tlvObject.getValueAsHexString(false);
                }
            }
        }
        return null;
    }

    /**
     * * @return {@link EmvTagDescriptor#TRACK_2_EQUIVALENT_DATA}
     */
    private static String getKsnEquivalentData(List<TlvObject> emvTags) {
        if (emvTags != null) {
            for (TlvObject tlvObject : emvTags) {
                if (tlvObject.getTagDescriptor() ==
                        EmvTagDescriptor.BBPOS_TRACK_2_EQUIVALENT_DATA_KSN) {
                    return tlvObject.getValueAsHexString(false);
                }
                if (tlvObject.getTagDescriptor() ==
                        EmvTagDescriptor.INGENICO_KSN) {
                    return tlvObject.getValueAsHexString(false);
                }
            }
        }
        return null;
    }

    private static Credit buildMsrCardData(CardData cardData) {
        EncryptionData encryptionDataMsr = new EncryptionData();
        CreditTrackData msrCardData = new CreditTrackData();
        // Version represents TDES encryption used by the device
        encryptionDataMsr.setVersion("05");

        encryptionDataMsr.setKsn(PorticoUtils.encodeHexStringToBase64(cardData.getKsn()));

        // Track data
        if (!TextUtils.isEmpty(cardData.getTrack1()) &&
                !TextUtils.isEmpty(cardData.getTrack2())) {  // Track 1 and Track 2
            encryptionDataMsr.setTrackNumber("2");
            msrCardData.setValue(PorticoUtils
                    .encodeHexStringToBase64(cardData.getTrack1() + cardData.getTrack2()));
        } else if (!TextUtils.isEmpty(cardData.getTrack1())) {  // Track 1
            encryptionDataMsr.setTrackNumber("1");
            msrCardData.setValue(PorticoUtils.encodeHexStringToBase64(cardData.getTrack1()));
        } else if (!TextUtils.isEmpty(cardData.getTrack2())) {   // Track 2
            encryptionDataMsr.setTrackNumber("2");
            msrCardData.setValue(PorticoUtils.encodeHexStringToBase64(cardData.getTrack2()));
        }
        msrCardData.setEncryptionData(encryptionDataMsr);

        if (cardData.getCardDataSource() == CardDataSourceType.CONTACTLESS_MSR) {
            msrCardData.setEntryMethod(EntryMethod.Proximity);
        }

        return msrCardData;
    }

    private static Credit buildEmvCardData(CardData cardData) {
        EncryptionData encryptionDataEmv = new EncryptionData();
        encryptionDataEmv.setVersion("05");
        encryptionDataEmv.setTrackNumber("2");
        encryptionDataEmv.setKsn(PorticoUtils
                .encodeHexStringToBase64(getKsnEquivalentData(cardData.getEmvTlvData())));

        CreditTrackData emvCardData = new CreditTrackData();
        String track2EquivalentData = getTrack2EquivalentData(cardData.getEmvTlvData());

        if (!TextUtils.isEmpty(track2EquivalentData)) {
            emvCardData.setValue(PorticoUtils
                    .encodeHexStringToBase64(track2EquivalentData));
        }
        emvCardData.setEncryptionData(encryptionDataEmv);

        if (cardData.getCardDataSource() == CardDataSourceType.CONTACTLESS_MSR
                || cardData.getCardDataSource() == CardDataSourceType.CONTACTLESS_EMV) {
            emvCardData.setEntryMethod(EntryMethod.Proximity);
        }

        // Remove black listed Emv Tags
        cardData.setEmvTlvData(
                TlvUtils.stripEmvTagDescriptorsFromTlvList(sBlackListEmvTagDescriptors,
                        cardData.getEmvTlvData()));

        return emvCardData;
    }

    static Credit buildManualEntryCardData(CardData cardData) {
        CreditCardData manualEntryCardData = new CreditCardData();
        // Name
        manualEntryCardData.setCardHolderName(cardData.getCardholderName());
        // Number
        manualEntryCardData.setNumber(cardData.getPan());
        // Exp Date
        String expDate = cardData.getExpirationDate();
        if (!TextUtils.isEmpty(expDate)) {
            // Exp Month
            String expMonth = expDate.substring(0, 2);
            try {
                manualEntryCardData.setExpMonth(Integer.parseInt(expMonth));
            } catch (NumberFormatException e) {
                Timber.e("Could not parse expiration month from card data");
                manualEntryCardData.setExpMonth(0);
            }
            // Exp Year
            String expYear = expDate.substring(2);
            try {
                manualEntryCardData.setExpYear(Integer.parseInt(expYear));
            } catch (NumberFormatException e) {
                Timber.e("Could not parse expiration year from card data");
                manualEntryCardData.setExpYear(0);
            }
            // Cvv
            manualEntryCardData.setCvn(cardData.getCvv2());
            // Card Present
            if (CardDataSourceType.KEYED == cardData.getCardDataSource()) {
                manualEntryCardData.setCardPresent(true);
            } else {
                manualEntryCardData.setCardPresent(false);
            }
            manualEntryCardData.setReaderPresent(true);
        }
        return manualEntryCardData;
    }

    static CreditTrackData buildCreditTrackData(CardData cardData) {
        // TODO: Waiting on Card reader integration for more Info
        CreditTrackData trackData = new CreditTrackData();
        return trackData;
    }

    static Address populateAddress(
            @Nullable com.tsys.payments.library.domain.Address customerAddress) {
        Address address = new Address();
        if (customerAddress != null) {
            // Address line 1
            if (!TextUtils.isEmpty(customerAddress.getAddressLine1())) {
                address.setStreetAddress1(customerAddress.getAddressLine1());
            }
            // Address line 2
            if (!TextUtils.isEmpty(customerAddress.getAddressLine2())) {
                address.setStreetAddress2(customerAddress.getAddressLine2());
            }
            // City
            if (!TextUtils.isEmpty(customerAddress.getCity())) {
                address.setCity(customerAddress.getCity());
            }
            // Postal code
            if (!TextUtils.isEmpty(customerAddress.getPostalCode())) {
                address.setPostalCode(customerAddress.getPostalCode());
            }
            // Address type
            address.setType(AddressType.Billing);
        }
        return address;
    }

    static com.global.api.entities.Customer buildCustomerData(Customer customerData) {
        com.global.api.entities.Customer customer = new com.global.api.entities.Customer();
        customer.setEmail(customerData.getEmail());
        return customer;
    }

    static com.global.api.entities.AutoSubstantiation buildAutoSubstantiation(AutoSubstantiation autoSubstantiationData) {
        if (autoSubstantiationData == null) {
            return null;
        }
        com.global.api.entities.AutoSubstantiation autoSubstantiation = new com.global.api.entities.AutoSubstantiation();
        autoSubstantiation.setClinicSubTotal(autoSubstantiationData.getClinicSubTotal());
        autoSubstantiation.setRealTimeSubstantiation(autoSubstantiationData.isRealTimeSubstantiation());
        autoSubstantiation.setDentalSubTotal(autoSubstantiationData.getDentalSubTotal());
        autoSubstantiation.setVisionSubTotal(autoSubstantiationData.getVisionSubTotal());
        autoSubstantiation.setPrescriptionSubTotal(autoSubstantiationData.getPrescriptionSubTotal());
        autoSubstantiation.setMerchantVerificationValue(autoSubstantiationData.getMerchantVerificationValue());
        return autoSubstantiation;
    }

    static boolean isTransactionApproved(@NonNull String responseMessage) {
        return !TextUtils.isEmpty(responseMessage) &&
                (PORTICO_TRANSACTION_APPROVAL.equalsIgnoreCase(responseMessage)
                        || PORTICO_TRANSACTION_PARTIAL_APPROVAL.equalsIgnoreCase(responseMessage)
                        || PORTICO_GATEWAY_APPROVAL.equalsIgnoreCase(responseMessage));
    }

    static boolean isVerifyApproved(@NonNull String responseMessage) {
        // Discover card brand has a different approval response code
        return !TextUtils.isEmpty(responseMessage) &&
                (PORTICO_CARD_VERIFY_APPROVAL.equalsIgnoreCase(responseMessage)
                        || PORTICO_TRANSACTION_APPROVAL.equalsIgnoreCase(responseMessage));
    }

    static boolean isGatewayTimeout(@Nullable String responseCode) {
        return !TextUtils.isEmpty(responseCode) &&
                PORTICO_RESPONSE_COMMUNICATION_ERROR.equals(responseCode);
    }

    static boolean isGatewayApproved(@NonNull String responseMessage) {
        return !TextUtils.isEmpty(responseMessage) &&
                PORTICO_GATEWAY_APPROVAL.equalsIgnoreCase(responseMessage);
    }

    @Nullable
    static CardType getCardTypeFromHostResponse(@Nullable String gatewayCardType) {
        if ("Visa".equalsIgnoreCase(gatewayCardType)) {
            return CardType.VISA;
        } else if ("Mc".equalsIgnoreCase(gatewayCardType)) {
            return CardType.MASTERCARD;
        } else if ("Disc".equals(gatewayCardType)) {
            return CardType.DISCOVER;
        } else if ("Amex".equals(gatewayCardType)) {
            return CardType.AMERICAN_EXPRESS;
        } else {
            return null;
        }
    }

    public static String fromPennies(String pennyAmountString) {
        if (TextUtils.isEmpty(pennyAmountString)) {
            return null;
        }

        StringBuilder sb = new StringBuilder(pennyAmountString);
        if (pennyAmountString.length() == 1) {
            sb.insert(0, "0");
        }
        sb.insert(sb.length() - 2, ".");
        return sb.toString();
    }

    @Nullable
    public static String getConvertedToString(@Nullable Long input) {
        if (input == null) {
            return null;
        }
        try {
            return Long.toString(input);
        } catch (NumberFormatException e) {
            Timber.e(e);
            return null;
        }
    }

    @NonNull
    static String toPennies(@NonNull String amountString) {
        // remove all non-digit chars from string
        amountString = amountString.replaceAll("[^\\d]", "");

        // remove any leading zeros for amounts that are < $1
        amountString = amountString.replaceFirst("^0+(?!$)", "");
        return amountString;
    }

    /**
     * Returns the input string converted to corresponding {@link Long} value.
     */
    static long getConvertedToLong(@NonNull String input) {
        if (TextUtils.isEmpty(input)) {
            return 0;
        }
        try {
            return Long.parseLong(input);
        } catch (NumberFormatException ex) {
            Timber.e(ex);
            return 0;
        }
    }
}
