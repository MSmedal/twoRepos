package com.tsys.payments.host.portico;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.global.api.ServicesContainer;
import com.global.api.builders.AuthorizationBuilder;
import com.global.api.builders.ManagementBuilder;
import com.global.api.entities.EcommerceInfo;
import com.global.api.entities.Transaction;
import com.global.api.entities.TransactionSummary;
import com.global.api.entities.TransactionSummaryList;
import com.global.api.entities.enums.EcommerceChannel;
import com.global.api.entities.enums.EmvChipCondition;
import com.global.api.entities.enums.StoredCredentialInitiator;
import com.global.api.entities.enums.TransactionType;
import com.global.api.entities.exceptions.ApiException;
import com.global.api.entities.exceptions.ConfigurationException;
import com.global.api.entities.exceptions.GatewayException;
import com.global.api.entities.reporting.SearchCriteria;
import com.global.api.paymentMethods.Credit;
import com.global.api.serviceConfigs.GatewayConfig;
import com.global.api.serviceConfigs.PorticoConfig;
import com.global.api.services.ReportingService;
import com.tsys.payments.host.portico.constants.Constants;
import com.tsys.payments.host.portico.constants.PorticoCurrencyCodeType;
import com.tsys.payments.host.portico.utils.PorticoUtils;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.tlv.TlvUtils;
import com.tsys.payments.library.utils.LibraryConfigHelper;
import java.io.IOException;
import java.math.BigDecimal;

import timber.log.Timber;

public class PorticoGatewayController implements GatewayController {
    private static final String TAG = PorticoGatewayController.class.getName();
    private static final String EMV_RESPONSE_CODE_UNABLE_TO_GO_ONLINE = "8A025A33";
    private static final String TRANSACTION_STATUS_ACTIVE = "A";
    private static final String TRANSACTION_STATUS_CLEARED = "C";
    private static final String TRANSACTION_TYPE_CAPTURE = "CreditAddToBatch";
    private static final String TRANSACTION_APPROVED = "Success";
    private static final int UNDEFINED_ID = -1;
    private final GatewayListener mGatewayListener;
    private final String HOST_NOT_AVAILABLE = "Host not available";
    private GatewayRequest mGatewayRequest;

    PorticoGatewayController(@NonNull GatewayConfiguration hostConfig,
            @NonNull GatewayListener gatewayListener) {
        mGatewayListener = gatewayListener;
        initializePorticoWrapper(hostConfig);
    }

    private void initializePorticoWrapper(@NonNull GatewayConfiguration hostConfig) {
        try {
            ServicesContainer.configureService(buildGatewayConfig(hostConfig));
        } catch (ConfigurationException e) {
            Timber.e("Service container could not be configured%s", e.getMessage());
            broadcastGatewayError(GatewayAction.AUTHENTICATE, e.getMessage());
        }
    }

    private GatewayConfig buildGatewayConfig(@NonNull GatewayConfiguration hostConfig) {
        String versionNumber =
                hostConfig.getCredentials().get(PorticoCredentialKeys.VERSION_NUMBER);
        String developerId = hostConfig.getCredentials().get(PorticoCredentialKeys.DEVELOPER_ID);

        String userName = hostConfig.getCredentials().get(PorticoCredentialKeys.USER_NAME);
        String password = hostConfig.getCredentials().get(PorticoCredentialKeys.PASSWORD);
        String siteId = hostConfig.getCredentials().get(PorticoCredentialKeys.SITE_ID);
        String licenseId = hostConfig.getCredentials().get(PorticoCredentialKeys.LICENSE_ID);
        String deviceId = hostConfig.getCredentials().get(PorticoCredentialKeys.DEVICE_ID);

        PorticoConfig config = new PorticoConfig();
        config.setVersionNumber(versionNumber);
        config.setDeveloperId(developerId);

        config.setUsername(userName);
        config.setPassword(password);
        config.setSiteId(!TextUtils.isEmpty(siteId) ? Integer.parseInt(siteId) : UNDEFINED_ID);
        config.setLicenseId(
                !TextUtils.isEmpty(licenseId) ? Integer.parseInt(licenseId) : UNDEFINED_ID);
        config.setDeviceId(
                !TextUtils.isEmpty(deviceId) ? Integer.parseInt(deviceId) : UNDEFINED_ID);

        config.setEnableLogging(LibraryConfigHelper.isDebug());

        config.setSdkNameVersion(LibraryConfigHelper.getSdkNameVersion());

        if (LibraryConfigHelper.isDebug()) {
            config.setServiceUrl(Constants.TEST_ENDPOINT);
        } else {
            config.setServiceUrl(Constants.PRODUCTION_ENDPOINT);
        }
        return config;
    }

    private boolean isGatewayActionSupported(GatewayAction action) {
        if (action == null) return false;
        switch (action) {
            case AUTH:
            case SALE:
            case VERIFY:
            case CAPTURE:
            case PARTIAL_REFUND:
            case REFUND:
            case VOID:
            case TIP_ADJUST:
            case BATCH_CLOSE:
                return true;
            default:
                return false;
        }
    }

    @Override
    public void sendRequest(@NonNull GatewayRequest gatewayRequest) {
        Timber.d("sendRequest() called with: gatewayRequest = [" + gatewayRequest + "]");
        mGatewayRequest = gatewayRequest;

        if (!isGatewayActionSupported(gatewayRequest.getGatewayAction())) {
            handleUnsupportedGatewayAction();
        } else {
            processGatewayAction(mGatewayRequest);
        }
    }

    private void processGatewayAction(@NonNull GatewayRequest request) {
        Timber.d("processGatewayAction() called with action %s", request.getGatewayAction());

        switch (request.getGatewayAction()) {
            case AUTH:
                handleAuthorizeRequest(request);
                break;
            case SALE:
                handleSaleRequest(request);
                break;
            case VERIFY:
                handleVerifyRequest(request);
                break;
            case TIP_ADJUST:
                handleTipAdjust(request);
                break;
            case CAPTURE:
                handleCaptureRequest(request);
                break;
            case PARTIAL_REFUND:
            case REFUND:
            case VOID:
                getTransactionStatusAndPerformAction(request);
                break;
            case BATCH_CLOSE:
                handleBatchCloseRequest(request);
                break;
        }
    }

    // region Transactions requests
    // Auth
    private void handleAuthorizeRequest(GatewayRequest gatewayRequest) {
        Transaction hostResponse = null;
        CardDataSourceType type = null;

        if (gatewayRequest.getCardData() != null) {
            type = gatewayRequest.getCardData().getCardDataSource();
        }
        Credit hostRequest = PorticoModelConverter.toSaleAuthRequest(gatewayRequest);
        String totalFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTotal()));
        String tipFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTip()));
        String surchargeFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getSurcharge()));

        String clientTransactionId = getClientTransactionId(gatewayRequest);

        try {
            AuthorizationBuilder builder = hostRequest.authorize(new BigDecimal(totalFromPennies));
            // only case where type can be null is for a payment method that uses a token
            if (type != null) {
                if (CardDataSourceType.FALLBACK == type) {
                    builder.withChipCondition(EmvChipCondition.ChipFailPreviousSuccess);
                } else if (CardDataSourceType.SCR == type
                        || CardDataSourceType.CONTACTLESS_EMV == type
                        || CardDataSourceType.CONTACTLESS_MSR == type) {
                    builder.withTagData(
                            TlvUtils.getIccDataString(
                                    gatewayRequest.getCardData().getEmvTlvData()));
                }

                setEcommerceIndicator(builder, type);
            }
            builder = builder.withCurrency(PorticoCurrencyCodeType.USD.name())
                    .withAllowPartialAuth(true)
                    .withRequestMultiUseToken(gatewayRequest.isGenerateToken())
                    .withAddress(PorticoConversionHelper
                            .populateAddress(gatewayRequest.getCardholderAddress()))
                    .withClientTransactionId(clientTransactionId)
                    .withPosSequenceNumber(gatewayRequest.getPosReferenceNumber())
                    .withInvoiceNumber(gatewayRequest.getInvoiceNumber())
                    .withClerkId(gatewayRequest.getOperatingUserId())
                    .withAllowDuplicates(gatewayRequest.isAllowDuplicates())
                    .withGratuity(TextUtils.isEmpty(tipFromPennies) ? BigDecimal.ZERO :
                            new BigDecimal(tipFromPennies))
                    .withSurchargeAmount(TextUtils.isEmpty(surchargeFromPennies) ?
                            BigDecimal.ZERO : new BigDecimal(surchargeFromPennies))
                    .withCustomerData(gatewayRequest.getCustomer() != null ?
                            PorticoConversionHelper
                                    .buildCustomerData(gatewayRequest.getCustomer()) : null)
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .withCommercialRequest(true);

            if (gatewayRequest.isSAFIndicator()) {
                builder = (AuthorizationBuilder)builder.withSAFIndicator(gatewayRequest.isSAFIndicator())
                        .withSAFOrigDT(gatewayRequest.getSAFOrigDT());
            }
            hostResponse = builder.execute();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                fetchTransactionByClientTransactionId(clientTransactionId);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    type);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), type);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    // Sale
    private void handleSaleRequest(GatewayRequest gatewayRequest) {
        Transaction hostResponse = null;
        CardDataSourceType type = null;

        if (gatewayRequest.getCardData() != null) {
            type = gatewayRequest.getCardData().getCardDataSource();
        }
        Credit hostRequest = PorticoModelConverter.toSaleAuthRequest(gatewayRequest);
        String totalFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTotal()));
        String tipFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTip()));
        String surchargeFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getSurcharge()));

        String clientTransactionId = getClientTransactionId(gatewayRequest);

        try {
            AuthorizationBuilder builder = hostRequest.charge(new BigDecimal(totalFromPennies));
            // only case where type can be null is for a payment method that uses a token
            if (type != null) {
                if (CardDataSourceType.FALLBACK == type) {
                    builder.withChipCondition(EmvChipCondition.ChipFailPreviousSuccess);
                } else if (CardDataSourceType.SCR == type
                        || CardDataSourceType.CONTACTLESS_EMV == type
                        || CardDataSourceType.CONTACTLESS_MSR == type) {
                    builder.withTagData(
                            TlvUtils.getIccDataString(
                                    gatewayRequest.getCardData().getEmvTlvData()));
                }

                setEcommerceIndicator(builder, type);
            }
            builder = builder.withCurrency(PorticoCurrencyCodeType.USD.name())
                    .withAllowPartialAuth(true)
                    .withRequestMultiUseToken(gatewayRequest.isGenerateToken())
                    .withAddress(PorticoConversionHelper
                            .populateAddress(gatewayRequest.getCardholderAddress()))
                    .withClientTransactionId(clientTransactionId)
                    .withPosSequenceNumber(gatewayRequest.getPosReferenceNumber())
                    .withInvoiceNumber(gatewayRequest.getInvoiceNumber())
                    .withClerkId(gatewayRequest.getOperatingUserId())
                    .withAllowDuplicates(gatewayRequest.isAllowDuplicates())
                    .withGratuity(TextUtils.isEmpty(tipFromPennies) ? BigDecimal.ZERO :
                            new BigDecimal(tipFromPennies))
                    .withSurchargeAmount(TextUtils.isEmpty(surchargeFromPennies) ?
                            BigDecimal.ZERO : new BigDecimal(surchargeFromPennies))
                    .withCustomerData(gatewayRequest.getCustomer() != null ?
                            PorticoConversionHelper
                                    .buildCustomerData(gatewayRequest.getCustomer()) : null)
                    .withAutoSubstantiation(
                            PorticoConversionHelper.buildAutoSubstantiation(gatewayRequest.getAutoSubstantiation()))
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .withCommercialRequest(true);
            if (gatewayRequest.isSAFIndicator()) {
                builder = (AuthorizationBuilder)builder.withSAFIndicator(gatewayRequest.isSAFIndicator())
                        .withSAFOrigDT(gatewayRequest.getSAFOrigDT());
            }
            if (gatewayRequest.getCardBrandTxnId() != null && !gatewayRequest.getCardBrandTxnId().isEmpty()) {
                builder = (AuthorizationBuilder)builder.withCardBrandStorage(StoredCredentialInitiator.Merchant,
                        gatewayRequest.getCardBrandTxnId());
            }
            hostResponse = builder.execute();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                fetchTransactionByClientTransactionId(clientTransactionId);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    type);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), type);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    /**
     * Evaluates the provided GatewayRequest to determine what value will be sent as the ClientTransactionId.
     * <p>
     * If {@code gatewayRequest}contains a Pos Reference Number provided by the client it will be sent as-is. If the
     * gateway request does not contain a Pos Reference Number provided by the client a unique client id will be
     * generated on their behalf.
     *
     * @param gatewayRequest Original request data being sent to Portico
     * @return A unique transaction identifier generated by the library consumer or generated by this library.
     */
    private String getClientTransactionId(GatewayRequest gatewayRequest) {
        String clientTransactionId;
        if (!TextUtils.isEmpty(gatewayRequest.getPosReferenceNumber())) {
            clientTransactionId = gatewayRequest.getPosReferenceNumber();
        } else {
            clientTransactionId = PorticoUtils.generateClientTransactionId();
        }
        PorticoUtils.setMostRecentClientTransactionId(clientTransactionId);
        return clientTransactionId;
    }

    // Verify
    private void handleVerifyRequest(GatewayRequest gatewayRequest) {
        Transaction hostResponse = null;
        CardDataSourceType type = null;

        if (gatewayRequest.getCardData() != null) {
            type = gatewayRequest.getCardData().getCardDataSource();
        }
        Credit hostRequest = PorticoModelConverter.toVerifyRequest(gatewayRequest);

        String clientTransactionId = getClientTransactionId(gatewayRequest);

        try {
            AuthorizationBuilder builder = hostRequest.verify();
            // only case where type can be null is for a payment method that uses a token
            if (type != null) {
                if (CardDataSourceType.FALLBACK == type) {
                    builder.withChipCondition(EmvChipCondition.ChipFailPreviousSuccess);
                } else if (CardDataSourceType.SCR == type) {
                    builder.withTagData(
                            TlvUtils.getIccDataString(
                                    gatewayRequest.getCardData().getEmvTlvData()));
                }
            }
            hostResponse = builder.withCurrency(PorticoCurrencyCodeType.USD.name())
                    .withAllowPartialAuth(false)
                    .withRequestMultiUseToken(gatewayRequest.isGenerateToken())
                    .withAddress(PorticoConversionHelper
                            .populateAddress(gatewayRequest.getCardholderAddress()))
                    .withClientTransactionId(clientTransactionId)
                    .withInvoiceNumber(gatewayRequest.getInvoiceNumber())
                    .withClerkId(gatewayRequest.getOperatingUserId())
                    .withAllowDuplicates(gatewayRequest.isAllowDuplicates())
                    .withCustomerData(gatewayRequest.getCustomer() != null ?
                            PorticoConversionHelper
                                    .buildCustomerData(gatewayRequest.getCustomer()) : null)
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .execute();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    type);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), type);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    // Tip adjust
    private void handleTipAdjust(GatewayRequest gatewayRequest) {
        Transaction hostResponse = null;
        String totalFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTotal()));
        String tipFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTip()));

        String clientTransactionId = getClientTransactionId(gatewayRequest);

        try {
            ManagementBuilder builder = Transaction.fromId(gatewayRequest.getGatewayTransactionId())
                    .edit()
                    .withAmount(new BigDecimal(totalFromPennies))
                    .withClientTransactionId(clientTransactionId)
                    .withPosSequenceNumber(gatewayRequest.getPosReferenceNumber())
                    .withGratuity(TextUtils.isEmpty(tipFromPennies) ? BigDecimal.ZERO :
                            new BigDecimal(tipFromPennies))
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .withCurrency(PorticoCurrencyCodeType.USD.name());
            if (gatewayRequest.isSAFIndicator()) {
                builder = (ManagementBuilder)builder.withSAFIndicator(gatewayRequest.isSAFIndicator())
                        .withSAFOrigDT(gatewayRequest.getSAFOrigDT());
            }
            hostResponse = builder.execute();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exception from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    // Capture
    private void handleCaptureRequest(GatewayRequest gatewayRequest) {
        Transaction hostResponse = null;
        String totalFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTotal()));
        String tipFromPennies = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTip()));

        String clientTransactionId = getClientTransactionId(gatewayRequest);

        try {
            ManagementBuilder builder = Transaction.fromId(gatewayRequest.getGatewayTransactionId())
                    .capture(new BigDecimal(totalFromPennies))
                    .withClientTransactionId(clientTransactionId)
                    .withPosSequenceNumber(gatewayRequest.getPosReferenceNumber())
                    .withGratuity(TextUtils.isEmpty(tipFromPennies) ? BigDecimal.ZERO :
                            new BigDecimal(tipFromPennies))
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .withCurrency(PorticoCurrencyCodeType.USD.name());

            if (gatewayRequest.isSAFIndicator()) {
                builder = (ManagementBuilder)builder.withSAFIndicator(gatewayRequest.isSAFIndicator())
                        .withSAFOrigDT(gatewayRequest.getSAFOrigDT());
            }
            hostResponse = builder.execute();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    // Refund by Id
    private void handleRefundRequestById(@NonNull GatewayRequest gatewayRequest) {
        //PMW - Do not add client txn id as portico expects this to match like the gateway txn id
        Transaction hostResponse = null;
        String fromPennies =
                PorticoConversionHelper.fromPennies(
                        PorticoConversionHelper.getConvertedToString(gatewayRequest.getTotal()));

        String gatewayTransactionId = PorticoUtils.isOriginalTransactionIdValid() ?
                PorticoUtils.getOriginalTransactionIdCopy() :
                gatewayRequest.getGatewayTransactionId();

        try {
            ManagementBuilder builder = Transaction.fromId(gatewayTransactionId)
                    .refund(new BigDecimal(fromPennies))
                    .withCurrency(PorticoCurrencyCodeType.USD.name())
                    .withInvoiceNumber(gatewayRequest.getInvoiceNumber())
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .withClerkId(gatewayRequest.getOperatingUserId());
            if (gatewayRequest.isSAFIndicator()) {
                builder = (ManagementBuilder)builder.withSAFIndicator(gatewayRequest.isSAFIndicator())
                        .withSAFOrigDT(gatewayRequest.getSAFOrigDT());
            }
            hostResponse = builder.execute();

            PorticoUtils.resetOriginalTransactionIdCopy();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    /**
     * Performs the reversal request of the transactionId from {@link TransactionSummary}. After the reversal is done
     * tip amount will be added back if the transaction is captured and tip is not included in the reversal request.
     *
     * @param reversalAmount      This contains the amount to be reversed.
     * @param summary             Contains the transaction details of transactionId from {@link GatewayRequest}. This
     *                            details will be replace by the original transaction details if it is captured.
     * @param isTransactionEdited Is set to true if the transaction is captured and edited to negate the tip amount from
     *                            the original transaction or else set to false.
     */
    // Reversal
    private void handleReversalRequest(@NonNull GatewayRequest gatewayRequest,
            @Nullable BigDecimal reversalAmount, @NonNull TransactionSummary summary,
            boolean isTransactionEdited) {
        //PMW - Do not add client txn id as portico expects this to match like the gateway txn id
        Transaction hostResponse = null;
        try {
            ManagementBuilder builder = PorticoModelConverter.toReversalRequest(
                    gatewayRequest, reversalAmount, summary);

            builder = builder.withCurrency(PorticoCurrencyCodeType.USD.name())
                    .withInvoiceNumber(gatewayRequest.getInvoiceNumber())
                    .withPosSequenceNumber(gatewayRequest.getPosReferenceNumber())
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .withClerkId(gatewayRequest.getOperatingUserId());
            if (gatewayRequest.isSAFIndicator()) {
                builder = (ManagementBuilder)builder.withSAFIndicator(gatewayRequest.isSAFIndicator())
                        .withSAFOrigDT(gatewayRequest.getSAFOrigDT());
            }
            hostResponse = builder.execute();

            PorticoUtils.resetOriginalTransactionIdCopy();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                if (shouldAddTipBack(gatewayRequest, isTransactionEdited, response)) {
                    addTipBack(gatewayRequest, summary, builder.getAuthAmount(), response);
                } else {
                    callbackOnGatewayResponse(response);
                }
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    /**
     * For Portico we negate the adjusted tip before the reversal is processed, so the negated tip must be added back if
     * the user not requested for the tip reversal or the reversal failed for some reason.
     *
     * @return true for partial reversals if tip is adjusted and the request does not contain the tip reversal or
     * reversal fails and tip is adjusted.
     */
    private boolean shouldAddTipBack(@NonNull GatewayRequest request, boolean isTransactionEdited,
            GatewayResponse response) {
        return (request.getGatewayAction() != GatewayAction.VOID &&
                (request.getTip() != null && request.getTip() == 0) && isTransactionEdited) ||
                (!response.isApproved() && isTransactionEdited);
    }

    /**
     * For partial reversal of a tip adjusted transactions, if the tip amount is not included in the reversal amount, it
     * should be added back to the balance amount.
     *
     * @param balanceAmount Balance amount of the transaction after the partial reversal.
     */
    private void addTipBack(@NonNull GatewayRequest gatewayRequest,
            @NonNull TransactionSummary summary, @NonNull BigDecimal balanceAmount,
            GatewayResponse reversalResponse) {
        String addTipErrorMessage = "Unable to edit transaction to add tip back after reversal. ";

        Transaction hostResponse = null;

        try {
            hostResponse = Transaction.fromId(summary.getTransactionId())
                    .edit()
                    .withGratuity(summary.getGratuityAmount())
                    .withAmount(balanceAmount.add(summary.getGratuityAmount()))
                    .withCurrency(PorticoCurrencyCodeType.USD.name())
                    .execute();

            if (hostResponse != null) {
                GatewayResponse addTipResponse =
                        PorticoModelConverter.toGatewayResponse(gatewayRequest, hostResponse);
                if (addTipResponse.isApproved()) {
                    callbackOnGatewayResponse(reversalResponse);
                } else {
                    Timber.w("isReversalApproved: %s. Could not add tip back",
                            reversalResponse.isApproved());

                    addTipResponse.setGatewayResponseText(
                            addTipErrorMessage + addTipResponse.getGatewayResponseText());
                    callbackOnGatewayResponse(addTipResponse);
                }
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(),
                        addTipErrorMessage + HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(
                    e,
                    hostResponse,
                    addTipErrorMessage +
                            getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse,
                    addTipErrorMessage + e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), addTipErrorMessage);
        }
    }

    // Refund by card
    private void handleRefundByCardRequest(@NonNull GatewayRequest gatewayRequest) {
        Transaction hostResponse = null;
        Credit hostRequest = PorticoModelConverter.toRefundRequest(gatewayRequest);
        String fromPennies =
                PorticoConversionHelper.fromPennies(
                        PorticoConversionHelper.getConvertedToString(gatewayRequest.getTotal()));

        String gatewayTransactionId = PorticoUtils.isOriginalTransactionIdValid() ?
                PorticoUtils.getOriginalTransactionIdCopy() :
                gatewayRequest.getGatewayTransactionId();

        String clientTransactionId = getClientTransactionId(gatewayRequest);

        try {
            AuthorizationBuilder builder = hostRequest.refund(new BigDecimal(fromPennies));
            if (!TextUtils.isEmpty(gatewayTransactionId)) {
                builder = builder.withTransactionId(gatewayTransactionId);
            }

            CardData cardData = gatewayRequest.getCardData();
            if (cardData != null) {
                CardDataSourceType type = cardData.getCardDataSource();
                if (type != null) {
                    if (CardDataSourceType.FALLBACK == type) {
                        builder.withChipCondition(EmvChipCondition.ChipFailPreviousSuccess);
                    } else if (CardDataSourceType.SCR == type
                            || CardDataSourceType.CONTACTLESS_EMV == type
                            || CardDataSourceType.CONTACTLESS_MSR == type) {
                        builder.withTagData(
                                TlvUtils.getIccDataString(
                                        gatewayRequest.getCardData().getEmvTlvData()));
                    }
                }
            }

            builder = builder.withCurrency(PorticoCurrencyCodeType.USD.name())
                    .withInvoiceNumber(gatewayRequest.getInvoiceNumber())
                    .withClientTransactionId(clientTransactionId)
                    .withPosSequenceNumber(gatewayRequest.getPosReferenceNumber())
                    .withClerkId(gatewayRequest.getOperatingUserId())
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .withCustomerData(gatewayRequest.getCustomer() != null ?
                            PorticoConversionHelper
                                    .buildCustomerData(gatewayRequest.getCustomer()) : null);
            if (gatewayRequest.isSAFIndicator()) {
                builder = (AuthorizationBuilder)builder.withSAFIndicator(gatewayRequest.isSAFIndicator())
                        .withSAFOrigDT(gatewayRequest.getSAFOrigDT());
            }
            hostResponse = builder.execute();

            PorticoUtils.resetOriginalTransactionIdCopy();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    // Void
    private void handleVoidRequest(@NonNull GatewayRequest gatewayRequest) {
        //PMW - Do not add client txn id as portico expects this to match like the gateway txn id
        Transaction hostResponse = null;

        String gatewayTransactionId = PorticoUtils.isOriginalTransactionIdValid() ?
                PorticoUtils.getOriginalTransactionIdCopy() :
                gatewayRequest.getGatewayTransactionId();

        try {
            ManagementBuilder builder = Transaction.fromId(gatewayTransactionId)
                    .voidTransaction()
                    .withCurrency(PorticoCurrencyCodeType.USD.name())
                    .withPosSequenceNumber(gatewayRequest.getPosReferenceNumber())
                    .withInvoiceNumber(gatewayRequest.getInvoiceNumber())
                    .withUniqueDeviceId(getUniqueDeviceId(gatewayRequest))
                    .withClerkId(gatewayRequest.getOperatingUserId());
            if (gatewayRequest.isSAFIndicator()) {
                builder = (ManagementBuilder)builder.withSAFIndicator(gatewayRequest.isSAFIndicator())
                        .withSAFOrigDT(gatewayRequest.getSAFOrigDT());
            }
            hostResponse = builder.execute();

            PorticoUtils.resetOriginalTransactionIdCopy();

            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                        mGatewayRequest, hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    hostResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, hostResponse, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    /**
     * Portico doesn't allow reversals or voids of the original auth, if the captured amount is greater than $0 and if
     * the batch is still open. This workaround negates the captured amount and then attempts to reverse the original
     * auth.
     */
    // Edit transaction
    private void editTransaction(@NonNull GatewayRequest gatewayRequest,
            @NonNull TransactionSummary summary) {
        Transaction editTransactionResponse = null;

        String requestReversalAmount = PorticoConversionHelper.fromPennies(
                PorticoConversionHelper.getConvertedToString(gatewayRequest.getTotal()));

        BigDecimal settledAmountWithoutTip =
                summary.getSettlementAmount().subtract(summary.getGratuityAmount());

        if (gatewayRequest.getGatewayAction() == GatewayAction.VOID) {
            requestReversalAmount = summary.getAuthorizedAmount().toString();
        } else if (gatewayRequest.getTip() != null && gatewayRequest.getTip() > 0) {
            Long requestedReversalAmountWithoutTip =
                    gatewayRequest.getTotal() - gatewayRequest.getTip();
            // Partial reversal with tip included in the reversal amount
            requestReversalAmount = PorticoConversionHelper.fromPennies(PorticoConversionHelper
                    .getConvertedToString(requestedReversalAmountWithoutTip));
        }

        try {
            // Edit call
            editTransactionResponse = Transaction.fromId(summary.getTransactionId())
                    .edit()
                    .withGratuity(BigDecimal.ZERO)
                    .withAmount(settledAmountWithoutTip)
                    .withCurrency(PorticoCurrencyCodeType.USD.name())
                    .execute();

            if (editTransactionResponse != null) {
                if (TRANSACTION_APPROVED
                        .equalsIgnoreCase(editTransactionResponse.getResponseMessage())) {
                    summary.setSettlementAmount(settledAmountWithoutTip);
                    // Reverse the amount after negating the gratuity amount from the settlement
                    // amount
                    handleReversalRequest(gatewayRequest, new BigDecimal(requestReversalAmount),
                            summary,
                            true);
                } else {
                    GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                            mGatewayRequest, editTransactionResponse);
                    callbackOnGatewayResponse(response);
                }
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e,
                    editTransactionResponse,
                    getGatewayExceptionMessage(e.getResponseText(), e.getMessage()),
                    null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, editTransactionResponse, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    // Batch close
    private void handleBatchCloseRequest(GatewayRequest gatewayRequest) {
        try {
            Transaction hostResponse =
                    new ManagementBuilder(TransactionType.BatchClose).execute();
            if (hostResponse != null) {
                GatewayResponse response = PorticoModelConverter.toGatewayResponse(hostResponse);
                callbackOnGatewayResponse(response);
            } else {
                broadcastGatewayError(GatewayAction.BATCH_CLOSE, HOST_NOT_AVAILABLE);
            }
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            buildAndDispatchGatewayException("Error processing request");
        }
    }
    // endregion

    // region Transaction responses
    private void callbackOnGatewayResponse(@NonNull GatewayResponse gatewayResponse) {
        mGatewayRequest = null;
        mGatewayListener.onGatewayResponse(gatewayResponse);
    }

    private void buildAndDispatchGatewayException(@NonNull Exception e,
            @Nullable Transaction hostResponse, @NonNull String errorMessage,
            @Nullable CardDataSourceType type) {
        GatewayResponse response =
                PorticoModelConverter.toGatewayResponse(mGatewayRequest, hostResponse);

        if (e.getCause() instanceof IOException && type == CardDataSourceType.SCR) {
                /* If there is an issue with the connection, the transaction should be considered
                   unable to go online. */
            response.setEmvIssuerAuthCode(EMV_RESPONSE_CODE_UNABLE_TO_GO_ONLINE);
        }
        response.setError(true);
        response.setSafError(e instanceof GatewayException ? false : true);
        response.setErrorMessage(errorMessage);
        callbackOnGatewayResponse(response);
    }

    private void buildAndDispatchGatewayException(@NonNull String errorMessage) {
        GatewayResponse response = new GatewayResponse(GatewayAction.BATCH_CLOSE);
        response.setError(true);
        response.setSafError(true);
        response.setErrorMessage(errorMessage);
        callbackOnGatewayResponse(response);
    }

    private void broadcastGatewayError(GatewayAction action, String s) {
        GatewayResponse gatewayResponse = new GatewayResponse(action);
        gatewayResponse.setError(true);
        gatewayResponse.setSafError(false);
        gatewayResponse.setErrorMessage(s);
        callbackOnGatewayResponse(gatewayResponse);
    }
    //endregion

    // region Utils

    /**
     * Checks the status of the transaction based on the transaction id and performs one of the following actions {@link
     * GatewayAction#VOID} {@link GatewayAction#REFUND} {@link GatewayAction#PARTIAL_REFUND}
     */
    private void getTransactionStatusAndPerformAction(@NonNull GatewayRequest gatewayRequest) {
        if (TextUtils.isEmpty(gatewayRequest.getGatewayTransactionId())) {
            handleRefundByCardRequest(gatewayRequest);
            return;
        }

        TransactionSummary summary;
        try {
            summary =
                    ReportingService.transactionDetail(gatewayRequest.getGatewayTransactionId())
                            .execute();

            if (summary != null) {
                // Attempting to refund an auth that has been finalized.
                if (TRANSACTION_TYPE_CAPTURE.equalsIgnoreCase(summary.getServiceName())) {
                    PorticoUtils.setOriginalTransactionIdCopy(summary.getOriginalTransactionId());
                    if (PorticoUtils.isOriginalTransactionIdValid()) {
                        getParentTransactionSummary(gatewayRequest);
                    } else {
                        // This should never occur but in case it does perform an action based on
                        // the transaction status
                        performActionBasedOnTransactionStatus(gatewayRequest, summary, true);
                    }
                } else {
                    performActionBasedOnTransactionStatus(gatewayRequest, summary, false);
                }
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e, null, e.getResponseText(), null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, null, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    private void getParentTransactionSummary(@NonNull GatewayRequest gatewayRequest) {
        TransactionSummary summary;
        try {
            summary = ReportingService.transactionDetail(
                    PorticoUtils.getOriginalTransactionIdCopy()).execute();

            if (summary != null) {
                performActionBasedOnTransactionStatus(gatewayRequest, summary, true);
            } else {
                broadcastGatewayError(gatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (GatewayException e) {
            buildAndDispatchGatewayException(e, null, e.getResponseText(), null);
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, null, e.getMessage(), null);
        } catch (Exception e) {
            // Handle unexpected exceptions from the portico wrapper
            broadcastGatewayError(gatewayRequest.getGatewayAction(), "Error processing request");
        }
    }

    private void performActionBasedOnTransactionStatus(@NonNull GatewayRequest gatewayRequest,
            @NonNull TransactionSummary summary, boolean isCaptured) {
        String transactionStatus = summary.getTransactionStatus();
        if (!TextUtils.isEmpty(transactionStatus)) {
            if (TRANSACTION_STATUS_ACTIVE.equalsIgnoreCase(transactionStatus)) {
                // Open batch
                if (summary.getGratuityAmount().compareTo(BigDecimal.ZERO) > 0 && isCaptured) {
                    editTransaction(gatewayRequest, summary);
                } else if (summary.getServiceName().equalsIgnoreCase("creditReturn")
                        && gatewayRequest.getGatewayAction() == GatewayAction.VOID) {
                    //If the previous transaction was a CreditReturn and the batch is still open
                    // now we want to void the creditReturn.
                    handleVoidRequest(gatewayRequest);
                } else {
                    String totalFromPennies = PorticoConversionHelper.fromPennies(
                            PorticoConversionHelper
                                    .getConvertedToString(gatewayRequest.getTotal()));
                    // Original authorized amount will always be greater than the partially
                    // requested reversal amount
                    if ((summary.getSettlementAmount()
                            .compareTo(summary.getAuthorizedAmount()) != 0)
                            && (summary.getSettlementAmount().compareTo(BigDecimal.ZERO) > 0)
                            && ((gatewayRequest.getGatewayAction() == GatewayAction.REFUND)
                            || (gatewayRequest.getGatewayAction() == GatewayAction.PARTIAL_REFUND))) {
                        handleRefundRequestById(gatewayRequest);
                    } else if (summary.getAuthorizedAmount()
                            .compareTo(new BigDecimal(totalFromPennies)) >= 0) {
                        handleReversalRequest(gatewayRequest, null, summary, false);
                    } else {
                        broadcastGatewayError(gatewayRequest.getGatewayAction(), "Invalid amount");
                    }
                }
            } else if (TRANSACTION_STATUS_CLEARED.equalsIgnoreCase(transactionStatus)) {
                handleRefundRequestById(gatewayRequest);
            } else {
                handleVoidRequest(gatewayRequest);
            }
        } else {
            broadcastGatewayError(gatewayRequest.getGatewayAction(),
                    "Invalid transaction status");
        }
    }

    private void fetchTransactionByClientTransactionId(@NonNull String clientTransactionId) {
        try {
            TransactionSummaryList summary = ReportingService.findTransactions()
                    .where(SearchCriteria.ClientTransactionId, clientTransactionId)
                    .execute();
            if (summary != null) {
                TransactionSummary hostResponse = summary.get(0);
                if (hostResponse != null) {
                    GatewayResponse response = PorticoModelConverter.toGatewayResponse(
                            mGatewayRequest, hostResponse);
                    callbackOnGatewayResponse(response);
                } else {
                    broadcastGatewayError(mGatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
                }
            } else {
                broadcastGatewayError(mGatewayRequest.getGatewayAction(), HOST_NOT_AVAILABLE);
            }
        } catch (ApiException e) {
            buildAndDispatchGatewayException(e, null, e.getMessage(), null);
        }
    }

    private void handleUnsupportedGatewayAction() {
        GatewayAction unsupportedAction = mGatewayRequest.getGatewayAction();
        switch (unsupportedAction) {
            case TRANSACTION_ADJUSTMENT:
            case TOKENIZE_CARD:
            case BALANCE_INQUIRY:
            default:
                Timber.e("action [" + unsupportedAction +
                        "] not supported.");
                broadcastGatewayError(unsupportedAction, "Action Not Supported.");
                break;
        }
    }

    boolean isKeyedCardNotPresentTransaction(CardDataSourceType type) {
        return type == CardDataSourceType.PHONE
                || type == CardDataSourceType.MAIL
                || type == CardDataSourceType.INTERNET;
    }

    private void setEcommerceIndicator(AuthorizationBuilder builder, CardDataSourceType inputType) {
        if (isKeyedCardNotPresentTransaction(inputType)) {
            EcommerceInfo ecom = new EcommerceInfo();
            ecom.setChannel(EcommerceChannel.Moto);
            builder.withEcommerceInfo(ecom);
        }
    }

    /**
     * @return error message that originates from either the portico host or the underlying wrapper
     */
    private String getGatewayExceptionMessage(@Nullable String responseText,
            @Nullable String detailedMessage) {
        if (!TextUtils.isEmpty(responseText)) {
            return responseText;
        } else {
            if (!TextUtils.isEmpty(detailedMessage)) {
                return detailedMessage;
            }
        }
        return "Unknown Gateway Error";
    }
    // endregion

    private static String getUniqueDeviceId(GatewayRequest gatewayRequest) {
        //return null if no terminal info
        if (gatewayRequest.getTerminalInfo() == null) {
            return null;
        }
        //return null if no serial number
        if (gatewayRequest.getTerminalInfo().getSerialNumber() == null) {
            return null;
        }
        //return null if serial isn't long enough
        if (gatewayRequest.getTerminalInfo().getSerialNumber().length() < 4) {
            return null;
        }
        String serial = gatewayRequest.getTerminalInfo().getSerialNumber();
        String last4 = serial.substring(serial.length() - 4);
        return last4;
    }
}
