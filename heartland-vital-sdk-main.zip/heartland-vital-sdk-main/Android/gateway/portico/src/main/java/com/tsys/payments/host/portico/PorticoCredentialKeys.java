package com.tsys.payments.host.portico;

public class PorticoCredentialKeys {
    static final String SECRET_API_KEY = "secret_api_key";
    static final String VERSION_NUMBER = "version_number";
    static final String DEVELOPER_ID = "developer_id";
    static final String SITE_ID = "site_id";
    static final String LICENSE_ID = "license_id";
    static final String DEVICE_ID = "terminal_id";
    static final String USER_NAME = "user_name";
    static final String PASSWORD = "password";
}
