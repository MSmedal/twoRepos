package com.tsys.payments.host.portico;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.global.api.builders.ManagementBuilder;
import com.global.api.entities.AdditionalDuplicateData;
import com.global.api.entities.Transaction;
import com.global.api.entities.TransactionSummary;
import com.global.api.paymentMethods.Credit;
import com.global.api.paymentMethods.TransactionReference;
import com.tsys.payments.host.portico.utils.PorticoUtils;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.tlv.ConstructedTlvObject;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.Tag;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvObjectBuilder;
import com.tsys.payments.library.tlv.TlvUtils;
import com.tsys.payments.library.utils.ByteUtils;
import com.tsys.payments.library.utils.CreditCardHelper;
import java.math.BigDecimal;
import java.util.List;

import timber.log.Timber;

class PorticoModelConverter {
    private static final String TAG = PorticoModelConverter.class.getSimpleName();
    private static final String EMV_ISSUER_RESPONSE_APPROVAL_CODE = "00";
    private static final String EMV_ISSUER_RESPONSE_PARTIAL_APPROVAL_CODE = "10";
    private static final String EMV_ISSUER_RESPONSE_HONOR_WITH_IDENTIFICATION_CODE = "08";
    private static final String EMV_ISSUER_RESPONSE_DENIAL_CODE = "05";

    private PorticoModelConverter() {
        // No instance
    }

    // region Requests
    static Credit toSaleAuthRequest(@NonNull GatewayRequest request) {
        if (TextUtils.isEmpty(request.getToken())) {
            // Card data
            return PorticoConversionHelper.populateCardData(request);
        } else {
            // Token data
            return PorticoConversionHelper.populateTokenData(request);
        }
    }

    static Credit toVerifyRequest(@NonNull GatewayRequest request) {
        return PorticoConversionHelper.populateCardData(request);
    }

    @NonNull
    static Credit toRefundRequest(@NonNull GatewayRequest request) {
        return PorticoConversionHelper.populateCardData(request);
    }

    @NonNull
    static ManagementBuilder toReversalRequest(@NonNull GatewayRequest gatewayRequest,
            @Nullable BigDecimal reversalAmount, @NonNull TransactionSummary summary) {
        ManagementBuilder builder;
        BigDecimal total;

        if (reversalAmount == null) {
            if (gatewayRequest.getGatewayAction() == GatewayAction.VOID) {
                total = summary.getAuthorizedAmount();
            } else {
                String fromPennies =
                        PorticoConversionHelper.fromPennies(
                                PorticoConversionHelper
                                        .getConvertedToString(gatewayRequest.getTotal()));
                total = new BigDecimal(fromPennies);
            }
        } else {
            total = reversalAmount;
        }

        String gatewayTransactionId = PorticoUtils.isOriginalTransactionIdValid() ?
                PorticoUtils.getOriginalTransactionIdCopy() :
                gatewayRequest.getGatewayTransactionId();

        boolean isPartialVoid = gatewayRequest.getGatewayAction() == GatewayAction.VOID
                && total.longValue() < summary.getAuthorizedAmount().longValue();

        // For partial reversals portico requires the partial amount
        if (gatewayRequest.getGatewayAction() == GatewayAction.REFUND ||
                gatewayRequest.getGatewayAction() == GatewayAction.PARTIAL_REFUND
                || isPartialVoid) {
            // Partial amount reversal
            builder =
                    Transaction.fromId(gatewayTransactionId).reverse(summary.getAuthorizedAmount());
            BigDecimal adjustedAuthAmount = summary.getSettlementAmount().subtract(total);
            builder.withAuthAmount(adjustedAuthAmount);
        } else {
            // Full amount reversal
                builder = Transaction.fromId(gatewayTransactionId).reverse(total);
        }

        if (gatewayRequest.getCardData() != null &&
                gatewayRequest.getCardData().getCardDataSource() != null &&
                gatewayRequest.getCardData().getCardDataSource() == CardDataSourceType.SCR) {
            PorticoConversionHelper.populateCardData(gatewayRequest);
            builder.withTagData(
                    TlvUtils.getIccDataString(gatewayRequest.getCardData().getEmvTlvData()));
        }
        return builder;
    }
    // endregion

    // region Responses
    static GatewayResponse toGatewayResponse(@NonNull GatewayRequest request,
            @Nullable Transaction hostResponse) {
        // TODO: Continue to build more fields - Pending: tax
        GatewayResponse gatewayResponse = new GatewayResponse(request.getGatewayAction());

        // Host response
        if (hostResponse != null) {
            updateResponseApproval(hostResponse, gatewayResponse);
            gatewayResponse.setGatewayTimeout(
                    PorticoConversionHelper.isGatewayTimeout(hostResponse.getResponseCode()));
            // Token
            gatewayResponse.setToken(hostResponse.getToken());
            // Card Brand Transaction ID
            gatewayResponse.setCardBrandTxnId(hostResponse.getCardBrandTransactionId());

            if (gatewayResponse.isApproved()) {
                // We are in presence of a partial transaction
                if (hostResponse.getAuthorizedAmount() != null) {
                    String toPennies =
                            PorticoConversionHelper.toPennies(
                                    hostResponse.getAuthorizedAmount().toString());

                    gatewayResponse.setApprovedAmount(
                            PorticoConversionHelper.getConvertedToLong(toPennies));
                } else {
                    // Portico does not return approved amount unless partial transaction is in place
                    gatewayResponse.setApprovedAmount(request.getTotal());
                    gatewayResponse.setTipAmount(request.getTip());
                }
            }
            // Emv Data
            TlvObject issuerAuthData = null;
            if (hostResponse.getEmvIssuerResponse() != null) {
                issuerAuthData = getIssuerAuthData(hostResponse.getEmvIssuerResponse(),
                        gatewayResponse);
            }

            String emvIssuerResponseCode =
                    getEmvIssuerResponseCode(request,
                            hostResponse.getResponseCode(),
                            issuerAuthData);

            if (!TextUtils.isEmpty(emvIssuerResponseCode)) {
                gatewayResponse.setEmvIssuerAuthCode(emvIssuerResponseCode);
            }

            gatewayResponse.setGatewayResponseCode(hostResponse.getResponseCode());
            gatewayResponse.setPosReferenceId(PorticoUtils.getMostRecentClientTransactionId());

            TransactionReference transactionReference = hostResponse.getTransactionReference();
            if (transactionReference != null) {
                gatewayResponse.setAuthCode(transactionReference.getAuthCode());
                gatewayResponse.setGatewayTransactionId(transactionReference.getTransactionId());
            } else {
                Timber.d("Invalid transaction reference.Could not build full gateway response");
                gatewayResponse.setErrorMessage("Invalid transaction reference received from host");
            }

            AdditionalDuplicateData additionalDuplicateData = hostResponse.getAdditionalDuplicateData();
            if (additionalDuplicateData != null) {
                gatewayResponse.setOriginalGatewayTxnId(additionalDuplicateData.getOriginalGatewayTxnId());
                gatewayResponse.setOriginalRspDT(additionalDuplicateData.getOriginalRspDT());
                gatewayResponse.setOriginalClientTxnId(additionalDuplicateData.getOriginalClientTxnId());
                gatewayResponse.setOriginalAuthCode(additionalDuplicateData.getOriginalAuthCode());
                gatewayResponse.setOriginalRefNbr(additionalDuplicateData.getOriginalRefNbr());
                gatewayResponse.setOriginalCardType(additionalDuplicateData.getOriginalCardType());
                gatewayResponse.setOriginalCardNbrLast4(additionalDuplicateData.getOriginalCardNbrLast4());

                String toPennies =
                        PorticoConversionHelper.toPennies(
                                additionalDuplicateData.getOriginalAuthAmt().toString());
                gatewayResponse.setOriginalAuthAmt(
                        PorticoConversionHelper.getConvertedToLong(toPennies));
            }
        }
        // Card data
        buildCardDataGatewayResponse(request, gatewayResponse);
        return gatewayResponse;
    }

    static GatewayResponse toGatewayResponse(@NonNull GatewayRequest request,
            @Nullable TransactionSummary hostResponse) {
        // TODO: Continue to build more fields - Pending: tax
        GatewayResponse gatewayResponse = new GatewayResponse(request.getGatewayAction());

        // Host response
        if (hostResponse != null) {
            updateResponseApproval(hostResponse, gatewayResponse);

            if (gatewayResponse.isApproved()) {
                // We are in presence of a partial approval
                if (hostResponse.getAuthorizedAmount() != null) {
                    gatewayResponse
                            .setApprovedAmount(hostResponse.getAuthorizedAmount().longValue());
                } else {
                    // Portico does not return approved amount unless partial approval is in place
                    gatewayResponse.setApprovedAmount(request.getTotal());
                    gatewayResponse.setTipAmount(request.getTip());
                }
            }
            // Emv Data
            TlvObject issuerAuthData = null;
            if (hostResponse.getEmvIssuerResponse() != null) {
                issuerAuthData = getIssuerAuthData(hostResponse.getEmvIssuerResponse(),
                        gatewayResponse);
            }

            String emvIssuerResponseCode =
                    getEmvIssuerResponseCode(request,
                            hostResponse.getIssuerResponseCode(),
                            issuerAuthData);

            if (!TextUtils.isEmpty(emvIssuerResponseCode)) {
                gatewayResponse.setEmvIssuerAuthCode(emvIssuerResponseCode);
            }
            gatewayResponse.setAuthCode(hostResponse.getAuthCode());
            gatewayResponse.setGatewayTransactionId(hostResponse.getTransactionId());
            gatewayResponse.setPosReferenceId(PorticoUtils.getMostRecentClientTransactionId());
        }
        // Card data
        buildCardDataGatewayResponse(request, gatewayResponse);
        return gatewayResponse;
    }

    private static TlvObject getIssuerAuthData(@NonNull String emvIssuerResponse,
            @NonNull GatewayResponse gatewayResponse) {
        TlvObject issuerAuthData = null;

        List<TlvObject> tlvObjectList =
                ConstructedTlvObject.parse(emvIssuerResponse);

        for (TlvObject object : tlvObjectList) {
            if (object.getTagDescriptor() == EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_1 ||
                    object.getTagDescriptor() ==
                            EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_2) {
                gatewayResponse.setEmvIssuerScripts(object.asHexString());
            }
            // EMV auth code
            if (object.getTagDescriptor() == EmvTagDescriptor.AUTHORIZATION_RESPONSE_CODE) {
                gatewayResponse.setEmvIssuerAuthCode(object.asHexString());
            }
            // Emv issuer auth data
            if (object.getTagDescriptor() == EmvTagDescriptor.ISSUER_AUTHENTICATION_DATA) {
                gatewayResponse.setEmvIssuerAuthenticationData(object.asHexString());
                issuerAuthData = object;
            }
        }
        return issuerAuthData;
    }

    @Nullable
    private static String getEmvIssuerResponseCode(@NonNull GatewayRequest gatewayRequest,
            @Nullable String responseCode, @Nullable TlvObject issuerAuthData) {
        Timber.d(
                "getEmvIssuerResponseCode() called with: gatewayRequest=[%s],responseCode=[%s],issuerAuthData=[%s]",
                gatewayRequest, responseCode, issuerAuthData);
        CardData cardData = gatewayRequest.getCardData();

        if (cardData != null) {
            if (!TextUtils.isEmpty(cardData.getPan())) {
                CardType cardType = CreditCardHelper.typeFromPan(cardData.getPan());

                if (cardType == CardType.AMERICAN_EXPRESS) {
                /* For AMEX cards, the EMV issuer response code must be taken from the last 2 bytes
                   of Tag 91 if present. */
                    if (issuerAuthData != null) {
                        String issuerHex = issuerAuthData.asHexString();
                        if (issuerHex != null && issuerHex.length() >= 4) {
                            byte[] issuerHexBytes = ByteUtils
                                    .hexStringToByteArray(
                                            issuerHex.substring(issuerHex.length() - 4));
                            if (issuerHexBytes != null) {
                                TlvObjectBuilder builder = TlvObjectBuilder.create(Tag
                                        .fromTagDescriptor(
                                                EmvTagDescriptor.AUTHORIZATION_RESPONSE_CODE))
                                        .setValue(issuerHexBytes);
                                return builder.build().asHexString();
                            }
                        }
                    }
                }
            } else {
                Timber.w("Card type cannot be determined due to missing PAN.");
            }
        }

        /* In the absence of Tag 91 for AMEX, or in general for all other card brands, the EMV
           issuer response code is just the HEX value of the <RespCode> field of the gateway
           response. */
        if (!TextUtils.isEmpty(responseCode)) {
            TlvObjectBuilder builder = TlvObjectBuilder.create(Tag
                    .fromTagDescriptor(
                            EmvTagDescriptor.AUTHORIZATION_RESPONSE_CODE));
            if (!responseCode.equals(EMV_ISSUER_RESPONSE_APPROVAL_CODE) &&
                    !responseCode.equals(EMV_ISSUER_RESPONSE_PARTIAL_APPROVAL_CODE) &&
                    !responseCode.equals(EMV_ISSUER_RESPONSE_HONOR_WITH_IDENTIFICATION_CODE)) {
                // All decline codes must be set to "05"(HEX 3035)
                builder.setValue(EMV_ISSUER_RESPONSE_DENIAL_CODE.getBytes());
            } else {
                builder.setValue(EMV_ISSUER_RESPONSE_APPROVAL_CODE.getBytes());
            }
            return builder.build().asHexString();
        }
        return null;
    }

    private static void buildCardDataGatewayResponse(@NonNull GatewayRequest request,
            @NonNull GatewayResponse gatewayResponse) {
        if (request != null) {
            CardData cardData = request.getCardData();
            if (cardData != null) {
                if (!TextUtils.isEmpty(cardData.getPan())) {
                    gatewayResponse.setMaskedPan(cardData.getPan());
                    gatewayResponse.setCardType(CreditCardHelper.typeFromPan(cardData.getPan()));
                } else if (cardData.getEmvTlvData() != null) {
                    for (TlvObject tlvObject : cardData.getEmvTlvData()) {
                        if (tlvObject != null &&
                                tlvObject.getTagDescriptor() == EmvTagDescriptor.PAN) {
                            if (!TextUtils.isEmpty(tlvObject.getValueAsHexString(false))) {
                                gatewayResponse.setMaskedPan(tlvObject.getValueAsHexString(false));
                                gatewayResponse.setCardType(
                                        CreditCardHelper
                                                .typeFromPan(tlvObject.getValueAsHexString(false)));
                                break;
                            }
                        }
                    }
                }
                gatewayResponse.setCardDataSourceType(cardData.getCardDataSource());
            }
        }
    }

    static GatewayResponse toGatewayResponse(@NonNull Transaction transaction) {
        GatewayResponse gatewayResponse = new GatewayResponse(GatewayAction.BATCH_CLOSE);
        updateResponseApproval(transaction, gatewayResponse);
        return gatewayResponse;
    }

    private static void updateResponseApproval(@NonNull Transaction hostResponse,
            @NonNull GatewayResponse gatewayResponse) {
        if (gatewayResponse.getGatewayAction() == GatewayAction.CAPTURE ||
                gatewayResponse.getGatewayAction() == GatewayAction.TIP_ADJUST ||
                gatewayResponse.getGatewayAction() == GatewayAction.BATCH_CLOSE) {
            gatewayResponse.setApproved(
                    PorticoConversionHelper.isGatewayApproved(hostResponse.getResponseMessage()));
        } else if (gatewayResponse.getGatewayAction() == GatewayAction.VERIFY) {
            gatewayResponse.setApproved(
                    PorticoConversionHelper.isVerifyApproved(hostResponse.getResponseMessage()));
        } else {
            gatewayResponse.setApproved(PorticoConversionHelper
                    .isTransactionApproved(hostResponse.getResponseMessage()));
        }
        gatewayResponse.setGatewayResponseText(hostResponse.getResponseMessage());
    }

    private static void updateResponseApproval(@NonNull TransactionSummary hostResponse,
            @NonNull GatewayResponse gatewayResponse) {
        gatewayResponse.setApproved(PorticoConversionHelper
                .isTransactionApproved(hostResponse.getIssuerResponseMessage()));
        gatewayResponse.setGatewayResponseText(hostResponse.getIssuerResponseMessage());
    }

    // endregion
}
