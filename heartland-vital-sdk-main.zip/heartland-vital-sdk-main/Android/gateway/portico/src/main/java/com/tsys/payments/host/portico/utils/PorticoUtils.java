package com.tsys.payments.host.portico.utils;

import android.text.TextUtils;
import android.util.Base64;

import com.global.api.entities.TransactionSummary;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.utils.ByteUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class PorticoUtils {
    private static String mOriginalTransactionIdCopy;
    private static String mMostRecentClientTransactionId;

    @Nullable
    public static String encodeHexStringToBase64(String hexString) {
        if (hexString == null) {
            return null;
        }

        byte[] bytes = ByteUtils.hexStringToByteArray(hexString);
        if (bytes == null) {
            return null;
        }

        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    @Nullable
    public static String decodeBase64ToHexString(String base64EncodedString) {
        if (base64EncodedString == null) {
            return null;
        }

        byte[] bytes = Base64.decode(base64EncodedString, Base64.NO_WRAP);

        return ByteUtils.bytesToHex(bytes, false);
    }

    private static long getDateGeneratedUniqueId() {
        return System.nanoTime();
    }

    /**
     * Locally generated client transaction id can be used as an alternate reference to retrieve
     * transactions from the Portico host.
     * This is useful in events where the host processes transactions but the client fails to
     * receive a response.
     */
    @NonNull
    public static String generateClientTransactionId() {
        return Long.toString(getDateGeneratedUniqueId());
    }

    public static void setMostRecentClientTransactionId(String clientTransactionId) {
        mMostRecentClientTransactionId = clientTransactionId;
    }

    public static String getMostRecentClientTransactionId() {
        return mMostRecentClientTransactionId;
    }

    public static String getOriginalTransactionIdCopy() {
        return mOriginalTransactionIdCopy;
    }

    public static void setOriginalTransactionIdCopy(String originalTransactionIdCopy) {
        mOriginalTransactionIdCopy = originalTransactionIdCopy;
    }

    public static void resetOriginalTransactionIdCopy() {
        mOriginalTransactionIdCopy = "";
    }

    /**
     * For non 'CreditAddToBatch' {@link TransactionSummary#getServiceName()} type
     * transactions, {@link TransactionSummary#getOriginalTransactionId() always returns 0}
     *
     * @return true if {@link #mOriginalTransactionIdCopy is greater than 0} in
     * {@link TransactionSummary#getOriginalTransactionId()}
     *
     */
    public static boolean isOriginalTransactionIdValid() {
        if (TextUtils.isEmpty(mOriginalTransactionIdCopy)) return false;
        try {
            int originalTransactionId = Integer.parseInt(mOriginalTransactionIdCopy);
            return originalTransactionId > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
