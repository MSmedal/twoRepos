package com.tsys.payments.host.portico.constants;

public class Constants {
    public static final String TEST_ENDPOINT = "https://cert.api2.heartlandportico.com";
    public static final String PRODUCTION_ENDPOINT = "https://api2.heartlandportico.com";
}
