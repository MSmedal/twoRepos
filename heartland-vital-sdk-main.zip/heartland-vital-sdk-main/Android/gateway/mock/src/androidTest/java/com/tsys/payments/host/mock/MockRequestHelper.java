package com.tsys.payments.host.mock;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

class MockRequestHelper {
    @NonNull
    static GatewayRequest getMockMsrAuthRequest(long amount, @Nullable Long tax,
            @Nullable Long tip) {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.AUTH);
        builder.setTotal(amount)
                .setTax(tax)
                .setTip(tip);
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);
        builder.setCardData(cardData);
        return builder.build();
    }

    @NonNull
    static GatewayRequest getMockMsrSaleRequest(long amount, @Nullable Long tax,
            @Nullable Long tip) {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.SALE);
        builder.setTotal(amount)
                .setTax(tax)
                .setTip(tip);
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);
        builder.setCardData(cardData);
        return builder.build();
    }

    @NonNull
    static GatewayRequest getMockEmvAuthRequest(long amount, @Nullable Long tax,
            @Nullable Long tip) {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.AUTH);
        builder.setTotal(amount)
                .setTax(tax)
                .setTip(tip);
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.SCR);
        builder.setCardData(cardData);
        return builder.build();
    }

    @NonNull
    static GatewayRequest getMockEmvSaleRequest(long amount, @Nullable Long tax,
            @Nullable Long tip) {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.SALE);
        builder.setTotal(amount)
                .setTax(tax)
                .setTip(tip);
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.SCR);
        builder.setCardData(cardData);
        return builder.build();
    }
}
