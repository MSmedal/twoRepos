package com.tsys.payments.host.mock;

import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;

import androidx.test.runner.AndroidJUnit4;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class MockGatewayControllerTest {
    private static final long TEST_EVEN_AMOUNT = 600;
    private static final long TEST_ODD_AMOUNT = 1109;

    private GatewayController mGatewayController;
    private ResponseHandler mResponseHandler;

    @Before
    public void setup() {
        mResponseHandler = new ResponseHandler();
        mGatewayController =
                new MockGatewayController(new GatewayConfiguration(), mResponseHandler);
    }

    @Test
    public void test_msrAuthEvenAmountApproved() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest request = MockRequestHelper.getMockMsrAuthRequest(TEST_EVEN_AMOUNT, 0L, 0L);
        mResponseHandler.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getAuthCode());
                latch.countDown();
            }
        });
        mGatewayController.sendRequest(request);

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_msrAuthOddAmountDeclined() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest request = MockRequestHelper.getMockMsrAuthRequest(TEST_ODD_AMOUNT, 0L, 0L);
        mResponseHandler.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                assertNotNull(response);
                assertFalse(response.isApproved());
                latch.countDown();
            }
        });
        mGatewayController.sendRequest(request);

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_msrSaleEvenAmountApproved() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest request = MockRequestHelper.getMockMsrSaleRequest(TEST_EVEN_AMOUNT, 0L, 0L);
        mResponseHandler.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getAuthCode());
                latch.countDown();
            }
        });
        mGatewayController.sendRequest(request);

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_msrSaleOddAmountDeclined() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest request = MockRequestHelper.getMockMsrSaleRequest(TEST_ODD_AMOUNT, 0L, 0L);
        mResponseHandler.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                assertNotNull(response);
                assertFalse(response.isApproved());
                latch.countDown();
            }
        });
        mGatewayController.sendRequest(request);

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_emvSaleEvenAmountApproved() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest request = MockRequestHelper.getMockEmvSaleRequest(TEST_EVEN_AMOUNT, 0L, 0L);
        mResponseHandler.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertNotNull(response.getEmvIssuerAuthCode());
                assertEquals(MockGatewayController.EMV_APPROVAL_RESPONSE_CODE,
                        response.getEmvIssuerAuthCode());
                assertNotNull(response.getAuthCode());
                latch.countDown();
            }
        });
        mGatewayController.sendRequest(request);

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_emvSaleOddAmountDeclined() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest request = MockRequestHelper.getMockEmvSaleRequest(TEST_ODD_AMOUNT, 0L, 0L);
        mResponseHandler.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                assertNotNull(response);
                assertFalse(response.isApproved());
                assertNotNull(response.getEmvIssuerAuthCode());
                assertEquals(MockGatewayController.EMV_DECLINE_RESPONSE_CODE,
                        response.getEmvIssuerAuthCode());
                latch.countDown();
            }
        });
        mGatewayController.sendRequest(request);

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private class ResponseHandler implements GatewayListener {

        private ResponseProcessor mResponseProcessor;

        public void setResponseProcessor(ResponseProcessor responseProcessor) {
            mResponseProcessor = responseProcessor;
        }

        @Override
        public void onGatewayResponse(GatewayResponse gatewayResponse) {
            mResponseProcessor.processResponse(gatewayResponse);
        }
    }

    private interface ResponseProcessor {
        void processResponse(GatewayResponse response);
    }
}
