package com.tsys.payments.host.mock;

import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayControllerFactory;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.enums.GatewayType;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MockGatewayControllerFactory implements GatewayControllerFactory {
    @Nullable
    @Override
    public GatewayType[] getSupportedGateways() {
        return new GatewayType[] {GatewayType.MOCK};
    }

    @Nullable
    @Override
    public TerminalType[] getSupportedTerminals() {
        return TerminalType.values();
    }

    @Nullable
    @Override
    public GatewayController create(@NonNull GatewayConfiguration gatewayConfiguration,
            @NonNull GatewayListener listener) throws InitializationException {
        return new MockGatewayController(gatewayConfiguration, listener);
    }
}
