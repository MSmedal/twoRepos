package com.tsys.payments.host.mock;

import android.os.Build;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.utils.CreditCardHelper;

import java.math.BigDecimal;
import java.math.RoundingMode;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

/**
 * Simulated payment gateway operating with the following rules for approving and declining transactions:
 *
 * <ul>
 *     <li>Approve all even number transaction amounts.</li>
 *     <li>Partially approve all amounts that are multiples of 11, a randomly chosen number.</li>
 *     <li>The check for partial approval occurs before the check for approval.</li>
 * </ul>
 * <p>
 * There is support for keyed, MSR and emv transactions.
 */
public class MockGatewayController implements GatewayController {
    static final String EMV_APPROVAL_RESPONSE_CODE = "8A023030";
    static final String EMV_DECLINE_RESPONSE_CODE = "8A023035";
    static final String EMV_UNABLE_TO_GO_ONLINE_RESPONSE_CODE = "8A025A33";
    /**
     * Partially approve amounts that are multiples of 11.
     */
    private static final long PARTIAL_APPROVAL_AMOUNT_FACTOR = 11;
    private static final String APPROVAL_AUTH_CODE = "APPRV123";

    @NonNull
    private GatewayListener mGatewayListener;
    @NonNull
    private GatewayConfiguration mGatewayConfiguration;
    @NonNull
    private GatewayRequest mGatewayRequest;
    @NonNull
    private GatewayResponse mGatewayResponse;

    MockGatewayController(@NonNull GatewayConfiguration hostConfig,
            @NonNull GatewayListener gatewayListener) {
        mGatewayListener = gatewayListener;
        mGatewayConfiguration = hostConfig;
    }

    @Override
    public void sendRequest(@NonNull GatewayRequest gatewayRequest) {
        mGatewayRequest = gatewayRequest;
        GatewayAction action = mGatewayRequest.getGatewayAction();
        if (isSupportedAction(action)) {
            handleAction(action);
            mGatewayListener.onGatewayResponse(mGatewayResponse);
        } else {
            mGatewayResponse = getErrorResponse(action,
                    String.format("Unsupported gateway action -> %s", action));
            mGatewayListener.onGatewayResponse(mGatewayResponse);
        }
    }

    private boolean isSupportedAction(@Nullable GatewayAction action) {
        Timber.d("isSupportedAction() called with action->%s", action);
        if (action == null) {
            Timber.e("No action specified");
            return false;
        }

        switch (action) {
            case AUTH:
            case SALE:
            case REFUND:
            case VOID:
            case VERIFY:
            case PARTIAL_REFUND:
                return true;
            default:
                return false;
        }
    }

    @NonNull
    private GatewayResponse getErrorResponse(@Nullable GatewayAction action, String errorMessage) {
        Timber.d("getErrorResponse() called with errorMessage->%s", action);
        GatewayResponse response = new GatewayResponse(action);
        response.setError(true);
        response.setErrorMessage(errorMessage);
        return response;
    }

    private void handleAction(@NonNull GatewayAction action) {
        mGatewayResponse = new GatewayResponse(action);
        populateResponseCardData();

        switch (action) {
            case AUTH:
            case SALE:
                handleAuthSaleRequest();
                break;
            case VOID:
            case REFUND:
            case PARTIAL_REFUND:
                handleVoidRefundRequest();
                break;
            case VERIFY:
                handleVerifyRequest();
                break;
        }
    }

    private void handleAuthSaleRequest() {
        Timber.d("handleAuthSaleRequest() called");
        String errorMessage = null;
        CardData data = mGatewayRequest.getCardData();
        if (data != null) {
            if (data.getCardDataSource() != null) {
                switch (data.getCardDataSource()) {
                    case MSR:
                    case FALLBACK:
                    case SCR:
                    case CONTACTLESS_MSR:
                    case CONTACTLESS_EMV:
                    case KEYED:
                        completeGatewayProcessing(data);
                        break;
                    case PHONE:
                    case MAIL:
                    case INTERNET:
                        break;
                }
            } else {
                errorMessage = "Unable to determine  card  data input mode(swipe,EMV, etc)";
            }
        } else {
            errorMessage = "No card data specified";
        }

        if (errorMessage != null) {
            mGatewayResponse = getErrorResponse(mGatewayRequest.getGatewayAction(), errorMessage);
            mGatewayListener.onGatewayResponse(mGatewayResponse);
        }
    }

    private void completeGatewayProcessing(@NonNull CardData cardData) {
        processTransactionAmount();
        if (cardData.getCardDataSource() == CardDataSourceType.CONTACTLESS_EMV
                || cardData.getCardDataSource() == CardDataSourceType.SCR) {
            if (mGatewayResponse.isApproved()) {
                mGatewayResponse.setEmvIssuerAuthCode(EMV_APPROVAL_RESPONSE_CODE);
            } else {
                mGatewayResponse.setEmvIssuerAuthCode(EMV_DECLINE_RESPONSE_CODE);
            }
        }
    }

    private void handleVoidRefundRequest() {
        mGatewayResponse.setApproved(true);
        mGatewayResponse.setApprovedAmount(mGatewayRequest.getTotal());
    }

    private void handleVerifyRequest() {
        // TODO: Pending. Details are not worked out.
    }

    //region Helper Methods
    private void populateResponseCardData() {
        Timber.d("populateResponseCardData() called");
        if (mGatewayRequest.getCardData() != null) {
            CardData cardData = mGatewayRequest.getCardData();
            mGatewayResponse.setCardDataSourceType(cardData.getCardDataSource());
            mGatewayResponse.setMaskedPan(cardData.getPan());
            mGatewayResponse.setCardholderName(cardData.getCardholderName());
            mGatewayResponse.setCardExpiryDate(cardData.getExpirationDate());
            mGatewayResponse.setCardType(CreditCardHelper.typeFromCardData(cardData));
        }
    }

    private void populateBaseApprovalResponseData() {
        Timber.d("populateBaseApprovalResponseData() called");
        mGatewayResponse.setApproved(true);
        mGatewayResponse.setAuthCode(APPROVAL_AUTH_CODE);
    }

    private void processTransactionAmount() {
        Timber.d("processTransactionAmount() called");
        populateBaseApprovalResponseData();
        mGatewayResponse.setApprovedAmount(mGatewayRequest.getTotal());
    }

    private boolean isApprovedPartialAmount(long amount) {
        Timber.d("isApprovedPartialAmount() called with amount->%d", amount);
        return amount > 0 && amount % PARTIAL_APPROVAL_AMOUNT_FACTOR == 0;
    }

    private boolean isApprovedAmount(long amount) {
        Timber.d("isApprovedAmount() called with amount->%d", amount);
        return amount % 2 == 0;
    }

    //endregion
}
