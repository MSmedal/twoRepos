package com.tsys.payments.host.transit.webservices.enums;

public enum TransitCreditCardProviderType {
    None(10000),
    NetSecure(10001),
    PaywareConnect(10002),
    BridgePay(10003),
    TsysTransIt(10004),
    HeartlandPortico(10005),
    YesMan(99999);

    public int key;

    TransitCreditCardProviderType(int key) {
        this.key = key;
    }

    public static TransitCreditCardProviderType fromKey(int key) {
        for (TransitCreditCardProviderType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
