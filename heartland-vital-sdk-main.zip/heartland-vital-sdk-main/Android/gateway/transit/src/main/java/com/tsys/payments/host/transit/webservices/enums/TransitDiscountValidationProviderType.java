package com.tsys.payments.host.transit.webservices.enums;

public enum TransitDiscountValidationProviderType {
    None(10000),
    SixFlags(10001);

    public int key;

    TransitDiscountValidationProviderType(int key) {
        this.key = key;
    }

    public static TransitDiscountValidationProviderType fromKey(int key) {
        for (TransitDiscountValidationProviderType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
