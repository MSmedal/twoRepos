package com.tsys.payments.host.transit.webservices.enums;

public enum TransitGiftCardProviderType {
    None(10000);

    public int key;

    private TransitGiftCardProviderType(int key) {
        this.key = key;
    }

    public static TransitGiftCardProviderType fromKey(int key) {
        for (TransitGiftCardProviderType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
