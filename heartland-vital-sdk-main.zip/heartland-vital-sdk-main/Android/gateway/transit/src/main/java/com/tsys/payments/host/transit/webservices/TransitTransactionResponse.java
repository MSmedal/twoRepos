package com.tsys.payments.host.transit.webservices;

import androidx.annotation.Nullable;

import java.util.Date;

public interface TransitTransactionResponse {
    /**
     * TSYS API Status String. E.g., "PASS", "FAIL".
     */
    @Nullable
    String getStatus();

    /**
     * TSYS API Response Code. E.g., A0000.
     *
     * @see TransitResponseCode
     */
    @Nullable
    TransitResponseCode getResponseCode();

    /**
     * TSYS API Response Message. E.g., "Success", "Duplicate Request (Approved previously)".
     */
    @Nullable
    String getResponseMessage();

    @Nullable
    String getAuthCode();

    @Nullable
    String getHostReferenceNumber();

    @Nullable
    String getTaskID();

    @Nullable
    String getTransactionID();

    @Nullable
    String getCustomerReceipt();

    @Nullable
    String getMerchantReceipt();

    @Nullable
    Date getTransactionTimestamp();

    @Nullable
    String getMaskedCardNumber();

    @Nullable
    String getCardType();
}
