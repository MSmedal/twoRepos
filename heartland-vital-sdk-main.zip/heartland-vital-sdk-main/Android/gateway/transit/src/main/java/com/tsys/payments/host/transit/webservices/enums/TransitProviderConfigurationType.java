package com.tsys.payments.host.transit.webservices.enums;

public enum TransitProviderConfigurationType {
    Gateway(100000),
    Loyalty(100001),
    Gift(100002);

    public int key;

    TransitProviderConfigurationType(int key) {
        this.key = key;
    }

    public static TransitProviderConfigurationType fromKey(int key) {
        for (TransitProviderConfigurationType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
