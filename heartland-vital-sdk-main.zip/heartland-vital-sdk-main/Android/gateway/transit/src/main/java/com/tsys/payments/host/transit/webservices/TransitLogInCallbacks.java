package com.tsys.payments.host.transit.webservices;

public interface TransitLogInCallbacks {
    void onLogInSuccess();

    void onLogInFailure();
}
