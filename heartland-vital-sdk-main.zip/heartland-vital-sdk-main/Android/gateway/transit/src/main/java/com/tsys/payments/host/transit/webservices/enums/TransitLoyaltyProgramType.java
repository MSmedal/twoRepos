package com.tsys.payments.host.transit.webservices.enums;

public enum TransitLoyaltyProgramType {
    Punches(10000),
    Points(10001),
    Amount(10002),
    Visits(10003),
    StoredValue(10004);

    public int key;

    private TransitLoyaltyProgramType(int key) {
        this.key = key;
    }

    public static TransitLoyaltyProgramType fromKey(int key) {
        for (TransitLoyaltyProgramType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
