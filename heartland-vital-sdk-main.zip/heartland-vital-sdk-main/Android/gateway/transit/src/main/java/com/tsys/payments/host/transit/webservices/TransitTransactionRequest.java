package com.tsys.payments.host.transit.webservices;

public interface TransitTransactionRequest {

    /**
     * Gets the value of the deviceID property.
     *
     * @return possible object is
     * {@link String }
     */
    String getDeviceID();

    /**
     * Gets the value of the transactionKey property.
     *
     * @return possible object is
     * {@link String }
     */
    String getTransactionKey();

    /**
     * Gets the value of the manifest property.
     *
     * @return possible object is
     * {@link String }
     */
    String getManifest();
}
