package com.tsys.payments.host.transit.enums;

import androidx.annotation.Nullable;
import android.text.TextUtils;

public enum TransitDisplayText {
    AMOUNT("Amount: "),
    AMOUNT_OK_OR_NOT("Amount OK?"),
    APPROVED("Approved"),
    CALL_YOUR_BANK("Call Your Bank"),
    CANCEL_OR_ENTER("Cancel or Enter"),
    CARD_ERROR("Card Error"),
    CARD_REMOVED_TOO_SOON_ERROR("Card was removed too soon. Please start transaction over."),
    DECLINED("Declined"),
    ENTER_AMOUNT("Enter Amount"),
    ENTER_PIN("Enter PIN"),
    INCORRECT_PIN("Incorrect PIN"),
    INSERT_CARD("Insert Card"),
    NOT_ACCEPTED("Not Accepted"),
    PIN_OK("PIN OK"),
    PLEASE_WAIT("Please wait..."),
    DEVICE_CONFIGURATION_APPLICATION_IDS("Configuring device application. This may take a few moments."),
    DEVICE_CONFIGURATION_SECURITY_KEYS("Configuring security keys. This may take a few moments."),
    DEVICE_CONFIGURATION_DATA_OBJECT_LISTS("Configuring device. This may take a few moments."),
    DEVICE_CONFIGURATION_INTERFACE("Configuring device interface. This may take a few moments."),
    PROCESSING_ERROR("Processing Error"),
    REMOVE_CARD("Remove card"),
    REINSERT_CARD("Reinsert Card"),
    USE_CHIP_READER("Use Chip Reader"),
    USE_MAG_STRIPE("Use Mag Stripe"),
    TRY_AGAIN("Try Again"),
    REFER_TO_YOUR_PAYMENT_DEVICE("Refer to Payment Device"),
    TRANSACTION_TERMINATED("Transaction Terminated"),
    TRY_ANOTHER_INTERFACE("Try Another Interface"),
    ONLINE_REQUIRED("Online Required"),
    PROCESSING("Processing"),
    WELCOME("Welcome"),
    PRESENT_ONLY_ONE_CARD("Present Only One Card"),
    CAPK_LOADING_FAILED("CAPK Load Failed"),
    LAST_PIN_TRY("Last PIN Attempt"),
    INSERT_OR_TAP_CARD("Insert or Tap Card"),
    SELECT_ACCOUNT("Select Account"),
    APPROVED_PLEASE_SIGN("Approved, Please Sign"),
    TAP_CARD_AGAIN("Tap Card Again"),
    AUTHORIZING("Authorizing"),
    INSERT_OR_SWIPE_CARD_OR_TAP_ANOTHER_CARD("Insert or Swipe Card, or Tap Another Card"),
    INSERT_OR_SWIPE_CARD("Insert or Swipe Card"),
    MULTIPLE_CARDS_DETECTED("Multiple Cards Detected"),
    CLEAR_DISPLAY(""),
    ONLINE_PROCESSING_REQUIRED("Online Processing Required"),
    SWIPE_CARD("Please Swipe Card"),
    UNKNOWN("Unknown"),
    CONTACTLESS_INTERFACE_FAILED_TRY_CONTACT("Contactless Interface failed. Please insert card."),
    PRESENT_CARD_AGAIN("Present card again"),
    CONTACTLESS_CARD_STILL_IN_FIELD("Contactless card still in field"),
    WAITING_FOR_DEVICE("Waiting for device"),
    WAITING_FOR_CARD_SWIPE("Waiting for card swipe"),
    TAP_DETECTED("Tap detected"),
    SWIPE_DETECTED("Swipe detected"),
    ICC_ERROR_SWIPE_CARD("Chip error. Please swipe card"),
    ERROR_READING_CONTACTLESS_CARD("Error reading contactless card"),
    DEVICE_BUSY("Device busy"),
    CONTACTLESS_TRANSACTION_REVERTED_TO_CONTACT("Contactless transaction reverted to contact"),
    CARD_INSERTED("Card inserted"),
    PLEASE_SEE_PHONE("Please see phone for instructions");

    private String mSuggestedText;

    TransitDisplayText(String suggestedText) {
        mSuggestedText = suggestedText;
    }

    public String getSuggestedText() {
        return mSuggestedText;
    }

    @Nullable
    public static TransitDisplayText fromString(@Nullable String text) {
        if (TextUtils.isEmpty(text)) {
            return null;
        }

        for (TransitDisplayText displayText : values()) {
            if (displayText.getSuggestedText().equalsIgnoreCase(text)) {
                return displayText;
            }
        }
        return null;
    }
}
