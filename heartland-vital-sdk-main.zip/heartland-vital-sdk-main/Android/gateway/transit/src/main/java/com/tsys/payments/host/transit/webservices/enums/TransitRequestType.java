package com.tsys.payments.host.transit.webservices.enums;

public enum TransitRequestType {
    Sale(0),
    Authorization(1),
    Credit(2);

    public int key;

    private TransitRequestType(int key) {
        this.key = key;
    }

    public static TransitRequestType fromKey(int key) {
        for (TransitRequestType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
