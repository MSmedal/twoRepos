package com.tsys.payments.host.transit;

import android.text.TextUtils;

import com.tsys.payments.host.transit.webservices.TransitResponseCode;
import com.tsys.payments.host.transit.webservices.TransitXMLConverter;
import com.tsys.payments.host.transit.webservices.generated.TransitAuth;
import com.tsys.payments.host.transit.webservices.generated.TransitAuthResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitBatchClose;
import com.tsys.payments.host.transit.webservices.generated.TransitBatchCloseResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitCapture;
import com.tsys.payments.host.transit.webservices.generated.TransitCaptureResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitForcedAuth;
import com.tsys.payments.host.transit.webservices.generated.TransitForcedAuthResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitReturn;
import com.tsys.payments.host.transit.webservices.generated.TransitReturnResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitSale;
import com.tsys.payments.host.transit.webservices.generated.TransitSaleResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitTransactionAdjustment;
import com.tsys.payments.host.transit.webservices.generated.TransitTransactionAdjustmentResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitVoid;
import com.tsys.payments.host.transit.webservices.generated.TransitVoidResponse;
import com.tsys.payments.library.exceptions.InitializationException;

import org.simpleframework.xml.core.ValueRequiredException;

import androidx.annotation.NonNull;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import timber.log.Timber;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

final class TransitApi {
    private static final String TAG = TransitApi.class.getSimpleName();
    private static final String DEBUG_URL =
            "https://stagegw.transnox.com/servlets/TransNox_API_Server/";
    private static final String PROD_URL =
            "https://gateway.transit-pass.com/servlets/TransNox_API_Server/";

    private HttpLoggingInterceptor mHttpLogger = new HttpLoggingInterceptor();

    static final long TRANSACTIONLESS_TRANSACTION_ID = -1;

    private static TransitApi sInstance;
    private TransitEndPoints mClient;
    private String mDeviceId;
    private String mTransactionKey;

    @NonNull
    static TransitApi getInstance() {
        synchronized (TransitApi.class) {
            if (sInstance == null) {
                sInstance = new TransitApi();
            }
        }
        return sInstance;
    }

    /**
     * Initializes an {@link TransitApi} client.
     *
     * @param deviceId TransIT deviceID
     * @param transactionKey TransIT transaction key
     * @param connectionTimeout Connection timeout in milliseconds
     * @param debug Determines if {@link HttpLoggingInterceptor} should be enabled.
     */
    void initialize(String deviceId, String transactionKey, long connectionTimeout, boolean debug)
            throws InitializationException {
        mDeviceId = deviceId;
        mTransactionKey = transactionKey;

        // Logging configuration is determined by the consuming application;
        // any changes to the log level here would override the application, because
        // this constructor is invoked by a singleton on an as-needed basis
        if (debug) {
            mHttpLogger.setLevel(HttpLoggingInterceptor.Level.BODY);
        } else {
            mHttpLogger.setLevel(HttpLoggingInterceptor.Level.NONE);
        }
        final OkHttpClient okHttpClient = TransitHttpClient.getBaseClientBuilder(connectionTimeout)
                .addInterceptor(mHttpLogger)
                .build();

        Retrofit restAdapter = new Retrofit.Builder()
                .baseUrl(debug ? DEBUG_URL : PROD_URL)
                .client(okHttpClient)
                .addConverterFactory(new TransitXMLConverter().createFactory())
                .build();

        mClient = restAdapter.create(TransitEndPoints.class);
    }

    /**
     * Performs an auth request
     *
     * @param request request
     * @param tsysSdkListener response handler
     */
    void performAuth(@NonNull final TransitAuth request,
            @NonNull final TransitSdkListener<TransitAuthResponse> tsysSdkListener) {
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        // TODO: Condense handling ofthe auth and sale responses to a single location since they're pretty similar.

        try {
            Response<TransitAuthResponse> response = mClient.performAuth(request).execute();
            TransitAuthResponse result = response.body();
            if (response.isSuccessful() && result != null) {
                if (TextUtils.isEmpty(result.getStatus())) {
                    tsysSdkListener.onError(result, TransitConversionHelper.
                            transactionResultFromGatewayResponseCode
                                    (result.getResponseCode()));
                } else {
                    tsysSdkListener.onTransitResponse(response.body());
                }
            } else {
                ResponseBody errorBody = response.errorBody();
                TransitAuthResponse error = new TransitAuthResponse();
                error.setResponseCode(TransitResponseCode.HOST_UNAVAILABLE);
                if (errorBody != null) {
                    error.setResponseMessage(errorBody.string());
                }
                tsysSdkListener
                        .onError(error,
                                TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                        error.getResponseCode()));
            }
        } catch (Exception e) {
            Timber.e(e);

            TransitAuthResponse error = new TransitAuthResponse();
            error.setResponseCode(responseCodeFromException(e));

            Throwable wrappedException = e.getCause();
            if (wrappedException instanceof ValueRequiredException) {
                error.setResponseMessage(getResponseFormatErrorMessage(wrappedException));
            } else {
                error.setResponseMessage(e.getLocalizedMessage());
            }

            tsysSdkListener
                    .onError(error,
                            TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                    error.getResponseCode()));
        }
    }

    /**
     * Performs a sale request
     *
     * @param request request data
     * @param tsysSdkListener response handler
     */
    void performSale(@NonNull final TransitSale request,
            @NonNull final TransitSdkListener<TransitSaleResponse> tsysSdkListener) {
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        try {
            Response<TransitSaleResponse> response = mClient.performSale(request).execute();
            TransitSaleResponse result = response.body();
            if (response.isSuccessful() && result != null) {
                if (TextUtils.isEmpty(result.getStatus())) {
                    tsysSdkListener.onError(result, TransitConversionHelper.
                            transactionResultFromGatewayResponseCode(
                                    result.getResponseCode()));
                } else {
                    tsysSdkListener.onTransitResponse(response.body());
                }
            } else {
                ResponseBody errorBody = response.errorBody();
                TransitSaleResponse error = new TransitSaleResponse();
                error.setResponseCode(TransitResponseCode.HOST_UNAVAILABLE);
                if (errorBody != null) {
                    error.setResponseMessage(errorBody.string());
                }
                tsysSdkListener
                        .onError(error,
                                TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                        result == null ? null : result.getResponseCode()));
            }
        } catch (Exception e) {
            Timber.e(e);

            TransitSaleResponse error = new TransitSaleResponse();
            error.setResponseCode(responseCodeFromException(e));

            Throwable wrappedException = e.getCause();
            if (wrappedException instanceof ValueRequiredException) {
                error.setResponseMessage(getResponseFormatErrorMessage(wrappedException));
            } else {
                error.setResponseMessage(e.getLocalizedMessage());
            }

            tsysSdkListener
                    .onError(error,
                            TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                    error.getResponseCode()));
        }
    }

    /**
     * Performs a void request
     *
     * @param request request data
     * @param tsysSdkListener response handler
     */
    void performVoid(@NonNull final TransitVoid request,
            @NonNull final TransitSdkListener<TransitVoidResponse> tsysSdkListener) {
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        try {
            Response<TransitVoidResponse> response = mClient.performVoid(request).execute();
            TransitVoidResponse result = response.body();
            if (response.isSuccessful() && result != null) {
                if (TextUtils.isEmpty(result.getStatus())) {
                    tsysSdkListener.onError(result, TransitConversionHelper.
                            transactionResultFromGatewayResponseCode(
                                    result.getResponseCode()));
                } else {
                    tsysSdkListener.onTransitResponse(response.body());
                }
            } else {
                ResponseBody errorBody = response.errorBody();
                TransitVoidResponse error = new TransitVoidResponse();
                error.setResponseCode(TransitResponseCode.HOST_UNAVAILABLE);
                if (errorBody != null) {
                    error.setResponseMessage(errorBody.string());
                }
                tsysSdkListener
                        .onError(error,
                                TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                        error.getResponseCode()));
            }
        } catch (Exception e) {
            Timber.e(e);

            TransitVoidResponse error = new TransitVoidResponse();
            error.setResponseCode(responseCodeFromException(e));

            Throwable wrappedException = e.getCause();
            if (wrappedException instanceof ValueRequiredException) {
                error.setResponseMessage(getResponseFormatErrorMessage(wrappedException));
            } else {
                error.setResponseMessage(e.getLocalizedMessage());
            }

            tsysSdkListener
                    .onError(error,
                            TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                    error.getResponseCode()));
        }
    }

    /**
     * Performs a forced auth request
     *
     * @param request request data
     * @param tsysSdkListener response handler
     */
    void performForcedAuth(@NonNull final TransitForcedAuth request,
            @NonNull final TransitSdkListener<TransitForcedAuthResponse> tsysSdkListener) {
        request.setDeveloperID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        try {
            Response<TransitForcedAuthResponse> response =
                    mClient.performForcedAuth(request).execute();
            TransitForcedAuthResponse result = response.body();
            if (response.isSuccessful() && result != null) {
                if (TextUtils.isEmpty(result.getStatus())) {
                    tsysSdkListener.onError(result, TransitConversionHelper.
                            transactionResultFromGatewayResponseCode(
                                    result.getResponseCode()));
                } else {
                    tsysSdkListener.onTransitResponse(response.body());
                }
            } else {
                ResponseBody errorBody = response.errorBody();
                TransitForcedAuthResponse error = new TransitForcedAuthResponse();
                error.setResponseCode(TransitResponseCode.HOST_UNAVAILABLE);
                if (errorBody != null) {
                    error.setResponseMessage(errorBody.string());
                }
                tsysSdkListener
                        .onError(error,
                                TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                        error.getResponseCode()));
            }
        } catch (Exception e) {
            Timber.e(e);

            TransitForcedAuthResponse error = new TransitForcedAuthResponse();
            error.setResponseCode(responseCodeFromException(e));

            Throwable wrappedException = e.getCause();
            if (wrappedException instanceof ValueRequiredException) {
                error.setResponseMessage(getResponseFormatErrorMessage(wrappedException));
            } else {
                error.setResponseMessage(e.getLocalizedMessage());
            }

            tsysSdkListener
                    .onError(error,
                            TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                    error.getResponseCode()));
        }
    }

    /**
     * performs a return request
     *
     * @param request request data
     * @param tsysSdkListener response handler
     */
    void performReturn(@NonNull final TransitReturn request,
            @NonNull final TransitSdkListener<TransitReturnResponse> tsysSdkListener) {
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        try {
            Response<TransitReturnResponse> response = mClient.performReturn(request).execute();
            TransitReturnResponse result = response.body();
            if (response.isSuccessful() && result != null) {
                if (TextUtils.isEmpty(result.getStatus())) {
                    tsysSdkListener.onError(result, TransitConversionHelper.
                            transactionResultFromGatewayResponseCode(
                                    result.getResponseCode()));
                } else {
                    tsysSdkListener.onTransitResponse(response.body());
                }
            } else {
                ResponseBody errorBody = response.errorBody();
                TransitReturnResponse error = new TransitReturnResponse();
                error.setResponseCode(TransitResponseCode.HOST_UNAVAILABLE);
                if (errorBody != null) {
                    error.setResponseMessage(errorBody.string());
                }
                tsysSdkListener
                        .onError(error,
                                TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                        error.getResponseCode()));
            }
        } catch (Exception e) {
            Timber.e(e);

            TransitReturnResponse error = new TransitReturnResponse();
            error.setResponseCode(responseCodeFromException(e));

            Throwable wrappedException = e.getCause();
            if (wrappedException instanceof ValueRequiredException) {
                error.setResponseMessage(getResponseFormatErrorMessage(wrappedException));
            } else {
                error.setResponseMessage(e.getLocalizedMessage());
            }

            tsysSdkListener
                    .onError(error,
                            TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                    error.getResponseCode()));
        }
    }

    /**
     * Performs a capture request
     *
     * @param request {@link TransitCapture} object.
     * @param tsysSdkListener {@link TransitSdkListener<TransitCaptureResponse>} listener.
     */
    void performCapture(@NonNull final TransitCapture request,
            @NonNull final TransitSdkListener<TransitCaptureResponse> tsysSdkListener) {
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        try {
            Response<TransitCaptureResponse> response = mClient.performCapture(request).execute();
            TransitCaptureResponse result = response.body();
            if (response.isSuccessful() && result != null) {
                if (TextUtils.isEmpty(result.getStatus())) {
                    tsysSdkListener.onError(result, TransitConversionHelper.
                            transactionResultFromGatewayResponseCode(
                                    TransitResponseCode.fromString(result.getResponseCode())));
                } else {
                    tsysSdkListener.onTransitResponse(response.body());
                }
            } else {
                ResponseBody errorBody = response.errorBody();
                TransitCaptureResponse error = new TransitCaptureResponse();
                error.setResponseCode(TransitResponseCode.HOST_UNAVAILABLE.toString());
                if (errorBody != null) {
                    error.setResponseMessage(errorBody.string());
                }
                tsysSdkListener.onError(error,
                        TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                TransitResponseCode.fromString(error.getResponseCode())));
            }
        } catch (Exception e) {
            Timber.e(e);

            TransitCaptureResponse error = new TransitCaptureResponse();
            error.setResponseCode(responseCodeFromException(e).toString());

            Throwable wrappedException = e.getCause();
            if (wrappedException instanceof ValueRequiredException) {
                error.setResponseMessage(getResponseFormatErrorMessage(wrappedException));
            } else {
                error.setResponseMessage(e.getLocalizedMessage());
            }

            tsysSdkListener
                    .onError(error,
                            TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                    TransitResponseCode.fromString(error.getResponseCode())));
        }
    }

    /**
     * Performs a transaction adjustment request
     *
     * @param request {@link TransitTransactionAdjustment} object.
     * @param tsysSdkListener {@link TransitSdkListener<TransitTransactionAdjustmentResponse>}
     * listener.
     */
    void performTransactionAdjustment(@NonNull final TransitTransactionAdjustment request,
            @NonNull final TransitSdkListener<TransitTransactionAdjustmentResponse> tsysSdkListener) {
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        try {
            Response<TransitTransactionAdjustmentResponse> response =
                    mClient.performTransactionAdjustment(request).execute();
            TransitTransactionAdjustmentResponse result = response.body();
            if (response.isSuccessful() && result != null) {
                if (TextUtils.isEmpty(result.getStatus())) {
                    tsysSdkListener.onError(result, TransitConversionHelper.
                            transactionResultFromGatewayResponseCode(
                                    TransitResponseCode.fromString(result.getResponseCode())));
                } else {
                    tsysSdkListener.onTransitResponse(response.body());
                }
            } else {
                ResponseBody errorBody = response.errorBody();
                TransitTransactionAdjustmentResponse error =
                        new TransitTransactionAdjustmentResponse();
                error.setResponseCode(TransitResponseCode.HOST_UNAVAILABLE.toString());
                if (errorBody != null) {
                    error.setResponseMessage(errorBody.string());
                }
                tsysSdkListener.onError(error,
                        TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                TransitResponseCode.fromString(error.getResponseCode())));
            }
        } catch (Exception e) {
            Timber.e(e);

            TransitTransactionAdjustmentResponse error = new TransitTransactionAdjustmentResponse();
            error.setResponseCode(responseCodeFromException(e).toString());

            Throwable wrappedException = e.getCause();
            if (wrappedException instanceof ValueRequiredException) {
                error.setResponseMessage(getResponseFormatErrorMessage(wrappedException));
            } else {
                error.setResponseMessage(e.getLocalizedMessage());
            }

            tsysSdkListener
                    .onError(error,
                            TransitConversionHelper.transactionResultFromGatewayResponseCode(
                                    TransitResponseCode.fromString(error.getResponseCode())));
        }
    }

    /**
     * Performs a batch close request
     *
     * @param request {@link TransitBatchClose} object.
     * @param tsysSdkListener {@link TransitSdkListener<TransitBatchCloseResponse>}
     * listener.
     */
    void performCloseBatch(@NonNull final TransitBatchClose request,
            @NonNull final TransitSdkListener<TransitBatchCloseResponse> tsysSdkListener) {
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);

        try {
            Response<TransitBatchCloseResponse> response = mClient.closeBatch(request).execute();
            TransitBatchCloseResponse result = response.body();
            if (response.isSuccessful() && result != null) {
                if (TextUtils.isEmpty(result.getStatus())) {
                    tsysSdkListener.onError(result, TransitConversionHelper.
                            transactionResultFromGatewayResponseCode(result.getResponseCode()));
                } else {
                    tsysSdkListener.onTransitResponse(response.body());
                }
            } else {
                ResponseBody errorBody = response.errorBody();
                TransitBatchCloseResponse error = new TransitBatchCloseResponse();
                error.setResponseCode(TransitResponseCode.HOST_UNAVAILABLE);
                if (errorBody != null) {
                    error.setResponseMessage(errorBody.string());
                }
                tsysSdkListener.onError(error, TransitConversionHelper
                        .transactionResultFromGatewayResponseCode(error.getResponseCode()));
            }
        } catch (Exception e) {
            Timber.e(e);
            TransitBatchCloseResponse error = new TransitBatchCloseResponse();
            error.setResponseCode(responseCodeFromException(e));
            error.setResponseMessage(e.getLocalizedMessage());
            tsysSdkListener.onError(error,
                    TransitConversionHelper
                            .transactionResultFromGatewayResponseCode(error.getResponseCode()));
        }
    }

    private String getResponseFormatErrorMessage(@NonNull Throwable e) {
        return "Response received from host is missing required elements: " + e.getLocalizedMessage();
    }

    private TransitResponseCode responseCodeFromException(@NonNull Exception e) {
        Throwable throwable = e.getCause();
        if (throwable instanceof UnknownHostException) {
            return TransitResponseCode.UNKNOWN_HOST;
        } else if (throwable instanceof SocketTimeoutException) {
            return TransitResponseCode.HOST_TIMEOUT;
        } else if (throwable instanceof ValueRequiredException) {
            return TransitResponseCode.UNKNOWN_CODE;
        } else {
            return TransitResponseCode.HOST_UNAVAILABLE;
        }
    }

    private interface TransitEndPoints {
        String CONTENT_TYPE = "Content-Type: text/xml; charset=UTF-8";

        @NonNull
        @POST("Auth")
        @Headers(CONTENT_TYPE)
        Call<TransitAuthResponse> performAuth(@Body TransitAuth request);

        @NonNull
        @POST("ForcedAuth")
        @Headers(CONTENT_TYPE)
        Call<TransitForcedAuthResponse> performForcedAuth(@Body TransitForcedAuth request);

        @NonNull
        @POST("Sale")
        @Headers(CONTENT_TYPE)
        Call<TransitSaleResponse> performSale(@Body TransitSale request);

        @NonNull
        @POST("Void")
        @Headers(CONTENT_TYPE)
        Call<TransitVoidResponse> performVoid(@Body TransitVoid request);

        @NonNull
        @POST("Return")
        @Headers(CONTENT_TYPE)
        Call<TransitReturnResponse> performReturn(@Body TransitReturn returnRequest);

        @NonNull
        @POST("Capture")
        @Headers(CONTENT_TYPE)
        Call<TransitCaptureResponse> performCapture(@Body TransitCapture captureRequest);

        @NonNull
        @POST("TransactionAdjustment")
        @Headers(CONTENT_TYPE)
        Call<TransitTransactionAdjustmentResponse> performTransactionAdjustment(@Body
                TransitTransactionAdjustment adjustmentRequest);

        @NonNull
        @POST("Batch")
        @Headers(CONTENT_TYPE)
        Call<TransitBatchCloseResponse> closeBatch(@Body TransitBatchClose closeBatchRequest);
    }
}
