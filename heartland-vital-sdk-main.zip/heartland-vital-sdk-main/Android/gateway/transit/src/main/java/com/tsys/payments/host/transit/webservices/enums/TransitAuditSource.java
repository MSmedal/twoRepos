package com.tsys.payments.host.transit.webservices.enums;

public enum TransitAuditSource {
    AndroidPro(100001),
    AndroidMobile(100003),
    AndroidECR(100006);

    public int key;

    TransitAuditSource(int key) {
        this.key = key;
    }

    public static TransitAuditSource fromKey(int key) {
        for (TransitAuditSource type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
