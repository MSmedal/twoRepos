package com.tsys.payments.host.transit.utils;

import android.content.Context;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.MediaScannerConnectionClient;
import android.net.Uri;

/**
 * A way to inform Android's media scanner that local content has been updated. Current Android
 * devices use MTP instead of MassStorage when connected to a PC via USB. MTP makes use of the
 * Android's media scanner for indexing files. When the app writes debug data to storage, it won't
 * be accessible over USB until the media scanner indexes the files. Android does this automatically
 * on boot (and occasionally in the background) but sometimes that isn't fast enough during
 * development. This class is simply a way to make that happen immediately.
 */
public class TransitMediaScannerNotifier implements MediaScannerConnectionClient {

    private MediaScannerConnection mConnection;
    private String mPath;
    private String mMimeType;

    public TransitMediaScannerNotifier(Context context, String path, String mimeType) {
        mPath = path;
        mMimeType = mimeType;
        mConnection = new MediaScannerConnection(context, this);
        mConnection.connect();
    }

    @Override
    public void onMediaScannerConnected() {
        mConnection.scanFile(mPath, mMimeType);
    }

    @Override
    public void onScanCompleted(String path, Uri uri) {
        // nothing
    }
}
