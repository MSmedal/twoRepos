package com.tsys.payments.host.transit.constants;

public class TransitIds {

    // general purpose
    public static final int UNDEFINED = -1;
    public static final String MAX_PIN_LENGTH = "NOT_SUPPORTED";

    // notifications
    public static final int PUSH_NOTIFICATION_ID = 1;
    public static final int REGISTER_ACCESSORY_DISPLAY_SERVICE_NOTIFICATION_ID = 2;
}
