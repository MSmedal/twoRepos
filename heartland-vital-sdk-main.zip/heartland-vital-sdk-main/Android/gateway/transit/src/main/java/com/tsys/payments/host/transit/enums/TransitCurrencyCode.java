package com.tsys.payments.host.transit.enums;

public enum TransitCurrencyCode {
    USD("0840"),
    EUR("0978"),
    GBP("0826");

    private String mCode;

    TransitCurrencyCode(String code) {
        mCode = code;
    }

    public String getCode() {
        return mCode;
    }

}
