package com.tsys.payments.host.transit.utils;

public class TransitBuildConfigHelper {

    // Library modules currently build in release mode only, and the workarounds are all ugly.
    // Set this value from the main app and query it from anywhere that doesn't have the
    // BuildConfig.DEBUG value you were hoping for.

    private static boolean sIsDebugMode;

    public static boolean isDebugMode() {
        return sIsDebugMode;
    }

    public static void setDebugMode(boolean isDebugMode) {
        sIsDebugMode = isDebugMode;
    }
}
