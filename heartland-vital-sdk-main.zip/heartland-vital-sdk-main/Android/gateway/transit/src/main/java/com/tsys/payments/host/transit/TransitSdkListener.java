package com.tsys.payments.host.transit;


import com.tsys.payments.host.transit.webservices.enums.TransitTransactionResult;

import androidx.annotation.WorkerThread;

@WorkerThread
public interface TransitSdkListener<T> {

    /**
     * Called when the remote server returns a response
     *
     * @param result server response
     */
    void onTransitResponse(T result);

    /**
     * Called when there is an error
     *
     * @param result response
     * @param hostResult reason request failed.
     */
    void onError(T result, TransitTransactionResult hostResult);
}
