package com.tsys.payments.host.transit;

import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayControllerFactory;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.enums.GatewayType;

import java.util.Map;

import androidx.annotation.Nullable;

public class TransitGatewayControllerFactory implements GatewayControllerFactory {
    private static final String TAG = TransitGatewayControllerFactory.class.getName();

    @Nullable
    @Override
    public GatewayType[] getSupportedGateways() {
        return new GatewayType[] {GatewayType.TRANSIT};
    }

    @Nullable
    @Override
    public TerminalType[] getSupportedTerminals() {
        return new TerminalType[] {TerminalType.INGENICO_MOBY_3000, TerminalType.INGENICO_MOBY_8500,
                TerminalType.INGENICO_RP45BT,
                TerminalType.INGENICO_RP350, TerminalType.ROAM_G5X_TSYS_DECRYPTION,
                TerminalType.INGENICO_RP450C};
    }

    @Nullable
    @Override
    public GatewayController create(GatewayConfiguration hostConfiguration, GatewayListener listener)
            throws InitializationException {
        validateConfiguration(hostConfiguration);
        return new TransitGatewayController(hostConfiguration, listener);
    }

    private void validateConfiguration(GatewayConfiguration hostConfiguration) {
        Map<String, String> creds = hostConfiguration.getCredentials();
        if (creds == null || creds.isEmpty()) {
            throw new IllegalArgumentException("Invalid configuration. Credentials are not provided but are required.");
        }

        if (!creds.containsKey(TransitCredentialKeys.DEVICE_ID)) {
            throw new IllegalArgumentException("Invalid configuration. Device id is missing but required.");
        }
        if (!creds.containsKey(TransitCredentialKeys.TRANSACTION_KEY)) {
            throw new IllegalArgumentException("Invalid configuration. Transaction key is missing but required.");
        }
        if (!creds.containsKey(TransitCredentialKeys.APP_VERSION)) {
            throw new IllegalArgumentException("Invalid configuration.App version is missing but required.");
        }
    }
}
