package com.tsys.payments.host.transit.webservices.enums;

import androidx.annotation.NonNull;

import com.tsys.payments.library.utils.CreditCardHelper;

public enum TransitPaymentCardType {
    Visa(100000, "Visa"),
    MasterCard(100001, "MasterCard"),
    Discover(100002, "Discover"),
    AmericanExpress(100003, "AMEX");

    public int key;
    public String displayName;

    TransitPaymentCardType(int key, String displayName) {
        this.key = key;
        this.displayName = displayName;
    }

    public static TransitPaymentCardType fromKey(int key) {
        for (TransitPaymentCardType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }

    public static TransitPaymentCardType fromCardNumber(@NonNull String cardNumber) {
        cardNumber = cardNumber.replaceAll("\\D", "");

        if (CreditCardHelper.isVisa(cardNumber)) {
            return TransitPaymentCardType.Visa;
        } else if (CreditCardHelper.isAmericanExpress(cardNumber)) {
            return TransitPaymentCardType.AmericanExpress;
        } else if (CreditCardHelper.isDiscover(cardNumber)) {
            return TransitPaymentCardType.Discover;
        } else if (CreditCardHelper.isMasterCard(cardNumber)) {
            return TransitPaymentCardType.MasterCard;
        }
        return null;
    }
}
