package com.tsys.payments.host.transit.enums;

public enum TransitFallbackCondition {
    ICC_TERMINAL_ERROR,
    NO_CANDIDATE_LIST
}
