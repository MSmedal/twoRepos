package com.tsys.payments.host.transit.webservices;

import org.simpleframework.xml.transform.Transform;

import java.text.DateFormat;
import java.util.Date;

public class TransitDateFormatTransformer implements Transform<Date> {

    private DateFormat serializer, deserializer;

    public TransitDateFormatTransformer(DateFormat serializer, DateFormat deserializer) {
        super();
        this.serializer = serializer;
        this.deserializer = deserializer;
    }

    @Override
    public Date read(String value) throws Exception {
        return deserializer.parse(value);
    }

    @Override
    public String write(Date value) throws Exception {
        return serializer.format(value);
    }
}
