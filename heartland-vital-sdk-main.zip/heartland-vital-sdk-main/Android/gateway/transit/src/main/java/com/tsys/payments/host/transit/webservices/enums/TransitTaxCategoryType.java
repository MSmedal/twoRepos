package com.tsys.payments.host.transit.webservices.enums;

public enum TransitTaxCategoryType {

    SERVICE,
    DUTY,
    VAT,
    ALTERNATE,
    NATIONAL,
    TAX_EXEMPT

}
