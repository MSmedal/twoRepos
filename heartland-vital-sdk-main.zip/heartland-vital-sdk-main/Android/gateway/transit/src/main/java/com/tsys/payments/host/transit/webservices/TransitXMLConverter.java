package com.tsys.payments.host.transit.webservices;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;
import org.simpleframework.xml.transform.RegistryMatcher;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import retrofit2.converter.simplexml.SimpleXmlConverterFactory;

public class TransitXMLConverter {
    private static final TransitDateFormatTransformer DATE_TRANSFORMER =
            new TransitDateFormatTransformer(
                    new SimpleDateFormat(TransitDateUtility.API_DATE_FORMAT, Locale.getDefault()),
                    new SimpleDateFormat(TransitDateUtility.TRANSACTION_TIMESTAMP_FORMAT,
                            Locale.getDefault()));
    private static final TransitDateFormatTransformer TRANSACTION_DATE_TRANSFORMER =
            new TransitDateFormatTransformer(
                    new SimpleDateFormat(TransitDateUtility.TRANSACTION_TIMESTAMP_FORMAT,
                            Locale.getDefault()),
                    new SimpleDateFormat(TransitDateUtility.TRANSACTION_TIMESTAMP_FORMAT,
                            Locale.getDefault()));

    private Serializer mSerializer;

    public TransitXMLConverter() {
        RegistryMatcher registryMatcher = new RegistryMatcher();
        registryMatcher.bind(Date.class, DATE_TRANSFORMER);
        registryMatcher.bind(TransitTimestampDate.class, TRANSACTION_DATE_TRANSFORMER);
        this.mSerializer = new Persister(registryMatcher);
    }

    public SimpleXmlConverterFactory createFactory() {
        return SimpleXmlConverterFactory.createNonStrict(mSerializer);
    }
}
