package com.tsys.payments.host.transit.enums;

public enum TransitPosEntryMode {
    MANUAL("01"),// = Entry mode - manual
    MSR("02"),// = Entry mode - magnetic stripe reader
    BAR_CODE("03"),// = Entry mode - bar code
    OCR("04"),// = Entry mode - optical character recognition (OCR)
    ICC("05"),// = Entry mode - Integrated circuit card 1
    CONTACTLESS_ICC("07"),// = Entry Mode - proximity payment using ICC data
    ICC_FALLBACK_TO_MSR("80"),// = Entry mode - ICC fallback to magnetic stripe
    E_COMMERCE("81"),// = Entry mode - electronic commerce
    MSR_COMPLETE("90"),// = Entry mode - Complete contents of magnetic stripe, track 2 have been read and checked
    CONTACTLESS_MSR("91"),// = Entry Mode - proximity payment using magnetic stripe data
    UNKNOWN("");
    private final String mPosEntryMode;

    TransitPosEntryMode(String code) {
        mPosEntryMode = code;
    }

    public static TransitPosEntryMode fromCode(String code) {

        for (TransitPosEntryMode mode : TransitPosEntryMode.values()) {
            if (code.compareTo(mode.mPosEntryMode) == 0) {
                return mode;
            }
        }
        return UNKNOWN;
    }
}
