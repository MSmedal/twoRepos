package com.tsys.payments.host.transit.webservices.enums;

public enum TransitGiftCardMetaDataType {
    Activate(100000),
    Reload(100001);

    public int key;

    private TransitGiftCardMetaDataType(int key) {
        this.key = key;
    }

    public static TransitGiftCardMetaDataType fromKey(int key) {
        for (TransitGiftCardMetaDataType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
