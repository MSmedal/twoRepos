package com.tsys.payments.host.transit.webservices.enums;

public enum TransitAuditLevel {
    Debug(1),
    Verbose(2),
    Information(3),
    Warning(4),
    Error(5),
    Critical(6);

    public int key;

    TransitAuditLevel(int key) {
        this.key = key;
    }

    public static TransitAuditLevel fromKey(int key) {
        for (TransitAuditLevel type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
