package com.tsys.payments.host.transit.webservices;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Utility class for formatting date
 *

 */
public class TransitDateUtility {

    public static final String API_DATE_FORMAT = "yyyy-MM-dd";
    public static final String API_TIME_FORMAT = "HH:mm:ss";
    public static final String READABLE_DATE_FORMAT = "MMM dd, yyyy";
    public static final String READABLE_TIME_FORMAT = "hh:mmaa";
    public static final String TRANSACTION_TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String TIMESTAMP_REPORTING_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_TIME_REPORTING_FORMAT = "yyyy-MM-dd HH:mm";
    public static final String ORDER_HISTORY_FORMAT = "yyyy-MM-dd h:mm aa";

    static DateTimeFormatter apiDateFormatter = DateTimeFormat.forPattern(API_DATE_FORMAT);
    static DateTimeFormatter apiTimeFormatter = DateTimeFormat.forPattern(API_TIME_FORMAT);
    static DateTimeFormatter TRANSACTION_FORMATTER =
            DateTimeFormat.forPattern(TRANSACTION_TIMESTAMP_FORMAT);
    static DateTimeFormatter dateTimeFormatter =
            DateTimeFormat.forPattern(DATE_TIME_REPORTING_FORMAT);
    static DateTimeFormatter orderHistoryFormatter =
            DateTimeFormat.forPattern(ORDER_HISTORY_FORMAT);

    public static String getReadableDate(String apiDate) {
        DateTime date = DateTime.parse(apiDate, apiDateFormatter);
        return date.toString(READABLE_DATE_FORMAT);
    }

    public static String getApiDate(@NonNull DateTime dateTime) {
        return dateTime.toString(API_DATE_FORMAT);
    }

    public static String getApiTime(@NonNull DateTime dateTime) {
        return dateTime.toString(API_TIME_FORMAT);
    }

    public static DateTime getDateTime(String dateString) {
        return DateTime.parse(dateString, apiDateFormatter);
    }

    public static String getTransactionTimeStamp(@NonNull DateTime dateTime) {
        return dateTime.toString(TRANSACTION_TIMESTAMP_FORMAT);
    }

    public static String getOrderHistoryTimeStamp(@Nullable String timestamp) {
        if (timestamp == null) {
            return "";
        }
        DateTime dateTime = DateTime.parse(timestamp, TRANSACTION_FORMATTER);
        return dateTime.toString(orderHistoryFormatter);
    }

    public static String getDateFromTimeStamp(String timestamp) {
        DateTime dateTime = DateTime.parse(timestamp, TRANSACTION_FORMATTER);
        return dateTime.toString(API_DATE_FORMAT);
    }

    public static String getReadableTime(String timestamp) {
        DateTime dateTime = DateTime.parse(timestamp, apiTimeFormatter);
        return dateTime.toString(READABLE_TIME_FORMAT);
    }

    public static String getReadableDate(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        return dateFormat.format(date);
    }
}
