package com.tsys.payments.host.transit.enums;

import com.tsys.payments.library.enums.CvmResult;

import androidx.annotation.Nullable;

public enum TransitCardholderAuthenticationMethod {
    NOT_AUTHENTICATED("NOT_AUTHENTICATED"),
    UNKNOWN("UNKNOWN"),
    OFFLINE_PIN("OFFLINE_PIN"),
    ONLINE_PIN("ONLINE_PIN"),
    SIGNATURE("MANUAL_SIGNATURE");

    public final String displayName;

    TransitCardholderAuthenticationMethod(String displayName) {
        this.displayName = displayName;
    }

    public static TransitCardholderAuthenticationMethod fromCvmResult(@Nullable CvmResult cvmResult) {
        if (cvmResult == null) return NOT_AUTHENTICATED;

        switch (cvmResult) {
            case PIN_ONLINE:
                return ONLINE_PIN;
            case PIN_OFFLINE_ENCR:
            case PIN_OFFLINE_PLAIN:
                return OFFLINE_PIN;
            case SIGNATURE_REQUIRED:
                return SIGNATURE;
            default:
                return NOT_AUTHENTICATED;
        }
    }
}
