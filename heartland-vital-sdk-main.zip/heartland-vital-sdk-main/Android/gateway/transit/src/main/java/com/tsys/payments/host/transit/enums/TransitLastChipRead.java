package com.tsys.payments.host.transit.enums;

/**
 * Indicates the resut of the last ICC read prcededing the current transaction. In a normal EMV scenario where there are
 * no errors reading the chip, the value {@link TransitLastChipRead#SUCCESSFUL} applies.
 */
public enum TransitLastChipRead {
    /**
     * No errors occurred in reading the ICC.
     */
    SUCCESSFUL,
    /**
     * Failure occurred in attempting to read the chip. If the user performs an MSR fallback, this value would be
     * used to indicate the last chip read.
     */
    FAILED,
    /**
     * A failure occurred to read the AIDs or some other required data from the chip. Typically, the list of AIDs is
     * missing. If an MSR fallback transaction is performed in response, this value would be used.
     */
    NOT_A_CHIP_TRANSACTION,

    /**
     * An unknown error occurred preventing any attempts to read the chip.
     */
    UNKNOWN
}
