package com.tsys.payments.host.transit.enums;

public enum TransitCvm {
    FAIL_CVM_PROCESSING(new String[] {"00"}),
    PLAINTEXT_PIN_OFFLINE(new String[] {"01"}),
    ENCIPHERED_PIN_VERIFIED_ONLINE(new String[] {"02", "42"}),
    PLAINTEXT_PIN_VERIFIED_OFFLINE_PAPER_SIGNATURE(new String[] {"05", "45"}),
    SIGNATURE(new String[] {"1E", "5E"}),
    NO_CVM(new String[] {"1F", "5F"}),
    UNKNOWN(new String[] {"3F", "7F"});
    private final String[] mValues;

    TransitCvm(String[] values) {
        mValues = values;
    }

    public String[] getValues() {
        return mValues;
    }

    public static TransitCvm cvmFromString(String value) {
        for (TransitCvm cvm : TransitCvm.values()) {
            for (String item : cvm.getValues()) {
                if (value.equalsIgnoreCase(item)) {
                    return cvm;
                }
            }
        }
        return UNKNOWN;
    }

    /**
     * NOT_AUTHENTICATED
     * ONLINE_PIN
     * OFFLINE_PIN
     * ELECTRONIC_SIGNATURE_ANALYSIS
     * MANUAL_SIGNATURE
     * MANUAL_OTHER
     * UNKNOWN
     * SYSTEMATIC_OTHER
     * E_TICKET_ENV_AMEX
     */

    public String getTsysValue() {

        String tsysValue;
        switch (this) {
            case PLAINTEXT_PIN_OFFLINE:
                tsysValue = "OFFLINE_PIN";
                break;
            case ENCIPHERED_PIN_VERIFIED_ONLINE:
                tsysValue = "ONLINE_PIN";
                break;
            case PLAINTEXT_PIN_VERIFIED_OFFLINE_PAPER_SIGNATURE:
            case SIGNATURE:
                tsysValue = "MANUAL_SIGNATURE";
                break;
            case UNKNOWN:
                tsysValue = "UNKNOWN";
                break;
            case FAIL_CVM_PROCESSING:
            case NO_CVM:
            default:
                tsysValue = "NOT_AUTHENTICATED";
                break;
        }
        return tsysValue;
    }

    public static TransitCvm cvmFromTsysValue(String value) {
        for (TransitCvm cvm : TransitCvm.values()) {
            if (cvm.getTsysValue().equalsIgnoreCase(value)) {
                return cvm;
            }
        }
        return UNKNOWN;
    }
}
