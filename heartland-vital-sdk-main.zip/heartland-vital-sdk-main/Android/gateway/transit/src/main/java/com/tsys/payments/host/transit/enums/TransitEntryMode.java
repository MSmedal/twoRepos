package com.tsys.payments.host.transit.enums;

public enum TransitEntryMode {
    SWIPE,
    INSERT,
    TAP,
    MANUAL,
    SWIPE_OR_INSERT,
    SWIPE_OR_TAP,
    SWIPE_TAP_OR_INSERT, EntryMode;

    TransitEntryMode() {
    }
}
