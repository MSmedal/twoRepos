package com.tsys.payments.host.transit.webservices.enums;

import timber.log.Timber;

public enum TransitPaymentType {
    CreditCard(100000),
    Cash(100001),
    Check(100003),
    GiftCertificate(100004),
    DebitCard(100005),
    GiftCard(100006);

    public int key;

    TransitPaymentType(int key) {
        this.key = key;
    }

    public static TransitPaymentType fromKey(int key) {
        for (TransitPaymentType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        switch (this) {
            case CreditCard:
                return "Credit Card";

            case Cash:
                return this.name();

            case Check:
                return this.name();

            case GiftCertificate:
                return "Gift Certificate";

            case DebitCard:
                return "Debit Card";

            case GiftCard:
                return "Gift Card";

            default:
                Timber.w("toString: Default");
                return "";
        }
    }
}
