package com.tsys.payments.host.transit.webservices.enums;

public enum TransitLogSource {
    AndroidPro(100001),
    AndroidMobile(100003),
    AndroidECR(100006);

    public int key;

    TransitLogSource(int key) {
        this.key = key;
    }

    public static TransitLogSource fromKey(int key) {
        for (TransitLogSource type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
