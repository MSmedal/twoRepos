package com.tsys.payments.host.transit;

import com.tsys.payments.host.transit.webservices.TransitTLS1_1And1_2SocketFactory;
import com.tsys.payments.library.exceptions.InitializationException;

import androidx.annotation.NonNull;
import okhttp3.ConnectionSpec;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.TlsVersion;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;

/**
 * See: <a href="https://github.com/square/okhttp/wiki/Interceptors">github.com/square/okhttp/wiki/Interceptors</a>
 */
final class TransitHttpClient {
    private static final String TAG = TransitHttpClient.class.getName();

    private TransitHttpClient() {
    }

    /**
     * Returns the default client provider used by Retrofit for Android but with support for only TLS v1.1 and v1.2.
     * Follow the "sees" below in the listed order to understand where this code is coming from.
     * <p/>
     * Note that the interceptor headers mechanism may be overridden by {@linkplain okhttp3.OkHttpClient OkHttpClient}
     * after a request has been serialized; in this case, the more widely accepted content type
     * {@code "application/xml"} will be used, unfortunately TSYS does not support it. See the
     * {@link TransitApi} client implementation for more details, and the usage of the
     * {@linkplain retrofit2.http.Headers @Headers} annotation.
     * <p/>
     * See: Platform.Android#defaultClient() (the method used to get the default client for Retrofit for Android
     * See: Platform.Android#hasOkHttpOnClasspath() (will always returns true for this project setup)
     *
     * @param connectionTimeout {@link Long} indicating the connection and read timeouts in milliseconds.
     * The {@link OkHttpClient#readTimeout} will be set to twice this value.
     */
    @NonNull
    static OkHttpClient.Builder getBaseClientBuilder(long connectionTimeout) throws InitializationException {
        OkHttpClient.Builder okHttpClient = new OkHttpClient.Builder();
        okHttpClient.connectTimeout(connectionTimeout, TimeUnit.MILLISECONDS);
        okHttpClient.readTimeout(connectionTimeout, TimeUnit.MILLISECONDS);
        okHttpClient.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(@NonNull Chain chain) throws IOException {
                okhttp3.Request original = chain.request();
                okhttp3.Request request = original.newBuilder()
                        .header("Content-Type", "text/xml; charset=UTF-8")
                        .method(original.method(), original.body())
                        .build();
                return chain.proceed(request);
            }
        });

        ConnectionSpec spec = new ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                .tlsVersions(TlsVersion.TLS_1_2)
                .build();
        List<ConnectionSpec> specList = new ArrayList<>(1);
        specList.add(spec);
        okHttpClient.connectionSpecs(specList);

        try {
            SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
            sslContext.init(null, null, null);
            okHttpClient.sslSocketFactory(new TransitTLS1_1And1_2SocketFactory(sslContext.getSocketFactory()));
        } catch (GeneralSecurityException e) {
            throw new InitializationException("TLSv1.2 is not supported on this device.");// The system has no TLSv1.1.
        }

        return okHttpClient;
    }
}
