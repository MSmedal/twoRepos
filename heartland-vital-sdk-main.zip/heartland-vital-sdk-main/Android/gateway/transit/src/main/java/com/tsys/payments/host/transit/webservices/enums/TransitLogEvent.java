package com.tsys.payments.host.transit.webservices.enums;

public enum TransitLogEvent {
    Generic(0),
    SecurityAudit(100001),
    ZipFinancialAudit(100002),
    ApiRequest(100003),
    ApiResponse(100004);

    public int key;

    TransitLogEvent(int key) {
        this.key = key;
    }

    public static TransitLogEvent fromKey(int key) {
        for (TransitLogEvent type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
