package com.tsys.payments.host.transit.webservices.generated;

public enum TransitCardDataSourceType {

    SWIPE,
    NFC,
    EMV,
    EMV_CONTACTLESS,
    BAR_CODE,
    MANUAL,
    PHONE,
    MAIL,
    INTERNET,
    FALLBACK_SWIPE;

    public static TransitCardDataSourceType fromValue(String v) {
        return valueOf(v);
    }
}
