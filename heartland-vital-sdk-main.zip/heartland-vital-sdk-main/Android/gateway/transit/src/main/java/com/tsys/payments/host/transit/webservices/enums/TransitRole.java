package com.tsys.payments.host.transit.webservices.enums;

public enum TransitRole {
    Cashier(1),
    Manager(2),
    Owner(3),
    Administrator(4),
    SystemAdministrator(5);

    public int key;

    TransitRole(int key) {
        this.key = key;
    }

    public static TransitRole fromKey(int key) {
        for (TransitRole type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
