package com.tsys.payments.host.transit.webservices.enums;

public enum TransitDeviceType {
    IosPro(100000),
    AndroidPro(100001),
    IosMobile(100002),
    AndroidMobile(100003),
    Virtual(100004),
    IosRegister(100005),
    AndroidRegister(100006);

    public int key;

    TransitDeviceType(int key) {
        this.key = key;
    }

    public static TransitDeviceType fromKey(int key) {
        for (TransitDeviceType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
