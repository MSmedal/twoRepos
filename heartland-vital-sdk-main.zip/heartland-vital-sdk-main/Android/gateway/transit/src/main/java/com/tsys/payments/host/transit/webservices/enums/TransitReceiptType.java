package com.tsys.payments.host.transit.webservices.enums;

public enum TransitReceiptType {
    None(0),
    Email(100000),
    Print(100002);

    public int key;

    TransitReceiptType(int key) {
        this.key = key;
    }

    public static TransitReceiptType fromKey(int key) {
        for (TransitReceiptType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
