package com.tsys.payments.host.transit.webservices.generated;

import com.tsys.payments.host.transit.webservices.TransitResponseCode;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Root;

import java.math.BigDecimal;

@Root(name = "BatchCloseResponse")
@Order(elements = {
        "status",
        "responseCode",
        "responseMessage",
        "batchInfo"
})
public class TransitBatchCloseResponse {

    @Element(required = true)
    protected String status;
    @Element(required = true)
    protected TransitResponseCode responseCode;
    @Element(required = true)
    protected String responseMessage;

    @Element(name = "batchInfo", type = TransitBatchInfo.class, required = false)
    protected TransitBatchInfo batchInfo;

    /**
     * Gets the value of the status property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     *
     * @param value allowed object is
     * {@link String }
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the responseCode property.
     *
     * @return possible object is
     * {@link TransitResponseCode }
     */
    public TransitResponseCode getResponseCode() {
        return responseCode;
    }

    /**
     * Sets the value of the responseCode property.
     *
     * @param value allowed object is
     * {@link TransitResponseCode }
     */
    public void setResponseCode(TransitResponseCode value) {
        this.responseCode = value;
    }

    /**
     * Gets the value of the responseMessage property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getResponseMessage() {
        return responseMessage;
    }

    /**
     * Sets the value of the responseMessage property.
     *
     * @param value allowed object is
     * {@link String }
     */
    public void setResponseMessage(String value) {
        this.responseMessage = value;
    }

    public TransitBatchInfo getBatchInfo() {
        return batchInfo;
    }

    public void setBatchInfo(TransitBatchInfo batchInfo) {
        this.batchInfo = batchInfo;
    }

    @Order(elements = {
            "deviceID",
            "userID",
            "SICCODE",
            "saleCount",
            "saleAmount",
            "returnCount",
            "returnAmount"
    })

    @Root(name = "batchInfo")
    @Default(value = DefaultType.FIELD, required = false)
    public static class TransitBatchInfo {
        protected String deviceID;
        protected String userID;
        @Element(name = "SICCODE", required = false)
        protected String sicCode;
        protected BigDecimal saleCount;
        protected BigDecimal saleAmount;
        protected BigDecimal returnCount;
        protected BigDecimal returnAmount;

        public String getDeviceID() {
            return deviceID;
        }

        public void setDeviceID(String deviceID) {
            this.deviceID = deviceID;
        }

        public String getUserID() {
            return userID;
        }

        public void setUserID(String userID) {
            this.userID = userID;
        }

        public String getSicCode() {
            return sicCode;
        }

        public void setSicCode(String sicCode) {
            this.sicCode = sicCode;
        }

        public BigDecimal getSaleCount() {
            return saleCount;
        }

        public void setSaleCount(BigDecimal saleCount) {
            this.saleCount = saleCount;
        }

        public BigDecimal getSaleAmount() {
            return saleAmount;
        }

        public void setSaleAmount(BigDecimal saleAmount) {
            this.saleAmount = saleAmount;
        }

        public BigDecimal getReturnCount() {
            return returnCount;
        }

        public void setReturnCount(BigDecimal returnCount) {
            this.returnCount = returnCount;
        }

        public BigDecimal getReturnAmount() {
            return returnAmount;
        }

        public void setReturnAmount(BigDecimal returnAmount) {
            this.returnAmount = returnAmount;
        }
    }
}
