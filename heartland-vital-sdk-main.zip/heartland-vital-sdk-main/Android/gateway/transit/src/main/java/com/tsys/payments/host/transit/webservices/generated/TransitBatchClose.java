package com.tsys.payments.host.transit.webservices.generated;

import com.tsys.payments.host.transit.webservices.TransitTransactionRequest;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Root;

@Root(name = "BatchClose")
@Default(value = DefaultType.FIELD, required = false)
@Order(elements = {
        "deviceID",
        "transactionKey",
        "manifest",
        "operatingUserID",
        "batchCloseParameter"
})
public class TransitBatchClose implements TransitTransactionRequest {

    protected String deviceID;
    protected String transactionKey;
    protected String manifest;
    protected String operatingUserID;
    protected TransitBatchCloseParameter batchCloseParameter;

    @Override
    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    @Override
    public String getTransactionKey() {
        return transactionKey;
    }

    public void setTransactionKey(String transactionKey) {
        this.transactionKey = transactionKey;
    }

    @Override
    public String getManifest() {
        return manifest;
    }

    public void setManifest(String manifest) {
        this.manifest = manifest;
    }

    public String getOperatingUserID() {
        return operatingUserID;
    }

    public void setOperatingUserID(String operatingUserID) {
        this.operatingUserID = operatingUserID;
    }

    public TransitBatchCloseParameter getBatchCloseParameter() {
        return batchCloseParameter;
    }

    public void setBatchCloseParameter(TransitBatchCloseParameter batchCloseParameter) {
        this.batchCloseParameter = batchCloseParameter;
    }

    @Default(value = DefaultType.FIELD, required = false)
    @Order(elements = {
            "deviceID",
            "userID"
    })
    public static class TransitBatchCloseParameter {
        protected String deviceID;
        protected String userID;

        public String getDeviceID() {
            return deviceID;
        }

        public void setDeviceID(String deviceID) {
            this.deviceID = deviceID;
        }

        public String getUserID() {
            return userID;
        }

        public void setUserID(String userID) {
            this.userID = userID;
        }
    }
}
