package com.tsys.payments.host.transit.enums;

public enum TransitCvmResult {
    UNKNOWN("00"),
    FAILED("01"),
    SUCCESS("02");

    private String mValue;

    TransitCvmResult(String value) {
        mValue = value;
    }

    public String getValue() {
        return mValue;
    }

    public static TransitCvmResult cvmResultFromString(String value) {
        for (TransitCvmResult cvmResult : TransitCvmResult.values()) {
            if (value.equalsIgnoreCase(cvmResult.getValue())) {
                return cvmResult;
            }
        }
        return UNKNOWN;
    }
}
