package com.tsys.payments.host.transit.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;

import com.tsys.payments.library.utils.LibraryConfigHelper;

import androidx.annotation.NonNull;
import timber.log.Timber;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;

public class TransitFileHelper {

    private static final String TAG = TransitFileHelper.class.getSimpleName();

    public static String getFilesDir(@NonNull Context context) {
        return context.getFilesDir().getAbsolutePath();
    }

    public static boolean fileExists(@NonNull String filePath) {
        File f = new File(filePath);
        return f.exists();
    }

    public static void deleteFile(@NonNull String sourceFilePath) {
        if (fileExists(sourceFilePath)) {
            File f = new File(sourceFilePath);
            f.delete();
        }
    }

    public static Bitmap loadBitmap(String sourceFilePath, boolean downSample) {
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            if (downSample) {
                options.inSampleSize = 2;
            }

            return BitmapFactory.decodeFile(sourceFilePath, options);
        } catch (Exception e) {
            Timber.e(e);
        }
        return null;
    }

    public static void copyDbToStorage(@NonNull Context context, String dbFilename,
            String storageDirName) {
        if (LibraryConfigHelper.isDebug()) {
            boolean externalStorageAvailable;
            boolean externalStorageWriteable;
            String state = Environment.getExternalStorageState();

            if (Environment.MEDIA_MOUNTED.equals(state)) {
                externalStorageAvailable = externalStorageWriteable = true;
            } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
                externalStorageAvailable = true;
                externalStorageWriteable = false;
            } else {
                externalStorageAvailable = externalStorageWriteable = false;
            }

            try {
                if (externalStorageAvailable && externalStorageWriteable) {
                    File srcFile = context.getApplicationContext().getDatabasePath(dbFilename);

                    File extDir =
                            new File(Environment.getExternalStorageDirectory().getAbsolutePath());
                    File dstFile = new File(extDir, '/' + storageDirName + '/' + dbFilename);
                    dstFile.getParentFile().mkdirs();
                    dstFile.createNewFile();
                    @SuppressWarnings("resource")
                    FileChannel inChannel = new FileInputStream(srcFile).getChannel();
                    @SuppressWarnings("resource")
                    FileChannel outChannel = new FileOutputStream(dstFile).getChannel();
                    try {
                        inChannel.transferTo(0, inChannel.size(), outChannel);
                    } finally {
                        if (inChannel != null) {
                            inChannel.close();
                        }
                        if (outChannel != null) {
                            outChannel.close();
                        }
                    }

                    // poke mediascanner for file availability over MTP
                    new TransitMediaScannerNotifier(context.getApplicationContext(), Environment
                            .getExternalStorageDirectory()
                            .getAbsolutePath() + '/' + storageDirName + '/' + dbFilename,
                            "text/plain");

                    Timber.d("DATABASE \"" + dbFilename + "\" COPIED TO STORAGE");
                }
            } catch (Exception e) {
                Timber.e(e);
            }
        }
    }
}
