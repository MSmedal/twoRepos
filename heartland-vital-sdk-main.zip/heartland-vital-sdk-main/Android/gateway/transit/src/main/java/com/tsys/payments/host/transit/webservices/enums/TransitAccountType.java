package com.tsys.payments.host.transit.webservices.enums;

public enum TransitAccountType {
    Restaurant(100000),
    Retail(100001);

    public int key;

    TransitAccountType(int key) {
        this.key = key;
    }

    public static TransitAccountType fromKey(int key) {
        for (TransitAccountType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
