package com.tsys.payments.host.transit.webservices.enums;

public enum TransitExceptionCode {
    ServerError(90000),
    BadRequest(90001),
    AuthenticationFailed(90002),
    AuthenticationTokenFailed(90003),
    NotAuthorized(90004),
    NotFound(90005),
    NotImplemented(90006),
    NotSupported(90007),
    ProcessError(90008),
    UserPasswordExpired(90009),
    GiftProviderError(90010),
    GatewayProviderError(90011),
    LoyaltyProviderError(90012),
    ProviderConfigurationError(90013),
    DecryptorError(90014),
    AccountLockedOut(90015),
    DiscountValidationProviderError(90016),
    InvalidCertificate(90017),
    PasswordChangeLimitExceeded(90018),
    PasswordRepeated(90019),
    RegisterUnassigned(90020),
    DecryptionError(90021),
    ForceAuthNotSupported(90022),
    RegisterNotFound(90023),
    ProviderTimeout(90024),
    TransactionLocked(90025),
    TotalsMismatch(90026);

    public int key;

    TransitExceptionCode(int key) {
        this.key = key;
    }

    public static TransitExceptionCode fromKey(int key) {
        for (TransitExceptionCode type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
