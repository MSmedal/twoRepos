package com.tsys.payments.host.transit.enums;

public enum TransitCodeType {
    Approval,
    PartialApproval,
    Unknown,
    ConnectionError,
    Denial
}
