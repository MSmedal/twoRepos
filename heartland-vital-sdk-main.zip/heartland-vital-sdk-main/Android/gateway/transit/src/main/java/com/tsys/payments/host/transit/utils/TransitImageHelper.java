package com.tsys.payments.host.transit.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import androidx.annotation.NonNull;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;

import java.io.ByteArrayOutputStream;

public class TransitImageHelper {
    public static String encodeBase64Image(@NonNull Bitmap bitmap) {
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream);
        byte[] imageByteArray = outStream.toByteArray();
        return Base64.encodeToString(imageByteArray, Base64.NO_WRAP);
    }

    public static Bitmap decodeBase64Image(@NonNull String base64ImageText) {
        byte[] imageAsBytes = Base64.decode(base64ImageText.getBytes(), Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.length);
    }

    public static int dp2px(@NonNull Context context, int dp) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        float px = dp * (metrics.densityDpi / 160f);
        return (int)px;
    }

    public static int px2dp(@NonNull Context context, float px) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        double dp = px / (metrics.densityDpi / 160f);
        return (int)dp;
    }

    /**
     * Gets the left position in pixels of passed view in relation to the root view
     *
     * @param myView Anchor view for measuring
     *
     * @return Position in pixels
     */
    public static int getRelativeLeft(@NonNull View myView) {
        if (myView.getParent() == myView.getRootView()) {
            return myView.getLeft();
        } else {
            return myView.getLeft() + getRelativeLeft((View)myView.getParent());
        }
    }

    /**
     * Gets the top position in pixels of passed view in relation to the root view
     *
     * @param myView Anchor view for measuring
     *
     * @return Position in pixels
     */
    public static int getRelativeTop(@NonNull View myView) {
        if (myView.getParent() == myView.getRootView()) {
            return myView.getTop();
        } else {
            return myView.getTop() + getRelativeTop((View)myView.getParent());
        }
    }

    /**
     * Returns the input color with a calculated darker shade
     *
     * @param color The color to manipulate
     *
     * @return A darker shade of the input color
     */
    public static int getDarkerColor(int color) {
        float brightness = 0.5f; // 0.0 - 1.0
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] *= brightness;
        return Color.HSVToColor(hsv);
    }
}
