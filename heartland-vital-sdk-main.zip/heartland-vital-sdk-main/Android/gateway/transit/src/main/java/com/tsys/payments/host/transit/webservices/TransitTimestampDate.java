package com.tsys.payments.host.transit.webservices;

import java.util.Date;

/**
 * Custom date for handling timestamp formatted date objects.
 */
public class TransitTimestampDate extends Date {
}
