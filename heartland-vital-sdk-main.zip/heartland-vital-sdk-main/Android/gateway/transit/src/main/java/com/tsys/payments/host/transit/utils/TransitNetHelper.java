/*

 Copyright 2013 iMobile3, LLC. All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, is permitted provided that adherence to the following
 conditions is maintained. If you do not agree with these terms,
 please do not use, install, modify or redistribute this software.

 1. Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.

 2. Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY IMOBILE3, LLC "AS IS" AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 EVENT SHALL IMOBILE3, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

package com.tsys.payments.host.transit.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.tsys.payments.host.transit.constants.TransitIds;
import com.tsys.payments.library.enums.HttpStatusCode;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.util.InetAddressUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TransitNetHelper {

    private static final String TAG = TransitNetHelper.class.getSimpleName();

    public static final int DEFAULT_HTTP_TIMEOUT = 30000;

    public class HttpURLResponse {
        private int mResponseCode;
        private String mResponseBody;

        public int getResponseCode() {
            return mResponseCode;
        }

        public void setResponseCode(int responseCode) {
            mResponseCode = responseCode;
        }

        public String getResponseBody() {
            return mResponseBody;
        }

        public void setResponseBody(String responseBody) {
            mResponseBody = responseBody;
        }
    }

    public static boolean hasConnection(@NonNull Context context, boolean verboseLogging) {
        ConnectivityManager cm = (ConnectivityManager)context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnected()) {
            if (verboseLogging) {
                TransitLogHelper.write(TAG, "Network connection: " + getConnectionInfo(context, netInfo));
            }
            return true;
        }
        if (verboseLogging) {
            TransitLogHelper.write(TAG, "Network disconnected");
        }
        return false;
    }

    @NonNull
    private static String getConnectionInfo(@Nullable Context context, @Nullable NetworkInfo netInfo) {
        if (context == null || netInfo == null) {
            return "N/A";
        }
        return netInfo.getTypeName() + " @ " + getLocalIpv4Address();
    }

    public static String getLocalIpv4Address() {
        try {
            String ipv4;
            List<NetworkInterface> nilist =
                    Collections.list(NetworkInterface.getNetworkInterfaces());
            if (nilist.size() > 0) {
                for (NetworkInterface ni : nilist) {
                    List<InetAddress> ialist = Collections.list(ni.getInetAddresses());
                    if (ialist.size() > 0) {
                        for (InetAddress address : ialist) {
                            if (!address.isLoopbackAddress() &&
                                    InetAddressUtils
                                            .isIPv4Address(ipv4 = address.getHostAddress())) {
                                return ipv4;
                            }
                        }
                    }
                }
            }
        } catch (SocketException e) {
            TransitLogHelper.write(TAG, e);
        }
        return "";
    }

    @NonNull
    private static DefaultHttpClient createHttpClient(int customTimeout) {
        HttpParams params = new BasicHttpParams();
        if (customTimeout < 1) {
            HttpConnectionParams.setConnectionTimeout(params, DEFAULT_HTTP_TIMEOUT);
            HttpConnectionParams.setSoTimeout(params, DEFAULT_HTTP_TIMEOUT);
        } else {
            HttpConnectionParams.setConnectionTimeout(params, customTimeout);
            HttpConnectionParams.setSoTimeout(params, customTimeout);
        }
        HttpProtocolParams.setContentCharset(params, HTTP.UTF_8);
        HttpProtocolParams.setHttpElementCharset(params, HTTP.UTF_8);
        DefaultHttpClient client = new DefaultHttpClient(params);
        return client;
    }

    @Nullable
    public static HttpURLResponse get(String url, @NonNull Map<String, String> headers) {
        return get(url, headers, TransitIds.UNDEFINED);
    }

    @Nullable
    public static HttpURLResponse get(String url, @NonNull Map<String, String> headers,
            int customTimeout) {
        String requestMethod = "GET";
        HttpURLResponse response = null;

        try {
            TransitLogHelper.write(TAG, requestMethod, url, headers);

            HttpClient httpclient = createHttpClient(customTimeout);
            HttpGet httpGet = new HttpGet(url);

            setHeaders(httpGet, headers);

            HttpResponse httpResponse = httpclient.execute(httpGet);

            int responseCode = getHttpResponseCode(httpResponse);
            String responseBody = getHttpResponseBody(httpResponse);

            TransitLogHelper.write(TAG, requestMethod, url, headers, getHttpResponseHeaders(httpResponse),
                    responseCode, responseBody);

            response = new TransitNetHelper().new HttpURLResponse();
            response.setResponseCode(responseCode);
            response.setResponseBody(responseBody);
        } catch (Exception e) {
            TransitLogHelper.write(TAG, requestMethod, url, headers, e);
        }

        return response;
    }

    @Nullable
    public static HttpURLResponse saveImage(String url, @NonNull Map<String, String> headers,
            @NonNull String localFilePath) {
        return saveImage(url, headers, localFilePath, TransitIds.UNDEFINED);
    }

    @Nullable
    public static HttpURLResponse saveImage(String url, @NonNull Map<String, String> headers,
            @NonNull String localFilePath, int customTimeout) {
        String requestMethod = "GET";
        HttpURLResponse response = null;

        try {
            TransitLogHelper.write(TAG, requestMethod, url, headers);

            HttpClient httpclient = createHttpClient(customTimeout);
            HttpGet httpGet = new HttpGet(url);

            setHeaders(httpGet, headers);

            HttpResponse httpResponse = httpclient.execute(httpGet);

            int responseCode = getHttpResponseCode(httpResponse);

            response = new TransitNetHelper().new HttpURLResponse();
            if (HttpStatusCode.fromKey(responseCode) == HttpStatusCode.OK) {
                Boolean success = saveHttpResponseBody(httpResponse, localFilePath);
                TransitLogHelper.write(TAG, requestMethod, url, headers,
                        getHttpResponseHeaders(httpResponse), responseCode,
                        "response saved to: " + localFilePath + ": " + success);
            }
            response.setResponseCode(responseCode);

            if (HttpStatusCode.fromKey(responseCode) != HttpStatusCode.OK) {
                String responseBody = getHttpResponseBody(httpResponse);
                response.setResponseBody(responseBody);
                TransitLogHelper.write(TAG, requestMethod, url, headers,
                        getHttpResponseHeaders(httpResponse), responseCode, responseBody);
            }
        } catch (Exception e) {
            TransitLogHelper.write(TAG, requestMethod, url, headers, e);
        }

        return response;
    }

    @Nullable
    public static HttpURLResponse post(String url, @NonNull Map<String, String> headers) {
        return post(url, headers, TransitIds.UNDEFINED);
    }

    @Nullable
    public static HttpURLResponse post(String url, @NonNull Map<String, String> headers,
            int customTimeout) {
        String requestMethod = "POST";
        HttpURLResponse response = null;

        try {
            TransitLogHelper.write(TAG, requestMethod, url, headers);

            HttpClient httpclient = createHttpClient(customTimeout);
            HttpPost httpPost = new HttpPost(url);

            setHeaders(httpPost, headers);

            HttpResponse httpResponse = httpclient.execute(httpPost);

            int responseCode = getHttpResponseCode(httpResponse);
            String responseBody = getHttpResponseBody(httpResponse);

            TransitLogHelper.write(TAG, requestMethod, url, headers, getHttpResponseHeaders(httpResponse),
                    responseCode, responseBody);

            response = new TransitNetHelper().new HttpURLResponse();
            response.setResponseCode(responseCode);
            response.setResponseBody(responseBody);
        } catch (Exception e) {
            TransitLogHelper.write(TAG, requestMethod, url, headers, e);
        }

        return response;
    }

    @Nullable
    public static HttpURLResponse post(String url, @NonNull Map<String, String> headers,
            String requestBody) {
        return post(url, headers, requestBody, TransitIds.UNDEFINED);
    }

    @Nullable
    public static HttpURLResponse post(String url, @NonNull Map<String, String> headers, String requestBody,
            int customTimeout) {
        return post(url, headers, requestBody, customTimeout, true);
    }

    @Nullable
    public static HttpURLResponse post(String url, @NonNull Map<String, String> headers, String requestBody,
            int customTimeout, boolean verbose) {
        String requestMethod = "POST";
        HttpURLResponse response = null;

        try {
            if (verbose) {
                TransitLogHelper.write(TAG, requestMethod, url, headers, requestBody);
            }

            HttpClient httpclient = createHttpClient(customTimeout);
            HttpPost httpPost = new HttpPost(url);

            setHeaders(httpPost, headers);
            setHttpRequestBody(httpPost, requestBody);

            HttpResponse httpResponse = httpclient.execute(httpPost);

            int responseCode = getHttpResponseCode(httpResponse);
            String responseBody = getHttpResponseBody(httpResponse);
            if (verbose) {
                TransitLogHelper.write(TAG, requestMethod, url, headers, requestBody,
                        getHttpResponseHeaders(httpResponse), responseCode, responseBody);
            }

            response = new TransitNetHelper().new HttpURLResponse();
            response.setResponseCode(responseCode);
            response.setResponseBody(responseBody);
        } catch (Exception e) {
            if (verbose) {
                TransitLogHelper.write(TAG, requestMethod, url, headers, requestBody, e);
            }
        }

        return response;
    }

    @Nullable
    public static HttpURLResponse put(String url, @NonNull Map<String, String> headers) {
        return put(url, headers, TransitIds.UNDEFINED);
    }

    @Nullable
    public static HttpURLResponse put(String url, @NonNull Map<String, String> headers,
            int customTimeout) {
        String requestMethod = "PUT";
        HttpURLResponse response = null;

        try {
            TransitLogHelper.write(TAG, requestMethod, url, headers);

            HttpClient httpclient = createHttpClient(customTimeout);
            HttpPut httpPut = new HttpPut(url);

            setHeaders(httpPut, headers);

            HttpResponse httpResponse = httpclient.execute(httpPut);

            int responseCode = getHttpResponseCode(httpResponse);
            String responseBody = getHttpResponseBody(httpResponse);

            TransitLogHelper.write(TAG, requestMethod, url, headers, getHttpResponseHeaders(httpResponse),
                    responseCode, responseBody);

            response = new TransitNetHelper().new HttpURLResponse();
            response.setResponseCode(responseCode);
            response.setResponseBody(responseBody);
        } catch (Exception e) {
            TransitLogHelper.write(TAG, requestMethod, url, headers, e);
        }

        return response;
    }

    @Nullable
    public static HttpURLResponse put(String url, @NonNull Map<String, String> headers, String requestBody) {
        return put(url, headers, requestBody, TransitIds.UNDEFINED);
    }

    @Nullable
    public static HttpURLResponse put(String url, @NonNull Map<String, String> headers, String requestBody,
            int customTimeout) {
        String requestMethod = "PUT";
        HttpURLResponse response = null;

        try {
            TransitLogHelper.write(TAG, requestMethod, url, headers, requestBody);

            HttpClient httpclient = createHttpClient(customTimeout);
            HttpPut httpPut = new HttpPut(url);

            setHeaders(httpPut, headers);
            setHttpRequestBody(httpPut, requestBody);

            HttpResponse httpResponse = httpclient.execute(httpPut);

            int responseCode = getHttpResponseCode(httpResponse);
            String responseBody = getHttpResponseBody(httpResponse);

            TransitLogHelper.write(TAG, requestMethod, url, headers, requestBody,
                    getHttpResponseHeaders(httpResponse), responseCode, responseBody);

            response = new TransitNetHelper().new HttpURLResponse();
            response.setResponseCode(responseCode);
            response.setResponseBody(responseBody);
        } catch (Exception e) {
            TransitLogHelper.write(TAG, requestMethod, url, headers, requestBody, e);
        }

        return response;
    }

    @Nullable
    public static HttpURLResponse delete(String url, @NonNull Map<String, String> headers) {
        return delete(url, headers, TransitIds.UNDEFINED);
    }

    @Nullable
    public static HttpURLResponse delete(String url, @NonNull Map<String, String> headers,
            int customTimeout) {
        String requestMethod = "DELETE";
        HttpURLResponse response = null;

        try {
            TransitLogHelper.write(TAG, requestMethod, url, headers);

            HttpClient httpclient = createHttpClient(customTimeout);
            HttpDelete httpDelete = new HttpDelete(url);

            setHeaders(httpDelete, headers);

            HttpResponse httpResponse = httpclient.execute(httpDelete);

            int responseCode = getHttpResponseCode(httpResponse);
            String responseBody = getHttpResponseBody(httpResponse);

            TransitLogHelper.write(TAG, requestMethod, url, headers, getHttpResponseHeaders(httpResponse),
                    responseCode, responseBody);

            response = new TransitNetHelper().new HttpURLResponse();
            response.setResponseCode(responseCode);
            response.setResponseBody(responseBody);
        } catch (Exception e) {
            TransitLogHelper.write(TAG, requestMethod, url, headers, e);
        }

        return response;
    }

    // Helpers

    private static void setHeaders(@NonNull HttpGet httpGet, @NonNull Map<String, String> headers) {
        for (Map.Entry<String, String> pair : headers.entrySet()) {
            httpGet.setHeader(pair.getKey(), pair.getValue());
        }
    }

    private static void setHeaders(@NonNull HttpPost httpPost, @NonNull Map<String, String> headers) {
        for (Map.Entry<String, String> pair : headers.entrySet()) {
            httpPost.setHeader(pair.getKey(), pair.getValue());
        }
    }

    private static void setHeaders(@NonNull HttpPut httpPut, @NonNull Map<String, String> headers) {
        for (Map.Entry<String, String> pair : headers.entrySet()) {
            httpPut.setHeader(pair.getKey(), pair.getValue());
        }
    }

    private static void setHeaders(@NonNull HttpDelete httpDelete, @NonNull Map<String, String> headers) {
        for (Map.Entry<String, String> pair : headers.entrySet()) {
            httpDelete.setHeader(pair.getKey(), pair.getValue());
        }
    }

    private static int getHttpResponseCode(@NonNull HttpResponse response) throws Exception {
        return response.getStatusLine().getStatusCode();
    }

    private static void setHttpRequestBody(@NonNull HttpPost httpPost, @Nullable String requestBody)
            throws Exception {
        if (requestBody != null) {
            StringEntity se = new StringEntity(requestBody, HTTP.UTF_8);
            httpPost.setEntity(se);
        }
    }

    private static void setHttpRequestBody(@NonNull HttpPut httpPut, @Nullable String requestBody)
            throws Exception {
        if (requestBody != null) {
            StringEntity se = new StringEntity(requestBody, HTTP.UTF_8);
            httpPut.setEntity(se);
        }
    }

    @NonNull
    public static Map<String, String> getHttpResponseHeaders(@NonNull HttpResponse response)
            throws Exception {
        Map<String, String> responseHeaders = new HashMap<>();

        Header[] headers = response.getAllHeaders();
        for (Header header : headers) {
            responseHeaders.put(header.getName(), header.getValue());
        }
        return responseHeaders;
    }

    public static String getHttpResponseBody(@NonNull HttpResponse response) throws Exception {
        HttpEntity entity = response.getEntity();
        InputStream instream = entity.getContent();

        BufferedReader reader = new BufferedReader(new InputStreamReader(instream));
        StringBuilder stringBuilder = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line + '\n');
            }
        } catch (Exception e) {
            TransitLogHelper.write(e);
            return null;
        } finally {
            try {
                instream.close();
            } catch (Exception e) {
                TransitLogHelper.write(e);
                return null;
            }
        }

        return stringBuilder.toString();
    }

    public static boolean saveHttpResponseBody(@NonNull HttpResponse response, @NonNull String localFilePath)
            throws Exception {
        TransitFileHelper.deleteFile(localFilePath);

        HttpEntity entity = response.getEntity();
        InputStream instream = entity.getContent();
        OutputStream outstream = new BufferedOutputStream(new FileOutputStream(localFilePath));

        byte[] buffer = new byte[65536];
        int len;
        try {
            while ((len = instream.read(buffer)) != -1) {
                outstream.write(buffer, 0, len);
            }
        } catch (Exception e) {
            TransitLogHelper.write(e);
            return false;
        } finally {
            try {
                instream.close();
                outstream.close();
            } catch (Exception e) {
                TransitLogHelper.write(e);
                return false;
            }
        }

        return true;
    }
}
