package com.tsys.payments.host.transit.enums;

import androidx.annotation.NonNull;

import com.tsys.payments.host.transit.webservices.TransitResponseCode;

public enum TransactionResult {

    /**
     * Indicates the transaction was successfully authorized.
     */
    APPROVED,

    /**
     * Indicates the transaction was ultimately declined, either offline or by the processor.
     */
    DECLINED,

    /**
     * Indicates the transaction was cancelled by the user. If the transaction was cancelled after an online
     * authorization was successful a reversal will be issued. Receipt information will be present containing the
     * reversal data.
     */
    USER_CANCELLED,

    /**
     * Indicates the card is blocked by the issuer and should not be processed. No Receipt information is present.
     */
    CARD_BLOCKED,

    /**
     * Indicates that the selected EMV application has been blocked by the issuer. No receipt information is present.
     */
    APPLICATION_BLOCKED,

    /**
     * Indicates there was an error with the terminal or swiper. No receipt information is present.
     */
    DEVICE_ERROR,

    /**
     * Indicates the transaction could not be processed by the host and has been terminated. Receipt information is
     * made available.
     */
    HOST_TIMEOUT,

    /**
     * Indicates the transaction could not be processed because the host is currently unavailable.
     */
    HOST_UNAVAILABLE,

    /**
     * Indicates the transaction could not be completed because the host gateway credentials were invalid.
     */
    HOST_INVALID_CREDENTIALS,

    /**
     * Indicates the chip was removed prematurely. If the card was removed prior to online processing a reversal will
     * be generated. Receipt information will contain reversal data if it was generated.
     */
    CARD_REMOVED,

    /**
     * Indicates that no transaction ID was not supplied, or the supplied transaction ID is not valid
     */
    INVALID_REFUND_TRANSACTION_ID,
    MISSING_REQUIRED_TRANSACTION_DATA,
    PROCESSING_ERROR,
    UNKNOWN,
    PARTIAL_APPROVAL,
    POST_AUTH_CHIP_DECLINE,
    OFFLINE_DECLINED,
    OFFLINE_APPROVED,
    CARD_INTERFACE_GENERAL_ERROR,
    NO_MUTUALLY_SUPPORTED_AIDS,
    CARD_READER_TRANSACTION_TIMEOUT,
    NOT_ACCEPTED,
    UNKNOWN_HOST;

    TransactionResult() {
    }

    public static TransactionResult valueOf(TransitResponseCode responseCode) {
        TransactionResult result = null;
        switch (responseCode.getCodeType()) {

            case Approval:
            case PartialApproval:
                result = APPROVED;
                break;
            case Unknown:
                result = UNKNOWN;
                break;
            case ConnectionError:
                result = getTransactionResultForConnectionError(responseCode);
                break;
            case Denial:
                result = DECLINED;
                break;
        }
        return result;
    }

    @NonNull
    private static TransactionResult getTransactionResultForConnectionError(TransitResponseCode responseCode) {
        TransactionResult result;
        switch (responseCode) {
            case HOST_UNAVAILABLE:
                result = HOST_UNAVAILABLE;
                break;
            case UNKNOWN_HOST:
                result = UNKNOWN_HOST;
                break;
            case HOST_TIMEOUT:
                result = HOST_TIMEOUT;
                break;
            default:
                result = UNKNOWN;
                break;
        }
        return result;
    }
}
