package com.tsys.payments.host.transit.webservices.enums;

public enum TransitGlyphType {
    Restaurant(100000, "Restaurant", "glyphs_restaurant.ttf"),
    ApparelAccessories(100001, "Apparel & Accessories", "glyphs_apparel-accessories.ttf"),
    ElectronicsAppliancesKitchen(100002, "Electronics, Appliances, & Kitchen",
            "glyphs_electronics-appliances-kitchen.ttf"),
    SportsToysBaby(100003, "Sports, Toys, & Baby", "glyphs_sports-toys-baby.ttf"),
    FurnitureToolsAuto(100004, "Furniture, Tools, & Auto", "glyphs_furniture-tools-auto.ttf"),
    HealthPetMisc(100005, "Health, Pet, & Misc", "glyphs_health-pet-misc.ttf");

    public int key;
    public String displayName;
    public String fontAsset;

    TransitGlyphType(int key, String displayName, String fontAsset) {
        this.key = key;
        this.displayName = displayName;
        this.fontAsset = fontAsset;
    }

    public static TransitGlyphType fromKey(int key) {
        for (TransitGlyphType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }

    public static TransitGlyphType fromDisplayName(String displayName) {
        for (TransitGlyphType type : values()) {
            if (type.displayName.equals(displayName)) {
                return type;
            }
        }
        return null;
    }
}
