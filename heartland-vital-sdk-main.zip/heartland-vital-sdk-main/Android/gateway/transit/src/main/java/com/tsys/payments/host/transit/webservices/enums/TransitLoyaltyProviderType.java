package com.tsys.payments.host.transit.webservices.enums;

public enum TransitLoyaltyProviderType {
    None(10000),
    PassMarket(10001);

    public int key;

    private TransitLoyaltyProviderType(int key) {
        this.key = key;
    }

    public static TransitLoyaltyProviderType fromKey(int key) {
        for (TransitLoyaltyProviderType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
