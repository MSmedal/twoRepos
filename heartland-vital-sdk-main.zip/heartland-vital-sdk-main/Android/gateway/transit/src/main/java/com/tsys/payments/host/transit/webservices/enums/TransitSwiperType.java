package com.tsys.payments.host.transit.webservices.enums;

public enum TransitSwiperType {
    ROAMG5XROAMDecryption,
    ROAMG5XTSYSDecryption,
    IngenicoMoby3000,
    IngenicoMoby8500,
    IngenicoRP350,
    IngenicoRP450c,
    IngenicoRP45Bt,
}
