package com.tsys.payments.host.transit.webservices.enums;

public enum TransitTipMethod {
    None(100000),
    Retail(100001),
    Restaurant(100002);

    public int key;

    TransitTipMethod(int key) {
        this.key = key;
    }

    public static TransitTipMethod fromKey(int key) {
        for (TransitTipMethod type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
