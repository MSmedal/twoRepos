package com.tsys.payments.host.transit.enums;

public enum TransitCvmCode {
    Always("00"),
    If_unattended_cash("01"),
    If_not_unattended_cash_and_not_manual_cash_and_not_purchase_with_cashback("02"),
    If_terminal_supports_the_CVM_20("03"),
    If_manual_cash("04"),
    If_purchase_with_cashback("05"),
    If_transaction_is_in_the_application_currency_21_and_is_under_X_value("06"),
    If_transaction_is_in_the_application_currency_and_is_over_X_value("07"),
    If_transaction_is_in_the_application_currency_and_is_under_Y_value_("08"),
    If_transaction_is_in_the_application_currency_and_is_over_Y_value("09");

    private String mValue;

    TransitCvmCode(String value) {
        mValue = value;
    }

    public String getValue() {
        return mValue;
    }

    public TransitCvmCode cvmCodeFromString(String value) throws Exception {
        for (TransitCvmCode cvmCode : TransitCvmCode.values()) {
            if (value.equalsIgnoreCase(cvmCode.getValue())) {
                return cvmCode;
            }
        }
        return Always;
    }
}
