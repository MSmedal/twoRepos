package com.tsys.payments.host.transit.webservices.enums;

public enum TransitCategoryType {
    Category(100000),
    SubCategory(100001),
    Group(100002);

    public int key;

    TransitCategoryType(int key) {
        this.key = key;
    }

    public static TransitCategoryType fromKey(int key) {
        for (TransitCategoryType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
