package com.tsys.payments.host.transit.webservices.generated;

import com.tsys.payments.host.transit.webservices.TransitResponseCode;
import com.tsys.payments.host.transit.webservices.TransitTransactionResponse;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Root;

import java.util.Date;

/**
 * <p>Java class for anonymous complex type.
 * <p>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;group ref="{}result"/>
 *         &lt;group ref="{}hostResponseData" minOccurs="0"/>
 *         &lt;group ref="{}transactionResponseData" minOccurs="0"/>
 *         &lt;group ref="{}voidAmountResponseData" minOccurs="0"/>
 *         &lt;group ref="{}cardResponseData" minOccurs="0"/>
 *         &lt;group ref="{}cardBrandTokenVoidResponseData" minOccurs="0"/>
 *         &lt;group ref="{}receiptResponseData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@Default(value = DefaultType.FIELD, required = false)
@Order(elements = {
        "status",
        "responseCode",
        "responseMessage",
        "authCode",
        "hostReferenceNumber",
        "taskID",
        "transactionID",
        "transactionTimestamp",
        "orderNumber",
        "externalReferenceID",
        "transactionAmount",
        "voidedAmount",
        "cardType",
        "maskedCardNumber",
        "token",
        "expirationDate",
        "accountUpdaterResponseCode",
        "commercialCard",
        "cavvResponseCode",
        "ucafCollectionIndicator",
        "paymentAccountReference",
        "panReferenceIdentifier",
        "balanceAmount",
        "fcsID",
        "transactionIntegrityClassification",
        "tokenAssuranceLevel",
        "maskedPAN",
        "customerReceipt",
        "merchantReceipt",
        "consolidatedCustomerReceipt",
        "consolidatedMerchantReceipt"
})
@Root(name = "VoidResponse")
public class TransitVoidResponse implements TransitTransactionResponse {

    @Element(required = true)
    protected String status;
    @Element(required = true)
    protected TransitResponseCode responseCode;
    @Element(required = true)
    protected String responseMessage;
    protected String authCode;
    protected String hostReferenceNumber;
    protected String taskID;
    protected String transactionID;
    protected String balanceAmount;
    protected Date transactionTimestamp;
    protected String orderNumber;
    protected String externalReferenceID;
    protected String transactionAmount;
    protected String voidedAmount;
    protected String cardType;
    protected String maskedCardNumber;
    protected String token;
    protected String expirationDate;
    protected String accountUpdaterResponseCode;
    protected String commercialCard;
    protected String cavvResponseCode;
    protected String ucafCollectionIndicator;
    protected String paymentAccountReference;
    protected String panReferenceIdentifier;
    protected String fcsID;
    protected String transactionIntegrityClassification;
    protected String tokenAssuranceLevel;
    protected String maskedPAN;
    protected String customerReceipt;
    protected String merchantReceipt;
    protected String consolidatedCustomerReceipt;
    protected String consolidatedMerchantReceipt;

    public void setStatus(String status) {
        this.status = status;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(String balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public void setTransactionTimestamp(Date transactionTimestamp) {
        this.transactionTimestamp = transactionTimestamp;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getExternalReferenceID() {
        return externalReferenceID;
    }

    public void setExternalReferenceID(String externalReferenceID) {
        this.externalReferenceID = externalReferenceID;
    }

    public String getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(String transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public String getVoidedAmount() {
        return voidedAmount;
    }

    public void setVoidedAmount(String voidedAmount) {
        this.voidedAmount = voidedAmount;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public void setMaskedCardNumber(String maskedCardNumber) {
        this.maskedCardNumber = maskedCardNumber;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getAccountUpdaterResponseCode() {
        return accountUpdaterResponseCode;
    }

    public void setAccountUpdaterResponseCode(String accountUpdaterResponseCode) {
        this.accountUpdaterResponseCode = accountUpdaterResponseCode;
    }

    public String getCommercialCard() {
        return commercialCard;
    }

    public void setCommercialCard(String commercialCard) {
        this.commercialCard = commercialCard;
    }

    public String getCavvResponseCode() {
        return cavvResponseCode;
    }

    public void setCavvResponseCode(String cavvResponseCode) {
        this.cavvResponseCode = cavvResponseCode;
    }

    public String getUcafCollectionIndicator() {
        return ucafCollectionIndicator;
    }

    public void setUcafCollectionIndicator(String ucafCollectionIndicator) {
        this.ucafCollectionIndicator = ucafCollectionIndicator;
    }

    public String getPaymentAccountReference() {
        return paymentAccountReference;
    }

    public void setPaymentAccountReference(String paymentAccountReference) {
        this.paymentAccountReference = paymentAccountReference;
    }

    public String getPanReferenceIdentifier() {
        return panReferenceIdentifier;
    }

    public void setPanReferenceIdentifier(String panReferenceIdentifier) {
        this.panReferenceIdentifier = panReferenceIdentifier;
    }

    public String getFcsID() {
        return fcsID;
    }

    public void setFcsID(String fcsID) {
        this.fcsID = fcsID;
    }

    public String getTransactionIntegrityClassification() {
        return transactionIntegrityClassification;
    }

    public void setTransactionIntegrityClassification(String transactionIntegrityClassification) {
        this.transactionIntegrityClassification = transactionIntegrityClassification;
    }

    public String getTokenAssuranceLevel() {
        return tokenAssuranceLevel;
    }

    public void setTokenAssuranceLevel(String tokenAssuranceLevel) {
        this.tokenAssuranceLevel = tokenAssuranceLevel;
    }

    public String getMaskedPAN() {
        return maskedPAN;
    }

    public void setMaskedPAN(String maskedPAN) {
        this.maskedPAN = maskedPAN;
    }

    public void setCustomerReceipt(String customerReceipt) {
        this.customerReceipt = customerReceipt;
    }

    public void setMerchantReceipt(String merchantReceipt) {
        this.merchantReceipt = merchantReceipt;
    }

    public String getConsolidatedCustomerReceipt() {
        return consolidatedCustomerReceipt;
    }

    public void setConsolidatedCustomerReceipt(String consolidatedCustomerReceipt) {
        this.consolidatedCustomerReceipt = consolidatedCustomerReceipt;
    }

    public String getConsolidatedMerchantReceipt() {
        return consolidatedMerchantReceipt;
    }

    public void setConsolidatedMerchantReceipt(String consolidatedMerchantReceipt) {
        this.consolidatedMerchantReceipt = consolidatedMerchantReceipt;
    }

    /**
     * Gets the value of the status property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getStatus() {
        return status;
    }

    /**
     * Gets the value of the responseCode property.
     *
     * @return possible object is
     * {@link String }
     */
    public TransitResponseCode getResponseCode() {
        return responseCode;
    }

    /**
     * Sets the value of the responseCode property.
     *
     * @param value allowed object is
     * {@link String }
     */
    public void setResponseCode(TransitResponseCode value) {
        this.responseCode = value;
    }

    /**
     * Gets the value of the responseMessage property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getResponseMessage() {
        return responseMessage;
    }

    /**
     * Sets the value of the responseMessage property.
     *
     * @param value allowed object is
     * {@link String }
     */
    public void setResponseMessage(String value) {
        this.responseMessage = value;
    }

    /**
     * Gets the value of the authCode property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getAuthCode() {
        return authCode;
    }

    /**
     * Gets the value of the hostReferenceNumber property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getHostReferenceNumber() {
        return hostReferenceNumber;
    }

    /**
     * Sets the value of the hostReferenceNumber property.
     *
     * @param value allowed object is
     * {@link String }
     */
    public void setHostReferenceNumber(String value) {
        this.hostReferenceNumber = value;
    }

    /**
     * Gets the value of the taskID property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getTaskID() {
        return taskID;
    }

    /**
     * Gets the value of the transactionID property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Gets the value of the transactionTimestamp property.
     *
     * @return possible object is
     * {@link String }
     */
    public Date getTransactionTimestamp() {
        return transactionTimestamp;
    }

    /**
     * Gets the value of the cardType property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Gets the value of the maskedCardNumber property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getMaskedCardNumber() {
        return maskedCardNumber;
    }

    /**
     * Gets the value of the customerReceipt property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCustomerReceipt() {
        return customerReceipt;
    }

    /**
     * Gets the value of the merchantReceipt property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getMerchantReceipt() {
        return merchantReceipt;
    }
}
