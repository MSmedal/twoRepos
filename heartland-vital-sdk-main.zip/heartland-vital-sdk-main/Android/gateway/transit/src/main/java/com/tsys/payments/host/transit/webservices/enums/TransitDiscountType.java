package com.tsys.payments.host.transit.webservices.enums;

public enum TransitDiscountType {

    Amount(10000),
    Percentage(10001);

    public int key;

    TransitDiscountType(int key) {
        this.key = key;
    }

    public static TransitDiscountType fromKey(int key) {
        for (TransitDiscountType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }

}
