package com.tsys.payments.host.transit.webservices.enums;

import androidx.annotation.NonNull;

public enum TransitTransactionResult {

    /**
     * Indicates the transaction was successfully authorized.
     */
    APPROVED,

    /**
     * Indicates the transaction was ultimately declined, either offline or by the processor.
     */
    DECLINED,

    /**
     * Indicates the transaction was cancelled by the user. If the transaction was cancelled after an online
     * authorization was successful a reversal will be issued. Receipt information will be present containing the
     * reversal data.
     */
    USER_CANCELLED,

    /**
     * Indicates the card is blocked by the issuer and should not be processed. No Receipt information is present.
     */
    CARD_BLOCKED,

    /**
     * Indicates that the selected EMV application has been blocked by the issuer. No receipt information is present.
     */
    APPLICATION_BLOCKED,

    /**
     * Indicates there was an error with the terminal or swiper. No receipt information is present.
     */
    DEVICE_ERROR,

    /**
     * Indicates the transaction could not be processed by the host and has been terminated. Receipt information is
     * made available.
     */
    HOST_TIMEOUT,

    /**
     * Indicates the transaction could not be processed because the host is currently unavailable.
     */
    HOST_UNAVAILABLE,

    /**
     * Indicates the transaction could not be completed because the host gateway credentials were invalid.
     */
    HOST_INVALID_CREDENTIALS,

    /**
     * Indicates the chip was removed prematurely. If the card was removed prior to online processing a reversal will
     * be generated. Receipt information will contain reversal data if it was generated.
     */
    CARD_REMOVED,

    /**
     * Indicates that no transaction ID was not supplied, or the supplied transaction ID is not valid
     */
    INVALID_REFUND_TRANSACTION_ID,
    MISSING_REQUIRED_TRANSACTION_DATA,
    PROCESSING_ERROR,
    UNKNOWN,
    PARTIAL_APPROVAL,
    POST_AUTH_CHIP_DECLINE,
    OFFLINE_DECLINED,
    OFFLINE_APPROVED,
    CARD_INTERFACE_GENERAL_ERROR,
    NO_MUTUALLY_SUPPORTED_AIDS,
    CARD_READER_TRANSACTION_TIMEOUT,
    NOT_ACCEPTED,
    UNKNOWN_HOST;

    public static boolean isConnectionError(@NonNull TransitTransactionResult transactionResult) {
        return transactionResult == HOST_UNAVAILABLE || transactionResult ==
                UNKNOWN_HOST || transactionResult == HOST_TIMEOUT;
    }

    TransitTransactionResult() {
    }
}
