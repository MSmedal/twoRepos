package com.tsys.payments.host.transit;

final class TransitCredentialKeys {

    static final String TRANSACTION_KEY = "transaction_key";

    static final String DEVICE_ID = "device_id";

    static final String DEBUG = "debug";

    static final String APP_VERSION = "app_version";

    static final String CUSTOMER_CODE = "customer_code";

    private TransitCredentialKeys() {
        // no instance
    }
}
