package com.tsys.payments.host.transit;

import android.text.TextUtils;

import com.tsys.payments.host.transit.constants.TransitIds;
import com.tsys.payments.host.transit.enums.TransitCardholderAuthenticationMethod;
import com.tsys.payments.host.transit.webservices.TransitResponseCode;
import com.tsys.payments.host.transit.webservices.TransitTimestampDate;
import com.tsys.payments.host.transit.webservices.enums.TransitTaxCategoryType;
import com.tsys.payments.host.transit.webservices.generated.TransitAuth;
import com.tsys.payments.host.transit.webservices.generated.TransitAuthResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitBatchClose;
import com.tsys.payments.host.transit.webservices.generated.TransitBatchClose.TransitBatchCloseParameter;
import com.tsys.payments.host.transit.webservices.generated.TransitBatchCloseResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitCapture;
import com.tsys.payments.host.transit.webservices.generated.TransitCaptureResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitCardDataSourceType;
import com.tsys.payments.host.transit.webservices.generated.TransitCurrencyCodeType;
import com.tsys.payments.host.transit.webservices.generated.TransitForcedAuth;
import com.tsys.payments.host.transit.webservices.generated.TransitForcedAuthResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitReturn;
import com.tsys.payments.host.transit.webservices.generated.TransitReturnResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitSale;
import com.tsys.payments.host.transit.webservices.generated.TransitSaleResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitTransactionAdjustment;
import com.tsys.payments.host.transit.webservices.generated.TransitTransactionAdjustmentResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitVoid;
import com.tsys.payments.host.transit.webservices.generated.TransitVoidResponse;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.TerminalCapabilities;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.enums.CommercialCard;
import com.tsys.payments.library.enums.CommercialCardDataField;
import com.tsys.payments.library.enums.TaxCategory;
import com.tsys.payments.library.enums.TerminalAuthenticationCapability;
import com.tsys.payments.library.enums.TerminalInputCapability;
import com.tsys.payments.library.enums.TerminalOperatingEnvironment;
import com.tsys.payments.library.enums.TerminalOutputCapability;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.tlv.ConstructedTlvObject;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map.Entry;

class TransitModelConverter {
    private static final String TAG = TransitModelConverter.class.getCanonicalName();
    private static final String INVALID_HOST_RESPONSE_AMOUNT =
            "Invalid authorized amount returned by the host.";
    private static final String EMV_DECLINE_RESPONSE = "8A023035";
    private static final String TRANSIT_STATUS_FAIL = "FAIL";
    private static final String TRANSIT_STATUS_PASS = "PASS";
    private static final String COMMERCIAL_CARD_LEVEL = "LEVEL2";

    private TransitModelConverter() {
        // No instance
    }

    @NonNull
    static TransitAuth toAuthRequest(@NonNull GatewayRequest request) {
        TransitAuth authRequest = new TransitAuth();
        authRequest.setExternalReferenceID(request.getPosReferenceNumber());
        if (request.getTax() != null) {
            authRequest.setSalesTax(new BigDecimal(request.getTax()));
        }
        if (request.getTip() != null) {
            authRequest.setTip(new BigDecimal(request.getTip()));
        }
        authRequest.setTransactionAmount(new BigDecimal(request.getTotal()));
        authRequest.setCurrencyCode(TransitCurrencyCodeType.USD);
        TerminalCapabilities terminalCapabilities = request.getTerminalCapabilities();

        if (request.getTaxCategory() == TaxCategory.TAX_EXEMPT) {
            TransitSale.AdditionalTaxDetails taxDetails = new TransitSale.AdditionalTaxDetails();
            if (request.getTax() != null) {
                taxDetails.setTaxAmount(new BigDecimal(request.getTax()));
            }
            taxDetails.setTaxType("TAX EXEMPT");
            taxDetails.setTaxCategory(TransitTaxCategoryType.TAX_EXEMPT);
            authRequest.getAdditionalTaxDetails().add(taxDetails);
        } else {
            if (request.getTax() != null) {
                authRequest.setSalesTax(new BigDecimal(request.getTax()));
            }
        }

        if (terminalCapabilities != null) {
            authRequest.setTerminalOperatingEnvironment(
                    terminalCapabilities.getOperatingEnvironment().name());
            authRequest.setTerminalAuthenticationCapability(
                    terminalCapabilities.getAuthenticationCapability().name());
            authRequest
                    .setTerminalOutputCapability(terminalCapabilities.getOutputCapability().name());
            authRequest.setTerminalCapability(terminalCapabilities.getInputCapability().name());
        } else {
            authRequest.setTerminalCapability(
                    TerminalInputCapability.MAGSTRIPE_ICC_KEYED_ENTRY_ONLY.name());
            authRequest
                    .setTerminalOutputCapability(TerminalOutputCapability.PRINT_AND_DISPLAY.name());
            authRequest.setTerminalAuthenticationCapability(
                    TerminalAuthenticationCapability.NO_CAPABILITY.name());
            authRequest
                    .setTerminalOperatingEnvironment(
                            TerminalOperatingEnvironment.ON_MERCHANT_PREMISES_ATTENDED.name());
        }

        authRequest.setCardholderAuthenticationMethod(
                TransitCardholderAuthenticationMethod
                        .fromCvmResult(request.getCvmResult()).displayName);
        authRequest.setMaxPinLength(TransitIds.MAX_PIN_LENGTH);
        TransitConversionHelper.populateAuthCardSwipeData(authRequest, request);

        authRequest.setOrderNumber(request.getInvoiceNumber());
        updateCommercialDataInAuthRequestIfAvailable(authRequest, request);
        authRequest.setCommercialCardLevel(COMMERCIAL_CARD_LEVEL);

        return authRequest;
    }

    static GatewayResponse toGatewayResponse(@NonNull TransitAuthResponse gatewayResponse) {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.AUTH);
        sdkResponse.setApproved(TransitConversionHelper
                .isOnlineApproved(gatewayResponse, gatewayResponse.getResponseCode()));
        if (sdkResponse.isApproved() || sdkResponse.isPartialApproval()) {
            validateHostResponseAmount(sdkResponse, gatewayResponse.getProcessedAmount());
        }
        checkForMalformedTransactionResponse(sdkResponse, gatewayResponse.getResponseCode());
        if (gatewayResponse.getTip() != null) {
            sdkResponse.setTipAmount(getFinancialAmountFromString(gatewayResponse.getTip()));
        }
        sdkResponse.setGatewayTransactionId(gatewayResponse.getTransactionID());
        sdkResponse.setAuthCode(gatewayResponse.getAuthCode());
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        sdkResponse.setCardType(getCardTypeFromGatewayResponse(gatewayResponse.getCardType()));
        sdkResponse.setCommercialCard(
                getCommercialCardFromGatewayResponse(gatewayResponse.getCommercialCard()));
        sdkResponse.setMaskedPan(gatewayResponse.getMaskedCardNumber());

        if (gatewayResponse.getEmvIssuerScripts() != null) {
            List<TlvObject> tlvObjectList =
                    ConstructedTlvObject.parse(gatewayResponse.getEmvIssuerScripts());

            for (TlvObject object : tlvObjectList) {
                if (object.getTagDescriptor() == EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_1 ||
                        object.getTagDescriptor() == EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_2) {
                    sdkResponse.setEmvIssuerScripts(object.asHexString());
                }
            }
        }
        sdkResponse.setAuthCode(sdkResponse.getAuthCode());
        sdkResponse.setEmvIssuerAuthCode(sdkResponse.getEmvIssuerAuthCode());
        sdkResponse
                .setEmvIssuerAuthenticationData(gatewayResponse.getEmvIssuerAuthenticationData());
        return sdkResponse;
    }

    static TransitSale toSaleRequest(@NonNull GatewayRequest request) {
        TransitSale saleRequest = new TransitSale();
        saleRequest.setExternalReferenceID(request.getPosReferenceNumber());
        if (request.getTax() != null) {
            saleRequest.setSalesTax(new BigDecimal(request.getTax()));
        }
        if (request.getTip() != null) {
            saleRequest.setTip(new BigDecimal(request.getTip()));
        }
        saleRequest.setTransactionAmount(new BigDecimal(request.getTotal()));
        saleRequest.setCurrencyCode(TransitCurrencyCodeType.USD);

        if (request.getTaxCategory() == TaxCategory.TAX_EXEMPT) {
            TransitSale.AdditionalTaxDetails taxDetails = new TransitSale.AdditionalTaxDetails();
            if (request.getTax() != null) {
                taxDetails.setTaxAmount(new BigDecimal(request.getTax()));
            }
            taxDetails.setTaxType("TAX EXEMPT");
            taxDetails.setTaxCategory(TransitTaxCategoryType.TAX_EXEMPT);
            saleRequest.getAdditionalTaxDetails().add(taxDetails);
        } else if (request.getTax() != null) {
            saleRequest.setSalesTax(new BigDecimal(request.getTax()));
        }

        TransitConversionHelper.populateSaleCardSwipeData(saleRequest, request);

        saleRequest.setOrderNumber(request.getInvoiceNumber());
        updateCommercialDataInSaleRequestIfAvailable(saleRequest, request);
        saleRequest.setCommercialCardLevel(COMMERCIAL_CARD_LEVEL);

        TerminalCapabilities terminalCapabilities = request.getTerminalCapabilities();
        if (terminalCapabilities != null) {
            saleRequest.setTerminalOperatingEnvironment(
                    terminalCapabilities.getOperatingEnvironment().name());
            saleRequest.setTerminalAuthenticationCapability(
                    terminalCapabilities.getAuthenticationCapability().name());
            saleRequest
                    .setTerminalOutputCapability(terminalCapabilities.getOutputCapability().name());
            saleRequest.setTerminalCapability(terminalCapabilities.getInputCapability().name());
        } else {
            saleRequest.setTerminalCapability(
                    TerminalInputCapability.MAGSTRIPE_ICC_KEYED_ENTRY_ONLY.name());
            saleRequest
                    .setTerminalOutputCapability(TerminalOutputCapability.PRINT_AND_DISPLAY.name());
            saleRequest.setTerminalAuthenticationCapability(
                    TerminalAuthenticationCapability.NO_CAPABILITY.name());
            saleRequest
                    .setTerminalOperatingEnvironment(
                            TerminalOperatingEnvironment.ON_MERCHANT_PREMISES_ATTENDED.name());
        }
        saleRequest.setCardholderAuthenticationMethod(
                TransitCardholderAuthenticationMethod
                        .fromCvmResult(request.getCvmResult()).displayName);
        saleRequest.setMaxPinLength(TransitIds.MAX_PIN_LENGTH);
        return saleRequest;
    }

    static GatewayResponse toGatewayResponse(@NonNull TransitSaleResponse gatewayResponse) {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.SALE);
        sdkResponse.setApproved(
                TransitConversionHelper
                        .isOnlineApproved(gatewayResponse, gatewayResponse.getResponseCode()));
        validateHostResponseAmount(sdkResponse, gatewayResponse.getProcessedAmount());
        checkForMalformedTransactionResponse(sdkResponse, gatewayResponse.getResponseCode());
        if (gatewayResponse.getTip() != null) {
            sdkResponse.setTipAmount(getFinancialAmountFromString(gatewayResponse.getTip()));
        }
        sdkResponse.setAuthCode(gatewayResponse.getAuthCode());
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        sdkResponse.setGatewayTransactionId(gatewayResponse.getTransactionID());
        sdkResponse.setCardType(getCardTypeFromGatewayResponse(gatewayResponse.getCardType()));
        sdkResponse.setCommercialCard(
                getCommercialCardFromGatewayResponse(gatewayResponse.getCommercialCard()));
        sdkResponse.setMaskedPan(gatewayResponse.getMaskedCardNumber());
        if (gatewayResponse.getEmvIssuerScripts() != null) {
            List<TlvObject> tlvObjectList =
                    ConstructedTlvObject.parse(gatewayResponse.getEmvIssuerScripts());
            for (TlvObject object : tlvObjectList) {
                if (object.getTagDescriptor() == EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_1 ||
                        object.getTagDescriptor() == EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_2) {
                    sdkResponse.setEmvIssuerScripts(object.asHexString());
                }
            }
        }
        sdkResponse.setAuthCode(gatewayResponse.getAuthCode());
        sdkResponse.setEmvIssuerAuthCode(gatewayResponse.getEmvIssuerAuthorizationCode());
        if (TextUtils.isEmpty(gatewayResponse.getEmvIssuerAuthorizationCode())) {
            if (TRANSIT_STATUS_FAIL.equals(gatewayResponse.getStatus())) {
                sdkResponse.setEmvIssuerAuthCode(EMV_DECLINE_RESPONSE);
            }
        }
        sdkResponse
                .setEmvIssuerAuthenticationData(gatewayResponse.getEmvIssuerAuthenticationData());
        return sdkResponse;
    }

    static TransitForcedAuth toForcedAuthRequest(@NonNull GatewayRequest request) {
        TransitForcedAuth forcedAuthRequest = new TransitForcedAuth();
        CardData cardData = request.getCardData();
        if (cardData != null) {
            forcedAuthRequest.setExpirationDate(cardData.getExpirationDate());
            forcedAuthRequest.setCardNumber(cardData.getPan());
            forcedAuthRequest.setCvv2(cardData.getCvv2());
            forcedAuthRequest.setCardHolderName(cardData.getCardholderName());
            if (cardData.getCardholderAddress() != null) {
                String zipCode = cardData.getCardholderAddress().getPostalCode();
                String addressLine1 = cardData.getCardholderAddress().getAddressLine1();
                if (!TextUtils.isEmpty(zipCode)) {
                    forcedAuthRequest.setZip(zipCode);
                }
                if (!TextUtils.isEmpty(addressLine1)) {
                    forcedAuthRequest.setAddressLine1(addressLine1);
                }
            }
        }
        if (request.getTax() != null) {
            forcedAuthRequest.setSalesTax(new BigDecimal(request.getTax()));
        }
        if (request.getTip() != null) {
            forcedAuthRequest.setTip(new BigDecimal(request.getTip()));
        }
        forcedAuthRequest.setOrderNumber(request.getInvoiceNumber());
        forcedAuthRequest.setTransactionAmount(new BigDecimal(request.getTotal()));
        forcedAuthRequest.setCurrencyCode(TransitCurrencyCodeType.USD);
        forcedAuthRequest.setAuthTimestamp(new TransitTimestampDate());
        forcedAuthRequest.setCardDataSource(TransitCardDataSourceType.MANUAL);
        forcedAuthRequest.setAuthCode(request.getForceAuthCode());
        return forcedAuthRequest;
    }

    static GatewayResponse toGatewayResponse(@NonNull TransitForcedAuthResponse gatewayResponse) {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.FORCE_AUTH);
        sdkResponse.setApproved(
                TransitConversionHelper
                        .isOnlineApproved(gatewayResponse, gatewayResponse.getResponseCode()));
        checkForMalformedTransactionResponse(sdkResponse, gatewayResponse.getResponseCode());
        if (gatewayResponse.getTip() != null) {
            sdkResponse.setTipAmount(gatewayResponse.getTip().longValue());
        }
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        sdkResponse.setCardType(getCardTypeFromGatewayResponse(gatewayResponse.getCardType()));
        sdkResponse.setMaskedPan(gatewayResponse.getMaskedCardNumber());
        sdkResponse.setGatewayTransactionId(gatewayResponse.getTransactionID());
        sdkResponse.setAuthCode(sdkResponse.getAuthCode());
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        return sdkResponse;
    }

    static TransitReturn toRefundRequest(@NonNull GatewayRequest request)
            throws IllegalArgumentException {
        TransitReturn returnRequest = new TransitReturn();
        CardData cardData = request.getCardData();
        if (cardData == null) {
            if (TransitConversionHelper
                    .longTransactionIdFromString(request.getGatewayTransactionId()) !=
                    TransitApi.TRANSACTIONLESS_TRANSACTION_ID) {
                returnRequest.setTransactionID(request.getGatewayTransactionId());
            }
        } else {
            if (request.getTotal() <= 0 ||
                    (request.getTip() != null && request.getTotal() - request.getTip() <= 0)) {
                throw new IllegalArgumentException(
                        "A positive dollar amount is required for a return.");
            }
            returnRequest.setTransactionAmount(new BigDecimal(request.getTotal()));
            TransitConversionHelper.populateReturnSwipeData(returnRequest, request);
        }
        returnRequest.setCurrencyCode(TransitCurrencyCodeType.USD);

        return returnRequest;
    }

    static TransitReturn toPartialRefundRequest(@NonNull GatewayRequest request)
            throws IllegalArgumentException {
        TransitReturn returnRequest = new TransitReturn();
        CardData cardData = request.getCardData();
        if (cardData == null) {
            if (TransitConversionHelper
                    .longTransactionIdFromString(request.getGatewayTransactionId()) !=
                    TransitApi.TRANSACTIONLESS_TRANSACTION_ID) {
                returnRequest.setTransactionID(request.getGatewayTransactionId());
                returnRequest.setTransactionAmount(new BigDecimal(request.getTotal()));
                if (request.getTip() != null) {
                    returnRequest.setTip(new BigDecimal(request.getTip()));
                }
                if (request.getTax() != null) {
                    returnRequest.setSalesTax(new BigDecimal(request.getTax()));
                }
            }
        } else {
            if (request.getTotal() <= 0 ||
                    (request.getTip() != null && request.getTotal() - request.getTip() <= 0)) {
                throw new IllegalArgumentException(
                        "A positive dollar amount is required for a return.");
            }
            returnRequest.setTransactionAmount(new BigDecimal(request.getTotal()));
            TransitConversionHelper.populateReturnSwipeData(returnRequest, request);
        }
        returnRequest.setCurrencyCode(TransitCurrencyCodeType.USD);

        return returnRequest;
    }

    static GatewayResponse toGatewayResponse(@NonNull TransitReturnResponse gatewayResponse,
            @NonNull GatewayAction refundAction) {
        GatewayResponse sdkResponse = new GatewayResponse(refundAction);
        sdkResponse.setAuthCode(gatewayResponse.getAuthCode());
        if (TRANSIT_STATUS_PASS.equals(gatewayResponse.getStatus())) {
            sdkResponse.setApproved(true);
        }
        sdkResponse.setGatewayResponseText(gatewayResponse.toString());
        sdkResponse.setGatewayTransactionId(gatewayResponse.getTransactionID());
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        sdkResponse.setCardType(getCardTypeFromGatewayResponse(gatewayResponse.getCardType()));
        sdkResponse.setMaskedPan(gatewayResponse.getMaskedCardNumber());
        validateHostResponseAmount(sdkResponse, gatewayResponse.getReturnedAmount());
        return sdkResponse;
    }

    static TransitVoid toVoidRequest(@NonNull GatewayRequest request) {
        TransitVoid voidRequest = new TransitVoid();
        voidRequest.setTransactionAmount(new BigDecimal(request.getTotal()));
        voidRequest.setTransactionID(request.getGatewayTransactionId());
        if (request.getReversalReason() != null) {
            voidRequest.setVoidReason(
                    TransitConversionHelper.getVoidReasonFromSdk(request.getReversalReason()));
        }
        if (TextUtils.isEmpty(voidRequest.getTransactionID())) {
            voidRequest.setExternalReferenceID(request.getPosReferenceNumber());
        }
        voidRequest.setCurrencyCode(TransitCurrencyCodeType.USD);
        return voidRequest;
    }

    static TransitCapture toCaptureRequest(@NonNull GatewayRequest request) {
        TransitCapture captureRequest = new TransitCapture();
        captureRequest.setTip((request.getTip() != null) ? new BigDecimal(request.getTip()) :
                BigDecimal.ZERO);
        captureRequest.setTransactionAmount(new BigDecimal(request.getTotal()));
        captureRequest.setTransactionID(request.getGatewayTransactionId());

        updateCommercialDataInCaptureRequestIfAvailable(captureRequest, request);
        captureRequest.setCommercialCardLevel(COMMERCIAL_CARD_LEVEL);

        return captureRequest;
    }

    static GatewayResponse toGatewayResponse(@NonNull TransitVoidResponse gatewayResponse) {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.VOID);
        validateHostResponseAmount(sdkResponse, gatewayResponse.getVoidedAmount());
        sdkResponse.setCardType(getCardTypeFromGatewayResponse(gatewayResponse.getCardType()));
        sdkResponse.setGatewayTransactionId(gatewayResponse.getTransactionID());
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        if (TRANSIT_STATUS_PASS.equals(gatewayResponse.getStatus())) {
            sdkResponse.setApproved(true);
        }
        sdkResponse.setMaskedPan(gatewayResponse.getMaskedCardNumber());
        return sdkResponse;
    }

    static GatewayResponse toGatewayResponse(@NonNull TransitCaptureResponse gatewayResponse) {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.CAPTURE);
        validateHostResponseAmount(sdkResponse, gatewayResponse.getTotalAmount());
        if (gatewayResponse.getTip() != null) {
            sdkResponse.setTipAmount(gatewayResponse.getTip().longValue());
        }
        sdkResponse.setGatewayTransactionId(gatewayResponse.getTransactionID());
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        sdkResponse.setApproved(TransitConversionHelper
                .isOnlineApproved(gatewayResponse, gatewayResponse.getResponseCode()));
        return sdkResponse;
    }

    @NonNull
    static TransitTransactionAdjustment toTransactionAdjustmentRequest(
            @NonNull GatewayRequest gatewayRequest) {
        TransitTransactionAdjustment transitTransactionAdjustmentRequest =
                new TransitTransactionAdjustment();

        transitTransactionAdjustmentRequest.setTip((gatewayRequest.getTip() != null) ?
                new BigDecimal(gatewayRequest.getTip()) :
                BigDecimal.ZERO);
        transitTransactionAdjustmentRequest
                .setTransactionAmount(new BigDecimal(gatewayRequest.getTotal()));
        transitTransactionAdjustmentRequest.setSalesTax(gatewayRequest.getTax() != null ?
                new BigDecimal(gatewayRequest.getTax()) :
                BigDecimal.ZERO);
        transitTransactionAdjustmentRequest
                .setTransactionID(gatewayRequest.getGatewayTransactionId());

        updateCommercialDataInAdjustmentRequestIfAvailable(transitTransactionAdjustmentRequest,
                gatewayRequest);
        transitTransactionAdjustmentRequest.setCommercialCardLevel(COMMERCIAL_CARD_LEVEL);
        return transitTransactionAdjustmentRequest;
    }

    static GatewayResponse toGatewayResponse(@NonNull
            TransitTransactionAdjustmentResponse gatewayResponse) {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.TRANSACTION_ADJUSTMENT);
        validateHostResponseAmount(sdkResponse, gatewayResponse.getTotalAmount());
        if (gatewayResponse.getTip() != null) {
            sdkResponse.setTipAmount(gatewayResponse.getTip().longValue());
        }
        sdkResponse.setGatewayTransactionId(gatewayResponse.getTransactionID());
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        sdkResponse.setApproved(TransitConversionHelper
                .isOnlineApproved(gatewayResponse, gatewayResponse.getResponseCode()));
        return sdkResponse;
    }

    @NonNull
    static TransitBatchClose toCloseBatchRequest(@NonNull String deviceId,
            @NonNull GatewayRequest gatewayRequest) {

        TransitBatchClose closeBatchRequest = new TransitBatchClose();
        closeBatchRequest.setOperatingUserID(gatewayRequest.getOperatingUserId());

        TransitBatchCloseParameter batchCloseParameter = new TransitBatchCloseParameter();
        batchCloseParameter.setDeviceID(deviceId);
        closeBatchRequest.setBatchCloseParameter(batchCloseParameter);

        return closeBatchRequest;
    }

    static GatewayResponse toGatewayResponse(@NonNull TransitBatchCloseResponse gatewayResponse) {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.BATCH_CLOSE);
        sdkResponse.setGatewayResponseText(gatewayResponse.getResponseMessage());
        sdkResponse.setApproved(TransitConversionHelper.isOnlineApproved(gatewayResponse));
        return sdkResponse;
    }

    private static void updateCommercialDataInAuthRequestIfAvailable(@NonNull TransitAuth request,
            GatewayRequest gatewayRequest) {

        if (isCommercialCardAvailable(gatewayRequest)) {

            for (Entry<CommercialCardDataField, String> currentField : gatewayRequest
                    .getCommercialCardData()
                    .getCommercialCardDataValues().entrySet()) {
                switch (currentField.getKey()) {
                    case CHARGE_DESCRIPTOR:
                        request.setChargeDescriptor(currentField.getValue());
                        break;
                    case PURCHASE_ORDER_NUMBER:
                        request.setPurchaseOrder(currentField.getValue());
                        break;
                    case CUSTOMER_REF_ID:
                        request.setCustomerRefID(currentField.getValue());
                        break;
                    case SUPPLIER_REF_NUMBER:
                        request.setSupplierReferenceNumber(currentField.getValue());
                        break;
                    case SHIP_TO_ZIP:
                        request.setShipToZip(currentField.getValue());
                        break;
                }
            }
        }
    }

    private static void updateCommercialDataInSaleRequestIfAvailable(@NonNull TransitSale request,
            GatewayRequest gatewayRequest) {

        if (isCommercialCardAvailable(gatewayRequest)) {

            for (Entry<CommercialCardDataField, String> currentField : gatewayRequest
                    .getCommercialCardData()
                    .getCommercialCardDataValues().entrySet()) {
                switch (currentField.getKey()) {
                    case CHARGE_DESCRIPTOR:
                        request.setChargeDescriptor(currentField.getValue());
                        break;
                    case PURCHASE_ORDER_NUMBER:
                        request.setPurchaseOrder(currentField.getValue());
                        break;
                    case CUSTOMER_REF_ID:
                        request.setCustomerRefID(currentField.getValue());
                        break;
                    case SUPPLIER_REF_NUMBER:
                        request.setSupplierReferenceNumber(currentField.getValue());
                        break;
                    case SHIP_TO_ZIP:
                        request.setShipToZip(currentField.getValue());
                        break;
                }
            }
        }
    }

    private static void updateCommercialDataInCaptureRequestIfAvailable(
            @NonNull TransitCapture request, GatewayRequest gatewayRequest) {

        if (isCommercialCardAvailable(gatewayRequest)) {
            for (Entry<CommercialCardDataField, String> currentField : gatewayRequest
                    .getCommercialCardData()
                    .getCommercialCardDataValues().entrySet()) {
                switch (currentField.getKey()) {
                    case CHARGE_DESCRIPTOR:
                        request.setChargeDescriptor(currentField.getValue());
                        break;
                    case PURCHASE_ORDER_NUMBER:
                        request.setPurchaseOrder(currentField.getValue());
                        break;
                    case CUSTOMER_REF_ID:
                        request.setCustomerRefID(currentField.getValue());
                        break;
                    case SUPPLIER_REF_NUMBER:
                        request.setSupplierReferenceNumber(currentField.getValue());
                        break;
                    case SHIP_TO_ZIP:
                        request.setShipToZip(currentField.getValue());
                        break;
                }
            }
        }
    }

    private static void updateCommercialDataInAdjustmentRequestIfAvailable(
            @NonNull TransitTransactionAdjustment request,
            GatewayRequest gatewayRequest) {

        if (isCommercialCardAvailable(gatewayRequest)) {
            for (Entry<CommercialCardDataField, String> currentField : gatewayRequest
                    .getCommercialCardData()
                    .getCommercialCardDataValues().entrySet()) {
                switch (currentField.getKey()) {
                    case PURCHASE_ORDER_NUMBER:
                        request.setPurchaseOrder(currentField.getValue());
                        break;
                    case SUPPLIER_REF_NUMBER:
                        request.setSupplierReferenceNumber(currentField.getValue());
                        break;
                    case CUSTOMER_REF_ID:
                        request.setCustomerRefID(currentField.getValue());
                        break;
                    case SHIP_TO_ZIP:
                        request.setShipToZip(currentField.getValue());
                        break;
                    case CHARGE_DESCRIPTOR:
                        request.setChargeDescriptor(currentField.getValue());
                        break;
                }
            }
        }
    }

    private static boolean isCommercialCardAvailable(GatewayRequest request) {
        return request != null && request.getCommercialCardData() != null &&
                request.getCommercialCardData().getCommercialCardDataValues() != null &&
                request.getCommercialCardData().getCommercialCardDataValues().size() > 0;
    }

    private static void checkForMalformedTransactionResponse(@NonNull GatewayResponse sdkResponse,
            @Nullable TransitResponseCode responseCode) {
        if (responseCode == TransitResponseCode.UNKNOWN_CODE) {
            /*
            Scenario indicating an invalid server response. This transaction should be reversed
            if possible. Otherwise the result will be sent back as a decline. Setting the timeout
            to true will invoke a timeout reversal if reversal is possible. That logic is negotiated
            in the TransactionManager class in the isReversalPossible() private method. If reversal
            is not possible the result will be sent back as a decline.
            */
            sdkResponse.setGatewayTimeout(true);
        }
    }

    private static void validateHostResponseAmount(GatewayResponse sdkResponse,
            String authorizedAmount) {
        try {
            sdkResponse.setApprovedAmount(getFinancialAmountFromString(authorizedAmount));
        } catch (NumberFormatException e) {
            Timber.e(e);
            sdkResponse.setError(true);
            sdkResponse.setErrorMessage(INVALID_HOST_RESPONSE_AMOUNT);
        }
    }

    @Nullable
    private static CardType getCardTypeFromGatewayResponse(@Nullable String gatewayCardType) {
        if ("V".equals(gatewayCardType)) {
            return CardType.VISA;
        } else if ("M".equals(gatewayCardType)) {
            return CardType.MASTERCARD;
        } else if ("R".equals(gatewayCardType)) {
            return CardType.DISCOVER;
        } else if ("X".equals(gatewayCardType)) {
            return CardType.AMERICAN_EXPRESS;
        } else if ("J".equals(gatewayCardType)) {
            return CardType.JCB;
        } else {
            return null;
        }
    }

    @Nullable
    private static CommercialCard getCommercialCardFromGatewayResponse(
            @Nullable String commercialCard) {
        if (TextUtils.isEmpty(commercialCard)) {
            return null;
        }

        switch (commercialCard) {
            case "B":
                return CommercialCard.BUSINESS;
            case "D":
                return CommercialCard.VISA_COMMERCE;
            case "L":
                return CommercialCard.B2B_SETTLEMENT_ELIGIBLE;
            case "R":
                return CommercialCard.CORPORATE;
            case "S":
                return CommercialCard.PURCHASE;
            case "0":
                return CommercialCard.NON_COMMERCIAL;
            default:
                return null;
        }
    }

    private static long getFinancialAmountFromString(@Nullable String amount)
            throws NumberFormatException {
        if (amount == null) {
            Timber.w("Attempt to convert null amount to Long. Returning 0");
            return 0;
        }
        return Long.parseLong(amount);
    }
}
