package com.tsys.payments.host.transit.webservices.enums;

public enum TransitAvsType {
    None(100000),
    Zip(100001),
    ZipAddress(100002);

    public int key;

    TransitAvsType(int key) {
        this.key = key;
    }

    public static TransitAvsType fromKey(int key) {
        for (TransitAvsType type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
