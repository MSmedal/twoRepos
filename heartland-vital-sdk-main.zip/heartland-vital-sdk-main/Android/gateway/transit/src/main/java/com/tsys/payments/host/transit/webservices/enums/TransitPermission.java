package com.tsys.payments.host.transit.webservices.enums;

public enum TransitPermission {
    RegisterManualItemEntry(1, "manually enter items"),
    RegisterCancelOrder(2, "cancel orders"),
    RegisterNoSale(3, "perform a No Sale"),
    RegisterEnterCashPayment(4, "enter cash payments"),
    RegisterEnterCreditDebitCardPayment(5, "enter credit/debit payments"),
    RegisterEnterGiftPayment(6, "enter gift payments"),
    InventoryAddEditDeactivateProduct(7, "add, edit, deactivate products"),
    RegisterApplyAdHocDiscount(10, "apply ad hoc discounts"),
    ManagementAddEditDeactivateDiscount(11, "add, edit, deactivate discounts"),
    HistoryViewTransactionDetails(13, "view transaction details"),
    HistoryRefundTransaction(14, "refund transactions"),
    InventoryExport(15, "export inventory"),
    ManagementAddEditDeactivateTaxes(16, "add, edit, deactivate taxes"),
    RegisterSearchProductName(21, "search products by name"),
    RegisterSplitOrder(22, "split orders"),
    RegisterHoldOrder(23, "hold orders"),
    InventoryAddEditDeactivateCategory(24, "add, edit, deactivate categories"),
    InventoryAddEditDeactivateModifier(34, "add, edit, deactivate modifiers"),
    InventoryAddRemoveFavorite(39, "add/remove favorites"),
    CustomersViewCustomerDetail(42, "view customer details"),
    HistoryEmailCustomerReceipt(44, "email customer receipts"),
    HistoryPrintCustomerReceipt(45, "print customer receipts"),
    HistoryViewOfflineTransactions(47, "view offline transactions"),
    HistoryRefundOfflineTransaction(48, "refund offline transactions"),
    HistoryCloseBatch(49, "close batches"),
    HistoryTipAdjust(50, "adjust credit card tips and/or capture charges for settlement"),
    ManagementSettings(52, "adjust settings"),
    ManagementPaidTips(53, "pay out tips"),
    ManagementOrderEditAfterSentToStation(54, "edit an order after it has been sent to a station"),
    DashboardBatchSummary(58, "view batch summary lists and details"),
    DashboardMerchantReports(60, "view merchant reports"),
    DashboardFinancialAudits(62, "view financial audit entries"),
    HistoryViewTransactions(63, "view transaction lists"),
    RegisterCashIn(64, "add cash to the register"),
    RegisterCashOut(65, "remove cash from the register"),
    RegisterSafeDrop(66, "perform Safe Drop operations to move cash from the cash drawer"),
    InventoryAccess(73, "access inventory"),
    InventoryImport(74, "import inventory"),
    ManagementEditAccount(75, "edit accounts"),
    ManagementAddCopyDeactivateLocation(76, "add, copy, deactivate locations"),
    ManagementEditLocation(77, "edit locations"),
    ManagementEditLocationReceipt(79, "edit receipt layout and options for this location"),
    ManagementEditLocationAccessoryDisplaySettings(80,
            "edit accessory display settings for a location"),
    ManagementAddRegister(81, "add registers"),
    ManagementAddRemoveUserToLocation(84, "add/remove users to a location"),
    ManagementAddEditDeactivateUser(86, "add, edit, deactivate users"),
    ManagementAssignUnassignUserGroup(87, "assign/unassign users to groups"),
    ManagementAddEditDeactivateUserGroups(88, "add, edit, deactivate user groups"),
    AccessApp(94, "access the application"),
    AccessPortal(95, "access the portal"),
    ManagementReceiveExceptionEmail(96, "manage recipient of exception email");

    public int key;
    public String readableAction;

    TransitPermission(int key, String readableAction) {
        this.key = key;
        this.readableAction = readableAction;
    }

    public static TransitPermission fromKey(int key) {
        for (TransitPermission permission : values()) {
            if (permission.key == key) {
                return permission;
            }
        }
        return null;
    }

}
