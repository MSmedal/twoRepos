package com.tsys.payments.host.transit.utils;

import androidx.annotation.NonNull;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tsys.payments.host.transit.BuildConfig;

import java.util.Map;

public class TransitLogHelper {
    private static Gson sGson;

    public static Gson getGson() {
        synchronized (TransitLogHelper.class) {
            if (sGson == null) {
                sGson = new GsonBuilder().setPrettyPrinting().create();
            }
        }
        return sGson;
    }

    public static final String TAG = TransitLogHelper.class.getSimpleName();

    public static void write(Exception e) {

    }

    public static void write(String tag, String requestMethod, String url, Map<String, String> headers,
            Map<String, String> httpResponseHeaders, int responseCode, String responseBody) {

    }

    public static void write(String tag, String requestMethod, String url, Map<String, String> headers, Exception e) {

    }

    public static void write(String tag, String requestMethod, String url, Map<String, String> headers) {

    }

    public static void write(String tag, String requestMethod, String url, Map<String, String> headers,
            String requestBody, Exception e) {

    }

    public static void write(String tag, String requestMethod, String url, Map<String, String> headers,
            String requestBody, Map<String, String> httpResponseHeaders, int responseCode, String responseBody) {

    }

    public static void write(String tag, String requestMethod, String url, Map<String, String> headers,
            String requestBody) {

    }

    public static void write(String tag, @NonNull Exception e) {
        if (BuildConfig.DEBUG) {
            Log.e(tag, e.getLocalizedMessage(), e);
        }
    }

    public static void write(String tag, String message) {
        if (BuildConfig.DEBUG) {
            Log.d(tag, message);
        }
    }

    public static void write(String tag, String message, Object o) {
        if (BuildConfig.DEBUG) {
            Log.d(tag, message + '\t' + getGson().toJson(o));
        }
    }

    public static void write(String message) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, message);
        }
    }
}
