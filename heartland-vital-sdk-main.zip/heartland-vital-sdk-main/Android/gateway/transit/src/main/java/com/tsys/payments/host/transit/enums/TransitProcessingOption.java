package com.tsys.payments.host.transit.enums;

public enum TransitProcessingOption {
    /**
     * Starts an EMV transaction that will use the chip configuration to determine how the data should be captured.
     */
    START,

    /**
     * Starts an EMV transaction that will force online processing regardless of the chip configuration.
     */
    FORCE_ONLINE,

    /**
     * Start an EMV transaction that will attempt offline processing and return batch data that can be sent online at a
     * later time.
     */
    BATCH_DATA_CAPTURE,

    /**
     * Starts an EMV transaction that will return online processing data if offline processing fails.
     */
    ONLINE_DATA_CAPTURE
}
