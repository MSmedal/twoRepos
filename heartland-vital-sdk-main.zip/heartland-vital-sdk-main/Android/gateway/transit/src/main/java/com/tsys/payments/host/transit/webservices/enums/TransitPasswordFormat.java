package com.tsys.payments.host.transit.webservices.enums;

public enum TransitPasswordFormat {
    PlainText(0),
    BCrypt(1);

    public int key;

    TransitPasswordFormat(int key) {
        this.key = key;
    }

    public static TransitPasswordFormat fromKey(int key) {
        for (TransitPasswordFormat type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
