package com.tsys.payments.host.transit.enums;

/**
 * Type of service to use when processing a payment.
 */
public enum TransitServiceType {
    /**
     * Authorizes the transaction amount but does not mark the transaction for settlement. A subsequent call to Capture
     * the transaction must be made in order for the transaction to be settled and finally posted to the cardholders
     * account.
     */
    AUTH,

    /**
     * Authorizes and marks the transaction for settlement. These transactions are considered finalized immediately and
     * may not be altered once completed.
     */
    SALE,

    /**
     * Refunds the transaction amount back to the cardholders account. This service does not require the refund to be
     * associated with a specific transaction.
     */
    REFUND,

    /**
     * Force a transaction to be approved without getting an authorization code from the processor. The transaction is
     * marked for settlement.
     */
    FORCED_AUTH
}
