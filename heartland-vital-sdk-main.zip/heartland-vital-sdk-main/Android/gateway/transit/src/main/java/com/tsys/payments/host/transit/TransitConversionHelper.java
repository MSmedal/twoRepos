package com.tsys.payments.host.transit;

import android.text.TextUtils;

import com.tsys.payments.host.transit.constants.TransitIds;
import com.tsys.payments.host.transit.enums.TransitCardholderAuthenticationMethod;
import com.tsys.payments.host.transit.enums.TransitCodeType;
import com.tsys.payments.host.transit.enums.TransitFallbackCondition;
import com.tsys.payments.host.transit.enums.TransitLastChipRead;
import com.tsys.payments.host.transit.webservices.TransitResponseCode;
import com.tsys.payments.host.transit.webservices.TransitTransactionResponse;
import com.tsys.payments.host.transit.webservices.enums.TransitTransactionResult;
import com.tsys.payments.host.transit.webservices.generated.TransitAuth;
import com.tsys.payments.host.transit.webservices.generated.TransitBatchCloseResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitCaptureResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitCardDataSourceType;
import com.tsys.payments.host.transit.webservices.generated.TransitEncryptionTypeType;
import com.tsys.payments.host.transit.webservices.generated.TransitReturn;
import com.tsys.payments.host.transit.webservices.generated.TransitSale;
import com.tsys.payments.host.transit.webservices.generated.TransitTransactionAdjustmentResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitVoidReason;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.TerminalCapabilities;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.EncryptionType;
import com.tsys.payments.library.enums.FallbackReason;
import com.tsys.payments.library.enums.LastChipRead;
import com.tsys.payments.library.enums.ReversalReason;
import com.tsys.payments.library.enums.TerminalAuthenticationCapability;
import com.tsys.payments.library.enums.TerminalInputCapability;
import com.tsys.payments.library.enums.TerminalOperatingEnvironment;
import com.tsys.payments.library.enums.TerminalOutputCapability;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

final class TransitConversionHelper {
    private static final String TAG = TransitConversionHelper.class.getName();
    private static final String NOT_SUPPORTED = "NOT_SUPPORTED";

    static boolean isOnlineApproved(TransitTransactionResponse response,
            TransitResponseCode responseCode) {
        //noinspection SimplifiableIfStatement
        if (response != null && responseCode != null) {
            return responseCode.getCodeType() == TransitCodeType.Approval ||
                    responseCode.getCodeType() == TransitCodeType.PartialApproval;
        }
        return false;
    }

    private static List<String> filterEmvTagList(List<TlvObject> emvTags) {
        List<String> emvTagList = new ArrayList<>();
        if (emvTags != null) {
            for (TlvObject tlvObject : emvTags) {
                if (tlvObject.getTagDescriptor() != EmvTagDescriptor.TRACK_1_DISCRETIONARY_DATA
                        && tlvObject.getTagDescriptor() != EmvTagDescriptor.
                        TRACK_2_DISCRETIONARY_DATA
                        && tlvObject.getTagDescriptor() != EmvTagDescriptor.PAN
                        && tlvObject.getTagDescriptor() != EmvTagDescriptor.CARDHOLDER_NAME
                        && tlvObject.getTagDescriptor() != EmvTagDescriptor.
                        TRACK_2_EQUIVALENT_DATA) {
                    emvTagList.add(tlvObject.asHexString());
                }
            }
        }

        return emvTagList;
    }

    static boolean isOnlineApproved(TransitCaptureResponse response,
            String responseCode) {
        //noinspection SimplifiableIfStatement
        if (response != null &&
                isResponseCodeApproval(TransitResponseCode.fromString(responseCode))) {
            return true;
        }
        return false;
    }

    static boolean isOnlineApproved(TransitTransactionAdjustmentResponse response,
            String responseCode) {
        //noinspection SimplifiableIfStatement
        if (response != null &&
                isResponseCodeApproval(TransitResponseCode.fromString(responseCode))) {
            return true;
        }
        return false;
    }

    static boolean isOnlineApproved(TransitBatchCloseResponse response) {
        //noinspection SimplifiableIfStatement
        if (response != null &&
                isResponseCodeApproval(response.getResponseCode())) {
            return true;
        }
        return false;
    }

    private static boolean isResponseCodeApproval(
            @Nullable TransitResponseCode transitResponseCode) {
        return transitResponseCode != null &&
                (transitResponseCode.getCodeType() == TransitCodeType.Approval ||
                        transitResponseCode.getCodeType() == TransitCodeType.PartialApproval);
    }

    static void populateAuthCardSwipeData(@NonNull TransitAuth request,
            @NonNull GatewayRequest sdkRequest) {
        CardData cardData = sdkRequest.getCardData();
        request.setCardDataSource(cardDataSourceFromSdk(cardData.getCardDataSource()));
        if (cardData.getCardholderAddress() != null) {
            String zipCode = cardData.getCardholderAddress().getPostalCode();
            String addressLine1 = cardData.getCardholderAddress().getAddressLine1();
            if (!TextUtils.isEmpty(zipCode)) {
                request.setZip(zipCode);
            }
            if (!TextUtils.isEmpty(addressLine1)) {
                request.setAddressLine1(addressLine1);
            }
        }
        switch (request.getCardDataSource()) {
            case NFC:
                TransitSale.NfcTags nfcTags = new TransitSale.NfcTags();
                nfcTags.getTag().addAll(filterEmvTagList(cardData.getEmvTlvData()));
                request.setNfcTags(nfcTags);
                if (!TextUtils.isEmpty(cardData.getCardholderName())) {
                    request.setCardHolderName(cardData.getCardholderName());
                }
                request.setKsn(cardData.getKsn());
                request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                request.setEmulatedTrackData(cardData.getPackedEncryptedData());
                break;
            case SWIPE:
                if (!TextUtils.isEmpty(cardData.getCardholderName())) {
                    request.setCardHolderName(cardData.getCardholderName());
                }
                request.setKsn(cardData.getKsn());
                request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                request.setEmulatedTrackData(cardData.getPackedEncryptedData());
                break;
            case EMV:
            case EMV_CONTACTLESS:
                request.setPaymentAppVersion(sdkRequest.getTerminalInfo().getAppVersion());
                request.setKsn(cardData.getKsn());
                request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                // TODO: set track2data to cardData.getPackedEncryptedData if transactions get
                //  declined at transit.
                request.setTrack2Data(cardData.getPackedEncryptedData());
                TransitSale.EmvTags emvTags = new TransitSale.EmvTags();
                emvTags.getTag().addAll(filterEmvTagList(cardData.getEmvTlvData()));
                request.setEmvTags(emvTags);
                break;
            case FALLBACK_SWIPE:
                request.setKsn(cardData.getKsn());
                request.setPaymentAppVersion(sdkRequest.getTerminalInfo().getAppVersion());
                request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                request.setTrack2Data(cardData.getPackedEncryptedData());
                TransitFallbackCondition fallbackCondition =
                        getFallbackCondition(cardData.getFallbackReason());
                if (fallbackCondition != null) {
                    request.setEmvFallbackCondition(fallbackCondition.name());
                }
                if (fallbackCondition != TransitFallbackCondition.NO_CANDIDATE_LIST) {
                    if (cardData.getLastChipRead() != null) {
                        request.setLastChipRead(
                                getLastChipRead(cardData.getLastChipRead()).name());
                    } else {
                        request.setLastChipRead(
                                TransitLastChipRead.NOT_A_CHIP_TRANSACTION.name());
                    }
                }
                break;
            case MANUAL:
            case MAIL:
            case PHONE:
            case INTERNET:
                request.setCardNumber(cardData.getPan());
                request.setCardHolderName(cardData.getCardholderName());
                request.setCvv2(cardData.getCvv2());
                request.setExpirationDate(cardData.getExpirationDate());
                request.setTerminalOperatingEnvironment(null);
                request.setTerminalAuthenticationCapability(null);
                request.setTerminalOutputCapability(null);
                request.setCardholderAuthenticationMethod(null);
                request.setTerminalCapability(null);
                break;
            default:
                throw new IllegalArgumentException(
                        "CardDataSourceType " + request.getCardDataSource() +
                                " not supported.");
        }
    }

    static void populateSaleCardSwipeData(@NonNull TransitSale request,
            @NonNull GatewayRequest sdkRequest) {
        CardData cardData = sdkRequest.getCardData();
        if (cardData != null) {
            request.setCardDataSource(cardDataSourceFromSdk(cardData.getCardDataSource()));
            if (cardData.getCardholderAddress() != null) {
                String zipCode = cardData.getCardholderAddress().getPostalCode();
                String addressLine1 = cardData.getCardholderAddress().getAddressLine1();
                if (!TextUtils.isEmpty(zipCode)) {
                    request.setZip(zipCode);
                }
                if (!TextUtils.isEmpty(addressLine1)) {
                    request.setAddressLine1(addressLine1);
                }
            }
            switch (request.getCardDataSource()) {
                case NFC:
                    TransitSale.NfcTags nfcTags = new TransitSale.NfcTags();
                    nfcTags.getTag().addAll(filterEmvTagList(cardData.getEmvTlvData()));
                    request.setNfcTags(nfcTags);
                    if (!TextUtils.isEmpty(cardData.getCardholderName())) {
                        request.setCardHolderName(cardData.getCardholderName());
                    }
                    request.setKsn(cardData.getKsn());
                    request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                    request.setEmulatedTrackData(cardData.getPackedEncryptedData());
                    break;
                case SWIPE:
                    if (!TextUtils.isEmpty(cardData.getCardholderName())) {
                        request.setCardHolderName(cardData.getCardholderName());
                    }
                    request.setKsn(cardData.getKsn());
                    request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                    request.setEmulatedTrackData(cardData.getPackedEncryptedData());
                    break;
                case EMV:
                case EMV_CONTACTLESS:
                    request.setPaymentAppVersion(sdkRequest.getTerminalInfo().getAppVersion());
                    request.setKsn(cardData.getKsn());
                    request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                    if (cardData.getPackedEncryptedData() != null) {
                        request.setTrack2Data(cardData.getPackedEncryptedData());
                    } else {
                        request.setTrack2Data(cardData.getEncryptedData());
                    }
                    TransitSale.EmvTags emvTags = new TransitSale.EmvTags();
                    emvTags.getTag().addAll(filterEmvTagList(cardData.getEmvTlvData()));
                    request.setEmvTags(emvTags);
                    break;
                case FALLBACK_SWIPE:
                    request.setKsn(cardData.getKsn());
                    request.setPaymentAppVersion(sdkRequest.getTerminalInfo().getAppVersion());
                    request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                    request.setTrack2Data(cardData.getPackedEncryptedData());
                    TransitFallbackCondition fallbackCondition =
                            getFallbackCondition(cardData.getFallbackReason());
                    if (fallbackCondition != null) {
                        request.setEmvFallbackCondition(fallbackCondition.name());
                    }
                    if (fallbackCondition != TransitFallbackCondition.NO_CANDIDATE_LIST) {
                        if (cardData.getLastChipRead() != null) {
                            request.setLastChipRead(
                                    getLastChipRead(cardData.getLastChipRead()).name());
                        } else {
                            request.setLastChipRead(
                                    TransitLastChipRead.NOT_A_CHIP_TRANSACTION.name());
                        }
                    }
                    break;
                case MANUAL:
                case MAIL:
                case PHONE:
                case INTERNET:
                    request.setCardNumber(cardData.getPan());
                    request.setCardHolderName(cardData.getCardholderName());
                    request.setCvv2(cardData.getCvv2());
                    request.setExpirationDate(cardData.getExpirationDate());
                    request.setTerminalOperatingEnvironment(null);
                    request.setTerminalAuthenticationCapability(null);
                    request.setTerminalOutputCapability(null);
                    request.setCardholderAuthenticationMethod(null);
                    request.setTerminalCapability(null);
                    break;
                default:
                    throw new IllegalArgumentException(
                            "CardDataSourceType " + request.getCardDataSource() +
                                    " not supported.");
            }
        }
    }

    static void populateReturnSwipeData(@NonNull TransitReturn request,
            @NonNull GatewayRequest sdkRequest) {
        Timber.d("populateReturnSwipeData() called with: request=[%s], sdkRequest=[%s]",
                request, sdkRequest);
        CardData cardData = sdkRequest.getCardData();
        /* In the event of a a user-initiated void, the card data or card data source may be null
           since the card data is not required for performing reversals. */
        if (cardData != null) {
            if (cardData.getCardDataSource() == null) {
                // In the event of a fallback return due to a user-initiated reversal failing, the
                // card data source may be null.
                Timber.w(
                        "Card data source unavailable. Card data cannot be populated in the Transit Return request.");
                return;
            }
            request.setCardDataSource(cardDataSourceFromSdk(cardData.getCardDataSource()));
            switch (request.getCardDataSource()) {
                case NFC:
                    if (!TextUtils.isEmpty(cardData.getCardholderName())) {
                        request.setCardHolderName(cardData.getCardholderName());
                    }
                    request.setKsn(cardData.getKsn());
                    request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                    request.setEmulatedTrackData(cardData.getEncryptedData());
                    populateTerminalCapabilities(request, sdkRequest);
                    break;
                case SWIPE:
                    if (!TextUtils.isEmpty(cardData.getCardholderName())) {
                        request.setCardHolderName(cardData.getCardholderName());
                    }
                    request.setKsn(cardData.getKsn());
                    request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                    request.setEmulatedTrackData(cardData.getPackedEncryptedData());
                    populateTerminalCapabilities(request, sdkRequest);
                    break;
                case EMV:
                case EMV_CONTACTLESS:
                    request.setPaymentAppVersion(sdkRequest.getTerminalInfo().getAppVersion());
                    request.setKsn(cardData.getKsn());
                    request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                    if (cardData.getPackedEncryptedData() != null) {
                        request.setTrack2Data(cardData.getPackedEncryptedData());
                    } else {
                        request.setTrack2Data(cardData.getEncryptedData());
                    }
                    TransitReturn.EmvTags emvTags = new TransitReturn.EmvTags();
                    emvTags.getTag().addAll(filterEmvTagList(cardData.getEmvTlvData()));
                    request.setEmvTags(emvTags);
                    populateTerminalCapabilities(request, sdkRequest);
                    break;
                case FALLBACK_SWIPE:
                    request.setKsn(cardData.getKsn());
                    request.setEncryptionType(encryptingTypeFromSdk(cardData.getEncryptionType()));
                    request.setPaymentAppVersion(sdkRequest.getTerminalInfo().getAppVersion());
                    request.setTrack2Data(cardData.getPackedEncryptedData());
                    TransitFallbackCondition fallbackCondition =
                            getFallbackCondition(cardData.getFallbackReason());
                    if (fallbackCondition != null) {
                        request.setEmvFallbackCondition(fallbackCondition.name());
                    }
                    if (fallbackCondition != TransitFallbackCondition.NO_CANDIDATE_LIST) {
                        if (cardData.getLastChipRead() != null) {
                            request.setLastChipRead(cardData.getLastChipRead().name());
                        } else {
                            request.setLastChipRead(
                                    TransitLastChipRead.NOT_A_CHIP_TRANSACTION.name());
                        }

                    }
                    populateTerminalCapabilities(request, sdkRequest);
                    break;
                case MANUAL:
                case MAIL:
                case PHONE:
                case INTERNET:
                    request.setCardNumber(cardData.getPan());
                    request.setCardHolderName(cardData.getCardholderName());
                    request.setCvv2(cardData.getCvv2());
                    request.setExpirationDate(cardData.getExpirationDate());
                    request.setTerminalOperatingEnvironment(null);
                    request.setTerminalAuthenticationCapability(null);
                    request.setTerminalOutputCapability(null);
                    request.setCardholderAuthenticationMethod(null);
                    request.setTerminalCapability(null);
                    break;
                default:
                    Timber.e(
                            "CardDataSourceType " + request.getCardDataSource() +
                                    " not supported.");
            }
        } else {
            Timber.w(
                    "CardData object is unavailable. Cannot populate card data in the Return request.");
        }
    }

    static void populateTerminalCapabilities(@NonNull TransitReturn request,
            @NonNull GatewayRequest sdkRequest) {
        TerminalCapabilities terminalCapabilities = sdkRequest.getTerminalCapabilities();
        if (terminalCapabilities != null) {
            request.setTerminalOperatingEnvironment(
                    terminalCapabilities.getOperatingEnvironment().name());
            request.setTerminalAuthenticationCapability(
                    terminalCapabilities.getAuthenticationCapability().name());
            request.setTerminalOutputCapability(
                    terminalCapabilities.getOutputCapability().name());
            request.setTerminalCapability(
                    terminalCapabilities.getInputCapability().name());
        } else {
            request.setTerminalOperatingEnvironment(
                    TerminalOperatingEnvironment.ON_MERCHANT_PREMISES_ATTENDED.name());
            request.setTerminalAuthenticationCapability(
                    TerminalAuthenticationCapability.NO_CAPABILITY.name());
            request.setTerminalOutputCapability(
                    TerminalOutputCapability.PRINT_AND_DISPLAY.name());
            request.setTerminalCapability(
                    TerminalInputCapability.MAGSTRIPE_ICC_KEYED_ENTRY_ONLY.name());
        }
        request.setCardholderAuthenticationMethod(
                TransitCardholderAuthenticationMethod.
                        fromCvmResult(sdkRequest.getCvmResult()).displayName);
        request.setMaxPinLength(TransitIds.MAX_PIN_LENGTH);

    }

    static BigDecimal getAmountFromString(String amountValue) {
        return TextUtils.isEmpty(amountValue) ? BigDecimal.ZERO : new BigDecimal(amountValue);
    }

    static String getPinLengthString(int pinLength) {
        return pinLength == 0 ? NOT_SUPPORTED : Integer.toString(pinLength);
    }

    private static TransitCardDataSourceType cardDataSourceFromSdk(
            CardDataSourceType sdkDataSource) {
        switch (sdkDataSource) {
            case MSR:
                return TransitCardDataSourceType.SWIPE;
            case SCR:
                return TransitCardDataSourceType.EMV;
            case CONTACTLESS_MSR:
                return TransitCardDataSourceType.NFC;
            case CONTACTLESS_EMV:
                return TransitCardDataSourceType.EMV_CONTACTLESS;
            case KEYED:
                return TransitCardDataSourceType.MANUAL;
            case PHONE:
                return TransitCardDataSourceType.PHONE;
            case MAIL:
                return TransitCardDataSourceType.MAIL;
            case INTERNET:
                return TransitCardDataSourceType.INTERNET;
            case FALLBACK:
                return TransitCardDataSourceType.FALLBACK_SWIPE;
            default:
                return null;
        }
    }

    /**
     * For Transit payment requests, the tip must be subtracted from the total. This method relies
     * on the expectation that the total in the {@link GatewayRequest} includes the tip amount.
     *
     * @param gatewayRequest {@link GatewayRequest} containing the transaction amounts, with the tip
     * included in the {@link GatewayRequest#getTotal()} amount.
     *
     * @return Transaction total minus the tip.
     */
    static long getTransactionTotal(@NonNull GatewayRequest gatewayRequest) {
        if (gatewayRequest.getTip() != null) {
            return gatewayRequest.getTotal() - gatewayRequest.getTip();
        }

        return gatewayRequest.getTotal();
    }

    static long longTransactionIdFromString(String transactionIdString) {
        long transactionId = TransitApi.TRANSACTIONLESS_TRANSACTION_ID;
        try {
            transactionId = Long.parseLong(transactionIdString);
        } catch (NumberFormatException e) {
            Timber.e(e);
        }

        return transactionId;
    }

    private static TransitEncryptionTypeType encryptingTypeFromSdk(EncryptionType encryptionType) {
        if (encryptionType != null) {
            switch (encryptionType) {
                case TDES:
                    return TransitEncryptionTypeType.TDES;
                case VOLTAGE:
                    return TransitEncryptionTypeType.VOLTAGE;
                default:
                    return TransitEncryptionTypeType.IDT_TDES;
            }
        }
        return null;
    }

    @NonNull
    static TransitVoidReason getVoidReasonFromSdk(ReversalReason reversalReason) {
        switch (reversalReason) {
            case VOIDED_BY_CUSTOMER:
                return TransitVoidReason.POST_AUTH_USER_DECLINE;
            case DEVICE_TIMEOUT:
                return TransitVoidReason.DEVICE_TIMEOUT;
            case PARTIAL_REVERSAL:
                return TransitVoidReason.PARTIAL_REVERSAL;
            case CHIP_DECLINED:
                return TransitVoidReason.POST_AUTH_CHIP_DECLINE;
            default:
                return TransitVoidReason.DEVICE_UNAVAILABLE;
        }
    }

    @Nullable
    private static TransitFallbackCondition getFallbackCondition(
            @Nullable FallbackReason fallbackReason) {
        if (fallbackReason == null) {
            return null;
        }

        switch (fallbackReason) {
            case EMPTY_CANDIDATE_LIST:
                return TransitFallbackCondition.NO_CANDIDATE_LIST;
            default:
                return TransitFallbackCondition.ICC_TERMINAL_ERROR;
        }
    }

    @NonNull
    private static TransitLastChipRead getLastChipRead(@Nullable LastChipRead lastChipRead) {
        if (lastChipRead == null) return TransitLastChipRead.UNKNOWN;

        switch (lastChipRead) {
            case SUCCESSFUL:
                return TransitLastChipRead.SUCCESSFUL;
            case FAILED:
                return TransitLastChipRead.FAILED;
            case NOT_A_CHIP_TRANSACTION:
                return TransitLastChipRead.NOT_A_CHIP_TRANSACTION;
            default:
                return TransitLastChipRead.UNKNOWN;
        }
    }

    @NonNull
    private static TransitTransactionResult transactionResultFromConnectionError(
            TransitResponseCode responseCode) {
        switch (responseCode) {
            case HOST_UNAVAILABLE:
                break;
            case UNKNOWN_HOST:
                break;
            case HOST_TIMEOUT:
                break;
            case UNKNOWN_CODE:
                break;
        }
        return TransitTransactionResult.UNKNOWN;
    }

    static TransitTransactionResult transactionResultFromGatewayResponseCode(
            @Nullable TransitResponseCode responseCode) {
        if (responseCode != null) {
            switch (responseCode.getCodeType()) {
                case Approval:
                    return TransitTransactionResult.APPROVED;
                case PartialApproval:
                    return TransitTransactionResult.PARTIAL_APPROVAL;
                case Unknown:
                    return TransitTransactionResult.UNKNOWN;
                case ConnectionError:
                    return transactionResultFromConnectionError(responseCode);
                case Denial:
                    return TransitTransactionResult.DECLINED;
            }
        }

        return TransitTransactionResult.UNKNOWN;
    }
}
