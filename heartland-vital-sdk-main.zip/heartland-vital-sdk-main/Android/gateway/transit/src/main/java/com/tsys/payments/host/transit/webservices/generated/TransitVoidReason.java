package com.tsys.payments.host.transit.webservices.generated;

public enum TransitVoidReason {
    POST_AUTH_USER_DECLINE,
    DEVICE_TIMEOUT,
    DEVICE_UNAVAILABLE,
    PARTIAL_REVERSAL,
    TORN_TRANSACTIONS,
    POST_AUTH_CHIP_DECLINE
}
