package com.tsys.payments.host.transit;

import android.text.TextUtils;

import com.tsys.payments.host.transit.webservices.TransitResponseCode;
import com.tsys.payments.host.transit.webservices.enums.TransitTransactionResult;
import com.tsys.payments.host.transit.webservices.generated.TransitAuth;
import com.tsys.payments.host.transit.webservices.generated.TransitAuthResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitBatchClose;
import com.tsys.payments.host.transit.webservices.generated.TransitBatchCloseResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitCapture;
import com.tsys.payments.host.transit.webservices.generated.TransitCaptureResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitForcedAuth;
import com.tsys.payments.host.transit.webservices.generated.TransitForcedAuthResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitReturn;
import com.tsys.payments.host.transit.webservices.generated.TransitReturnResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitSale;
import com.tsys.payments.host.transit.webservices.generated.TransitSaleResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitTransactionAdjustment;
import com.tsys.payments.host.transit.webservices.generated.TransitTransactionAdjustmentResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitVoid;
import com.tsys.payments.host.transit.webservices.generated.TransitVoidResponse;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.utils.LibraryConfigHelper;

import androidx.annotation.NonNull;
import timber.log.Timber;

/**
 * Controller for handling communications with the TransIt payment gateway.
 */
class TransitGatewayController implements GatewayController {
    private static final String TAG = TransitGatewayController.class.getName();

    private GatewayListener mGatewayListener;

    private TransitApi mTransitApi;

    private String mDeviceId;
    private String mTransactionKey;

    private GatewayRequest mGatewayRequest;

    TransitGatewayController(@NonNull GatewayConfiguration configuration, GatewayListener listener)
            throws InitializationException {
        mGatewayListener = listener;

        mDeviceId = configuration.getCredentials().get(TransitCredentialKeys.DEVICE_ID);
        mTransactionKey = configuration.getCredentials().get(TransitCredentialKeys.TRANSACTION_KEY);
        mTransitApi = TransitApi.getInstance();
        mTransitApi.initialize(mDeviceId, mTransactionKey, configuration.getGatewayTimeout(),
                LibraryConfigHelper.isDebug());
    }

    @Override
    public void sendRequest(GatewayRequest gatewayRequest) {
        Timber.d("sendRequest() called with: gatewayRequest = [" + gatewayRequest + "]");
        mGatewayRequest = gatewayRequest;

        if (!isGatewayActionSupported(mGatewayRequest.getGatewayAction())) {
            handleUnsupportedGatewayAction();
        } else {
            processGatewayAction(mGatewayRequest);
        }
    }

    private void processGatewayAction(@NonNull GatewayRequest gatewayRequest) {
        Timber.d("processGatewayAction() called with action %s", gatewayRequest.getGatewayAction());

        if (gatewayRequest.isGenerateToken() || !TextUtils.isEmpty(gatewayRequest.getToken())) {
            Timber.w("Tokenization is not yet supported for this host");
        }

        switch (gatewayRequest.getGatewayAction()) {
            case AUTH:
                handleAuthorizeRequest(gatewayRequest);
                break;
            case FORCE_AUTH:
                handleForcedAuthRequest(gatewayRequest);
                break;
            case SALE:
                handleSaleRequest(gatewayRequest);
                break;
            case REFUND:
                handleRefundRequest(gatewayRequest);
                break;
            case PARTIAL_REFUND:
                handlePartialRefundRequest(gatewayRequest);
                break;
            case VOID:
                handleVoidRequest(gatewayRequest);
                break;
            case TIP_ADJUST:
            case CAPTURE:
                handleCaptureRequest(gatewayRequest);
                break;
            case TRANSACTION_ADJUSTMENT:
                handleTransactionAdjustmentRequest(gatewayRequest);
                break;
            case BATCH_CLOSE:
                handleCloseBatchRequest(gatewayRequest);
                break;
        }
    }

    private boolean isGatewayActionSupported(GatewayAction action) {
        if (action == null) return false;
        switch (action) {
            case AUTH:
            case FORCE_AUTH:
            case SALE:
            case CAPTURE:
            case REFUND:
            case PARTIAL_REFUND:
            case VOID:
            case TIP_ADJUST:
            case TRANSACTION_ADJUSTMENT:
            case BATCH_CLOSE:
                return true;
            default:
                return false;
        }
    }

    private void handleUnsupportedGatewayAction() {
        GatewayAction unsupportedAction = mGatewayRequest.getGatewayAction();
        switch (unsupportedAction) {
            case TOKENIZE_CARD:
            case BALANCE_INQUIRY:
            case VERIFY:
            case AUTHENTICATE:
            default:
                Timber.e("action [" + unsupportedAction + "] not supported.");
                broadcastGatewayError(unsupportedAction);
                break;
        }
    }

    private void handleTransactionAdjustmentRequest(GatewayRequest gatewayRequest) {
        final TransitTransactionAdjustment request = TransitModelConverter
                .toTransactionAdjustmentRequest(gatewayRequest);
        mTransitApi.performTransactionAdjustment(request,
                new TransitSdkListener<TransitTransactionAdjustmentResponse>() {
                    @Override
                    public void onTransitResponse(TransitTransactionAdjustmentResponse result) {
                        dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
                    }

                    @Override
                    public void onError(TransitTransactionAdjustmentResponse result,
                            TransitTransactionResult hostResult) {
                        dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
                    }
                });
    }

    private void handleAuthorizeRequest(GatewayRequest gatewayRequest) {
        final TransitAuth request = TransitModelConverter.toAuthRequest(gatewayRequest);
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        mTransitApi.performAuth(request, new TransitSdkListener<TransitAuthResponse>() {
            @Override
            public void onTransitResponse(TransitAuthResponse result) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }

            @Override
            public void onError(TransitAuthResponse result, TransitTransactionResult hostResult) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }
        });
    }

    private void handleForcedAuthRequest(GatewayRequest gatewayRequest) {
        final TransitForcedAuth request = TransitModelConverter.toForcedAuthRequest(gatewayRequest);
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        mTransitApi.performForcedAuth(request, new TransitSdkListener<TransitForcedAuthResponse>() {
            @Override
            public void onTransitResponse(TransitForcedAuthResponse result) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }

            @Override
            public void onError(TransitForcedAuthResponse result,
                    TransitTransactionResult hostResult) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }
        });
    }

    private void handleSaleRequest(GatewayRequest gatewayRequest) {
        final TransitSale request = TransitModelConverter.toSaleRequest(gatewayRequest);
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        mTransitApi.performSale(request, new TransitSdkListener<TransitSaleResponse>() {
            @Override
            public void onTransitResponse(TransitSaleResponse result) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }

            @Override
            public void onError(TransitSaleResponse result, TransitTransactionResult hostResult) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }
        });
    }

    private void handleRefundRequest(final GatewayRequest gatewayRequest) {
        TransitReturn request;
        try {
            request = TransitModelConverter.toRefundRequest(gatewayRequest);
        } catch (IllegalArgumentException e) {
            Timber.e(e);
            GatewayResponse response = new GatewayResponse(gatewayRequest.getGatewayAction());
            response.setError(true);
            response.setErrorMessage(e.getMessage());
            dispatchGatewayResponse(response);
            return;
        }
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        mTransitApi.performReturn(request, new TransitSdkListener<TransitReturnResponse>() {
            @Override
            public void onTransitResponse(TransitReturnResponse result) {
                if (result.getResponseCode() == TransitResponseCode.D0005 &&
                        gatewayRequest.getGatewayAction() == GatewayAction.REFUND) {
                    performFallbackVoid(gatewayRequest);
                } else {
                    dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result, GatewayAction.REFUND));
                }
            }

            @Override
            public void onError(TransitReturnResponse result, TransitTransactionResult hostResult) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result, GatewayAction.REFUND));
            }
        });
    }

    private void handlePartialRefundRequest(final GatewayRequest gatewayRequest) {
        TransitReturn request;
        try {
            request = TransitModelConverter.toPartialRefundRequest(gatewayRequest);
        } catch (IllegalArgumentException e) {
            Timber.e(e);
            GatewayResponse response = new GatewayResponse(gatewayRequest.getGatewayAction());
            response.setError(true);
            response.setErrorMessage(e.getMessage());
            dispatchGatewayResponse(response);
            return;
        }
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        mTransitApi.performReturn(request, new TransitSdkListener<TransitReturnResponse>() {
            @Override
            public void onTransitResponse(TransitReturnResponse result) {
                if (result.getResponseCode() == TransitResponseCode.D0005 &&
                        gatewayRequest.getGatewayAction() == GatewayAction.PARTIAL_REFUND) {
                    performFallbackVoid(gatewayRequest);
                } else {
                    dispatchGatewayResponse(
                            TransitModelConverter.toGatewayResponse(result, GatewayAction.PARTIAL_REFUND));
                }
            }

            @Override
            public void onError(TransitReturnResponse result, TransitTransactionResult hostResult) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result, GatewayAction.PARTIAL_REFUND));
            }
        });
    }

    private void handleVoidRequest(final GatewayRequest gatewayRequest) {
        final TransitVoid request = TransitModelConverter.toVoidRequest(gatewayRequest);
        request.setDeviceID(mDeviceId);
        request.setTransactionKey(mTransactionKey);
        mTransitApi.performVoid(request, new TransitSdkListener<TransitVoidResponse>() {
            @Override
            public void onTransitResponse(TransitVoidResponse result) {
                if (result.getResponseCode() == TransitResponseCode.D0004 &&
                        gatewayRequest.getGatewayAction() == GatewayAction.VOID) {
                    performFallbackRefund(gatewayRequest);
                } else {
                    dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
                }
            }

            @Override
            public void onError(TransitVoidResponse result, TransitTransactionResult hostResult) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }
        });
    }

    private void performFallbackRefund(GatewayRequest gatewayRequest) {
        handleRefundRequest(gatewayRequest);
    }

    private void performFallbackVoid(GatewayRequest gatewayRequest) {
        handleVoidRequest(gatewayRequest);
    }

    private void handleCaptureRequest(GatewayRequest gatewayRequest) {
        final TransitCapture request = TransitModelConverter.toCaptureRequest(gatewayRequest);

        mTransitApi.performCapture(request, new TransitSdkListener<TransitCaptureResponse>() {
            @Override
            public void onTransitResponse(TransitCaptureResponse result) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }

            @Override
            public void onError(TransitCaptureResponse result,
                    TransitTransactionResult hostResult) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }
        });
    }

    private void handleCloseBatchRequest(@NonNull GatewayRequest gatewayRequest) {
        final TransitBatchClose request = TransitModelConverter.toCloseBatchRequest(mDeviceId, gatewayRequest);

        mTransitApi.performCloseBatch(request, new TransitSdkListener<TransitBatchCloseResponse>() {
            @Override
            public void onTransitResponse(TransitBatchCloseResponse result) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }

            @Override
            public void onError(TransitBatchCloseResponse result,
                    TransitTransactionResult hostResult) {
                dispatchGatewayResponse(TransitModelConverter.toGatewayResponse(result));
            }
        });
    }

    private void dispatchGatewayResponse(GatewayResponse gatewayResponse) {
        if (mGatewayRequest != null && mGatewayRequest.getCardData() != null) {
            gatewayResponse
                    .setCardDataSourceType(mGatewayRequest.getCardData().getCardDataSource());
        }
        mGatewayListener.onGatewayResponse(gatewayResponse);
    }

    private void broadcastGatewayError(GatewayAction action) {
        GatewayResponse gatewayResponse = new GatewayResponse(action);
        gatewayResponse.setError(true);
        gatewayResponse.setErrorMessage("Action Not Supported.");
        callbackOnGatewayResponse(gatewayResponse);
    }

    private void callbackOnGatewayResponse(@NonNull GatewayResponse gatewayResponse) {
        mGatewayRequest = null;
        mGatewayListener.onGatewayResponse(gatewayResponse);
    }
}
