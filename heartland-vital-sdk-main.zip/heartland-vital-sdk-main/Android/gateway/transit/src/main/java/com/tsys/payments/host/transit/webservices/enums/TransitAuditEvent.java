package com.tsys.payments.host.transit.webservices.enums;

public enum TransitAuditEvent {
    Generic(0),
    SecurityAudit(100001),
    FinancialAudit(100002);

    public int key;

    TransitAuditEvent(int key) {
        this.key = key;
    }

    public static TransitAuditEvent fromKey(int key) {
        for (TransitAuditEvent type : values()) {
            if (type.key == key) {
                return type;
            }
        }
        return null;
    }
}
