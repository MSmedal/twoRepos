package com.tsys.payments.host.transit;

import com.tsys.payments.host.transit.webservices.TransitXMLConverter;
import com.tsys.payments.host.transit.webservices.generated.TransitAuth;
import com.tsys.payments.host.transit.webservices.generated.TransitAuthResponse;
import com.tsys.payments.host.transit.webservices.generated.TransitCardDataSourceType;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.simpleframework.xml.core.ValueRequiredException;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

import androidx.annotation.NonNull;
import androidx.test.runner.AndroidJUnit4;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

@RunWith(AndroidJUnit4.class)
public class TransitMockApiTest {
    private static final String BASE_MOCK_URL = "/";
    private static final String TEST_DEVICE_ID = "12345678";
    private static final TransitCardDataSourceType TEST_DATA_SOURCE_TYPE =
            TransitCardDataSourceType.EMV;
    private static final BigDecimal TEST_AMOUNT = BigDecimal.TEN;

    private MockWebServer mServer;
    private MockTransitEndPoints mClient;

    @Before
    public void setUp() {
        mServer = new MockWebServer();

        HttpLoggingInterceptor logger = new HttpLoggingInterceptor();
        logger.setLevel(HttpLoggingInterceptor.Level.BODY);
        final OkHttpClient okHttpClient = getBaseClientBuilder()
                .addInterceptor(logger)
                .build();

        Retrofit restAdapter = new Retrofit.Builder()
                .baseUrl(mServer.url(BASE_MOCK_URL))
                .client(okHttpClient)
                .addConverterFactory(new TransitXMLConverter().createFactory())
                .build();

        mClient = restAdapter.create(MockTransitEndPoints.class);
    }

    @Test
    public void test_performTransaction_responseCodeMissing_creates_ValueRequiredException() {
        // Create mock Transit response with response code missing. E.g. <responseCode>D2026</responseCode>
        MockResponse authResponse = new MockResponse()
                .addHeader("Content-Type", "text/xml; charset=utf-8")
                .addHeader("Cache-Control", "no-cache")
                .setBody("<SaleResponse><status>FAIL</status>" +
                        "<responseMessage>Do not honor</responseMessage>" +
                        "<hostReferenceNumber>922415011354</hostReferenceNumber>" +
                        "<hostResponseCode>05</hostResponseCode><taskID>1907450497</taskID>" +
                        "<transactionID>1860894429</transactionID>" +
                        "<transactionTimestamp>2019-08-12T11:51:51</transactionTimestamp>" +
                        "<transactionAmount>1</transactionAmount>" +
                        "<addressVerificationCode>0</addressVerificationCode><cardType>V</cardType>" +
                        "<maskedCardNumber>7442</maskedCardNumber><aci>N</aci>" +
                        "<cardTransactionIdentifier>589224571117939</cardTransactionIdentifier>" +
                        "</SaleResponse>");
        mServer.enqueue(authResponse);

        // Populate requested with required elements
        TransitAuth auth = new TransitAuth();
        auth.setDeviceID(TEST_DEVICE_ID);
        auth.setTransactionAmount(TEST_AMOUNT);
        auth.setCardDataSource(TEST_DATA_SOURCE_TYPE);

        Call<TransitAuthResponse> call = mClient.performAuth(auth);
        Assert.assertNotNull(call);
        try {
            call.execute();
        } catch (Exception e) {
            Assert.assertTrue(e.getCause() instanceof ValueRequiredException);
            ValueRequiredException missingValueException = (ValueRequiredException)e.getCause();
            String message = missingValueException.getMessage();
            Assert.assertTrue(message.contains("field \'responseCode\'"));
        }
    }

    @Test
    public void test_performTransaction_responseCodePresent_ThrowsNoException() {
        MockResponse authResponse = new MockResponse()
                .addHeader("Content-Type", "text/xml; charset=utf-8")
                .addHeader("Cache-Control", "no-cache")
                .setBody("<SaleResponse><status>FAIL</status>" +
                        "<responseCode>D2026</responseCode>" +
                        "<responseMessage>Do not honor</responseMessage>" +
                        "<hostReferenceNumber>922415011354</hostReferenceNumber>" +
                        "<hostResponseCode>05</hostResponseCode><taskID>1907450497</taskID>" +
                        "<transactionID>1860894429</transactionID>" +
                        "<transactionTimestamp>2019-08-12T11:51:51</transactionTimestamp>" +
                        "<transactionAmount>1</transactionAmount>" +
                        "<addressVerificationCode>0</addressVerificationCode><cardType>V</cardType>" +
                        "<maskedCardNumber>7442</maskedCardNumber><aci>N</aci>" +
                        "<cardTransactionIdentifier>589224571117939</cardTransactionIdentifier>" +
                        "</SaleResponse>");
        mServer.enqueue(authResponse);

        // Populate requested with required elements
        TransitAuth auth = new TransitAuth();
        auth.setDeviceID(TEST_DEVICE_ID);
        auth.setTransactionAmount(TEST_AMOUNT);
        auth.setCardDataSource(TEST_DATA_SOURCE_TYPE);

        Call<TransitAuthResponse> call = mClient.performAuth(auth);
        Assert.assertNotNull(call);
        try {
            call.execute();
        } catch (Exception e) {
            Assert.fail("Exception thrown: " + e.getCause().getMessage());
        }
    }

    @Test
    public void test_performTransaction_nonTransitResponse_creates_ValueRequiredException() {
        // Create general HTML response that does not conform to Transit XSD specs.
        MockResponse authResponse = new MockResponse()
                .addHeader("Content-Type", "text/xml; charset=utf-8")
                .addHeader("Cache-Control", "no-cache")
                .setBody("<!DOCTYPE html>" +
                        "<html>" +
                        "<head>" +
                        "<title>Page Title</title>" +
                        "</head>" +
                        "<body>" +
                        "<h1>My First Heading</h1>" +
                        "<p>My first paragraph.</p>\n" +
                        "\n" +
                        "</body>\n" +
                        "</html>");
        mServer.enqueue(authResponse);

        // Populate requested with required elements
        TransitAuth auth = new TransitAuth();
        auth.setDeviceID(TEST_DEVICE_ID);
        auth.setTransactionAmount(TEST_AMOUNT);
        auth.setCardDataSource(TEST_DATA_SOURCE_TYPE);

        Call<TransitAuthResponse> call = mClient.performAuth(auth);
        Assert.assertNotNull(call);
        try {
            call.execute();
        } catch (Exception e) {
            Assert.assertTrue(e.getCause() instanceof ValueRequiredException);
            ValueRequiredException missingValueException = (ValueRequiredException)e.getCause();
            String message = missingValueException.getMessage();
            Assert.assertTrue(message.contains("field \'responseCode\'"));
        }
    }

    private OkHttpClient.Builder getBaseClientBuilder() {
        OkHttpClient.Builder okHttpClient = new OkHttpClient.Builder();
        okHttpClient.connectTimeout(2000, TimeUnit.MILLISECONDS);
        okHttpClient.readTimeout(2000, TimeUnit.MILLISECONDS);
        okHttpClient.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(@NonNull Chain chain) throws IOException {
                okhttp3.Request original = chain.request();
                okhttp3.Request request = original.newBuilder()
                        .header("Content-Type", "text/xml; charset=UTF-8")
                        .method(original.method(), original.body())
                        .build();
                return chain.proceed(request);
            }
        });

        return okHttpClient;
    }

    private interface MockTransitEndPoints {
        String CONTENT_TYPE = "Content-Type: text/xml; charset=UTF-8";

        @NonNull
        @POST("Auth")
        @Headers(CONTENT_TYPE)
        Call<TransitAuthResponse> performAuth(@Body TransitAuth request);
    }
}
