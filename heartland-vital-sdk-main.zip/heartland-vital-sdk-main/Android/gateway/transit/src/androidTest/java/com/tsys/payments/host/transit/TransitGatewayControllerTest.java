package com.tsys.payments.host.transit;

import android.text.TextUtils;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayRequest.Builder;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.utils.LibraryConfigHelper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.runner.AndroidJUnit4;

import java.util.HashMap;
import java.util.concurrent.CountDownLatch;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class TransitGatewayControllerTest {
    private static final long GATEWAY_TIMEOUT = 10000;

    private static final String TEST_CARD_NUMBER_MC = "5413330089099130";
    private static final String TEST_CARD_NUMBER_VISA = "4111111111111111";
    private static final String TEST_CARD_NUMBER_AMEX = "378282246310005";
    private static final String TEST_CARD_NUMBER_DISCOVER = "6011111111111117";

    private static final String TEST_CARD_CVV_MC = "998";
    private static final String TEST_CARD_CVV_VISA = "999";
    private static final String TEST_CARD_CVV_AMEX = "9997";
    private static final String TEST_CARD_CVV_DISCOVER = "996";

    private static final String TEST_EXPIRATION_DATE = "12/2022";
    private static final String TEST_CARD_HOLDER_NAME = "Johnathan Doe";

    private GatewayController mGatewayController;
    private ResponseHandler mGatewayListener;

    private CountDownLatch mCountDownLatch;

    @Before
    public void setUp() throws InitializationException {
        GatewayConfiguration configuration = new GatewayConfiguration();
        configuration.setGatewayTimeout(GATEWAY_TIMEOUT);

        LibraryConfigHelper.setDebugMode(true);

        HashMap<String, String> credentials = new HashMap<>();
        credentials.put(TransitCredentialKeys.DEVICE_ID, "88300000228402");
        credentials.put(TransitCredentialKeys.TRANSACTION_KEY, "IVKCI8VTJZKDARYLZ8JU4Y56X3BZKUM7");
        credentials.put(TransitCredentialKeys.APP_VERSION, "1.0");

        configuration.setCredentials(credentials);

        mGatewayListener = new ResponseHandler();
        mGatewayController = new TransitGatewayControllerFactory().create(configuration,
                mGatewayListener);
        mCountDownLatch = new CountDownLatch(1);
    }

    @Test
    public void testAuthCapture() throws InterruptedException {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setCardholderName(TEST_CARD_HOLDER_NAME);
        cardData.setCardDataSource(CardDataSourceType.PHONE);
        cardData.setPan(TEST_CARD_NUMBER_MC);
        cardData.setCvv2(TEST_CARD_CVV_MC);
        cardData.setExpirationDate(TEST_EXPIRATION_DATE);
        builder.setCardData(cardData);
        builder.setTotal(500L);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertTrue(!TextUtils.isEmpty(response.getAuthCode()));

                // Proceed and capture previously authorized transaction
                captureAuthorization(response);
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void captureAuthorization(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.CAPTURE);
        builder.setTip(600L);
        builder.setTotal(
                gatewayResponse.getApprovedAmount() + 600L); // Total always with tip included
        builder.setHostTransactionId(gatewayResponse.getGatewayTransactionId());

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_refundWithoutParentTransactionIdManualEntry() throws InterruptedException {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.REFUND);

        CardData cardData = new CardData();
        cardData.setCardholderName(TEST_CARD_HOLDER_NAME);
        cardData.setPan(TEST_CARD_NUMBER_MC);
        cardData.setExpirationDate(TEST_EXPIRATION_DATE);
        cardData.setCardDataSource(CardDataSourceType.KEYED);

        builder.setCardData(cardData);
        builder.setTenderType(TenderType.CREDIT);
        builder.setTotal(2000L);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();

                assertTrue(response.isApproved());
                assertNotNull(response.getGatewayTransactionId());
                assertNotNull(response.getAuthCode());
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    @Test
    public void testManualSaleRefundWithParentTransactionId() throws InterruptedException {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.SALE);
        CardData cardData = new CardData();
        cardData.setCardholderName(TEST_CARD_HOLDER_NAME);
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        cardData.setPan(TEST_CARD_NUMBER_MC);
        cardData.setCvv2(TEST_CARD_CVV_MC);
        cardData.setExpirationDate(TEST_EXPIRATION_DATE);
        builder.setCardData(cardData);
        builder.setTotal(100L);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
                assertFalse(TextUtils.isEmpty(response.getGatewayTransactionId()));

                // refund sale
                testRefundWithParentTransactionId(response);
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private void testRefundWithParentTransactionId(GatewayResponse gatewayResponse) {
        GatewayRequest.Builder builder = new Builder(GatewayAction.REFUND);
        builder.setHostTransactionId(gatewayResponse.getGatewayTransactionId());

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();
                assertNotNull(response);
                assertTrue(response.isApproved());
            }
        });
        mGatewayController.sendRequest(builder.build());
        try {
            mCountDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test_verifyGatewayActionUnsupported() throws InterruptedException {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.VERIFY);

        CardData cardData = new CardData();
        cardData.setCardholderName(TEST_CARD_HOLDER_NAME);
        cardData.setPan(TEST_CARD_NUMBER_MC);
        cardData.setCvv2(TEST_CARD_CVV_MC);
        cardData.setExpirationDate(TEST_EXPIRATION_DATE);
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        builder.setTenderType(TenderType.CREDIT);
        builder.setCardData(cardData);

        mGatewayListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                mCountDownLatch.countDown();

                assertFalse(response.isApproved());
                assertTrue(response.getErrorMessage()
                        .equalsIgnoreCase("Action Not Supported."));
            }
        });
        mGatewayController.sendRequest(builder.build());
        mCountDownLatch.await();
    }

    private class ResponseHandler implements GatewayListener {

        private ResponseProcessor mResponseProcessor;

        void setResponseProcessor(ResponseProcessor responseProcessor) {
            mResponseProcessor = responseProcessor;
        }

        @Override
        public void onGatewayResponse(GatewayResponse gatewayResponse) {
            assertNotNull(gatewayResponse);
            mResponseProcessor.processResponse(gatewayResponse);
        }
    }

    private interface ResponseProcessor {
        void processResponse(GatewayResponse response);
    }
}
