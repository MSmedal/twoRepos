package com.tsys.payments.host.propay.enums;

/**
 * Indicates the means by which cardholder authentication can be performed on the terminal.
 */
public enum ProPayTerminalCardholderAuthenticationCapability {
    NO_CAPABILITY(48),
    PIN_ENTRY(49),
    ELECTRONIC_SIGNATURE(50),
    INOPERATIVE(53),
    OTHER(54);

    public final int value;

    // Check-In: JGXWHH

    ProPayTerminalCardholderAuthenticationCapability(int value) {
        this.value = value;
    }
}
