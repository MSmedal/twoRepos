package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains the data of a credit card that has been processed by or swiped in a credit card reader
 */
public class SwipeCardData {



    private EncryptedTracks EncryptedTrackData;


    private String Name;

    public EncryptedTracks getEncryptedTrackData() {
        return EncryptedTrackData;
    }

    public void setEncryptedTrackData(EncryptedTracks encryptedTrackData) {
        EncryptedTrackData = encryptedTrackData;
    }

    /**
     * Gets the name of the payer to create or store this data.
     */
    public String getName() {
        return Name;
    }

    /**
     * Sets the name of the payer to create or store this data.
     */
    public void setName(String name) {
        Name = name;
    }
}
