package com.tsys.payments.host.propay.service.merchant.client.contracts.emv;

import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.model.MobileEmvPayload;

public class AuthorizeEmvRequest extends AuthorizeCardSwipeRequest {

    @SerializedName("EmvPayload")
    private MobileEmvPayload mMobileEmvPayload;

    public MobileEmvPayload getMobileEmvPayload() {
        return mMobileEmvPayload;
    }

    /**
     * Sets the EMV payload data.
     */
    public void setMobileEmvPayload(@Nullable MobileEmvPayload mobileEmvPayload) {
        mMobileEmvPayload = mobileEmvPayload;
    }
}
