package com.tsys.payments.host.propay.enums;

import androidx.annotation.Nullable;

import com.tsys.payments.library.enums.CvmResult;

/**
 * Specifies methods used to capture cardholder authentication.
 */
public enum ProPayCardholderAuthenticationEntity {
    NOT_AUTHENTICATED(48),
    ICC_OFFLINE_PIN(49),
    CARD_ACCEPTANCE_DEVICE(50),
    AUTHORIZING_AGENT_ONLINE_PIN(51),
    MERCHANT_SIGNATURE(52),
    OTHER(53);

    public final int value;

    ProPayCardholderAuthenticationEntity(int value) {
        this.value = value;
    }

    public static ProPayCardholderAuthenticationEntity fromCvmResult(@Nullable CvmResult cvmResult) {
        if (cvmResult != null) {
            switch (cvmResult) {
                case PIN_OFFLINE_PLAIN:
                    return ICC_OFFLINE_PIN;
                case PIN_ONLINE:
                    return AUTHORIZING_AGENT_ONLINE_PIN;
                case SIGNATURE_REQUIRED:
                    return MERCHANT_SIGNATURE;
                default:
                    return NOT_AUTHENTICATED;
            }
        } else {
            return NOT_AUTHENTICATED;
        }
    }

}
