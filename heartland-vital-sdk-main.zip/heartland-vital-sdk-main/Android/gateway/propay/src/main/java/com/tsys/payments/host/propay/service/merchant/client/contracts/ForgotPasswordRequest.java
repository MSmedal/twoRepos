package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * A request object that contains the identification information for triggering a forgotten password flow
 */
public class ForgotPasswordRequest {



    private String Username;


    private String DeviceRegistrationId;


    private ChallengeAnswer[] Answers;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getDeviceRegistrationId() {
        return DeviceRegistrationId;
    }

    public void setDeviceRegistrationId(String deviceRegistrationId) {
        DeviceRegistrationId = deviceRegistrationId;
    }

    public ChallengeAnswer[] getAnswers() {
        return Answers;
    }

    public void setAnswers(ChallengeAnswer[] answers) {
        Answers = answers;
    }
}
