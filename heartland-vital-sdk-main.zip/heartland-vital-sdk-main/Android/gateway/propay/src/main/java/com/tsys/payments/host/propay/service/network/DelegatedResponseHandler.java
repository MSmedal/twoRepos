package com.tsys.payments.host.propay.service.network;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * Delegates all WebServiceResponseHandler methods to another ResponseHandler.
 * This class can be useful if you want to inject code before or after another
 * WebServiceResponseHandler's calls.
 *
 * @param <T> type of response object expected from the web service
 */
public class DelegatedResponseHandler<T extends BaseResponse> implements ResponseHandler<T> {

    protected ResponseHandler<T> mDelegate;

    /**
     * Creates a new delegated web service response handler.
     *
     * @param delegate the ResponseHandler to mDelegate all calls to
     */
    public DelegatedResponseHandler(ResponseHandler<T> delegate) {
        this.mDelegate = delegate;
    }

    @Override
    public T executeService() throws Exception {
        if (mDelegate != null) {
            return mDelegate.executeService();
        }

        return null;
    }

    @Override
    public void handleResponse(T response) {
        if (mDelegate != null) {
            mDelegate.handleResponse(response);
        }
    }

    @Override
    public void handleException(Exception e) {
        if (mDelegate != null) {
            mDelegate.handleException(e);
        }
    }
}
