package com.tsys.payments.host.propay.service.network;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

public interface ResponseHandler<T extends BaseResponse> {

    public T executeService() throws Exception;

    public void handleResponse(T response);

    public void handleException(Exception e);
}
