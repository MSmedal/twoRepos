package com.tsys.payments.host.propay;

import android.text.TextUtils;

import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;
import com.tsys.payments.host.propay.service.merchant.client.MerchantRestClient;
import com.tsys.payments.host.propay.service.merchant.client.MerchantResultCodes;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeManualEntryRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeManualEntryResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CaptureAuthorizedTransactionRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CaptureAuthorizedTransactionResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessStoredCardRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessStoredCardResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SetPinRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SetPinResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.StoreCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.StoreCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.VoidOrRefundRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.VoidOrRefundResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvFallbackRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvResponse;
import com.tsys.payments.host.propay.service.network.ResponseHandler;
import com.tsys.payments.host.propay.service.network.WebServiceHelper;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.utils.CreditCardHelper;
import com.tsys.payments.library.utils.LibraryConfigHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

import java.util.ArrayDeque;

public class ProPayGatewayController implements GatewayController {
    private static final String TAG = ProPayGatewayController.class.getName();
    private static final String TEST_ENDPOINT = "https://mobileapitest.propay.com/";
    private static final String PROD_ENDPOINT = "https://mobileapi.propay.com/";
    private static final String EMV_RESPONSE_CODE_UNABLE_TO_GO_ONLINE = "8A025A33";

    private final GatewayConfiguration mHostConfig;
    private final GatewayListener mGatewayListener;

    private GatewayRequest mGatewayRequest;
    private GatewayResponse mInitialGatewayTransactionResponse;

    private String mSessionToken;

    private ProPayCurrencyCode mCurrencyCode = ProPayCurrencyCode.USD;

    @Nullable
    private ArrayDeque<GatewayAction> mPendingGatewayActions;

    ProPayGatewayController(@NonNull GatewayConfiguration configuration, GatewayListener listener) {
        mHostConfig = configuration;
        mGatewayListener = listener;
        if (LibraryConfigHelper.isDebug()) {
            MerchantRestClient.init(TEST_ENDPOINT);
        } else {
            MerchantRestClient.init(PROD_ENDPOINT);
        }
    }

    @Override
    public void sendRequest(GatewayRequest gatewayRequest) {
        Timber.d("sendRequest() called with: gatewayRequest = [" + gatewayRequest + "]");
        mGatewayRequest = gatewayRequest;
        if (mPendingGatewayActions == null) {
            mPendingGatewayActions = new ArrayDeque<>();
        }

        if (!isGatewayActionSupported(gatewayRequest.getGatewayAction())) {
            handleUnsupportedGatewayAction();
        } else {
            /* Nullify session token reference. This will force a query for a new one if one hasn't been
               passed down in the ProPay credentials map. The session token was added as an optional
               parameter in the case where the application is managing thee session token on it's own,
               as is the case with the ProPay mobile app. the application is fully responsible
               for all aspects of session token. */
            mSessionToken = null;
            checkSessionTokenAvailability();
            Timber.d("Acquiring a new session token...");
            if(TextUtils.isEmpty(mSessionToken)) {
                mPendingGatewayActions.add(GatewayAction.AUTHENTICATE);
            }
                mPendingGatewayActions.add(mGatewayRequest.getGatewayAction());
            processPendingGatewayActions();
        }
    }

    private void checkSessionTokenAvailability(){
        Timber.d("checkSessionTokenAvailability() called.");

        if(mHostConfig.getCredentials() != null){
            mSessionToken = mHostConfig.getCredentials().get(ProPayCredentialKeys.SESSION_TOKEN);
        }
    }

    private boolean isGatewayActionSupported(GatewayAction action) {
        if (action == null) return false;
        switch (action) {
            case AUTHENTICATE:
            case SALE:
            case TIP_ADJUST:
            case AUTH:
            case CAPTURE:
            case REFUND:
            case VOID:
            case TOKENIZE_CARD:
                return true;
            default:
                return false;
        }
    }

    private void processPendingGatewayActions() {
        Timber.d("processPendingGatewayActions() called");
        if (mPendingGatewayActions != null && !mPendingGatewayActions.isEmpty()) {
            GatewayAction nextAction = mPendingGatewayActions.removeFirst();
            Timber.d("processing next action [" + nextAction + "]");
            switch (nextAction) {
                case AUTHENTICATE:
                    handleAuthenticateRequest();
                    break;
                case TIP_ADJUST:
                    break;
                case AUTH:
                case SALE:
                    performAuthorization();
                    break;
                case REFUND:
                case VOID:
                    performReversal();
                    break;
                case CAPTURE:
                    performCapture();
                    break;
                case TOKENIZE_CARD:
                    performStoreCardSwipe();
                    break;
            }
        } else {
            Timber.d("Gateway action queue empty");
        }
    }

    private void handleUnsupportedGatewayAction() {
        GatewayAction unsupportedAction = mGatewayRequest.getGatewayAction();
        switch (unsupportedAction) {
            case BATCH_CLOSE:
                performBatchClose();
                break;
            case FORCE_AUTH:
            case BALANCE_INQUIRY:
            case VERIFY:
            default:
                Timber.e("action [" + unsupportedAction + "] not supported.");
                broadcastGatewayError(unsupportedAction, "Action Not Supported.");
                break;
        }
    }

    private void broadcastGatewayError(GatewayAction nextAction, String s) {
        GatewayResponse gatewayResponse = new GatewayResponse(nextAction);
        gatewayResponse.setError(true);
        gatewayResponse.setErrorMessage(s);
        callbackOnGatewayResponse(gatewayResponse);
    }

    private void performAuthorization() {
        CardData cardData = mGatewayRequest.getCardData();
        if (cardData != null) {
            if (cardData.getCardDataSource() != null) {
                switch (cardData.getCardDataSource()) {
                    case KEYED:
                    case PHONE:
                    case INTERNET:
                    case MAIL:
                        performManualAuthorization(mGatewayRequest);
                        break;
                    case MSR:
                        performMsrAuthorization(mGatewayRequest);
                        break;
                    case FALLBACK:
                        performFallbackAuthorization(mGatewayRequest);
                        break;
                    case SCR:
                        performEmvAuthorization(mGatewayRequest);
                        break;
                }
            }
        } else {
            broadcastGatewayError(GatewayAction.AUTH,
                    "CardData is required for performing an authorization.");
        }
    }

    private void performPayWithStoredCard(GatewayRequest gatewayRequest) {
        Timber.d("performPayWithStoredCard()");
        final ProcessStoredCardRequest processStoredCardRequest =
                ProPayModelConverter.toProcessStoredCardRequest(gatewayRequest,
                        mCurrencyCode);
        processStoredCardRequest.setSessionGuid(mSessionToken);
        WebServiceHelper.call(new ResponseHandler<ProcessStoredCardResponse>() {

            @Override
            public ProcessStoredCardResponse executeService()
                    throws Exception {
                return MerchantRestClient.getInstance().processStoredCard(processStoredCardRequest);
            }

            @Override
            public void handleResponse(
                    ProcessStoredCardResponse response) {
                GatewayResponse gatewayResponse = ProPayModelConverter.toGatewayResponse(response);
                populateBaseResponseDetails(gatewayResponse);
                callbackOnGatewayResponse(gatewayResponse);
            }

            @Override
            public void handleException(Exception e) {
                GatewayResponse gatewayResponse = new GatewayResponse(GatewayAction.CAPTURE);
                gatewayResponse.setError(true);
                gatewayResponse.setErrorMessage(getErrorMessage(e));
                populateBaseResponseDetails(gatewayResponse);
                callbackOnGatewayResponse(gatewayResponse);
            }
        });
    }

    private void performStoreCardSwipe() {
        Timber.d("performStoreCardSwipe()");
        final StoreCardSwipeRequest storeCardSwipeRequest = ProPayModelConverter
                .convertSdkToStoreSwipeRequest(mGatewayRequest, mCurrencyCode);
        storeCardSwipeRequest.setSessionGuid(mSessionToken);
        WebServiceHelper.call(new ResponseHandler<StoreCardSwipeResponse>() {
            @Override
            public StoreCardSwipeResponse executeService() throws Exception {
                return MerchantRestClient.getInstance().storeCardSwipe(storeCardSwipeRequest);
            }

            @Override
            public void handleResponse(StoreCardSwipeResponse response) {
                GatewayResponse gatewayResponse = ProPayModelConverter.toGatewayResponse(response);
                populateBaseResponseDetails(gatewayResponse);
                callbackOnGatewayResponse(gatewayResponse);
            }

            @Override
            public void handleException(Exception e) {
                GatewayResponse gatewayResponse = new GatewayResponse(mGatewayRequest.getGatewayAction());
                gatewayResponse.setError(true);
                gatewayResponse.setErrorMessage(getErrorMessage(e));
                populateBaseResponseDetails(gatewayResponse);
                callbackOnGatewayResponse(gatewayResponse);
            }
        });
    }

    private void performMsrAuthorization(GatewayRequest gatewayRequest) {
        Timber.d("performMsrAuthorization()");
        final AuthorizeCardSwipeRequest cardSwipeRequest =
                ProPayModelConverter.toGatewayAuth(gatewayRequest,
                        mCurrencyCode);
        cardSwipeRequest.setSessionGuid(mSessionToken);
        WebServiceHelper.call(new ResponseHandler<AuthorizeCardSwipeResponse>() {

            @Override
            public AuthorizeCardSwipeResponse executeService()
                    throws Exception {
                return MerchantRestClient.getInstance().authorizeCardSwipe(cardSwipeRequest);
            }

            @Override
            public void handleResponse(
                    AuthorizeCardSwipeResponse response) {
                GatewayResponse gatewayResponse = ProPayModelConverter.toGatewayResponse(response);
                populateBaseResponseDetails(gatewayResponse);
                handleAuthResponse(gatewayResponse);
            }

            @Override
            public void handleException(Exception e) {
                handleAuthException(e);
            }
        });
    }

    private void performFallbackAuthorization(GatewayRequest gatewayRequest) {
        Timber.d("performFallbackAuthorization()");
        final AuthorizeEmvFallbackRequest fallbackRequest =
                ProPayModelConverter.toGatewayEmvFallback(gatewayRequest, mCurrencyCode);
        fallbackRequest.setSessionGuid(mSessionToken);
        WebServiceHelper.call(new ResponseHandler<AuthorizeCardSwipeResponse>() {

            @Override
            public AuthorizeCardSwipeResponse executeService()
                    throws Exception {
                return MerchantRestClient.getInstance().authorizeEmvFallback(fallbackRequest);
            }

            @Override
            public void handleResponse(
                    AuthorizeCardSwipeResponse response) {
                GatewayResponse gatewayResponse = ProPayModelConverter.toGatewayResponse(response);
                populateBaseResponseDetails(gatewayResponse);
                handleAuthResponse(gatewayResponse);
            }

            @Override
            public void handleException(Exception e) {
                handleAuthException(e);
            }
        });
    }

    private void performManualAuthorization(GatewayRequest gatewayRequest) {
        Timber.d("performManualAuthorization()");
        final AuthorizeManualEntryRequest manualAuth =
                ProPayModelConverter.toGatewayManualAuth(gatewayRequest, mCurrencyCode);
        manualAuth.setSessionGuid(mSessionToken);
        WebServiceHelper.call(new ResponseHandler<AuthorizeManualEntryResponse>() {

            @Override
            public AuthorizeManualEntryResponse executeService()
                    throws Exception {
                return MerchantRestClient.getInstance().authorizeManualEntry(manualAuth);
            }

            @Override
            public void handleResponse(AuthorizeManualEntryResponse response) {
                GatewayResponse gatewayResponse = ProPayModelConverter.toGatewayResponse(response);
                populateBaseResponseDetails(gatewayResponse);
                handleAuthResponse(gatewayResponse);
            }

            @Override
            public void handleException(Exception e) {
                handleAuthException(e);
            }
        });
    }

    private void performEmvAuthorization(final GatewayRequest gatewayRequest) {
        Timber.d("performEmvAuthorization()");
        final AuthorizeEmvRequest emvRequest = ProPayModelConverter.toGatewayEmvAuth(gatewayRequest,
                mCurrencyCode);
        emvRequest.setSessionGuid(mSessionToken);
        WebServiceHelper.call(new ResponseHandler<AuthorizeEmvResponse>() {

            @Override
            public AuthorizeEmvResponse executeService()
                    throws Exception {
                return MerchantRestClient.getInstance().authorizeEmv(emvRequest);
            }

            @Override
            public void handleResponse(
                    AuthorizeEmvResponse response) {
                GatewayResponse gatewayResponse = ProPayModelConverter.toGatewayResponse(response);
                gatewayResponse
                        .setCardDataSourceType(mGatewayRequest.getCardData().getCardDataSource());
                populateBaseResponseDetails(gatewayResponse);
                handleAuthResponse(gatewayResponse);
            }

            @Override
            public void handleException(Exception e) {
                handleAuthException(e);
            }
        });
    }

    private void handleAuthResponse(@NonNull GatewayResponse authResponse) {
        mInitialGatewayTransactionResponse = authResponse;
        if (mGatewayRequest.getGatewayAction() == GatewayAction.SALE &&
                mInitialGatewayTransactionResponse.isApproved()) {
            performCapture(mGatewayRequest, mInitialGatewayTransactionResponse);
        } else {
            callbackOnGatewayResponse(mInitialGatewayTransactionResponse);
        }
    }

    private void handleAuthException(Exception e) {
        Timber.d("handleAuthException()");
        GatewayResponse gatewayResponse = new GatewayResponse(GatewayAction.AUTH);
        gatewayResponse.setGatewayTimeout(true);
        if (mGatewayRequest != null) {
            checkEmvAuthException(gatewayResponse);
        }
        gatewayResponse.setError(true);
        gatewayResponse.setErrorMessage(getErrorMessage(e));
        populateBaseResponseDetails(gatewayResponse);
        callbackOnGatewayResponse(gatewayResponse);
    }

    private void checkEmvAuthException(@NonNull GatewayResponse gatewayResponse) {
        // The response code is set here to match the expected functionality of the ProPay certification.
        // Logic in the terminal controller tries to determine the authorization response code if it
        // doesn't exist but the values it produces are not consistent with ProPay certification.
        CardData cardData = mGatewayRequest.getCardData();
        if (cardData != null) {
            gatewayResponse.setCardDataSourceType(cardData.getCardDataSource());
            if (cardData.getCardDataSource() == CardDataSourceType.SCR) {
                gatewayResponse.setEmvIssuerAuthCode(EMV_RESPONSE_CODE_UNABLE_TO_GO_ONLINE);
            }
        }
    }

    private void handleAuthenticateRequest() {
        Timber.d("handleAuthenticateRequest()");
        final SetPinRequest setPinRequest = new SetPinRequest();
        setPinRequest.setUsername(mHostConfig.getCredentials().get(ProPayCredentialKeys.USERNAME));
        setPinRequest.setPassword(mHostConfig.getCredentials().get(ProPayCredentialKeys.PASSWORD));
        setPinRequest.setPin(mHostConfig.getCredentials().get(ProPayCredentialKeys.PIN));

        // TODO: Potentially perform a network connectivity check.
        WebServiceHelper.call(new ResponseHandler<SetPinResponse>() {
            @Override
            public SetPinResponse executeService() throws Exception {
                return MerchantRestClient.getInstance().setPin(setPinRequest);
            }

            @Override
            public void handleResponse(SetPinResponse response) {
                Timber.d("handleAuthenticationResponse()");
                if (response != null) {
                    if (response.getResultCode() == MerchantResultCodes.SUCCESS) {
                        mSessionToken = response.getSessionToken();
                        processPendingGatewayActions();
                    } else {
                        GatewayResponse gatewayResponse =
                                new GatewayResponse(mGatewayRequest.getGatewayAction());
                        gatewayResponse.setError(true);
                        if (response.getResult() != null) {
                            gatewayResponse.setGatewayResponseText(
                                    response.getResult().getResultMessage());
                        } else {
                            gatewayResponse.setGatewayResponseText("Authentication Error");
                        }
                        if (mGatewayRequest != null) {
                            checkEmvAuthException(gatewayResponse);
                        }
                        populateBaseResponseDetails(gatewayResponse);
                        callbackOnGatewayResponse(gatewayResponse);
                    }
                }
            }

            @Override
            public void handleException(Exception e) {
                GatewayResponse gatewayResponse =
                        new GatewayResponse(mGatewayRequest.getGatewayAction());
                gatewayResponse.setGatewayTimeout(true);
                gatewayResponse.setError(true);
                gatewayResponse
                        .setErrorMessage("Authentication Error. Gateway could not be reached.");
                if (mGatewayRequest != null) {
                    checkEmvAuthException(gatewayResponse);
                }
                populateBaseResponseDetails(gatewayResponse);
                callbackOnGatewayResponse(gatewayResponse);
            }
        });
    }

    private void performCapture() {
        Timber.d("performCapture()");

        if (!TextUtils.isEmpty(mGatewayRequest.getToken())) {
            performPayWithStoredCard(mGatewayRequest);
        } else {
            final CaptureAuthorizedTransactionRequest captureRequest =
                    ProPayModelConverter.convertSdkDataToGatewayCapture(mGatewayRequest);
            captureRequest.setSessionGuid(mSessionToken);
            if (mGatewayRequest.getCustomer() != null) {
                captureRequest.getBillingData().setEmail(mGatewayRequest.getCustomer().getEmail());
            }
            WebServiceHelper.call(new ResponseHandler<CaptureAuthorizedTransactionResponse>() {

                @Override
                public CaptureAuthorizedTransactionResponse executeService()
                        throws Exception {
                    return MerchantRestClient.getInstance()
                            .captureAuthorizedTransaction(captureRequest);
                }

                @Override
                public void handleResponse(CaptureAuthorizedTransactionResponse response) {
                    GatewayResponse gatewayResponse =
                            ProPayModelConverter.toGatewayResponse(response);
                    populateBaseResponseDetails(gatewayResponse);
                    callbackOnGatewayResponse(gatewayResponse);
                }

                @Override
                public void handleException(Exception e) {
                    GatewayResponse gatewayResponse = new GatewayResponse(GatewayAction.CAPTURE);
                    gatewayResponse.setError(true);
                    gatewayResponse.setErrorMessage(getErrorMessage(e));
                    populateBaseResponseDetails(gatewayResponse);
                    callbackOnGatewayResponse(gatewayResponse);
                }
            });
        }
    }

    /**
     * Perform a capture in response to an authorization approval.
     *
     * @param gatewayRequest {@link GatewayRequest} containing the information about the original
     * sale request.
     * @param gatewayResponse {@link GatewayResponse} containing the response data from the
     * authorization approval.
     */
    private void performCapture(GatewayRequest gatewayRequest, GatewayResponse gatewayResponse) {
        Timber.d("performCapture()");
        final CaptureAuthorizedTransactionRequest captureRequest =
                ProPayModelConverter
                        .convertSdkDataToGatewayCapture(mGatewayRequest, gatewayResponse);
        captureRequest.setSessionGuid(mSessionToken);
        if (mGatewayRequest.getCustomer() != null) {
            captureRequest.getBillingData().setEmail(mGatewayRequest.getCustomer().getEmail());
        }
        WebServiceHelper.call(new ResponseHandler<CaptureAuthorizedTransactionResponse>() {

            @Override
            public CaptureAuthorizedTransactionResponse executeService()
                    throws Exception {
                return MerchantRestClient.getInstance()
                        .captureAuthorizedTransaction(captureRequest);
            }

            @Override
            public void handleResponse(CaptureAuthorizedTransactionResponse response) {
                GatewayResponse gatewayResponse = ProPayModelConverter.toGatewayResponse(response);
                populateBaseResponseDetails(gatewayResponse);
                if (mGatewayRequest.getGatewayAction() == GatewayAction.SALE) {
                    // If a sale occurred, we only want to return the original response from the
                    // auth given that the capture response provides no additional information.
                    callbackOnGatewayResponse(mInitialGatewayTransactionResponse);
                } else {
                    // Set token and cardholder Id
                    gatewayResponse.setToken(mInitialGatewayTransactionResponse.getToken());
                    gatewayResponse.setCardHolderId(mInitialGatewayTransactionResponse.getCardHolderId());
                    callbackOnGatewayResponse(gatewayResponse);
                }
            }

            @Override
            public void handleException(Exception e) {
                GatewayResponse gatewayResponse = new GatewayResponse(GatewayAction.CAPTURE);
                gatewayResponse.setError(true);
                gatewayResponse.setErrorMessage(getErrorMessage(e));
                populateBaseResponseDetails(gatewayResponse);
                if (mGatewayRequest.getGatewayAction() == GatewayAction.SALE) {
                    callbackOnGatewayResponse(mInitialGatewayTransactionResponse);
                } else {
                    callbackOnGatewayResponse(gatewayResponse);
                }
            }
        });
    }

    private void populateBaseResponseDetails(@NonNull GatewayResponse gatewayResponse) {
        if (mGatewayRequest != null) {
            CardData cardData = mGatewayRequest.getCardData();
            if (cardData != null) {
                if (!TextUtils.isEmpty(cardData.getPan())) {
                    gatewayResponse.setMaskedPan(cardData.getPan());
                    gatewayResponse.setCardType(CreditCardHelper.typeFromPan(cardData.getPan()));
                } else if (cardData.getEmvTlvData() != null) {
                    for (TlvObject tlvObject : cardData.getEmvTlvData()) {
                        if (tlvObject != null &&
                                tlvObject.getTagDescriptor() == EmvTagDescriptor.PAN) {
                            if (!TextUtils.isEmpty(tlvObject.getValueAsHexString(false))) {
                                gatewayResponse.setMaskedPan(tlvObject.getValueAsHexString(false));
                                gatewayResponse.setCardType(
                                        CreditCardHelper
                                                .typeFromPan(tlvObject.getValueAsHexString(false)));
                                break;
                            }
                        }
                    }
                }

                gatewayResponse.setCardDataSourceType(cardData.getCardDataSource());
            }

            if (gatewayResponse.isApproved()) {
                gatewayResponse.setApprovedAmount(mGatewayRequest.getTotal());
                if (mGatewayRequest.getTip() != null) {
                    gatewayResponse.setTipAmount(mGatewayRequest.getTip());
                }
            }
        }
    }

    private void performReversal() {
        Timber.d("performReversal()");
        final VoidOrRefundRequest reversalRequest =
                ProPayModelConverter.toReversalRequest(mGatewayRequest,
                        mInitialGatewayTransactionResponse);
        reversalRequest.setSessionGuid(mSessionToken);
        WebServiceHelper.call(new ResponseHandler<VoidOrRefundResponse>() {

            @Override
            public VoidOrRefundResponse executeService()
                    throws Exception {
                return MerchantRestClient.getInstance().voidOrRefund(reversalRequest);
            }

            @Override
            public void handleResponse(VoidOrRefundResponse response) {
                GatewayResponse gatewayResponse = ProPayModelConverter.toGatewayResponse(response);
                populateBaseResponseDetails(gatewayResponse);
                callbackOnGatewayResponse(gatewayResponse);
            }

            @Override
            public void handleException(Exception e) {
                GatewayResponse gatewayResponse = new GatewayResponse(GatewayAction.VOID);
                gatewayResponse.setError(true);
                gatewayResponse.setErrorMessage(getErrorMessage(e));
                populateBaseResponseDetails(gatewayResponse);
                callbackOnGatewayResponse(gatewayResponse);
            }
        });
    }

    private void performBatchClose() {
        Timber.d("performBatchClose() called.");
        Timber.w(
                "Batch close action is not supported. Responding with successful mock gateway response.");
        callbackOnGatewayResponse(ProPayModelConverter.getSuccessfulBatchCloseResponse());
    }

    private void callbackOnGatewayResponse(@NonNull GatewayResponse gatewayResponse) {
        mInitialGatewayTransactionResponse = null;
        mGatewayRequest = null;
        mGatewayListener.onGatewayResponse(gatewayResponse);
    }

    @NonNull
    private String getErrorMessage(Exception e) {
        if (!TextUtils.isEmpty(e.getMessage())) {
            return e.getMessage();
        }
        return "ProPay Gateway Error";
    }
}
