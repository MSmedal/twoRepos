package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains billing information associated with a ProPay-to-Propay money transfer. This is the information of the
 * recipient account.
 */

public class PropayToPropayBillingData {

    private String Email;



    private String FirstName;



    private String LastName;

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }
}
