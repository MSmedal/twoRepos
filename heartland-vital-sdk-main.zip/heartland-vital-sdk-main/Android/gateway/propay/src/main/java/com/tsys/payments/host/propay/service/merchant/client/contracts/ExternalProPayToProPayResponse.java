package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

/**
 * Contains the response to a request to perform a ProPay-to-ProPay money transfer.
 */

public class ExternalProPayToProPayResponse extends BaseResponse {


    private String PaymentMethodId;


    private String PaymentType;

    public String getPaymentMethodId() {
        return PaymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        PaymentMethodId = paymentMethodId;
    }

    public String getPaymentType() {
        return PaymentType;
    }

    public void setPaymentType(String paymentType) {
        PaymentType = paymentType;
    }
}
