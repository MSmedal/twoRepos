package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

/**
 * A response object that contains the identifiers associated to a credit card that has been successfully stored
 */
public class StoreCardSwipeResponse extends BaseResponse {



    private String PaymentMethodId;


    private long PayerId;

    public String getPaymentMethodId() {
        return PaymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        PaymentMethodId = paymentMethodId;
    }

    public long getPayerId() {
        return PayerId;
    }

    public void setPayerId(long payerId) {
        PayerId = payerId;
    }
}
