package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains the signature image of a financial transaction
 */
public class FullTransactionData {



    private byte[] SignatureBlock;

    public byte[] getSignatureBlock() {
        return SignatureBlock;
    }

    public void setSignatureBlock(byte[] signatureBlock) {
        SignatureBlock = signatureBlock;
    }
}
