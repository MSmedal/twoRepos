package com.tsys.payments.host.propay.service.network.exception;

/**
 * Custom exception to throw in the event of a null response from the server so that a null response is properly
 * handled by the web service delegate.
 */
public class NullResponseException extends Exception {
}
