package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the client's authentication result
 */
public class AuthenticateTokenPinResponse extends BaseResponse {

    @SerializedName("SessionToken")
    private String mSessionToken;

    @SerializedName("IdentityDetail")
    private IdentityDetail mIdentityDetail;

    @SerializedName("TipRule")
    private TipRule mTipRule;

    @SerializedName("DefaultCountryCode")
    private int mDefaultCountryCode;

    public int getDefaultCountryCode() {
        return mDefaultCountryCode;
    }

    public void setDefaultCountryCode(int defaultCountryCode) {
        mDefaultCountryCode = defaultCountryCode;
    }

    public String getSessionToken() {
        return mSessionToken;
    }

    public void setSessionToken(String sessionToken) {
        mSessionToken = sessionToken;
    }

    public IdentityDetail getIdentityDetail() {
        return mIdentityDetail;
    }

    public void setIdentityDetail(IdentityDetail identityDetail) {
        mIdentityDetail = identityDetail;
    }

    public TipRule getTipRule() {
        return mTipRule;
    }

    public void setTipRule(TipRule tipRule) {
        mTipRule = tipRule;
    }
}
