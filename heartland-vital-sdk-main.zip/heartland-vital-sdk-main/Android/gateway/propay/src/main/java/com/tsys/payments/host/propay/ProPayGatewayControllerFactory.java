package com.tsys.payments.host.propay;

import androidx.annotation.Nullable;

import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayControllerFactory;
import com.tsys.payments.library.gateway.enums.GatewayType;

import java.util.Map;

public class ProPayGatewayControllerFactory implements GatewayControllerFactory {

    @Nullable
    @Override
    public GatewayType[] getSupportedGateways() {
        return new GatewayType[] {GatewayType.PROPAY};
    }

    @Nullable
    @Override
    public TerminalType[] getSupportedTerminals() {
        return new TerminalType[] {TerminalType.INGENICO_MOBY_8500, TerminalType.INGENICO_MOBY_3000,
                TerminalType.ROAM_G5X_TSYS_DECRYPTION, TerminalType.INGENICO_MOBY_3000_PROPAY,
                TerminalType.MAGTEK_ADYNAMO, TerminalType.BBPOS_C2X};
    }

    @Nullable
    @Override
    public GatewayController create(GatewayConfiguration gatewayConfiguration,
            GatewayListener listener)
            throws InitializationException {
        validateConfiguration(gatewayConfiguration);
        return new ProPayGatewayController(gatewayConfiguration, listener);
    }

    /**
     * ProPay requires the following for authentication:
     * <p>
     * - Username - Password - PIN
     */
    private void validateConfiguration(GatewayConfiguration gatewayConfiguration)
            throws InitializationException {
        Map<String, String> creds = gatewayConfiguration.getCredentials();
        if (creds == null || creds.isEmpty()) {
            throw new InitializationException(
                    "Invalid ProPay configuration provided . Credentials are missing.");
        }

        if (!creds.containsKey(ProPayCredentialKeys.USERNAME)) {
            throw new InitializationException(
                    "Invalid ProPay configuration provided. Username is missing.");
        }
        if (!creds.containsKey(ProPayCredentialKeys.PASSWORD)) {
            throw new InitializationException("Invalid ProPay configuration. Password is missing.");
        }
        if (!creds.containsKey(ProPayCredentialKeys.PIN)) {
            throw new InitializationException("Invalid ProPay configuration. PIN is missing.");
        }
    }
}
