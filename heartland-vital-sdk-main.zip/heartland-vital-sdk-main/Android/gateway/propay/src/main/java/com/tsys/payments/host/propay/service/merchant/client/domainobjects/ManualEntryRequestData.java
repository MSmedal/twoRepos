package com.tsys.payments.host.propay.service.merchant.client.domainobjects;

import android.os.Parcel;
import android.os.Parcelable;

import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeManualEntryRequest;

/**
 * Contains info that will be used to populate an {@link AuthorizeManualEntryRequest} object for use with
 * manually entered credit card payment transactions.
 */
public class ManualEntryRequestData implements Parcelable {

    private String mZipCode;
    private String mInvoice;
    private String mCvvCode;
    private String mCardNumber;
    private String mExpirationDate;
    private String mCardholderName;
    private String mEmail;
    private int mTaxAmount;
    private int mRequestAmount;
    private boolean mStoreCardData;

    private ManualEntryRequestData(Parcel in) {
        mZipCode = in.readString();
        mInvoice = in.readString();
        mCvvCode = in.readString();
        mCardNumber = in.readString();
        mExpirationDate = in.readString();
        mCardholderName = in.readString();
        mEmail = in.readString();
        mTaxAmount = in.readInt();
        mRequestAmount = in.readInt();
        mStoreCardData = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mZipCode);
        dest.writeString(mInvoice);
        dest.writeString(mCvvCode);
        dest.writeString(mCardNumber);
        dest.writeString(mExpirationDate);
        dest.writeString(mCardholderName);
        dest.writeString(mEmail);
        dest.writeInt(mTaxAmount);
        dest.writeInt(mRequestAmount);
        dest.writeByte((byte)(mStoreCardData ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ManualEntryRequestData> CREATOR = new Creator<ManualEntryRequestData>() {
        @Override
        public ManualEntryRequestData createFromParcel(Parcel in) {
            return new ManualEntryRequestData(in);
        }

        @Override
        public ManualEntryRequestData[] newArray(int size) {
            return new ManualEntryRequestData[size];
        }
    };

    public ManualEntryRequestData(){

    }

    public String getZipCode() {
        return mZipCode;
    }

    public void setZipCode(String zipCode) {
        mZipCode = zipCode;
    }

    public String getInvoice() {
        return mInvoice;
    }

    public void setInvoice(String invoice) {
        mInvoice = invoice;
    }

    public String getCvvCode() {
        return mCvvCode;
    }

    public void setCvvCode(String cvvCode) {
        mCvvCode = cvvCode;
    }

    public String getCardNumber() {
        return mCardNumber;
    }

    public void setCardNumber(String cardNumber) {
        mCardNumber = cardNumber;
    }

    public String getExpirationDate() {
        return mExpirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        mExpirationDate = expirationDate;
    }

    public String getCardholderName() {
        return mCardholderName;
    }

    public void setCardholderName(String cardholderName) {
        mCardholderName = cardholderName;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public int getTaxAmount() {
        return mTaxAmount;
    }

    public void setTaxAmount(int taxAmount) {
        mTaxAmount = taxAmount;
    }

    public int getRequestAmount() {
        return mRequestAmount;
    }

    public void setRequestAmount(int requestAmount) {
        mRequestAmount = requestAmount;
    }

    public boolean doStoreCardData() {
        return mStoreCardData;
    }

    public void setStoreCardData(boolean storeCardData) {
        mStoreCardData = storeCardData;
    }
}
