package com.tsys.payments.host.propay;

final class ProPayCredentialKeys {

    static final String USERNAME = "username";
    static final String PASSWORD = "password";
    static final String PIN = "pin";
    static final String SESSION_TOKEN = "session_token";

    private ProPayCredentialKeys() {
        // no instance
    }
}
