package com.tsys.payments.host.propay.service.merchant.client.contracts.emv;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeRequest;

public class AuthorizeEmvFallbackRequest extends AuthorizeCardSwipeRequest {

    @SerializedName("CardDataInputMode")
    private int mCardDataInputMode;

    @SerializedName("LastChipRead")
    private int mLastChipRead;

    @SerializedName("TerminalCardDataInputCapability")
    private int mTerminalCardDataInputCapability;

    public int getCardDataInputMode() {
        return mCardDataInputMode;
    }

    public void setCardDataInputMode(int cardDataInputMode) {
        mCardDataInputMode = cardDataInputMode;
    }

    public int getLastChipRead() {
        return mLastChipRead;
    }

    public void setLastChipRead(int lastChipRead) {
        mLastChipRead = lastChipRead;
    }

    public int getTerminalCardDataInputCapability() {
        return mTerminalCardDataInputCapability;
    }

    public void setTerminalCardDataInputCapability(int terminalCardDataInputCapability) {
        mTerminalCardDataInputCapability = terminalCardDataInputCapability;
    }
}
