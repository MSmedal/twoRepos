package com.tsys.payments.host.propay.service.merchant.client.io;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CamsSystem;

import java.lang.reflect.Type;

/**
 * Serializes / Deserializes {@link CamsSystem CamsSystem} enum to / from the JSON
 * format
 */
public class CamsSystemSerializer implements JsonSerializer<CamsSystem>, JsonDeserializer<CamsSystem> {

    @Override
    public JsonElement serialize(CamsSystem sourceEnum, Type typeOfT, JsonSerializationContext context) {
        return new JsonPrimitive(sourceEnum.getCode());
    }

    @Override
    public CamsSystem deserialize(JsonElement element, Type typeOfT, JsonDeserializationContext context)
            throws JsonParseException {
        return CamsSystem.parse(element.getAsInt());
    }
}
