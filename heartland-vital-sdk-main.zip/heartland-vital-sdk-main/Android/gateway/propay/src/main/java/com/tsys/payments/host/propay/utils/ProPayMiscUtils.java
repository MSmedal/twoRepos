package com.tsys.payments.host.propay.utils;

import android.content.Context;
import android.text.TextUtils;

import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

public final class ProPayMiscUtils {
    private static final String TAG = ProPayMiscUtils.class.getCanonicalName();

    private ProPayMiscUtils() {

    }

    public static String getSignaturesFolderLocation(@NonNull Context context) {
        return context.getFilesDir().getAbsolutePath() + "/Signatures/";
    }

    /**
     * Converts the string representation of an amount to a long representation in cents.
     * E.g. "300" = 300
     */
    public static long stringToLong(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return 0;
        }

        long val = 0;
        try {
            BigDecimal amount = new BigDecimal(input);
            val = amount.longValue();
        } catch (NumberFormatException e) {
            Timber.e(e);
            ;
        } finally {
            return val;
        }
    }

    /**
     * Converts the string representation of an amount to a long representation in cents.
     * E.g. "300" = 300
     */
    public static int stringToInt(@Nullable String input) {
        if (TextUtils.isEmpty(input)) {
            return 0;
        }

        int val = 0;
        try {
            BigDecimal amount = new BigDecimal(input);
            val = amount.intValue();
        } catch (NumberFormatException e) {
            Timber.e(e);
        } finally {
            return val;
        }
    }

    /**
     * Converts pennies into the format applicable for the current ISO 4217 Currency Code and the
     * device's locale
     */
    public static String convertPenniesToStringDollars(long pennies, int currencyCountryNumber,
            boolean showSymbol,
            boolean useUsLocale) {
        NumberFormat currencyFormatter =
                getCurrencyNumberFormatter(currencyCountryNumber, showSymbol, useUsLocale);
        BigDecimal value = new BigDecimal(pennies);
        value = value.setScale(currencyFormatter.getMaximumFractionDigits(),
                BigDecimal.ROUND_HALF_UP).divide(
                new BigDecimal(100));
        prepCurrencyGroupingSymbols(currencyFormatter);
        return currencyFormatter.format(value);
    }

    static NumberFormat prepCurrencyGroupingSymbols(NumberFormat format) {
        DecimalFormatSymbols symbols = ((DecimalFormat)format).getDecimalFormatSymbols();
        symbols.setGroupingSeparator(',');
        symbols.setMonetaryDecimalSeparator('.');
        symbols.setDecimalSeparator('.');
        ((DecimalFormat)format).setDecimalFormatSymbols(symbols);
        return format;
    }

    private static NumberFormat getCurrencyNumberFormatter(int currencyCountryNumber,
            boolean showSymbol,
            boolean useUsaLocale) {
        Locale locale = useUsaLocale ? Locale.US : getCurrentCurrencyLocale(currencyCountryNumber);
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(locale);
        Currency currency = Currency.getInstance(
                ProPayCurrencyCode
                        .find(useUsaLocale ? ProPayCurrencyCode.USD.getCurrencyNumber() :
                                currencyCountryNumber)
                        .getCurrencyCode());
        currencyFormat.setCurrency(currency);
        currencyFormat.setMaximumFractionDigits(currency.getDefaultFractionDigits());

        NumberFormat numberFormat;
        if (!showSymbol) {
            numberFormat = NumberFormat.getNumberInstance(locale);
            numberFormat.setMinimumFractionDigits(currencyFormat.getMinimumFractionDigits());
            numberFormat.setMaximumFractionDigits(currencyFormat.getMaximumFractionDigits());
        } else {
            numberFormat = currencyFormat;
        }
        prepCurrencyGroupingSymbols(numberFormat);
        return numberFormat;
    }

    public static Locale getCurrentCurrencyLocale(int currencyCountryNumber) {
        return setCurrentCurrencyLocale(currencyCountryNumber);
    }

    private static Locale setCurrentCurrencyLocale(int currencyCountryNumber) {
        ProPayCurrencyCode proPayCurrencyCode = ProPayCurrencyCode.find(currencyCountryNumber);
        if (proPayCurrencyCode == null) {
            return Locale.getDefault();
        }
        if (!proPayCurrencyCode.hasMultipleCountriesForLanguage()) {
            return new Locale(proPayCurrencyCode.getCountry(), proPayCurrencyCode.getLanguage());
        }
        if (Locale.getDefault().getLanguage()
                .compareToIgnoreCase(proPayCurrencyCode.getLanguage()) !=
                0) {
            return new Locale(proPayCurrencyCode.getCountry(), proPayCurrencyCode.getLanguage());
        }

        final Locale[] locales = Locale.getAvailableLocales();
        for (int lcv = 0; lcv < locales.length; lcv++) {
            try {
                if (Locale.getDefault().getLanguage()
                        .compareToIgnoreCase(locales[lcv].getLanguage()) == 0) {
                    if (Locale.getDefault().getCountry()
                            .compareToIgnoreCase(locales[lcv].getCountry()) == 0) {
                        return locales[lcv];
                    }
                }
            } catch (java.util.MissingResourceException ex) {
                Timber.e(ex);
            } catch (Exception ex) {
                Timber.e(ex);
            }
        }
        return new Locale(proPayCurrencyCode.getCountry(), proPayCurrencyCode.getLanguage());
    }
}
