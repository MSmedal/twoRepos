package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A response object that contains the result of authenticating a manually entering credit card
 */
public class AuthorizeManualEntryResponse extends AuthorizeCardSwipeResponse {
}
