package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A request object that contains the validation data of the caller or origin of the financial transaction
 */
public class CallerValidationRequest {
    private CallerValidation CallerValidation;

    public CallerValidation getCallerValidation() {
        return CallerValidation;
    }

    public void setCallerValidation(CallerValidation callerValidation) {
        CallerValidation = callerValidation;
    }
}
