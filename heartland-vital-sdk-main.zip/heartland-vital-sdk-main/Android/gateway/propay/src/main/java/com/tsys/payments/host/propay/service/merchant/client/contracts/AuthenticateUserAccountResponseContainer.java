package com.tsys.payments.host.propay.service.merchant.client.contracts;



public class AuthenticateUserAccountResponseContainer {

    private AuthenticateUserAccountResponse mUserAccountResponse;

    public AuthenticateUserAccountResponse getUserAccountResponse() {
        return mUserAccountResponse;
    }

    public void setUserAccountResponse(
            AuthenticateUserAccountResponse userAccountResponse) {
        mUserAccountResponse = userAccountResponse;
    }
}
