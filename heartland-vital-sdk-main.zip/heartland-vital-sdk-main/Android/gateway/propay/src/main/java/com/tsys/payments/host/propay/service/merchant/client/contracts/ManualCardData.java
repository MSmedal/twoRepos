package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains the basic credit card metadata for processing a credit card manually
 */
public class ManualCardData {



    private String Name;


    private String CardNumber;


    private String ExpirationDate;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getCardNumber() {
        return CardNumber;
    }

    public void setCardNumber(String cardNumber) {
        CardNumber = cardNumber;
    }

    public String getExpirationDate() {
        return ExpirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        ExpirationDate = expirationDate;
    }
}
