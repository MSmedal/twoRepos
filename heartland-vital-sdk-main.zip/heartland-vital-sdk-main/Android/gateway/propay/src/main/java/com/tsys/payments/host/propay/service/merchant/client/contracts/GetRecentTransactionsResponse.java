package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

/**
 * A response object that contains the transactions associated with a user's session
 */
public class GetRecentTransactionsResponse extends BaseResponse {



    private TransactionData[] Transactions;


    private boolean ContainsLastTransaction;

    public TransactionData[] getTransactions() {
        return Transactions;
    }

    public void setTransactions(TransactionData[] transactions) {
        Transactions = transactions;
    }

    public boolean isContainsLastTransaction() {
        return ContainsLastTransaction;
    }

    public void setContainsLastTransaction(boolean containsLastTransaction) {
        ContainsLastTransaction = containsLastTransaction;
    }
}
