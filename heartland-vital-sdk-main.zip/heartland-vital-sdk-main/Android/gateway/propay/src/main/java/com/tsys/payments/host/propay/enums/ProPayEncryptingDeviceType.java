package com.tsys.payments.host.propay.enums;

import com.tsys.payments.library.enums.TerminalType;

/**
 * Definitions for the encryption types of the supported credit card readers
 */
public enum ProPayEncryptingDeviceType {
    Unknown(0), MagTekM20(1), MagTekFlash(2), Manual(4), MagTekADynamo(5), MagTekDynamag(
            6), RoamData(7), Bbpos(10), MobyBdk(12), Moby3000(13), Moby3000_ProPay(14);

    public final int value;

    ProPayEncryptingDeviceType(int value) {
        this.value = value;
    }

    public static ProPayEncryptingDeviceType parse(int currentValue) {
        for (ProPayEncryptingDeviceType type : ProPayEncryptingDeviceType.values()) {
            if (type.value == currentValue) {
                return type;
            }
        }

        return Unknown;
    }

    public static ProPayEncryptingDeviceType fromTerminalType(TerminalType terminalType) {
        if (terminalType == null) return Unknown;

        switch (terminalType) {
            case BBPOS_C2X:
                return Bbpos;
            case ROAM_G5X_TSYS_DECRYPTION:
                return RoamData;
            case INGENICO_MOBY_3000:
                return Moby3000;
            case INGENICO_MOBY_3000_PROPAY:
                return Moby3000_ProPay;
            case INGENICO_MOBY_8500:
                return MobyBdk;
            case MAGTEK_ADYNAMO:
                return MagTekADynamo;
            default:
                return Unknown;
        }
    }
}
