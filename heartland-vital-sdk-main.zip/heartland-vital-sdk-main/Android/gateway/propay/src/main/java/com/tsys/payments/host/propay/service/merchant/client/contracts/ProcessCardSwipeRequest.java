package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;

/**
 * A request object that contains the financial transaction data and the credit card data, which was obtained through a
 * credit card swiper, and is ready for payment processing
 */
public class ProcessCardSwipeRequest extends SessionValidationRequest {

    private SwipeCardData SwipeCardData;

    private ProcessCardData ProcessCardData;

    private BillingData BillingData;

    private FullTransactionData FullTransactionData;

    public SwipeCardData getSwipeCardData() {
        return SwipeCardData;
    }

    public void setSwipeCardData(SwipeCardData swipeCardData) {
        SwipeCardData = swipeCardData;
    }

    public ProcessCardData getProcessCardData() {
        return ProcessCardData;
    }

    public void setProcessCardData(ProcessCardData processCardData) {
        ProcessCardData = processCardData;
    }

    public BillingData getBillingData() {
        return BillingData;
    }

    public void setBillingData(BillingData billingData) {
        BillingData = billingData;
    }

    public FullTransactionData getFullTransactionData() {
        return FullTransactionData;
    }

    public void setFullTransactionData(FullTransactionData fullTransactionData) {
        FullTransactionData = fullTransactionData;
    }
}
