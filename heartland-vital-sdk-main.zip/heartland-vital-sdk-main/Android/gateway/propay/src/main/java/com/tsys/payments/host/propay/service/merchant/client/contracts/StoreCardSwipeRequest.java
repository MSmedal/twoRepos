package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object that contains the entire set of credit card data, which was retrieved from a user's storeage, for
 * storing under a user's session
 */
public class StoreCardSwipeRequest extends SessionValidationRequest {



    private SwipeCardData SwipeCardData;


    private com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData BillingData;


    private String Tag;

    public SwipeCardData getSwipeCardData() {
        return SwipeCardData;
    }

    public void setSwipeCardData(SwipeCardData swipeCardData) {
        SwipeCardData = swipeCardData;
    }

    public com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData getBillingData() {
        return BillingData;
    }

    public void setBillingData(
            com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData billingData) {
        BillingData = billingData;
    }

    public String getTag() {
        return Tag;
    }

    public void setTag(String tag) {
        Tag = tag;
    }
}
