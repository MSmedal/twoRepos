package com.tsys.payments.host.propay.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.Nullable;

/**
 * Definitions of the ISO 4217 Currency Codes and their corresponding Java Locale
 */
public enum ProPayCurrencyCode {
    /**
     * Unsupported
     */
    Unsupported("", "", false, 0),
    /**
     * (Next day)
     */
    USN("", "", false, 997),
    /**
     * (Same day)
     */
    USS("", "", false, 998),
    /**
     * Afghani
     */
    AFN("", "", false, 971),
    /**
     * Algerian Dinar
     */
    DZD("", "", false, 12),
    /**
     * Argentine Peso
     */
    ARS("", "", false, 32),
    /**
     * Armenian Dram
     */
    AMD("", "", false, 51),
    /**
     * Aruban Guilder
     */
    AWG("", "", false, 533),
    /**
     * Australian Dollar
     */
    AUD("", "", false, 36),
    /**
     * Azerbaijanian Manat
     */
    AZN("", "", false, 944),
    /**
     * Bahamian Dollar
     */
    BSD("", "", false, 44),
    /**
     * Bahraini Dinar
     */
    BHD("", "", false, 48),
    /**
     * Baht
     */
    THB("", "", false, 764),
    /**
     * Balboa
     */
    PAB("", "", false, 590),
    /**
     * Barbados Dollar
     */
    BBD("", "", false, 52),
    /**
     * Belarussian Ruble
     */
    BYR("", "", false, 974),
    /**
     * Belize Dollar
     */
    BZD("", "", false, 84),
    /**
     * Bermudian Dollar (customarily known as Bermuda Dollar)
     */
    BMD("", "", false, 60),
    /**
     * Bolivar Fuerte
     */
    VEF("", "", false, 937),
    /**
     * Boliviano
     */
    BOB("", "", false, 68),
    /**
     * Bond Markets Units European Composite Unit (EURCO)
     */
    XBA("", "", false, 955),
    /**
     * Brazilian Real
     */
    BRL("", "", false, 986),
    /**
     * Brunei Dollar
     */
    BND("", "", false, 96),
    /**
     * Bulgarian Lev
     */
    BGN("", "", false, 975),
    /**
     * Burundi Franc
     */
    BIF("", "", false, 108),
    /**
     * Canadian Dollar
     */
    CAD("CA", "fr", false, 124),
    /**
     * Cape Verde Escudo
     */
    CVE("", "", false, 132),
    /**
     * Cayman Islands Dollar
     */
    KYD("", "", false, 136),
    /**
     * CFA Franc BCEAO
     */
    XOF("", "", false, 952),
    /**
     * CFA Franc BEAC
     */
    XAF("", "", false, 950),
    /**
     * CFP Franc
     */
    XPF("", "", false, 953),
    /**
     * Chilean Peso
     */
    CLP("", "", false, 152),
    /**
     * Codes specifically reserved for testing purposes
     */
    XTS("", "", false, 963),
    /**
     * Colombian Peso
     */
    COP("", "", false, 170),
    /**
     * Comoro Franc
     */
    KMF("", "", false, 174),
    /**
     * Convertible Marks
     */
    BAM("", "", false, 977),
    /**
     * Cordoba Oro
     */
    NIO("", "", false, 558),
    /**
     * Costa Rican Colon
     */
    CRC("", "", false, 188),
    /**
     * Croatian Kuna
     */
    HRK("", "", false, 191),
    /**
     * Cuban Peso
     */
    CUP("", "", false, 192),
    /**
     * Cyprus Pound
     */
    CYP("", "", false, 196),
    /**
     * Czech Koruna
     */
    CZK("", "", false, 203),
    /**
     * Dalasi
     */
    GMD("", "", false, 270),
    /**
     * Danish Krone
     */
    DKK("", "", false, 208),
    /**
     * Denar
     */
    MKD("", "", false, 807),
    /**
     * Djibouti Franc
     */
    DJF("", "", false, 262),
    /**
     * Dobra
     */
    STD("", "", false, 678),
    /**
     * Dominican Peso
     */
    DOP("", "", false, 214),
    /**
     * Dong
     */
    VND("", "", false, 704),
    /**
     * East Caribbean Dollar
     */
    XCD("", "", false, 951),
    /**
     * Egyptian Pound
     */
    EGP("", "", false, 818),
    /**
     * El Salvador Colon
     */
    SVC("", "", false, 222),
    /**
     * Ethiopian Birr
     */
    ETB("", "", false, 230),
    /**
     * Euro
     */
    EUR("", "", false, 978),
    /**
     * European Monetary Unit (E.M.U.-6)
     */
    XBB("", "", false, 956),
    /**
     * European Unit of Account 17(E.U.A.-17)
     */
    XBD("", "", false, 958),
    /**
     * European Unit of Account 9(E.U.A.-9)
     */
    XBC("", "", false, 957),
    /**
     * Falkland Islands Pound
     */
    FKP("", "", false, 238),
    /**
     * Fiji Dollar
     */
    FJD("", "", false, 242),
    /**
     * Forint
     */
    HUF("", "", false, 348),
    /**
     * Franc Congolais
     */
    CDF("", "", false, 976),
    /**
     * Ghana Cedi
     */
    GHS("", "", false, 936),
    /**
     * Gibraltar Pound
     */
    GIP("", "", false, 292),
    /**
     * Gold
     */
    XAU("", "", false, 959),
    /**
     * Gourde
     */
    HTG("", "", false, 332),
    /**
     * Guarani
     */
    PYG("", "", false, 600),
    /**
     * Guinea Franc
     */
    GNF("", "", false, 324),
    /**
     * Guinea-Bissau Peso
     */
    GWP("", "", false, 624),
    /**
     * Guyana Dollar
     */
    GYD("", "", false, 328),
    /**
     * Hong Kong Dollar
     */
    HKD("", "", false, 344),
    /**
     * Hryvnia
     */
    UAH("", "", false, 980),
    /**
     * Iceland Krona
     */
    ISK("", "", false, 352),
    /**
     * Indian Rupee
     */
    INR("", "", false, 356),
    /**
     * Iranian Rial
     */
    IRR("", "", false, 364),
    /**
     * Iraqi Dinar
     */
    IQD("", "", false, 368),
    /**
     * Jamaican Dollar
     */
    JMD("", "", false, 88),
    /**
     * Jordanian Dinar
     */
    JOD("", "", false, 400),
    /**
     * Kenyan Shilling
     */
    KES("", "", false, 404),
    /**
     * Kina
     */
    PGK("", "", false, 598),
    /**
     * Kip
     */
    LAK("", "", false, 418),
    /**
     * Kroon
     */
    EEK("", "", false, 233),
    /**
     * Kuwaiti Dinar
     */
    KWD("", "", false, 414),
    /**
     * Kwacha
     */
    MWK("", "", false, 454),
    /**
     * Kwacha
     */
    ZMK("", "", false, 894),
    /**
     * Kwanza
     */
    AOA("", "", false, 973),
    /**
     * Kyat
     */
    MMK("", "", false, 104),
    /**
     * Lari
     */
    GEL("", "", false, 981),
    /**
     * Latvian Lats
     */
    LVL("", "", false, 428),
    /**
     * Lebanese Pound
     */
    LBP("", "", false, 422),
    /**
     * Lek
     */
    ALL("", "", false, 8),
    /**
     * Lempira
     */
    HNL("", "", false, 340),
    /**
     * Leone
     */
    SLL("", "", false, 694),
    /**
     * Liberian Dollar
     */
    LRD("", "", false, 430),
    /**
     * Libyan Dinar
     */
    LYD("", "", false, 434),
    /**
     * Lilangeni
     */
    SZL("", "", false, 748),
    /**
     * Lithuanian Litas
     */
    LTL("", "", false, 440),
    /**
     * Loti
     */
    LSL("", "", false, 426),
    /**
     * Malagasy Ariary
     */
    MGA("", "", false, 969),
    /**
     * Malaysian Ringgit
     */
    MYR("", "", false, 458),
    /**
     * Maltese Lira
     */
    MTL("", "", false, 470),
    /**
     * Manat
     */
    TMM("", "", false, 795),
    /**
     * Mauritius Rupee
     */
    MUR("", "", false, 480),
    /**
     * Metical
     */
    MZN("", "", false, 943),
    /**
     * Mexican Peso
     */
    MXN("", "", false, 484),
    /**
     * Mexican Unidad de Inversion (UDI)
     */
    MXV("", "", false, 979),
    /**
     * Moldovan Leu
     */
    MDL("", "", false, 498),
    /**
     * Moroccan Dirham
     */
    MAD("", "", false, 504),
    /**
     * Mvdol
     */
    BOV("", "", false, 984),
    /**
     * Naira
     */
    NGN("", "", false, 566),
    /**
     * Nakfa
     */
    ERN("", "", false, 232),
    /**
     * Namibia Dollar
     */
    NAD("", "", false, 516),
    /**
     * Nepalese Rupee
     */
    NPR("", "", false, 524),
    /**
     * Netherlands Antillian Guilder
     */
    AND("", "", false, 532),
    /**
     * New Israeli Sheqel
     */
    ILS("", "", false, 376),
    /**
     * New Leu
     */
    RON("", "", false, 946),
    /**
     * New Taiwan Dollar
     */
    TWD("", "", false, 901),
    /**
     * New Turkish Lira
     */
    TRY("", "", false, 949),
    /**
     * New Zealand Dollar
     */
    NZD("", "", false, 554),
    /**
     * Ngultrum
     */
    BTN("", "", false, 64),
    /**
     * North Korean Won
     */
    KPW("", "", false, 408),
    /**
     * Norwegian Krone
     */
    NOK("", "", false, 578),
    /**
     * Nuevo Sol
     */
    PEN("", "", false, 604),
    /**
     * Ouguiya
     */
    MRO("", "", false, 478),
    /**
     * Pa'anga
     */
    TOP("", "", false, 776),
    /**
     * Pakistan Rupee
     */
    PKR("", "", false, 586),
    /**
     * Palladium
     */
    XPD("", "", false, 964),
    /**
     * Pataca
     */
    MOP("", "", false, 446),
    /**
     * Peso Uruguayo
     */
    UYU("", "", false, 858),
    /**
     * Philippine Peso
     */
    PHP("", "", false, 608),
    /**
     * Platinum
     */
    XPT("", "", false, 962),
    /**
     * Pound Sterling
     */
    GBP("", "", false, 826),
    /**
     * Pula
     */
    BWP("", "", false, 72),
    /**
     * Qatari Rial
     */
    QAR("", "", false, 634),
    /**
     * Quetzal
     */
    GTQ("", "", false, 320),
    /**
     * Rand
     */
    ZAR("", "", false, 710),
    /**
     * Rial Omani
     */
    OMR("", "", false, 512),
    /**
     * Riel
     */
    KHR("", "", false, 116),
    /**
     * Rufiyaa
     */
    MVR("", "", false, 462),
    /**
     * Rupiah
     */
    IDR("", "", false, 360),
    /**
     * Russian Ruble
     */
    RUB("", "", false, 643),
    /**
     * Rwanda Franc
     */
    RWF("", "", false, 646),
    /**
     * Saint Helena Pound
     */
    SHP("", "", false, 654),
    /**
     * Saudi Riyal
     */
    SAR("", "", false, 682),
    /**
     * SDR
     */
    XDR("", "", false, 960),
    /**
     * Serbian Dinar
     */
    RSD("", "", false, 941),
    /**
     * Seychelles Rupee
     */
    SCR("", "", false, 690),
    /**
     * Silver
     */
    XAG("", "", false, 961),
    /**
     * Singapore Dollar
     */
    SGD("", "", false, 702),
    /**
     * Slovak Koruna
     */
    SKK("", "", false, 703),
    /**
     * Solomon Islands Dollar
     */
    SBD("", "", false, 90),
    /**
     * Som
     */
    KGS("", "", false, 417),
    /**
     * Somali Shilling
     */
    SOS("", "", false, 706),
    /**
     * Somoni
     */
    TJS("", "", false, 972),
    /**
     * Sri Lanka Rupee
     */
    LKR("", "", false, 144),
    /**
     * Sudanese Pound
     */
    SDG("", "", false, 938),
    /**
     * Surinam Dollar
     */
    SRD("", "", false, 968),
    /**
     * Swedish Krona
     */
    SEK("", "", false, 752),
    /**
     * Swiss Franc
     */
    CHF("", "", false, 756),
    /**
     * Syrian Pound
     */
    SYP("", "", false, 760),
    /**
     * Taka
     */
    BDT("", "", false, 50),
    /**
     * Tala
     */
    WST("", "", false, 882),
    /**
     * Tanzanian Shilling
     */
    TZS("", "", false, 834),
    /**
     * Tenge
     */
    KZT("", "", false, 398),
    /**
     * The code assigned for transactions where no currency is
     * // involved:
     */
    XXX("", "", false, 999),
    /**
     * Trinidad and Tobago Dollar
     */
    TTD("", "", false, 80),
    /**
     * Tugrik
     */
    MNT("", "", false, 496),
    /**
     * Tunisian Dinar
     */
    TND("", "", false, 788),
    /**
     * UAE Dirham
     */
    AED("", "", false, 784),
    /**
     * Uganda Shilling
     */
    UGX("", "", false, 800),
    /**
     * Unidad de Valor Real
     */
    COU("", "", false, 970),
    /**
     * Unidades de fomento
     */
    CLF("", "", false, 990),
    /**
     * Uruguay Peso en Unidades Indexadas
     */
    UYI("", "", false, 940),
    /**
     * US Dollar
     */
    USD("US", "en", true, 840),
    /**
     * Uzbekistan Sum
     */
    UZS("", "", false, 860),
    /**
     * Vatu
     */
    VUV("", "", false, 548),
    /**
     * WIR Euro
     */
    CHE("", "", false, 947),
    /**
     * WIR Franc
     */
    CHW("", "", false, 948),
    /**
     * Won
     */
    KRW("", "", false, 410),
    /**
     * Yemeni Rial
     */
    YER("", "", false, 886),
    /**
     * Yen
     */
    JPY("", "", false, 392),
    /**
     * Yuan Renminbi
     */
    CNY("", "", false, 156),
    /**
     * Zimbabwe Dollar
     */
    ZWD("", "", false, 716),
    /**
     * Zloty
     */
    PLN("", "", false, 985);

    private final String country;
    private final String language;
    private final boolean multipleCountriesForLanguage;
    private final int currencyNumber;

    ProPayCurrencyCode(String country, String language, boolean multipleCountriesForLanguage, int currencyNumber) {
        this.country = country;
        this.language = language;
        this.multipleCountriesForLanguage = multipleCountriesForLanguage;
        this.currencyNumber = currencyNumber;
    }

    public String getCountry() {
        return country;
    }

    public String getLanguage() {
        return language;
    }

    public int getCurrencyNumber() {
        return currencyNumber;
    }

    public boolean hasMultipleCountriesForLanguage() {
        return multipleCountriesForLanguage;
    }

    public String getCurrencyCode() {
        return this.name();
    }

    /**
     * Return the currency code based on the currency number.
     *
     * @param value Currency number.
     * @return {@link ProPayCurrencyCode} matching currency code.
     */
    @Nullable
    public static ProPayCurrencyCode find(int value) {
        for (ProPayCurrencyCode code : ProPayCurrencyCode.values()) {
            if (code.currencyNumber == value) return code;
        }

        return null;
    }
}
