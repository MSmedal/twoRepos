package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains the data of a credit card that has been stored under a user's session
 */
public class StoredCardData extends BaseCreditCard {



    private String Name;


    private String ObfuscatedCardNumber;


    private String ExpirationDate;


    private String PaymentMethodId;


    private long PayerId;


    private String Description;


    private String PostalCode;


    private String Email;

    @Override
    public String getCardHolderName() {
        return Name;
    }

    @Override
    public String getExpirationDate() {
        return ExpirationDate;
    }

    @Override
    public String getCardNumber() {
        return ObfuscatedCardNumber;
    }

    @Override
    public String getTag() {
        return null;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setObfuscatedCardNumber(String obfuscatedCardNumber) {
        ObfuscatedCardNumber = obfuscatedCardNumber;
    }

    public String getPaymentMethodId() {
        return PaymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        PaymentMethodId = paymentMethodId;
    }

    public long getPayerId() {
        return PayerId;
    }

    public void setPayerId(long payerId) {
        PayerId = payerId;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(String postalCode) {
        PostalCode = postalCode;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setExpirationDate(String expirationDate) {
        ExpirationDate = expirationDate;
    }
}
