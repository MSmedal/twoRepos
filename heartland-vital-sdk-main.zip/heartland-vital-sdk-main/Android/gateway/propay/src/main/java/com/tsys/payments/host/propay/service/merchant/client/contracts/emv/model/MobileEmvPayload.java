package com.tsys.payments.host.propay.service.merchant.client.contracts.emv.model;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;
import com.tsys.payments.host.propay.enums.ProPayCardDataInputMode;

/**
 * Defines the EMV data required when ICC terminals are used for chip cards.
 */
public final class MobileEmvPayload {

    @NonNull
    @SerializedName("TlvData")
    private String mTlvData;
    @SerializedName("PosSubfieldOne")
    private Integer mTerminalCardDataInputCapability;
    @SerializedName("PosSubfieldSeven")
    private int mCardDataInputMode;
    @SerializedName("LastChipRead")
    private int mLastChipRead;
    @SerializedName("VoidReason")
    private int mVoidReason;
    @SerializedName("EncryptingDeviceType")
    private ProPayEncryptingDeviceType mDeviceType;

    public MobileEmvPayload() {
        this("");
    }

    public MobileEmvPayload(@NonNull String tlvData) {
        this.mTlvData = tlvData;
        this.mCardDataInputMode = ProPayCardDataInputMode.UNDEFINED.value;
        // API Spec Requires this to be NonNull.
        this.mDeviceType = ProPayEncryptingDeviceType.Unknown;
    }

    @NonNull
    public String getTlvData() {
        return mTlvData;
    }

    public void setTlvData(@NonNull String tlvData) {
        mTlvData = tlvData;
    }

    public Integer getTerminalCardDataInputCapability() {
        return mTerminalCardDataInputCapability;
    }

    /**
     * Set value which corresponds to POS subfield 1.
     */
    public void setTerminalCardDataInputCapability(Integer terminalCardDataInputCapability) {
        mTerminalCardDataInputCapability = terminalCardDataInputCapability;
    }

    public int getCardDataInputMode() {
        return mCardDataInputMode;
    }

    public void setCardDataInputMode(int cardDataInputMode) {
        mCardDataInputMode = cardDataInputMode;
    }

    public int getLastChipRead() {
        return mLastChipRead;
    }

    public void setLastChipRead(int lastChipRead) {
        mLastChipRead = lastChipRead;
    }

    public int getVoidReason() {
        return mVoidReason;
    }

    /**
     * Set the reason a void request is being submitted.
     */
    public void setVoidReason(int voidReason) {
        mVoidReason = voidReason;
    }

    public ProPayEncryptingDeviceType getDeviceType() {
        return mDeviceType;
    }

    public void setDeviceType(ProPayEncryptingDeviceType deviceType) {
        mDeviceType = deviceType;
    }
}
