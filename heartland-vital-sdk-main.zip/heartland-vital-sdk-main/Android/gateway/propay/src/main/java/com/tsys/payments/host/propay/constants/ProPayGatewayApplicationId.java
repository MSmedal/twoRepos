package com.tsys.payments.host.propay.constants;

public final class ProPayGatewayApplicationId {
    public static final String ANDROID_MOBY_EMV = "B401";
    public static final String ANDROID_BBPOS_EMV = "B400";
    public static final String ANDROID_NON_EMV = "B250";
}
