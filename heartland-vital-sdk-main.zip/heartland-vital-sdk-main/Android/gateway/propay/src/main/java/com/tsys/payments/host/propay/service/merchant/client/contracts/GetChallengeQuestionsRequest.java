package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * A request object that contains the user's information for obtaining their security challenge questions
 */
public class GetChallengeQuestionsRequest {



    private String Username;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }
}
