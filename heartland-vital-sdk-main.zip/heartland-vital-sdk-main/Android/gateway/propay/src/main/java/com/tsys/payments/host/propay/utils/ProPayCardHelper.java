package com.tsys.payments.host.propay.utils;

import androidx.annotation.Nullable;
import android.text.TextUtils;

public class ProPayCardHelper {
    private static final int CARD_NUMBER_SUFFIX_LENGTH = 4;

    // card enum
    public static final int NONE = -1;
    public static final int CARD_VISA = 1;
    public static final int CARD_MASTER = 2;
    public static final int CARD_AMEX = 3;
    public static final int CARD_DISCOVER = 4;
    public static final int CARD_DINERS = 5;
    public static final int CARD_JCB = 6;
    public static final int CARD_BC = 7;
    public static final int CARD_DINA = 8;
    public static final int CARD_MAESTRO = 9;
    public static final int CARD_UNIONPAY = 10;
    public static final int CARD_UNKNOWN = 11;

    public static final String BAD_CARD_TYPE_TEXT = "BAD CARD TRANSACTION_TYPE";

    private ProPayCardHelper() {
    }

    // type and validation functions begin

    /**
     * Info on how the iin works is found here:
     * http://en.wikipedia.org/wiki/Credit_card_numbers Some info on the regex
     * involved: http://www.regular-expressions.info/creditcard.html Determines
     * what type of card the given cardnumber belongs to.
     *
     * @param iin The unmasked card number. If the card number is masked, it may
     * not be possible to identify the given card, which will result
     * in a {@link ProPayCardHelper#CARD_UNKNOWN}
     * @return An CardTypes enum value for the type of credit card
     */
    public static int getCreditCardType(String iin) {
        // remove spaces
        int result = ProPayCardHelper.CARD_UNKNOWN;
        if (!TextUtils.isEmpty(iin)) {
            iin = iin.replace(" ", "");
            if (TextUtils.isEmpty(iin) || iin.charAt(0) == '*') {
                return result;
            }

            // grab the integers at the given length
            // done this way because the regex for the >= and <= would have been
            // much less legible
            int iinLength = iin.length();
            int firstOne;
            try {
                firstOne = (iinLength >= 1) ? Integer.parseInt(iin.substring(0, 1)) : 0;
            } catch (NumberFormatException e) {
                firstOne = 0;
            }
            int firstTwo;
            try {
                firstTwo = (iinLength >= 2) ? Integer.parseInt(iin.substring(0, 2)) : 0;
            } catch (NumberFormatException e) {
                firstTwo = 0;
            }
            int firstThree;
            try {
                firstThree = (iinLength >= 3) ? Integer.parseInt(iin.substring(0, 3)) : 0;
            } catch (NumberFormatException e) {
                firstThree = 0;
            }
            int firstFour;
            try {
                firstFour = (iinLength >= 4) ? Integer.parseInt(iin.substring(0, 4)) : 0;
            } catch (NumberFormatException e) {
                firstFour = 0;
            }

            // after 4 digits, it's possible that we're getting a masked card
            // number. We should still try to identify it as the first four may give
            // us a match.
            int firstFive;
            try {
                firstFive = (iinLength >= 5) ? Integer.parseInt(iin.substring(0, 5)) : 0;
            } catch (NumberFormatException e) {
                firstFive = 0;
            }
            int firstSix;
            try {
                firstSix = (iinLength >= 6) ? Integer.parseInt(iin.substring(0, 6)) : 0;
            } catch (NumberFormatException e) {
                firstSix = 0;
            }

            if (isVisa(firstOne)) {
                result = ProPayCardHelper.CARD_VISA;
            } else if (isAmex(firstTwo)) {
                result = ProPayCardHelper.CARD_AMEX;
            } else if (isMasterCard(firstTwo, firstFour)) {
                result = ProPayCardHelper.CARD_MASTER;
            } else if (isDinersCard(firstTwo, firstThree, firstFour)) {
                result = ProPayCardHelper.CARD_DINERS;
            } else if (isDiscover(firstThree, firstFive, firstSix)) {
                result = ProPayCardHelper.CARD_DISCOVER;
            } else if (isJcb(firstFour)) {
                result = ProPayCardHelper.CARD_JCB;
            } else if (isMaestro(firstFour)) {
                result = ProPayCardHelper.CARD_MAESTRO;
            } else if (isUnionPay(firstFour, firstSix)) {
                result = ProPayCardHelper.CARD_UNIONPAY;
            }
        }

        return result;
    }

    private static boolean isUnionPay(int firstFour, int firstSix) {
        return (firstSix >= 622126 && firstSix <= 622925)
                || (firstFour >= 6240 && firstFour <= 6269)
                || (firstFour >= 6282 && firstFour <= 6288);
    }

    private static boolean isMaestro(int firstFour) {
        return firstFour == 5018 || firstFour == 5020 || firstFour == 5038
                || firstFour == 6304 || firstFour == 6759 || firstFour == 6761
                || firstFour == 6763;
    }

    private static boolean isJcb(int firstFour) {
        return firstFour >= 3528 && firstFour <= 3589;
    }

    private static boolean isDiscover(int firstThree, int firstFive, int firstSix) {
        return (firstFive == 60110)
                || (firstFive >= 60112 && firstFive <= 60114)
                || (firstSix == 601175 || firstSix == 601177)
                || (firstSix >= 601186 && firstSix <= 601199)
                || (firstThree >= 644 && firstThree <= 659)
                || (firstThree >= 601 && firstThree <= 659)
                // this line will cause false positives, but TSYS wanted it. Be
                // aware.
                || (firstThree >= 600 && firstThree <= 699);
    }

    private static boolean isDinersCard(int firstTwo, int firstThree, int firstFour) {
        return (firstThree >= 300 && firstThree <= 305) || firstTwo == 36
                || firstFour == 3095 || firstTwo == 38 || firstTwo == 39;
    }

    private static boolean isMasterCard(int firstTwo, int firstFour) {
        return (firstTwo >= 51 && firstTwo <= 59) || (firstFour >= 2221 && firstFour <= 2720);
    }

    private static boolean isAmex(int firstTwo) {
        return (firstTwo == 34 || firstTwo == 37)
                || (firstTwo >= 70 && firstTwo <= 79);
    }

    private static boolean isVisa(int firstOne) {
        return firstOne == 4;
    }

    public static boolean validateCreditCardNumber(int cardNumber) {
        return validateCreditCardNumber(cardNumber + "");
    }

    public static String getCardSuffix(String cardNumber) {
        if (TextUtils.isEmpty(cardNumber) || cardNumber.length() <= CARD_NUMBER_SUFFIX_LENGTH) {
            return cardNumber;
        }

        return cardNumber.substring(cardNumber.length() - 4);
    }

    /**
     * checks the length and uses the Luhn / mod 10 algorithm in order verify
     * that this is a possibly correct card. Note that the card itself may still
     * be invalid
     */

    public static boolean validateCreditCardNumber(String cardNumber) {
        int currentCardType = getCreditCardType(cardNumber);
        int cardNumberLength = cardNumber.length();

        if (currentCardType != ProPayCardHelper.CARD_UNKNOWN) {

            // if we're not a china unionpay, or a diners club enRoute type
            // card, we can use the Luhn algorithm
            if (currentCardType != ProPayCardHelper.CARD_UNIONPAY) {
                // verify that the cards are of the right potential length for
                // each type
                if (verifyCardTypeWithLength(currentCardType, cardNumberLength)) {
                    // step one of Luhn algorithm - double every second digit
                    // from
                    // the
                    // right
                    StringBuilder creditCardBuilder = new StringBuilder(20);

                    for (int i = cardNumberLength - 1, j = 0; i > -1; i--, j++) {
                        // double every second digit from the right.
                        if (j % 2 == 1) {
                            creditCardBuilder.append(Integer.parseInt(cardNumber
                                    .substring(i, i + 1)) * 2);
                        } else {
                            creditCardBuilder.append(Integer.parseInt(cardNumber
                                    .substring(i, i + 1)));
                        }
                    }

                    cardNumber = creditCardBuilder.toString();
                    cardNumberLength = cardNumber.length();

                    // step two, sum each individual digit
                    int sum = 0;
                    for (int i = 0; i < cardNumberLength; i++) {
                        sum += Integer.parseInt(cardNumber.substring(i, i + 1));
                    }

                    // step 3 - mod 10. if it's 0, it's possibly valid
                    if (sum % 10 == 0) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else if (verifyCardTypeWithLength(currentCardType, cardNumberLength)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static boolean verifyCardTypeWithLength(int cardType, int length) {
        // if it's of a certain type, it must match a certain length
        if ((cardType == ProPayCardHelper.CARD_AMEX && length == 15)
                || (cardType == ProPayCardHelper.CARD_BC && length == 16)
                || (cardType == ProPayCardHelper.CARD_DINERS && length == 14)
                || (cardType == ProPayCardHelper.CARD_DISCOVER && length == 16)
                || (cardType == ProPayCardHelper.CARD_JCB && length == 16)
                || (cardType == ProPayCardHelper.CARD_MASTER && length == 16)
                || (cardType == ProPayCardHelper.CARD_UNIONPAY && (length >= 16 && length <= 19))
                || (cardType == ProPayCardHelper.CARD_VISA && (length == 16))
                || (cardType == ProPayCardHelper.CARD_MAESTRO && (length >= 12 && length <= 19))) {
            return true;
        } else {
            return false;
        }
    }

    public static String formatStoredCardNumber(String cardNumber) {
        if (TextUtils.isEmpty(cardNumber) && cardNumber.length() < 12) {
            return cardNumber;
        } else {
            StringBuilder cardNumberBuilder = new StringBuilder(cardNumber);
            int originalCardLength = cardNumberBuilder.length();
            cardNumberBuilder.delete(6, cardNumberBuilder.length() - 4);
            for (int i = 6; i < originalCardLength - 4; i++) {
                cardNumberBuilder.insert(i, "*");
            }
            cardNumberBuilder.insert(4, " ");
            cardNumberBuilder.insert(9, " ");
            cardNumberBuilder.insert(14, " ");
            return cardNumberBuilder.toString();
        }
    }

    public static boolean cardLengthIsGreaterEqualThanMinimumLength(int cardType, int length) {
        // if it's of a certain type, it must match a certain length
        if ((cardType == ProPayCardHelper.CARD_AMEX && length >= 15)
                || (cardType == ProPayCardHelper.CARD_BC && length >= 16)
                || (cardType == ProPayCardHelper.CARD_DINERS && length >= 14)
                || (cardType == ProPayCardHelper.CARD_DISCOVER && length >= 16)
                || (cardType == ProPayCardHelper.CARD_JCB && length >= 16)
                || (cardType == ProPayCardHelper.CARD_MASTER && length >= 16)
                || (cardType == ProPayCardHelper.CARD_UNIONPAY && (length >= 16))
                || (cardType == ProPayCardHelper.CARD_VISA && (length >= 16))
                || (cardType == ProPayCardHelper.CARD_MAESTRO && (length >= 12))
                || (cardType == ProPayCardHelper.CARD_UNKNOWN && length >= 19)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Mask a card number leaving the first 4 and last 4 numbers exposed.
     *
     * @param cardNumber Card number.
     * @param maskChar Character that will mask the hidden numbers.
     */
    private static String maskCardNumber(String cardNumber, char maskChar) {

        StringBuilder current = new StringBuilder(cardNumber);

        // if we need to replace the data.
        String mask = Character.toString(maskChar);
        if (current.length() > 8) {
            for (int i = 4; i < current.length() - 4; i++) {
                current.replace(i, i + 1, mask);
            }
        }

        if (current.length() > 4) {
            current.insert(4, ' ');
        }

        if (getCreditCardType(cardNumber) != ProPayCardHelper.CARD_AMEX) {
            if (current.length() > 9) {
                current.insert(9, ' ');
            }
            if (current.length() > 14) {
                current.insert(14, ' ');
            }
            if (current.length() > 19) {

                current.insert(19, ' ');
            }
        } else {
            if (current.length() > 11) {
                current.insert(11, ' ');
            }
        }

        return current.toString();
    }

    /**
     * Mask a card number while leaving the first 4 and last 4 exposed. Uses a '*'
     * as the mask char.
     *
     * @param cardNumber {@link String} representing the card number.
     */
    public static String maskCardNumber(String cardNumber) {
        return maskCardNumber(cardNumber, '*');
    }

    /**
     * Obtain the card name based on the PAN.
     */
    @Nullable
    public static String getCardName(String cardNumber) {
        final int cardType = getCreditCardType(cardNumber);

        if (cardType != CARD_UNKNOWN) {
            return getCardName(cardType);
        }

        return null;
    }

    public static String getCardName(int cardType) {
        String result;
        switch (cardType) {
            case CARD_MASTER:
                result = "Mastercard";
                break;
            case CARD_VISA:
                result = "Visa";
                break;
            case CARD_DISCOVER:
                result = "Discover";
                break;
            case CARD_AMEX:
                result = "American Express";
                break;
            case CARD_BC:
                result = "BC";
                break;
            case CARD_DINA:
                result = "Dinacard";
                break;
            case CARD_DINERS:
                result = "Diners Club";
                break;
            case CARD_JCB:
                result = "JCB";
                break;
            case CARD_UNIONPAY:
                result = "China Union Pay";
                break;
            case CARD_MAESTRO:
                result = "Maestro";
                break;
            case CARD_UNKNOWN:
                result = "Unknown";
                break;
            default:
                result = BAD_CARD_TYPE_TEXT;
                break;
        }

        return result;
    }

    /**
     * Returns specific gateway format for expiration date passed by the consumer application.
     * Ex:
     * 02/21, 0221, 02/2021, 022021, = 0221
     *
     * @param givenExpDate Consumer application specified Expiration Date.
     * @return Desired expiration date format that complies with the Propay Gateway.
     */
    public static String toPropayExpDateFormat(String givenExpDate){
        String desiredGatewayExpDateFormat = "";
        if(givenExpDate == null || givenExpDate.isEmpty()){
            return desiredGatewayExpDateFormat;
        }
        else {
            // mm/yy
            boolean mmSyy = givenExpDate.matches("(?:0[1-9]|1[0-2])/[0-9]{2}");
            if (mmSyy){
                desiredGatewayExpDateFormat = givenExpDate.replace("/", "");
            }
            // mmyy
            else if (givenExpDate.matches("(?:0[1-9]|1[0-2])[0-9]{2}")){
                desiredGatewayExpDateFormat = givenExpDate;
            }
            // mm/yyyy
            else if (givenExpDate.matches("(?:0[1-9]|1[0-2])/[0-9]{4}")){
                desiredGatewayExpDateFormat = givenExpDate.replace("/", "")
                        .substring(0,2) + givenExpDate.substring(5);
            }
            // mmyyyy
            else if(givenExpDate.matches("(?:0[1-9]|1[0-2])[0-9]{4}")){
                desiredGatewayExpDateFormat = givenExpDate.substring(0,2) + givenExpDate.substring(4);
            }
            else {
                // In order to avoid confusion about what is being passed send the same exp date so consumer can
                // identify the error
                desiredGatewayExpDateFormat = givenExpDate;
            }
        }
        return desiredGatewayExpDateFormat;
    }
}
