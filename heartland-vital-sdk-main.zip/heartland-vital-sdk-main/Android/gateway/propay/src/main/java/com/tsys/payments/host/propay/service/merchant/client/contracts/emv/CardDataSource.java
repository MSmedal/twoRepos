package com.tsys.payments.host.propay.service.merchant.client.contracts.emv;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Card input source.
 */
public final class CardDataSource {
    @Retention(RetentionPolicy.SOURCE)
    @IntDef({Msr,
            Insert,
            MsrFallback,
            Unknown})
    public @interface Type {
    }

    public static final int Msr = 0;
    public static final int Insert = 3;
    public static final int MsrFallback = 5;
    public static final int Unknown = -1;
}
