package com.tsys.payments.host.propay.service.merchant.client.contracts;

public class AuthenticateUserAccountResponse extends AuthenticateTokenPinResponse {

    private GrantedRight[] mGrantedRights;

    public GrantedRight[] getGrantedRights() {
        return mGrantedRights;
    }

    public void setGrantedRights(GrantedRight[] grantedRights) {
        mGrantedRights = grantedRights;
    }
}
