package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A request object that contains the user name and password data used for authenticating the client
 */
public class AuthenticateUsernamePasswordRequest extends CallerValidationRequest {

    private String Username;

    private String Password;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}
