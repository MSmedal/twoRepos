package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the result of a request to log out of the system
 */
public class LogoutResponse extends BaseResponse {
}
