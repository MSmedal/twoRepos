package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A response object that contains the result of an attempt to capture and authorize credit card data related to a
 * billable transaction
 */
public class CaptureAuthorizedTransactionResponse extends BaseTransactionResponse {
}
