package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;

/**
 * A request object that contains the session information that should be logged out of the system
 */
public class LogoutRequest extends SessionValidationRequest {
}
