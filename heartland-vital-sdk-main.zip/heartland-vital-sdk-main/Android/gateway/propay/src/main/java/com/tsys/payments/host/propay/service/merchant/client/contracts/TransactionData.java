package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

import java.util.Date;

/**
 * The ProPay financial transactin data
 */
public class TransactionData {

    private String AuthorizationCode;

    private String AvsCode;

    private Date Date;

    private long Number;

    private String InvoiceNumber;

    private String Type;

    private String Name;

    private String Email;

    private int GrossAmount;

    private int NetAmount;

    private int Fee;

    private int TipAmount;

    private TransactionStatus Status;

    private String AccountNumber;

    public String getAuthorizationCode() {
        return AuthorizationCode;
    }

    public void setAuthorizationCode(String authorizationCode) {
        AuthorizationCode = authorizationCode;
    }

    public String getAvsCode() {
        return AvsCode;
    }

    public void setAvsCode(String avsCode) {
        AvsCode = avsCode;
    }

    public Date getDate() {
        return Date;
    }

    public void setDate(Date date) {
        Date = date;
    }

    public long getNumber() {
        return Number;
    }

    public void setNumber(long number) {
        Number = number;
    }

    public String getInvoiceNumber() {
        return InvoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        InvoiceNumber = invoiceNumber;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public int getGrossAmount() {
        return GrossAmount;
    }

    public void setGrossAmount(int grossAmount) {
        GrossAmount = grossAmount;
    }

    public int getNetAmount() {
        return NetAmount;
    }

    public void setNetAmount(int netAmount) {
        NetAmount = netAmount;
    }

    public int getFee() {
        return Fee;
    }

    public void setFee(int fee) {
        Fee = fee;
    }

    public int getTipAmount() {
        return TipAmount;
    }

    public void setTipAmount(int tipAmount) {
        TipAmount = tipAmount;
    }

    public TransactionStatus getStatus() {
        return Status;
    }

    public void setStatus(TransactionStatus status) {
        Status = status;
    }

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        AccountNumber = accountNumber;
    }
}
