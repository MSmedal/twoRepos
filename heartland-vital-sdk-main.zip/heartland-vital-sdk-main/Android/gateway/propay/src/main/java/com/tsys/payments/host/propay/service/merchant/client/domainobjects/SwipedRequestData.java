package com.tsys.payments.host.propay.service.merchant.client.domainobjects;

import android.os.Parcel;
import android.os.Parcelable;

import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeRequest;
import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;
import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;

/**
 * Contains information that will be used to populate an {@link AuthorizeCardSwipeRequest} object
 */
public class SwipedRequestData implements Parcelable {
    private String mZipCode;
    private ProPayCurrencyCode mCurrencyCode;
    private String mInvoiceNumber;
    private int mTaxAmount;
    private int mAmount;
    private short[] mKeySerialNumber;
    private short[] mEncryptedTrack1Data;
    private short[] mEncryptedTrack2Data;
    private ProPayEncryptingDeviceType mDeviceType;
    private String mCardholderName;
    private boolean mShouldStoreData;

    private SwipedRequestData(Parcel in) {
        mZipCode = in.readString();
        mInvoiceNumber = in.readString();
        mTaxAmount = in.readInt();
        mAmount = in.readInt();
        mCardholderName = in.readString();
        mShouldStoreData = in.readByte() != 0;
        mKeySerialNumber = intToShortArray(in.createIntArray());
        mEncryptedTrack1Data = intToShortArray(in.createIntArray());
        mEncryptedTrack2Data = intToShortArray(in.createIntArray());
        mDeviceType = ProPayEncryptingDeviceType.values()[in.readInt()];
        mCurrencyCode = ProPayCurrencyCode.values()[in.readInt()];
    }

    public SwipedRequestData() {

    }

    public static final Creator<SwipedRequestData> CREATOR = new Creator<SwipedRequestData>() {
        @Override
        public SwipedRequestData createFromParcel(Parcel in) {
            return new SwipedRequestData(in);
        }

        @Override
        public SwipedRequestData[] newArray(int size) {
            return new SwipedRequestData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mZipCode);
        dest.writeString(mInvoiceNumber);
        dest.writeInt(mTaxAmount);
        dest.writeInt(mAmount);
        dest.writeString(mCardholderName);
        dest.writeByte((byte)(mShouldStoreData ? 1 : 0));
        dest.writeIntArray(shortToIntArray(mKeySerialNumber));
        dest.writeIntArray(shortToIntArray(mEncryptedTrack1Data));
        dest.writeIntArray(shortToIntArray(mEncryptedTrack2Data));
        dest.writeInt(mDeviceType == null ? 0 : mDeviceType.ordinal());
        dest.writeInt(mCurrencyCode == null ? 0 : mCurrencyCode.ordinal());
    }

    private int[] shortToIntArray(short[] input) {
        if (input == null) {
            return null;
        }
        int[] output = new int[input.length];
        for (int i = 0; i < input.length; i++) {
            output[i] = input[i];
        }

        return output;
    }

    private short[] intToShortArray(int[] input) {
        if (input == null) {
            return null;
        }
        short[] output = new short[input.length];
        for (int i = 0; i < input.length; i++) {
            output[i] = (short)input[i];
        }

        return output;
    }

    public String getZipCode() {
        return mZipCode;
    }

    public void setZipCode(String zipCode) {
        mZipCode = zipCode;
    }

    public ProPayCurrencyCode getCurrencyCode() {
        return mCurrencyCode;
    }

    public void setCurrencyCode(ProPayCurrencyCode currencyCode) {
        mCurrencyCode = currencyCode;
    }

    public String getInvoiceNumber() {
        return mInvoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        mInvoiceNumber = invoiceNumber;
    }

    public int getTaxAmount() {
        return mTaxAmount;
    }

    public void setTaxAmount(int taxAmount) {
        mTaxAmount = taxAmount;
    }

    public int getAmount() {
        return mAmount;
    }

    public void setAmount(int amount) {
        mAmount = amount;
    }

    public short[] getKeySerialNumber() {
        return mKeySerialNumber;
    }

    public void setKeySerialNumber(short[] keySerialNumber) {
        mKeySerialNumber = keySerialNumber;
    }

    public short[] getEncryptedTrack1Data() {
        return mEncryptedTrack1Data;
    }

    public void setEncryptedTrack1Data(short[] encryptedTrack1Data) {
        mEncryptedTrack1Data = encryptedTrack1Data;
    }

    public short[] getEncryptedTrack2Data() {
        return mEncryptedTrack2Data;
    }

    public void setEncryptedTrack2Data(short[] encryptedTrack2Data) {
        mEncryptedTrack2Data = encryptedTrack2Data;
    }

    public ProPayEncryptingDeviceType getDeviceType() {
        return mDeviceType;
    }

    public void setDeviceType(ProPayEncryptingDeviceType deviceType) {
        mDeviceType = deviceType;
    }

    public String getCardholderName() {
        return mCardholderName;
    }

    public void setCardholderName(String cardholderName) {
        mCardholderName = cardholderName;
    }

    public boolean doStoreCardData() {
        return mShouldStoreData;
    }

    public void setStoreCardData(boolean shouldStoreData) {
        mShouldStoreData = shouldStoreData;
    }
}
