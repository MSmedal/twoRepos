package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;

/**
 * A request object that contains the entire set of credit card data, which was obtained by manually entering credit
 * card information, for storing under a user's session
 */
public class ProcessAndStoreManualCardRequest extends SessionValidationRequest {

    private ManualCardData ManualCardData;

    private ProcessCardData ProcessCardData;

    private BillingData BillingData;

    private FullTransactionData FullTransactionData;

    public ManualCardData getManualCardData() {
        return ManualCardData;
    }

    public void setManualCardData(ManualCardData manualCardData) {
        ManualCardData = manualCardData;
    }

    public ProcessCardData getProcessCardData() {
        return ProcessCardData;
    }

    public void setProcessCardData(ProcessCardData processCardData) {
        ProcessCardData = processCardData;
    }

    public BillingData getBillingData() {
        return BillingData;
    }

    public void setBillingData(BillingData billingData) {
        BillingData = billingData;
    }

    public FullTransactionData getFullTransactionData() {
        return FullTransactionData;
    }

    public void setFullTransactionData(FullTransactionData fullTransactionData) {
        FullTransactionData = fullTransactionData;
    }
}
