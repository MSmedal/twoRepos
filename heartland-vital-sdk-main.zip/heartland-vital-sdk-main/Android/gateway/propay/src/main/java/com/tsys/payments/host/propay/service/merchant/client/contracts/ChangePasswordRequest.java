package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * A request object that contains values to change a password for a user
 */
public class ChangePasswordRequest {



    private String Username;


    private String CurrentPassword;


    private String NewPassword;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getCurrentPassword() {
        return CurrentPassword;
    }

    public void setCurrentPassword(String currentPassword) {
        CurrentPassword = currentPassword;
    }

    public String getNewPassword() {
        return NewPassword;
    }

    public void setNewPassword(String newPassword) {
        NewPassword = newPassword;
    }
}
