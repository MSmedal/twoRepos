package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object that contains the entire set of credit card data, which was retrieved from a user's storage, for
 * payment processing and storing under a user's session
 */
public class ProcessStoredCardRequest extends SessionValidationRequest {



    private String PaymentMethodId;


    private long PayerId;


    private com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData BillingData;


    private ProcessCardData ProcessCardData;

    public String getPaymentMethodId() {
        return PaymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        PaymentMethodId = paymentMethodId;
    }

    public long getPayerId() {
        return PayerId;
    }

    public void setPayerId(long payerId) {
        PayerId = payerId;
    }

    public com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData getBillingData() {
        return BillingData;
    }

    public void setBillingData(
            com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData billingData) {
        BillingData = billingData;
    }

    public ProcessCardData getProcessCardData() {
        return ProcessCardData;
    }

    public void setProcessCardData(ProcessCardData processCardData) {
        ProcessCardData = processCardData;
    }
}
