package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * Definitions for the CAMS permission framework
 */
public enum CamsSystem {
    ALL(0), GW(1), SPS(2), SPC(3), PPL(4), PPLCAN(5), PARTNERPORTAL(6);

    private final int code;

    CamsSystem(int code) {
        this.code = code;
    }

    /**
     * Getter to obtain the CAMS code
     *
     * @return the code's integer value
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Getter to obtain the CAMS code
     *
     * @param asInt The code's integer value
     * @return the CAMS enumeration value
     */
    public static CamsSystem parse(int asInt) {
        switch (asInt) {
            default:
            case 0:
                return CamsSystem.ALL;
            case 1:
                return CamsSystem.GW;
            case 2:
                return CamsSystem.SPS;
            case 3:
                return CamsSystem.SPC;
            case 4:
                return CamsSystem.PPL;
            case 5:
                return CamsSystem.PPLCAN;
            case 6:
                return CamsSystem.PARTNERPORTAL;
        }
    }
}
