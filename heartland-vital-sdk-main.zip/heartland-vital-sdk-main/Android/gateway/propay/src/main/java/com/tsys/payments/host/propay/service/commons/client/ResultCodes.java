package com.tsys.payments.host.propay.service.commons.client;

/**
 * Definitions of the possible result codes from a ProPay service method.
 */
public class ResultCodes {

    /**
     * A connection failure has occurred while connecting to the ProPay service
     */
    public static final int ERROR_CONNECTION_EXCEPTION = -1;

    /**
     * Success
     */
    public static final int SUCCESS = 0;
}
