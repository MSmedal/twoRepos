package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

import java.util.Date;

/**
 * Contains basic metadata for validating and tracking a financial transaction
 */
public class CallerValidation {


    private byte[] ValidationCode;


    private Date ValidationDateTime;

    public byte[] getValidationCode() {
        return ValidationCode;
    }

    public void setValidationCode(byte[] validationCode) {
        ValidationCode = validationCode;
    }

    public Date getValidationDateTime() {
        return ValidationDateTime;
    }

    public void setValidationDateTime(Date validationDateTime) {
        ValidationDateTime = validationDateTime;
    }
}
