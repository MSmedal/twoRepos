package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

/**
 * Contains the success or failure response to an attempt to register a device
 */
public class RegisterDeviceResponse extends BaseResponse {



    private String DeviceRegistrationId;

    public String getDeviceRegistrationId() {
        return DeviceRegistrationId;
    }

    public void setDeviceRegistrationId(String deviceRegistrationId) {
        DeviceRegistrationId = deviceRegistrationId;
    }
}
