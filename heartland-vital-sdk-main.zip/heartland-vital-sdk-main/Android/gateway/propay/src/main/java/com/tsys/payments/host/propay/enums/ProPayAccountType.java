package com.tsys.payments.host.propay.enums;

/**
 * Represents the account type of the user currently signed in to the ProPay services. There are three primary account
 * types:
 * Sales Rep, Merchant and Commissions
 */
public enum ProPayAccountType {
    SalesRep,
    Merchant,
    Commissions
}
