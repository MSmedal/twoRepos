package com.tsys.payments.host.propay.enums;

import com.tsys.payments.library.enums.ReversalReason;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public enum VoidReason {
    Undefined(0),
    VoidedByCustomer(2501),
    DeviceTimeout(2502),
    DeviceUnavailable(2503),
    PartialReversal(2504),
    PrematureChipRemoval(2516),
    ChipDeclined(2517);

    public final int value;

    VoidReason(int value) {
        this.value = value;
    }

    @NonNull
    public static VoidReason fromSdkVoid(@Nullable ReversalReason reversalReason) {
        if (reversalReason != null) {
            switch (reversalReason) {
                case UNDEFINED:
                    return Undefined;
                case VOIDED_BY_CUSTOMER:
                    return VoidedByCustomer;
                case DEVICE_TIMEOUT:
                    return DeviceTimeout;
                case DEVICE_UNAVAILABLE:
                    return DeviceUnavailable;
                case CHIP_DECLINED:
                    return ChipDeclined;
                case PARTIAL_REVERSAL:
                    return PartialReversal;
                case PREMATURE_CHIP_REMOVAL:
                    return PrematureChipRemoval;
            }
        }

        return Undefined;
    }
}
