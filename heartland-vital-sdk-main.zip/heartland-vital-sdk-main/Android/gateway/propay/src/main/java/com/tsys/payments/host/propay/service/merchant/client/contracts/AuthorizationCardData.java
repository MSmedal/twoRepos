package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;

/**
 * A request object that contains the credit card metadata used for authenticating a credit card transaction
 */
public class AuthorizationCardData {

    private String InvoiceNumber;
    private long MerchantProfileId;
    private long Amount;
    private ProPayCurrencyCode CurrencyCode;
    private String Comment1;
    private String Comment2;
    private long TaxAmount;

    public String getInvoiceNumber() {
        return InvoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        InvoiceNumber = invoiceNumber;
    }

    public long getMerchantProfileId() {
        return MerchantProfileId;
    }

    /**
     * Sets the Merchant Profile Id to use (0 means "use default").
     */
    public void setMerchantProfileId(long merchantProfileId) {
        MerchantProfileId = merchantProfileId;
    }

    public long getAmount() {
        return Amount;
    }

    /**
     * Sets the amount in pennies of the transaction.
     */
    public void setAmount(long amount) {
        Amount = amount;
    }

    public ProPayCurrencyCode getCurrencyCode() {
        return CurrencyCode;
    }

    public void setCurrencyCode(ProPayCurrencyCode currencyCode) {
        CurrencyCode = currencyCode;
    }

    public String getComment1() {
        return Comment1;
    }

    public void setComment1(String comment1) {
        Comment1 = comment1;
    }

    public String getComment2() {
        return Comment2;
    }

    public void setComment2(String comment2) {
        Comment2 = comment2;
    }

    public long getTaxAmount() {
        return TaxAmount;
    }

    public void setTaxAmount(long taxAmount) {
        TaxAmount = taxAmount;
    }
}
