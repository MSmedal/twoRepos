package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;
import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;

/**
 * Contains the metadata for a financial transaction that is mature enough for checkout or processing
 */
public class ProcessCardData {



    private String InvoiceNumber;


    private long MerchantProfileId;


    private long Amount;


    private ProPayCurrencyCode CurrencyCode;


    private String Comment1;


    private String Comment2;


    private long TaxAmount;


    private long TipAmount;

    public String getInvoiceNumber() {
        return InvoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        InvoiceNumber = invoiceNumber;
    }

    public long getMerchantProfileId() {
        return MerchantProfileId;
    }

    public void setMerchantProfileId(long merchantProfileId) {
        MerchantProfileId = merchantProfileId;
    }

    public long getAmount() {
        return Amount;
    }

    public void setAmount(long amount) {
        Amount = amount;
    }

    public ProPayCurrencyCode getCurrencyCode() {
        return CurrencyCode;
    }

    public void setCurrencyCode(ProPayCurrencyCode currencyCode) {
        CurrencyCode = currencyCode;
    }

    public String getComment1() {
        return Comment1;
    }

    public void setComment1(String comment1) {
        Comment1 = comment1;
    }

    public String getComment2() {
        return Comment2;
    }

    public void setComment2(String comment2) {
        Comment2 = comment2;
    }

    public long getTaxAmount() {
        return TaxAmount;
    }

    public void setTaxAmount(long taxAmount) {
        TaxAmount = taxAmount;
    }

    public long getTipAmount() {
        return TipAmount;
    }

    public void setTipAmount(long tipAmount) {
        TipAmount = tipAmount;
    }
}
