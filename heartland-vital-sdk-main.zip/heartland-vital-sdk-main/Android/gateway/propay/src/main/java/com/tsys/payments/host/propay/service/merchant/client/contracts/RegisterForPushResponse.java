package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

public class RegisterForPushResponse extends BaseResponse {

    private String RegistrationId;

    public RegisterForPushResponse() {
    }

    public String getRegistrationId() {
        return RegistrationId;
    }

    public void setRegistrationId(String registrationId) {
        RegistrationId = registrationId;
    }
}
