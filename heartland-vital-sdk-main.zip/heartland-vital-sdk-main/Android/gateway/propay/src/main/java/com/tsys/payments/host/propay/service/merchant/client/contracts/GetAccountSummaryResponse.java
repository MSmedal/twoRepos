package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

import java.math.BigDecimal;
import java.util.Date;

/**
 * A response object that contains the account metadata associated with a user session
 */
public class GetAccountSummaryResponse extends BaseResponse {



    private BigDecimal AvailableBalance;


    private BigDecimal TransactionsInProcess;


    private BigDecimal LimitProcessed;


    private BigDecimal LimitRemaining;


    private long AccountNumber;


    private Date AccountExpiration;

    public BigDecimal getAvailableBalance() {
        return AvailableBalance;
    }

    public void setAvailableBalance(BigDecimal availableBalance) {
        AvailableBalance = availableBalance;
    }

    public BigDecimal getTransactionsInProcess() {
        return TransactionsInProcess;
    }

    public void setTransactionsInProcess(BigDecimal transactionsInProcess) {
        TransactionsInProcess = transactionsInProcess;
    }

    public BigDecimal getLimitProcessed() {
        return LimitProcessed;
    }

    public void setLimitProcessed(BigDecimal limitProcessed) {
        LimitProcessed = limitProcessed;
    }

    public BigDecimal getLimitRemaining() {
        return LimitRemaining;
    }

    public void setLimitRemaining(BigDecimal limitRemaining) {
        LimitRemaining = limitRemaining;
    }

    public long getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        AccountNumber = accountNumber;
    }

    public Date getAccountExpiration() {
        return AccountExpiration;
    }

    public void setAccountExpiration(Date accountExpiration) {
        AccountExpiration = accountExpiration;
    }
}
