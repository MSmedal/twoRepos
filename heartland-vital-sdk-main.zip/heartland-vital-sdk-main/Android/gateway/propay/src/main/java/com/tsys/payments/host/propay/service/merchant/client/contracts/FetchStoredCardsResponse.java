package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

/**
 * A response object that contains the stored credit cards associated with a user session
 */
public class FetchStoredCardsResponse extends BaseResponse {



    private StoredCardData[] StoredCards;

    public StoredCardData[] getStoredCards() {
        return StoredCards;
    }

    public void setStoredCards(StoredCardData[] storedCards) {
        StoredCards = storedCards;
    }
}
