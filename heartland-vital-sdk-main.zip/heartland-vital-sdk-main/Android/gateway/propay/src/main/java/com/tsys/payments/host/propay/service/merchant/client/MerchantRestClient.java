package com.tsys.payments.host.propay.service.merchant.client;

import androidx.annotation.NonNull;
import android.util.Log;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthenticateTokenPinRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthenticateTokenPinResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthenticateUsernamePasswordRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthenticateUsernamePasswordResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeManualEntryRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeManualEntryResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CaptureAuthorizedTransactionRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CaptureAuthorizedTransactionResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ChangePasswordRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ChangePasswordResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.DeleteStoredCardRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.DeleteStoredCardResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.EditStoredCardRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.EditStoredCardResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ExternalProPayToProPayRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ExternalProPayToProPayResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.FetchStoredCardsRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.FetchStoredCardsResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ForgotPasswordRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ForgotPasswordResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.GetAccountDataForTransferRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.GetAccountDataForTransferResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.GetAccountSummaryRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.GetAccountSummaryResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.GetChallengeQuestionsRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.GetChallengeQuestionsResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.GetRecentTransactionsRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.GetRecentTransactionsResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.LogoutRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.LogoutResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessAndStoreCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessAndStoreCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessAndStoreManualCardRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessAndStoreManualCardResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessManualCardRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessManualCardResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessStoredCardRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessStoredCardResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.RegisterDeviceRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.RegisterDeviceResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.RegisterForPushRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.RegisterForPushResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SendInvoiceRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SendInvoiceResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SetChallengeQuestionsRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SetChallengeQuestionsResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SetPinRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SetPinResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.StoreCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.StoreCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.TransferFundsToBankRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.TransferFundsToBankResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.UnregisterForPushRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.UpdateChallengeQuestionsRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.UpdateChallengeQuestionsResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.VoidOrRefundRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.VoidOrRefundResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvFallbackRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvResponse;

/**
 * MerchantRestClient is the main class for accessing and utilizing the ProPay Merchant Service SDK
 */
public final class MerchantRestClient extends BaseRestClient {

    private static final String TAG = MerchantRestClient.class.getSimpleName();

    private static MerchantRestClient sInstance;

    /**
     * Merchant web services accessible through ProPay's endpoints.
     */
    public enum MerchantServiceMethods {
        AuthenticateUsernamePassword,
        AuthenticateTokenPin,
        SetPin,
        Logout,
        ProcessCardSwipe,
        ProcessAndStoreCardSwipe,
        StoreCardSwipe,
        ProcessStoredCard,
        FetchStoredCards,
        DeleteStoredCard,
        EditStoredCard,
        GetAccountSummary,
        GetRecentTransactions,
        ProcessManualCard,
        ProcessAndStoreManualCard,
        GetAccountDataForTransfer,
        TransferFundsToBank,
        AuthorizeCardSwipe,
        AuthorizeManualEntry,
        CaptureAuthorizedTransaction,
        VoidOrRefund,
        ChangePassword,
        GetChallengeQuestions,
        RegisterDevice,
        UpdateChallengeQuestions,
        SetChallengeQuestions,
        ForgotPassword,
        ProcessAndStorePropayToPropayTransfer,
        SendInvoiceToCustomer,
        RegisterForPush,
        UnregisterForPush,
        AuthorizeEmv,
        AuthorizeEmvFallback
    }

    private MerchantRestClient() {

    }

    /**
     * Create a client object for accessing a ProPay Merchant service.
     * This must be called before
     *
     * @param baseEndpointUrl Endpoint for accessing ProPay web services.
     */
    public static void init(String baseEndpointUrl) {
        if (sInstance == null) {
            synchronized (MerchantRestClient.class) {
                if (sInstance == null) {
                    sInstance = new MerchantRestClient();
                    sInstance.setBaseEndpointUrl(baseEndpointUrl);
                }
            }
        }
    }

    /**
     * Return a reference to the client singleton.
     */
    public static MerchantRestClient getInstance() {
        return sInstance;
    }

    /**
     * Returns the string representation of the complete URL needed to access a particular
     * web service function.
     *
     * @param method {@link MerchantServiceMethods} identifier for the web service
     * @return URL to access the web service function.
     */
    private String getRequestUrl(MerchantServiceMethods method) {
        return super.getBaseEndpointUrl() + "Merchant.svc/json/" + method.toString();
    }

    private <TRequest, TResponse> TResponse invokeRemoteMethod(MerchantServiceMethods method, TRequest request,
            Class<? extends Object> responseType) throws Exception {
        try {
            return super.invokeRemoteMethod(getRequestUrl(method), request, responseType);
        } catch (Exception ex) {
            Log.e(TAG, ex.toString());
            throw ex;
        }
    }


    /**
     * Authenticates a caller with a username / password combination.
     * This method is the first one that must be called before other methods within this SDK.
     *
     * @param request {@link AuthenticateUsernamePasswordRequest AuthenticateUsernamePasswordRequest} The object
     * containing the service method's request data.
     * @return {@link AuthenticateUsernamePasswordResponse AuthenticateUsernamePasswordResponse} The object containing
     * the service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public AuthenticateUsernamePasswordResponse authenticateUsernamePassword(
            AuthenticateUsernamePasswordRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.AuthenticateUsernamePassword, request,
                AuthenticateUsernamePasswordResponse.class);
    }

    /**
     * Authenticates a caller with a token / pin combination
     *
     * @param request {@link AuthenticateTokenPinRequest AuthenticateTokenPinRequest} The object containing the service
     * method's request data.
     * @return {@link AuthenticateTokenPinResponse AuthenticateTokenPinResponse} The object containing the service
     * method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public AuthenticateTokenPinResponse authenticateTokenPin(AuthenticateTokenPinRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.AuthenticateTokenPin, request,
                AuthenticateTokenPinResponse.class);
    }

    /**
     * Creates or Updates a pin for a username / password combination
     *
     * @param request {@link SetPinRequest SetPinRequest} The object containing the service method's request data.
     * @return {@link SetPinResponse SetPinResponse} The object containing the service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public SetPinResponse setPin(SetPinRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.SetPin, request,
                SetPinResponse.class);
    }

    /**
     * Logs out the current session
     *
     * @param request {@link LogoutRequest LogoutRequest} The object containing the service method's request data.
     * @return {@link LogoutResponse LogoutResponse} The object containing the service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public LogoutResponse logout(LogoutRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.Logout, request,
                LogoutResponse.class);
    }

    /**
     * Process Manual Card Entry
     *
     * @param request {@link ProcessManualCardRequest ProcessManualCardRequest} The object containing the service
     * method's request data.
     * @return {@link ProcessManualCardResponse ProcessManualCardResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public ProcessManualCardResponse processManualCard(ProcessManualCardRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.ProcessManualCard, request,
                ProcessManualCardResponse.class);
    }

    /**
     * Process and Store Manual Card Entry
     *
     * @param request {@link ProcessAndStoreManualCardRequest ProcessAndStoreManualCardRequest} The object containing
     * the service method's request data.
     * @return {@link ProcessAndStoreManualCardResponse ProcessAndStoreManualCardResponse} The object containing the
     * service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public ProcessAndStoreManualCardResponse processAndStoreManualCard(ProcessAndStoreManualCardRequest request)
            throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.ProcessAndStoreManualCard, request,
                ProcessAndStoreManualCardResponse.class);
    }

    /**
     * Process Card Swipe
     *
     * @param request {@link ProcessCardSwipeRequest ProcessCardSwipeRequest} The object containing the service
     * method's
     * request data.
     * @return {@link ProcessCardSwipeResponse ProcessCardSwipeResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public ProcessCardSwipeResponse processCardSwipe(ProcessCardSwipeRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.ProcessCardSwipe, request,
                ProcessCardSwipeResponse.class);
    }

    /**
     * Process and Store Card Swipe
     *
     * @param request {@link ProcessAndStoreCardSwipeRequest ProcessAndStoreCardSwipeRequest} The object containing the
     * service method's request data.
     * @return {@link ProcessAndStoreCardSwipeResponse ProcessAndStoreCardSwipeResponse} The object containing the
     * service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public ProcessAndStoreCardSwipeResponse processAndStoreCardSwipe(ProcessAndStoreCardSwipeRequest request)
            throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.ProcessAndStoreCardSwipe, request,
                ProcessAndStoreCardSwipeResponse.class);
    }

    /**
     * Store card swipe
     *
     * @param request {@link StoreCardSwipeRequest StoreCardSwipeRequest} The object containing the service method's
     * request data.
     * @return {@link StoreCardSwipeResponse StoreCardSwipeResponse} The object containing the service method's response
     * data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public StoreCardSwipeResponse storeCardSwipe(StoreCardSwipeRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.StoreCardSwipe, request,
                StoreCardSwipeResponse.class);
    }

    /**
     * Process a stored card
     *
     * @param request {@link ProcessStoredCardRequest ProcessStoredCardRequest} The object containing the service
     * method's request data.
     * @return {@link ProcessStoredCardResponse ProcessStoredCardResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public ProcessStoredCardResponse processStoredCard(ProcessStoredCardRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.ProcessStoredCard, request,
                ProcessStoredCardResponse.class);
    }

    /**
     * Fetch Stored Cards
     *
     * @param request {@link FetchStoredCardsRequest FetchStoredCardsRequest} The object containing the service
     * method's
     * request data.
     * @return {@link FetchStoredCardsResponse FetchStoredCardsResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public FetchStoredCardsResponse fetchStoredCards(FetchStoredCardsRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.FetchStoredCards, request,
                FetchStoredCardsResponse.class);
    }

    /**
     * Send an invoice to the customer.
     */
    public SendInvoiceResponse sendInvoice(SendInvoiceRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.SendInvoiceToCustomer, request, SendInvoiceResponse.class);
    }

    /**
     * Delete Stored Card
     *
     * @param request {@link DeleteStoredCardRequest DeleteStoredCardDeleteRequest} The object containing the service
     * method's request data.
     * @return {@link DeleteStoredCardResponse DeleteStoredCardResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public DeleteStoredCardResponse deleteStoredCard(DeleteStoredCardRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.DeleteStoredCard, request,
                DeleteStoredCardResponse.class);
    }

    /**
     * Edit Stored Card
     *
     * @param request {@link EditStoredCardRequest EditStoredCardRequest} The object containing the service
     * method's request data.
     * @return {@link EditStoredCardResponse EditStoredCardResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public EditStoredCardResponse editStoredCard(EditStoredCardRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.EditStoredCard, request,
                EditStoredCardResponse.class);
    }

    /**
     * Get Account Summary
     *
     * @param request {@link GetAccountSummaryRequest GetAccountSummaryRequest} The object containing the service
     * method's request data.
     * @return {@link GetAccountSummaryResponse GetAccountSummaryResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public GetAccountSummaryResponse getAccountSummary(GetAccountSummaryRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.GetAccountSummary, request,
                GetAccountSummaryResponse.class);
    }

    /**
     * Gets the recent transactions
     *
     * @param request {@link GetRecentTransactionsRequest GetRecentTransactionsRequest} The object containing the
     * service method's request data.
     * @return {@link GetRecentTransactionsResponse GetRecentTransactionsResponse} The object containing the service
     * method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public GetRecentTransactionsResponse getRecentTransactions(GetRecentTransactionsRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.GetRecentTransactions, request,
                GetRecentTransactionsResponse.class);
    }

    /**
     * Gets relevant account data for an ACH transfer
     *
     * @param request {@link GetAccountDataForTransferRequest GetAccountDataForTransferRequest} The object containing
     * the service method's request data.
     * @return {@link GetAccountDataForTransferResponse GetAccountDataForTransferResponse} The object containing the
     * service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public GetAccountDataForTransferResponse getAccountDataForTransfer(GetAccountDataForTransferRequest request)
            throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.GetAccountDataForTransfer, request,
                GetAccountDataForTransferResponse.class);
    }

    /**
     * Transfers money to the on-file bank account
     *
     * @param request {@link TransferFundsToBankRequest TransferFundsToBankRequest} The object containing the service
     * method's request data.
     * @return {@link TransferFundsToBankResponse TransferFundsToBankResponse} The object containing the service
     * method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public TransferFundsToBankResponse transferFundsToBank(TransferFundsToBankRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.TransferFundsToBank, request,
                TransferFundsToBankResponse.class);
    }

    /**
     * @param request {@link AuthorizeCardSwipeRequest AuthorizeCardSwipeRequest} The object containing the service
     * method's request data.
     * @return {@link AuthorizeCardSwipeResponse AuthorizeCardSwipeResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public AuthorizeCardSwipeResponse authorizeCardSwipe(AuthorizeCardSwipeRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.AuthorizeCardSwipe, request,
                AuthorizeCardSwipeResponse.class);
    }

    /**
     * Perform an authorization request via EMV MSR fallback.
     *
     * @param request {@link AuthorizeEmvFallbackRequest} The object containing the data needed to perform an EMV
     * fallback
     * transaction to MSR.
     * @return {@link AuthorizeCardSwipeResponse} Response containing the result of performing the fallback request.
     */
    public AuthorizeCardSwipeResponse authorizeEmvFallback(@NonNull AuthorizeEmvFallbackRequest request)
            throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.AuthorizeEmvFallback, request,
                AuthorizeCardSwipeResponse.class);
    }

    /**
     * Perform an authorization request via EMV MSR fallback.
     *
     * @param request {@link AuthorizeEmvRequest} The object containing the data needed to perform an EMV
     * transaction.
     * @return {@link AuthorizeEmvResponse} Response containing the result of performing the EMV transaction request.
     */
    public AuthorizeEmvResponse authorizeEmv(@NonNull AuthorizeEmvRequest request)
            throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.AuthorizeEmv, request,
                AuthorizeEmvResponse.class);
    }

    /**
     * @param request {@link AuthorizeManualEntryRequest AuthorizeManualEntryRequest} The object containing the service
     * method's request data.
     * @return {@link AuthorizeManualEntryResponse AuthorizeManualEntryResponse} The object containing the service
     * method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public AuthorizeManualEntryResponse authorizeManualEntry(AuthorizeManualEntryRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.AuthorizeManualEntry, request,
                AuthorizeManualEntryResponse.class);
    }

    /**
     * @param request {@link CaptureAuthorizedTransactionRequest CaptureAuthorizedTransactionRequest} The object
     * containing the service method's request data.
     * @return {@link CaptureAuthorizedTransactionResponse CaptureAuthorizedTransactionResponse} The object containing
     * the service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public CaptureAuthorizedTransactionResponse captureAuthorizedTransaction(
            CaptureAuthorizedTransactionRequest request)
            throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.CaptureAuthorizedTransaction, request,
                CaptureAuthorizedTransactionResponse.class);
    }

    /**
     * @param request {@link VoidOrRefundRequest VoidOrRefundRequest} The object containing the service method's
     * request
     * data.
     * @return {@link VoidOrRefundResponse VoidOrRefundResponse} The object containing the service method's response
     * data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public VoidOrRefundResponse voidOrRefund(VoidOrRefundRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.VoidOrRefund, request,
                VoidOrRefundResponse.class);
    }

    /**
     * @param request {@link ChangePasswordRequest ChangePasswordRequest} The object containing the service method's
     * request data.
     * @return {@link ChangePasswordResponse ChangePasswordResponse} The object containing the service method's response
     * data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public ChangePasswordResponse changePassword(ChangePasswordRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.ChangePassword, request,
                ChangePasswordResponse.class);
    }

    /**
     * @param request {@link GetChallengeQuestionsRequest GetChallengeQuestionsRequest} The object containing the
     * service method's request data.
     * @return {@link GetChallengeQuestionsResponse GetChallengeQuestionsResponse} The object containing the service
     * method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public GetChallengeQuestionsResponse getChallengeQuestions(GetChallengeQuestionsRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.GetChallengeQuestions, request,
                GetChallengeQuestionsResponse.class);
    }

    /**
     * @param request {@link RegisterDeviceRequest RegisterDeviceRequest} The object containing the service method's
     * request data.
     * @return {@link RegisterDeviceResponse RegisterDeviceResponse} The object containing the service method's response
     * data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public RegisterDeviceResponse registerDevice(RegisterDeviceRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.RegisterDevice, request,
                RegisterDeviceResponse.class);
    }

    /**
     * @param request {@link UpdateChallengeQuestionsRequest UpdateChallengeQuestionsRequest} The object containing the
     * service method's request data.
     * @return {@link UpdateChallengeQuestionsResponse UpdateChallengeQuestionsResponse} The object containing the
     * service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public UpdateChallengeQuestionsResponse updateChallengeQuestions(UpdateChallengeQuestionsRequest request)
            throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.UpdateChallengeQuestions, request,
                UpdateChallengeQuestionsResponse.class);
    }

    /**
     * @param request {@link SetChallengeQuestionsRequest SetChallengeQuestionsRequest} The object containing the
     * service method's request data.
     * @return {@link SetChallengeQuestionsResponse SetChallengeQuestionsResponse} The object containing the service
     * method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public SetChallengeQuestionsResponse setChallengeQuestions(SetChallengeQuestionsRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.SetChallengeQuestions, request,
                SetChallengeQuestionsResponse.class);
    }

    /**
     * @param request {@link ForgotPasswordRequest ForgotPasswordRequest} The object containing the service method's
     * request data.
     * @return {@link ForgotPasswordResponse ForgotPasswordResponse} The object containing the service method's response
     * data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public ForgotPasswordResponse forgotPassword(ForgotPasswordRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.ForgotPassword, request,
                ForgotPasswordResponse.class);
    }

    /**
     * @param request {@link ExternalProPayToProPayRequest} The object containing the service method's request data.
     * @return {@link ExternalProPayToProPayResponse} The object containing the service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service.
     */
    public ExternalProPayToProPayResponse propayToPropayTransfer(ExternalProPayToProPayRequest request)
            throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.ProcessAndStorePropayToPropayTransfer, request,
                ExternalProPayToProPayResponse.class);
    }

    /**
     * @param request {@link RegisterForPushRequest RegisterForPushRequest} The object containing the service method's
     * request data.
     * @return {@link RegisterForPushResponse RegisterForPushResponse} The object containing the service method's
     * response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public RegisterForPushResponse registerForPushNotifications(RegisterForPushRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.RegisterForPush, request, RegisterForPushResponse.class);
    }

    /**
     * @param request {@link UnregisterForPushRequest UnregisterForPushRequest} The object containing the service
     * method's request data.
     * @return {@link BaseResponse BaseResponse} The object containing the service method's response data.
     *
     * @throws Exception The base Exception containing the specific error encountered during the service
     */
    public BaseResponse unregisterPushNotifications(UnregisterForPushRequest request) throws Exception {
        return invokeRemoteMethod(MerchantServiceMethods.UnregisterForPush, request, BaseResponse.class);
    }
}
