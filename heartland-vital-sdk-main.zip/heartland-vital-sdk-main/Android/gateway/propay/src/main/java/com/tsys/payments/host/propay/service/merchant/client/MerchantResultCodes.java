package com.tsys.payments.host.propay.service.merchant.client;

import com.tsys.payments.host.propay.service.commons.client.ResultCodes;

/**
 * Definitions of the possible result codes from a Merchant service method.
 */
public class MerchantResultCodes extends ResultCodes {

    /**
     * The user must visit the ProPay website due to a forgot password notification
     */
    public static final int FORGOT_PASSWORD_WEB = 306;
    /**
     * The user's PIN token was not found and the user will be denied access
     */
    public static final int PIN_TOKEN_NOT_FOUND = 331;
    /**
     * The user's credentials have been locked and the user will be denied access
     */
    public static final int CREDENTIALS_LOCKED = 333;
    /**
     * The user does not have any security challenge questions defined
     */
    public static final int NO_CHALLENGE_QUESTIONS = 338;
    /**
     * The password entered is invalid
     */
    public static final int BAD_PASSWORD = 339;
    /**
     * The user logged in with a temporary password and should be prompted to change it
     */
    public static final int TEMPORARY_PASSWORD = 340;
    /**
     * The user does not have enough security challenge questions defined
     */
    public static final int NOT_ENOUGH_CHALLENGE_QUESTIONS = 344;
}
