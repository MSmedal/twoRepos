package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;
;

/**
 * Contains the business rules to apply to tips during a financial transaction
 */
public class TipRule {

    @SerializedName("CanAcceptTips")

    private boolean mCanAcceptTips;

    private int MaximumDifference;

    private float MaximumDifferentialMultiplier;

    public boolean getCanAcceptTips() {
        return mCanAcceptTips;
    }

    public void setCanAcceptTips(boolean canAcceptTips) {
        mCanAcceptTips = canAcceptTips;
    }

    public int getMaximumDifference() {
        return MaximumDifference;
    }

    public void setMaximumDifference(int maximumDifference) {
        MaximumDifference = maximumDifference;
    }

    public float getMaximumDifferentialMultiplier() {
        return MaximumDifferentialMultiplier;
    }

    public void setMaximumDifferentialMultiplier(float maximumDifferentialMultiplier) {
        MaximumDifferentialMultiplier = maximumDifferentialMultiplier;
    }
}
