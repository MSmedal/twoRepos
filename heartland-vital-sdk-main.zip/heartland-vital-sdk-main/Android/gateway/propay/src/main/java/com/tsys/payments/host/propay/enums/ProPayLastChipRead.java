package com.tsys.payments.host.propay.enums;

/**
 * Indicates the results of the ICC chip read for the prior transaction.
 */
public enum ProPayLastChipRead {
    UNDEFINED(0),
    SUCCESSFUL(1),
    FAILED(2),
    NOT_A_CHIP_TRANSACTION(3),
    UNKNOWN(4);

    public final int value;

    ProPayLastChipRead(int value) {
        this.value = value;
    }
}
