package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;

/**
 * A request object that contains the session data associated with an account
 */
public class GetAccountSummaryRequest extends SessionValidationRequest {
}
