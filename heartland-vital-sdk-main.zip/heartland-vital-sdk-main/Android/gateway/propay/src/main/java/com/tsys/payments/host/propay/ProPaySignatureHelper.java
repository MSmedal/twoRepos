package com.tsys.payments.host.propay;

import android.graphics.Bitmap;

import com.tsys.payments.host.propay.utils.ProPayImageHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

class ProPaySignatureHelper {

    private static final int CAPTURE_SIGNATURE_BITMAP_WIDTH = 18;
    private static final int CAPTURE_SIGNATURE_BITMAP_LENGTH = 6;

    /**
     * @param signaturePath {@link String} Path to signature image on local file system.
     * @return Integer array representing the pixels for the signature image.
     */
    @Nullable
    static int[] getSignatureBlock(@NonNull String signaturePath) {
        Bitmap signatureImage;
        signatureImage = ProPayImageHelper
                .decodeSampledBitmapFromFile(signaturePath,
                        CAPTURE_SIGNATURE_BITMAP_WIDTH,
                        CAPTURE_SIGNATURE_BITMAP_LENGTH);
        if (signatureImage != null) {
            return ProPayImageHelper.getBytesAsIntArray(signatureImage);
        }
        return null;
    }
}
