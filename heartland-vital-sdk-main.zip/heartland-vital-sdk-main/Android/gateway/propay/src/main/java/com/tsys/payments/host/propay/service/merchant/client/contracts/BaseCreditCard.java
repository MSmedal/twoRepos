package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * Contains the basic metadata of a credit card
 */
public abstract class BaseCreditCard {

    public abstract String getCardHolderName();

    public abstract String getExpirationDate();

    public abstract String getCardNumber();

    public abstract String getTag();
}
