package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;

;
;

/**
 * Contains the encrypted track data of a credit card
 */
public class EncryptedTracks {



    private short[] EncryptedTrackData;


    private short[] EncryptedTrack2Data;


    private ProPayEncryptingDeviceType DeviceType;


    private short[] KeySerialNumber;

    public short[] getEncryptedTrackData() {
        return EncryptedTrackData;
    }

    public void setEncryptedTrackData(short[] encryptedTrackData) {
        EncryptedTrackData = encryptedTrackData;
    }

    public short[] getEncryptedTrack2Data() {
        return EncryptedTrack2Data;
    }

    public void setEncryptedTrack2Data(short[] encryptedTrack2Data) {
        EncryptedTrack2Data = encryptedTrack2Data;
    }

    public ProPayEncryptingDeviceType getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(ProPayEncryptingDeviceType deviceType) {
        DeviceType = deviceType;
    }

    public short[] getKeySerialNumber() {
        return KeySerialNumber;
    }

    public void setKeySerialNumber(short[] keySerialNumber) {
        KeySerialNumber = keySerialNumber;
    }
}
