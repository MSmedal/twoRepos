package com.tsys.payments.host.propay.enums;

/**
 * Specifies different means of capturing card data in the Point-of-Sale system.
 */
public enum ProPayCardDataInputMode {
    UNDEFINED(0),
    MANUAL_INPUT_NO_TERMINAL(49),
    MAG_STRIPE_READER(50),
    BARCODE_OR_PAYMENT_CODE(51),
    KEY_ENTRY(54),
    PAN_AUTO_ENTRY_VIA_CONTACTLESS_MAG_STRIPE(65),
    MAG_STRIPE_READER_TRACK_CAPTURED(66),
    ONLINE_CHIP(67),
    OFFLINE_CHIP(70),
    PAN_AUTO_ENTRY_VIA_CONTACTLESS_CHIP(77),
    TRACK_READ_FALLBACK_UNREADABLE_CHIP_CARD_DATA(78),
    EMPTY_CANDIDATE_LIST_FALLBACK(80),
    PAN_ENTRY_VIA_ECOMMERCE(82),
    ECOMMERCE_NO_SECURITY_CHANNEL_ENCRYPTION(83),
    MANUAL_ENTRY_WITH_KEYED_CID(86),
    SWIPED_ENTRY_WITH_KEYED_CID(87),
    DISCOVER_CONTACTLESS_INTERFACE_CHANGE(88);

    public final int value;

    ProPayCardDataInputMode(int value) {
        this.value = value;
    }
}
