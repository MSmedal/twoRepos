package com.tsys.payments.host.propay.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Collection of methods for handling {@link Date}s.
 */
public final class ProPayDateHelper {
    private static final String DEFAULT_DATE_FORMAT = "MM/dd/yy";
    private static final String CANADIAN_DATE_FORMAT = "dd/MM/yy";
    private static final String DEFAULT_DATE_FORMAT_ISO8601 = "yyyy-MM-dd";

    private ProPayDateHelper() {

    }

    /**
     * Returns the input time supplied in milliseconds formatted  based on the user's localed.
     * See {@link ProPayDateHelper#DEFAULT_DATE_FORMAT} and {@link ProPayDateHelper#CANADIAN_DATE_FORMAT}
     */
    public static String getCurrentDateFormatted(long timeInMillis) {
        Calendar cal = Calendar.getInstance(Locale.getDefault());
        DateFormat formatter = new SimpleDateFormat(DEFAULT_DATE_FORMAT, Locale.getDefault());

        // TODO: Pass in the ProPay Account Type and use that to resolve the date format needed.
        //        if (TSYSApplication.getInstance().getAccountType() == Analytics.AccountType.CANADA) {
        //            cal = Calendar.getInstance(Locale.CANADA_FRENCH);
        //            formatter = new SimpleDateFormat(CANADIAN_DATE_FORMAT, Locale.CANADA_FRENCH);
        //        } else {
        //            formatter = new SimpleDateFormat(DEFAULT_DATE_FORMAT, Locale.getDefault());
        //        }
        cal.setTimeInMillis(timeInMillis);
        return formatter.format(cal.getTime());
    }

    /**
     * Returns the input time in ISO-8601 format. yyyy-MM-dd
     */
    public static String getCurrentDateFormattedIso8601(long timeInMillis) {
        Calendar cal = Calendar.getInstance(Locale.getDefault());
        DateFormat formatter = new SimpleDateFormat(DEFAULT_DATE_FORMAT_ISO8601, Locale.getDefault());
        cal.setTimeInMillis(timeInMillis);
        return formatter.format(cal.getTime());
    }
}
