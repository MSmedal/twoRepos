package com.tsys.payments.host.propay.service.merchant.client.contracts.emv;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.model.EmvResponsePayload;
;

public class AuthorizeEmvResponse extends AuthorizeCardSwipeResponse {

    @SerializedName("EmvResponsePayload")
    private EmvResponsePayload EmvResponsePayload;

    public EmvResponsePayload getEmvResponsePayload() {
        return EmvResponsePayload;
    }

    public void setEmvResponsePayload(
            EmvResponsePayload emvResponsePayload) {
        EmvResponsePayload = emvResponsePayload;
    }
}
