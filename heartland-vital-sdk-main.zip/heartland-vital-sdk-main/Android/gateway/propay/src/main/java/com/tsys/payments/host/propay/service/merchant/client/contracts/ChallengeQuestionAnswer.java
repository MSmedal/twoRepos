package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * Contains a security challenge question and answer pair
 */
public class ChallengeQuestionAnswer {

    public ChallengeQuestionAnswer() {
    }

    public ChallengeQuestionAnswer(String question, String answer) {
        this.Question = question;
        this.Answer = answer;
    }

    public String Question;
    public String Answer;
}
