package com.tsys.payments.host.propay.service.merchant.client.io;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;

import java.lang.reflect.Type;

/**
 * Serializes / Deserializes {@link ProPayEncryptingDeviceType EncryptingDeviceType} enum to / from the JSON format
 */
public class EncryptingDeviceTypeSerializer
        implements JsonDeserializer<ProPayEncryptingDeviceType>, JsonSerializer<ProPayEncryptingDeviceType> {

    @Override
    public JsonElement serialize(ProPayEncryptingDeviceType sourceEnum, Type type, JsonSerializationContext context) {
        return new JsonPrimitive(sourceEnum.value);
    }

    @Override
    public ProPayEncryptingDeviceType deserialize(JsonElement element, Type type, JsonDeserializationContext context)
            throws JsonParseException {
        return ProPayEncryptingDeviceType.parse(element.getAsInt());
    }
}
