package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

/**
 * A response object that contains the basic metadata for the result of a financial transaction attempt
 */
public class BaseTransactionResponse extends BaseResponse {


    @SerializedName("AuthorizationCode")
    private String mAuthorizationCode;


    @SerializedName("AttemptNumber")
    public int mAttemptNumber;

    public String getAuthorizationCode() {
        return mAuthorizationCode;
    }

    public void setAuthorizationCode(String authorizationCode) {
        mAuthorizationCode = authorizationCode;
    }

    public int getAttemptNumber() {
        return mAttemptNumber;
    }

    public void setAttemptNumber(int attemptNumber) {
        mAttemptNumber = attemptNumber;
    }
}
