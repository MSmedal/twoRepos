package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * A response object that contains the identifiers associated to a credit card that has been successfully processed and
 * stored under a user's session
 */
public class ProcessAndStoreManualCardResponse extends BaseTransactionResponse {



    private String PaymentMethodId;


    private String PayerId;

    public String getPaymentMethodId() {
        return PaymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        PaymentMethodId = paymentMethodId;
    }

    public String getPayerId() {
        return PayerId;
    }

    public void setPayerId(String payerId) {
        PayerId = payerId;
    }
}
