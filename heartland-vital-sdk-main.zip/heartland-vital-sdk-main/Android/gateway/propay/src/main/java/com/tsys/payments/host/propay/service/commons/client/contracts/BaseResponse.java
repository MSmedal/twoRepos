package com.tsys.payments.host.propay.service.commons.client.contracts;

/**
 * Parent object for response objects from ProPay service methods
 */
public class BaseResponse {

    private com.tsys.payments.host.propay.service.commons.client.contracts.Result Result;

    /**
     * Getter for the {@link com.tsys.payments.host.propay.service.commons.client.contracts.Result Result}'s
     * response code
     *
     * @return the integer value of the Result
     */
    public int getResultCode() {
        if (Result != null) {
            return Result.getResultCode();
        }
        return -1;
    }

    /**
     * Getter for the {@link com.tsys.payments.host.propay.service.commons.client.contracts.Result Result} of
     * the response
     *
     * @return Result
     */
    public com.tsys.payments.host.propay.service.commons.client.contracts.Result getResult() {
        return Result;
    }

    /**
     * Setter for the {@link com.tsys.payments.host.propay.service.commons.client.contracts.Result Result} of
     * the response
     *
     * @param result The Result to set
     */
    public void setResult(com.tsys.payments.host.propay.service.commons.client.contracts.Result result) {
        Result = result;
    }
}
