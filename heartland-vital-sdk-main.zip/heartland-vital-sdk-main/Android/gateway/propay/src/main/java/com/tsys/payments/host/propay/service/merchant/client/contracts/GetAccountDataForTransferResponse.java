package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

/**
 * A response object that contains the parameters to conduct a money transfer for a particular account
 */
public class GetAccountDataForTransferResponse extends BaseResponse {



    private String AccountNumber;


    private int AvailableToTransfer;


    private int CurrentAccountBalance;


    private int MinimumTransferAmount;


    private int TransferFee;


    private boolean TransferFeeAdjusted;


    private boolean CanAchOut;

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        AccountNumber = accountNumber;
    }

    public int getAvailableToTransfer() {
        return AvailableToTransfer;
    }

    public void setAvailableToTransfer(int availableToTransfer) {
        AvailableToTransfer = availableToTransfer;
    }

    public int getCurrentAccountBalance() {
        return CurrentAccountBalance;
    }

    public void setCurrentAccountBalance(int currentAccountBalance) {
        CurrentAccountBalance = currentAccountBalance;
    }

    public int getMinimumTransferAmount() {
        return MinimumTransferAmount;
    }

    public void setMinimumTransferAmount(int minimumTransferAmount) {
        MinimumTransferAmount = minimumTransferAmount;
    }

    public int getTransferFee() {
        return TransferFee;
    }

    public void setTransferFee(int transferFee) {
        TransferFee = transferFee;
    }

    public boolean isTransferFeeAdjusted() {
        return TransferFeeAdjusted;
    }

    public void setTransferFeeAdjusted(boolean transferFeeAdjusted) {
        TransferFeeAdjusted = transferFeeAdjusted;
    }

    public boolean isCanAchOut() {
        return CanAchOut;
    }

    public void setCanAchOut(boolean canAchOut) {
        CanAchOut = canAchOut;
    }
}
