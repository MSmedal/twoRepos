package com.tsys.payments.host.propay.service.merchant.client.contracts;

import android.os.Parcel;
import android.os.Parcelable;

;
;

/**
 * Contains the answer for a security challenge question
 */
public class ChallengeAnswer implements Parcelable {



    public int Id;


    public String Answer;

    public ChallengeAnswer() {

    }

    public ChallengeAnswer(int id, String answer) {
        this.Id = id;
        this.Answer = answer;
    }

    // Parcelable
    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(Id);
        out.writeString(Answer);
    }

    public static final Creator<ChallengeAnswer> CREATOR = new Creator<ChallengeAnswer>() {
        public ChallengeAnswer createFromParcel(Parcel in) {
            return new ChallengeAnswer(in);
        }

        public ChallengeAnswer[] newArray(int size) {
            return new ChallengeAnswer[size];
        }
    };

    private ChallengeAnswer(Parcel in) {
        Id = in.readInt();
        Answer = in.readString();
    }
}
