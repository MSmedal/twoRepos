package com.tsys.payments.host.propay.service.merchant.client.io;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.tsys.payments.host.propay.service.merchant.client.contracts.TransactionStatus;

import java.lang.reflect.Type;

/**
 * Serializes / Deserializes {@link TransactionStatus TransactionStatus} enum to / from the JSON format
 */
public class ExternalTransactionStatusSerializer
        implements JsonDeserializer<TransactionStatus>, JsonSerializer<TransactionStatus> {

    @Override
    public JsonElement serialize(TransactionStatus sourceEnum, Type type, JsonSerializationContext context) {
        return new JsonPrimitive(sourceEnum.value);
    }

    @Override
    public TransactionStatus deserialize(JsonElement element, Type type, JsonDeserializationContext context)
            throws JsonParseException {
        return TransactionStatus.parse(element.getAsInt());
    }
}
