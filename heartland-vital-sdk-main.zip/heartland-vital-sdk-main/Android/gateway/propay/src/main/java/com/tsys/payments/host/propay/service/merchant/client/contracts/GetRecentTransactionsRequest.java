package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object for paging through recent transactions associated with a user's session
 */
public class GetRecentTransactionsRequest extends SessionValidationRequest {

    // The start position for paging indicating which ordinal of the most recent
    // transaction should be retrieved as the first transaction


    private int Start;

    // The number of transactions that should be retrieved as a part of this
    // request.


    private int Count;

    public int getStart() {
        return Start;
    }

    public void setStart(int start) {
        Start = start;
    }

    public int getCount() {
        return Count;
    }

    public void setCount(int count) {
        Count = count;
    }
}
