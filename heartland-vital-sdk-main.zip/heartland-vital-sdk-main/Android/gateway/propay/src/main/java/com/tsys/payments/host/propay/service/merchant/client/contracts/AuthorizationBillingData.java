package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A request object that contains the postal code and country code of the billing address used for authenticating a
 * client financial transaction
 */
public class AuthorizationBillingData {

    private String PostalCode;

    private int CountryCode = 840;

    public String getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(String postalCode) {
        PostalCode = postalCode;
    }

    public int getCountryCode() {
        return CountryCode;
    }

    public void setCountryCode(int countryCode) {
        CountryCode = countryCode;
    }
}
