package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object that contains values to delete the stored card information.
 */
public class DeleteStoredCardRequest extends SessionValidationRequest {


    public long PayerId;



    public String PaymentMethodId;

    public long getPayerId() {
        return PayerId;
    }

    public void setPayerId(long payerId) {
        PayerId = payerId;
    }

    public String getPaymentMethodId() {
        return PaymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        PaymentMethodId = paymentMethodId;
    }
}
