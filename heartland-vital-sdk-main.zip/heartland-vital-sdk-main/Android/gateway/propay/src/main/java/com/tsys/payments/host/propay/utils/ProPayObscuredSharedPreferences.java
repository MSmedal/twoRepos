package com.tsys.payments.host.propay.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

/**
 * File taken from the link below and modified:
 * http://stackoverflow.com/questions
 * /785973/what-is-the-most-appropriate-way-to-
 * store-user-settings-in-android-application/8445666#8445666 Warning, this
 * gives a false sense of security. If an attacker has enough access to acquire
 * your password store, then he almost certainly has enough access to acquire
 * your source binary and figure out your encryption key. However, it will
 * prevent casual investigators from acquiring passwords, and thereby may
 * prevent undesired negative publicity.
 */
public class ProPayObscuredSharedPreferences implements SharedPreferences {
    private static final String TAG = "CRASH";
    protected static final String UTF8 = "utf-8";

    // Don't use anything you wouldn't want to
    // get out there if someone decompiled
    // your app.

    @NonNull
    protected SharedPreferences mDelegate;
    @Nullable
    private DecryptionType mDecryptionType;

    // TODO: remove stored context
    protected Context mContext;

    public ProPayObscuredSharedPreferences(Context context, @NonNull SharedPreferences delegate) {
        this.mDelegate = delegate;
        this.mContext = context;
    }

    public class Editor implements SharedPreferences.Editor {
        protected SharedPreferences.Editor delegate;

        public Editor() {
            this.delegate = ProPayObscuredSharedPreferences.this.mDelegate.edit();
        }

        @Override
        public Editor putBoolean(String key, boolean value) {
            delegate.putString(encrypt(key), "b" + encrypt(Boolean.toString(value)));
            return this;
        }

        @Override
        public Editor putFloat(String key, float value) {
            try {
                delegate.putString(encrypt(key), "f" + encrypt(Float.toString(value)));
            } catch (NumberFormatException e) {
                delegate.putString(encrypt(key), "f" + encrypt(Float.toString(0.0f)));
            }
            return this;
        }

        @Override
        public Editor putInt(String key, int value) {
            try {
                delegate.putString(encrypt(key), "i" + encrypt(Integer.toString(value)));
            } catch (NumberFormatException e) {
                delegate.putString(encrypt(key), "i" + encrypt(Integer.toString(0)));
            }
            return this;
        }

        @Override
        public Editor putLong(String key, long value) {
            try {
                delegate.putString(encrypt(key), "l" + encrypt(Long.toString(value)));
            } catch (NumberFormatException e) {
                delegate.putString(encrypt(key), "l" + encrypt(Long.toString(0l)));
            }
            return this;
        }

        @Override
        public Editor putString(String key, String value) {
            delegate.putString(encrypt(key), "s" + encrypt(value));
            return this;
        }

        @Override
        public Editor putStringSet(String key, Set<String> values) {

            // we shouldn't use this, only available from api 11
            return null;
        }

        @SuppressLint("NewApi")
        @Override
        public void apply() {
            delegate.apply();
        }

        @Override
        public Editor clear() {
            delegate.clear();
            return this;
        }

        @Override
        public boolean commit() {
            return delegate.commit();
        }

        @Override
        public Editor remove(String s) {
            delegate.remove(s);
            return this;
        }
    }

    public Editor edit() {
        return new Editor();
    }

    @Override
    public void registerOnSharedPreferenceChangeListener(
            OnSharedPreferenceChangeListener listener) {

    }

    public int getSize() {
        // To avoid calling the decrypt method when all that's needed is the number of elements in the preferences.
        return mDelegate.getAll().size();
    }

    @Override
    public Map<String, ?> getAll() {
        Map<String, ?> map = mDelegate.getAll();

        Map<String, Object> result = new HashMap<String, Object>(map.size());

        try {
            for (Entry<String, ?> entry : map.entrySet()) {
                String value = (String)entry.getValue();
                String key = (String)entry.getKey();

                if (value.charAt(0) == 'b') {
                    boolean v;
                    mDecryptionType = DecryptionType.Boolean;
                    v = Boolean.parseBoolean(decrypt(value.substring(1)));
                    mDecryptionType = DecryptionType.Key;
                    result.put(decrypt(key), v);
                } else if (value.charAt(0) == 'f') {
                    float v = 0f;
                    try {
                        mDecryptionType = DecryptionType.Float;
                        v = Float.parseFloat(decrypt(value.substring(1)));
                    } catch (NumberFormatException e) {

                    }
                    mDecryptionType = DecryptionType.Key;
                    result.put(decrypt(key), v);
                } else if (value.charAt(0) == 'i') {
                    int v = 0;
                    try {
                        mDecryptionType = DecryptionType.Integer;
                        v = Integer.parseInt(decrypt(value.substring(1)));
                    } catch (NumberFormatException e) {

                    }
                    mDecryptionType = DecryptionType.Key;
                    result.put(decrypt(key), v);
                } else if (value.charAt(0) == 'l') {
                    long v = 0l;
                    try {
                        mDecryptionType = DecryptionType.Long;
                        v = Long.parseLong(decrypt(value.substring(1)));
                    } catch (NumberFormatException e) {

                    }
                    mDecryptionType = DecryptionType.Key;
                    result.put(decrypt(key), v);
                } else if (value.charAt(0) == 's') {
                    mDecryptionType = DecryptionType.String;
                    String resultString = decrypt(value.substring(1));
                    mDecryptionType = DecryptionType.Key;
                    result.put(decrypt(key), resultString);
                }
            }
        } catch (IllegalArgumentException e) {
            Log.d(TAG, e.getLocalizedMessage());
            mDelegate.edit().clear().apply();
            return new HashMap<String, Object>();
        }

        return result;
    }

    @Override
    public boolean getBoolean(String key, boolean defValue) {
        final String v = mDelegate.getString(encrypt(key), null);
        boolean result = defValue;
        if (v != null && v.charAt(0) == 'b') {
            result = Boolean.parseBoolean(decrypt(v.substring(1)));
        }

        return result;
    }

    @Override
    public float getFloat(String key, float defValue) {
        final String v = mDelegate.getString(encrypt(key), null);

        float result = defValue;
        if (v != null && v.charAt(0) == 'f') {
            try {
                result = Float.parseFloat(decrypt(v.substring(1)));
            } catch (NumberFormatException e) {

            }
        }

        return result;
    }

    @Override
    public int getInt(String key, int defValue) {
        final String v = mDelegate.getString(encrypt(key), null);

        int result = defValue;
        if (v != null && v.charAt(0) == 'i') {
            try {
                result = Integer.parseInt(decrypt(v.substring(1)));
            } catch (NumberFormatException e) {

            }
        }
        return result;
    }

    @Override
    public long getLong(String key, long defValue) {
        final String v = mDelegate.getString(encrypt(key), null);

        long result = defValue;
        if (v != null && v.charAt(0) == 'l') {
            try {
                result = Long.parseLong(decrypt(v.substring(1)));
            } catch (NumberFormatException e) {

            }
        }
        return result;
    }

    @Override
    public String getString(String key, String defValue) {
        final String v = mDelegate.getString(encrypt(key), null);

        String result = defValue;
        if (v != null && v.charAt(0) == 's') {
            result = decrypt(v.substring(1));
        }
        return result;
    }

    @Override
    public Set<String> getStringSet(String key, Set<String> defValues) {
        // we shouldn't use this, only available from api 11
        return null;
    }

    @Override
    public boolean contains(String s) {
        return mDelegate.contains(s);
    }

    public void imaregisterOnSharedPreferenceChangeListener(
            OnSharedPreferenceChangeListener onSharedPreferenceChangeListener) {
        mDelegate.registerOnSharedPreferenceChangeListener(onSharedPreferenceChangeListener);
    }

    @Override
    public void unregisterOnSharedPreferenceChangeListener(
            OnSharedPreferenceChangeListener onSharedPreferenceChangeListener) {
        mDelegate.unregisterOnSharedPreferenceChangeListener(onSharedPreferenceChangeListener);
    }

    @SuppressLint({"NewApi", "MissingPermission"})
    private String encrypt(String value) {
        try {
            final byte[] bytes = value != null ? value.getBytes(UTF8) : new byte[0];
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
            // TODO find a better password
            SecretKey key = keyFactory
                    .generateSecret(new PBEKeySpec(this.getClass().toString().toCharArray()));
            Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");

            String serialNumber;
            if (Build.SERIAL != Build.UNKNOWN) {
                serialNumber = Build.SERIAL;
            } else {
                TelephonyManager manager =
                        (TelephonyManager)mContext.getSystemService(Context.TELEPHONY_SERVICE);
                serialNumber = manager.getDeviceId();
            }

            pbeCipher.init(Cipher.ENCRYPT_MODE, key,
                    new PBEParameterSpec(serialNumber.getBytes(UTF8), 16));
            return new String(Base64.encode(pbeCipher.doFinal(bytes), Base64.NO_WRAP), UTF8);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressLint({"NewApi", "MissingPermission"})
    private String decrypt(String value) throws IllegalArgumentException {
        try {
            final byte[] bytes = value != null ? Base64.decode(value, Base64.DEFAULT) : new byte[0];
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");

            // TODO find a better password
            SecretKey key = keyFactory
                    .generateSecret(new PBEKeySpec(this.getClass().toString().toCharArray()));
            Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");

            String serialNumber;
            if (Build.SERIAL != Build.UNKNOWN) {
                serialNumber = Build.SERIAL;
            } else {
                TelephonyManager manager =
                        (TelephonyManager)mContext.getSystemService(Context.TELEPHONY_SERVICE);
                serialNumber = manager.getDeviceId();
            }

            pbeCipher.init(Cipher.DECRYPT_MODE, key,
                    new PBEParameterSpec(serialNumber.getBytes(UTF8), 16));
            return new String(pbeCipher.doFinal(bytes), UTF8);
        } catch (Exception e) {
            String decryptionType = mDecryptionType == null ? DecryptionType.Unknown.name() : mDecryptionType.name();
            String exceptionMessage = "decrypt(): Type Being Decrypted -> " + decryptionType;
            if (e.getCause() != null) {
                exceptionMessage += "\n" + e.getCause().toString();
            }
            throw new IllegalArgumentException(exceptionMessage);
        }
    }

    /**
     * Indicates the type of element being decrypted. This will help pinpoint the type of element causing the decryption
     * crash that occurs when handling encrypted {@link SharedPreferences} elements.
     */
    private enum DecryptionType {
        Key,
        Boolean,
        Float,
        Integer,
        Long,
        String,
        Unknown
    }
}
