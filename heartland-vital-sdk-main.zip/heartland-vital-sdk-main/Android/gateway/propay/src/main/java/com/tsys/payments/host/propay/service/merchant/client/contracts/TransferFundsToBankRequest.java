package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object to transfer an amount associated with a user's session
 */
public class TransferFundsToBankRequest extends SessionValidationRequest {



    private int Amount;

    public int getAmount() {
        return Amount;
    }

    public void setAmount(int amount) {
        Amount = amount;
    }
}
