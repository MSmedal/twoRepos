package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains the basic credit cardholder's metadata that was captured for the billable transaction
 */
public class CaptureBillingData {



    private String Email;

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
