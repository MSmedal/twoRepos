package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

import java.util.List;

/**
 * A request object that contains the security question and answer pairs to save for the user
 */
public class SetChallengeQuestionsRequest {



    private ChallengeQuestionAnswer[] ChallengeQuestions;


    private String Password;


    private String Username;

    //


    private List<ChallengeQuestionAnswer> CQs;

    public List<ChallengeQuestionAnswer> getCQs() {
        return CQs;
    }

    public void setCQs(List<ChallengeQuestionAnswer> CQs) {
        this.CQs = CQs;
    }
    //

    public ChallengeQuestionAnswer[] getChallengeQuestions() {
        return ChallengeQuestions;
    }

    public void setChallengeQuestions(ChallengeQuestionAnswer[] challengeQuestions) {
        ChallengeQuestions = challengeQuestions;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }
}
