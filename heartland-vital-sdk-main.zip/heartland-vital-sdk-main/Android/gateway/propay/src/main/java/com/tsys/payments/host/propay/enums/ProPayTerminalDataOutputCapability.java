package com.tsys.payments.host.propay.enums;

/**
 * Indicates how transaction related information is presented to the user via the terminal.
 */
public enum ProPayTerminalDataOutputCapability {
    NONE(49),
    PRINTING_ONLY(50),
    DISPLAY_ONLY(51),
    PRINTING_AND_DISPLAY(52);

    public final int value;

    ProPayTerminalDataOutputCapability(int value) {
        this.value = value;
    }
}
