package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object that contains the credit card data obtained by manually inputting the values into a user interface
 */
public class AuthorizeManualEntryRequest extends SessionValidationRequest {



    private ManualCardData ManualCardData;


    private AuthorizationCardData CardData;


    private AuthorizationBillingData BillingData;


    private boolean ShouldStoreCardData;


    private String Email;
    @SerializedName("ApplicationId")
    private String mApplicationId;
    @SerializedName("PointOfSaleData")
    private PointOfSaleData mPointOfSaleData;

    public ManualCardData getManualCardData() {
        return ManualCardData;
    }

    public void setManualCardData(ManualCardData manualCardData) {
        ManualCardData = manualCardData;
    }

    public AuthorizationCardData getCardData() {
        return CardData;
    }

    public void setCardData(AuthorizationCardData cardData) {
        CardData = cardData;
    }

    public AuthorizationBillingData getBillingData() {
        return BillingData;
    }

    public void setBillingData(AuthorizationBillingData billingData) {
        BillingData = billingData;
    }

    public boolean isShouldStoreCardData() {
        return ShouldStoreCardData;
    }

    public void setShouldStoreCardData(boolean shouldStoreCardData) {
        ShouldStoreCardData = shouldStoreCardData;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public PointOfSaleData getPointOfSaleData() {
        return mPointOfSaleData;
    }

    public void setPointOfSaleData(PointOfSaleData pointOfSaleData) {
        mPointOfSaleData = pointOfSaleData;
    }

    public String getApplicationId() {
        return mApplicationId;
    }

    public void setApplicationId(String applicationId) {
        mApplicationId = applicationId;
    }
}
