/*
 * Copyright (c) 2018.  ProPay Inc. All Rights Reserved
 */

package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;

public class PointOfSaleData {

    @SerializedName("CardDataInputMode")
    private int mCardDataInputMode;

    @SerializedName("TerminalCardDataInputCapability")
    private int mTerminalCardDataInputCapability;

    @SerializedName("TerminalCardCaptureCapability")
    private int mTerminalCardCaptureCapability;

    @SerializedName("TerminalCardholderAuthenticationCapability")
    private int mTerminalCardholderAuthenticationCapability;

    @SerializedName("TerminalOperatingEnvironment")
    private int mTerminalOperatingEnvironment;

    @SerializedName("CardholderPresentData")
    private int mCardholderPresentData;

    @SerializedName("CardPresentData")
    private int mCardPresentData;

    @SerializedName("CardholderAuthenticationMethod")
    private int mCardholderAuthenticationMethod;

    @SerializedName("CardholderAuthenticationEntity")
    private int mCardholderAuthenticationEntity;

    @SerializedName("CardDataOutputCapability")
    private int mCardDataOutputCapability;

    @SerializedName("TerminalDataOutputCapability")
    private int mTerminalDataOutputCapability;

    @SerializedName("PinCaptureCapability")
    private int mPinCaptureCapability;

    public int getCardDataInputMode() {
        return mCardDataInputMode;
    }

    public void setCardDataInputMode(int cardDataInputMode) {
        mCardDataInputMode = cardDataInputMode;
    }

    public int getTerminalCardDataInputCapability() {
        return mTerminalCardDataInputCapability;
    }

    public void setTerminalCardDataInputCapability(int terminalCardDataInputCapability) {
        mTerminalCardDataInputCapability = terminalCardDataInputCapability;
    }

    public int getTerminalCardCaptureCapability() {
        return mTerminalCardCaptureCapability;
    }

    public void setTerminalCardCaptureCapability(int terminalCardCaptureCapability) {
        mTerminalCardCaptureCapability = terminalCardCaptureCapability;
    }

    public int getTerminalCardholderAuthenticationCapability() {
        return mTerminalCardholderAuthenticationCapability;
    }

    public void setTerminalCardholderAuthenticationCapability(int terminalCardholderAuthenticationCapability) {
        mTerminalCardholderAuthenticationCapability = terminalCardholderAuthenticationCapability;
    }

    public int getTerminalOperatingEnvironment() {
        return mTerminalOperatingEnvironment;
    }

    public void setTerminalOperatingEnvironment(int terminalOperatingEnvironment) {
        mTerminalOperatingEnvironment = terminalOperatingEnvironment;
    }

    public int getCardholderPresentData() {
        return mCardholderPresentData;
    }

    public void setCardholderPresentData(int cardholderPresentData) {
        mCardholderPresentData = cardholderPresentData;
    }

    public int getCardPresentData() {
        return mCardPresentData;
    }

    public void setCardPresentData(int cardPresentData) {
        mCardPresentData = cardPresentData;
    }

    public int getCardholderAuthenticationMethod() {
        return mCardholderAuthenticationMethod;
    }

    public void setCardholderAuthenticationMethod(int cardholderAuthenticationMethod) {
        mCardholderAuthenticationMethod = cardholderAuthenticationMethod;
    }

    public int getCardholderAuthenticationEntity() {
        return mCardholderAuthenticationEntity;
    }

    public void setCardholderAuthenticationEntity(int cardholderAuthenticationEntity) {
        mCardholderAuthenticationEntity = cardholderAuthenticationEntity;
    }

    public int getCardDataOutputCapability() {
        return mCardDataOutputCapability;
    }

    public void setCardDataOutputCapability(int cardDataOutputCapability) {
        mCardDataOutputCapability = cardDataOutputCapability;
    }

    public int getTerminalDataOutputCapability() {
        return mTerminalDataOutputCapability;
    }

    public void setTerminalDataOutputCapability(int terminalDataOutputCapability) {
        mTerminalDataOutputCapability = terminalDataOutputCapability;
    }

    public int getPinCaptureCapability() {
        return mPinCaptureCapability;
    }

    public void setPinCaptureCapability(int pinCaptureCapability) {
        mPinCaptureCapability = pinCaptureCapability;
    }
}
