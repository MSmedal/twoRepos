package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object that contains the financial transaction data and the credit card data, which was manually obtained,
 * and is ready for payment processing
 */
public class ProcessManualCardRequest extends SessionValidationRequest {

    private ManualCardData ManualCardData;

    private ProcessCardData ProcessCardData;

    private com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData BillingData;

    private com.tsys.payments.host.propay.service.merchant.client.contracts.FullTransactionData
            FullTransactionData;

    public ManualCardData getManualCardData() {
        return ManualCardData;
    }

    public void setManualCardData(ManualCardData manualCardData) {
        ManualCardData = manualCardData;
    }

    public ProcessCardData getProcessCardData() {
        return ProcessCardData;
    }

    public void setProcessCardData(ProcessCardData processCardData) {
        ProcessCardData = processCardData;
    }

    public com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData getBillingData() {
        return BillingData;
    }

    public void setBillingData(BillingData billingData) {
        BillingData = billingData;
    }

    public FullTransactionData getFullTransactionData() {
        return FullTransactionData;
    }

    public void setFullTransactionData(FullTransactionData fullTransactionData) {
        FullTransactionData = fullTransactionData;
    }
}
