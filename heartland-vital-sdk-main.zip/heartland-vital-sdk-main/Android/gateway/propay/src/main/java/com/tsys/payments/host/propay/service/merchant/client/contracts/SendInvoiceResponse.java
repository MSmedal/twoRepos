package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

public class SendInvoiceResponse extends BaseResponse {
    //TODO Fill in implementation details once more details are given.
}
