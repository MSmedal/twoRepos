package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;
;

/**
 * Contains the user's identifier and their granted rights
 */
public class IdentityDetail {

    @SerializedName("IdentityId")

    private long mIdentityId;
    @SerializedName("GrantedRights")

    private GrantedRight[] mGrantedRights;

    public long getIdentityId() {
        return mIdentityId;
    }

    public void setIdentityId(long identityId) {
        mIdentityId = identityId;
    }

    public GrantedRight[] getGrantedRights() {
        return mGrantedRights;
    }

    public void setGrantedRights(GrantedRight[] grantedRights) {
        mGrantedRights = grantedRights;
    }
}
