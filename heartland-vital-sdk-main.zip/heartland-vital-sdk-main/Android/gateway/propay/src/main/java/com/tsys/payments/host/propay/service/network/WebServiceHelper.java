package com.tsys.payments.host.propay.service.network;

import android.util.Log;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

public class WebServiceHelper {

    public static <T extends BaseResponse> void call(ResponseHandler<T> responseHandler) {
        Log.v("WebserviceHelper", "call");
        // call the web service and wrap the response handler with one that will
        // dismiss the dialog when the web service completes
        AsyncService<T> ws = new AsyncService<T>();
        ws.call(new DelegatedResponseHandler<T>(responseHandler) {
            @Override
            public void handleResponse(T response) {
                Log.v("WebserviceHelper", "handleResponse");
                super.handleResponse(response);
            }

            @Override
            public void handleException(Exception e) {
                Log.v("WebserviceHelper", "handleException");
                super.handleException(e);
            }
        });
    }
}
