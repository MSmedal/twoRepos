package com.tsys.payments.host.propay.enums;

/**
 * Specifies different mediums the Point-of-Sale system reads card data from.
 */
public enum ProPayCardDataOutputCapability {
    NONE(49),
    MAG_STRIPE_WRITE(50),
    INTEGRATED_CHIP_CARD(51),
    OTHER(52);

    public final int value;

    ProPayCardDataOutputCapability(int value) {
        this.value = value;
    }
}
