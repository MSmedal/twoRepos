package com.tsys.payments.host.propay.service.merchant.client.contracts;

import android.os.Parcel;
import android.os.Parcelable;

;
;

/**
 * Contains the security challenge question
 */
public class ChallengeQuestion implements Parcelable {



    public int Id;


    public String Question;

    public ChallengeQuestion() {

    }

    public ChallengeQuestion(int id, String question) {
        this.Id = id;
        this.Question = question;
    }

    // Parcelable
    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(Id);
        out.writeString(Question);
    }

    public static final Creator<ChallengeQuestion> CREATOR = new Creator<ChallengeQuestion>() {
        public ChallengeQuestion createFromParcel(Parcel in) {
            return new ChallengeQuestion(in);
        }

        public ChallengeQuestion[] newArray(int size) {
            return new ChallengeQuestion[size];
        }
    };

    private ChallengeQuestion(Parcel in) {
        Id = in.readInt();
        Question = in.readString();
    }
}
