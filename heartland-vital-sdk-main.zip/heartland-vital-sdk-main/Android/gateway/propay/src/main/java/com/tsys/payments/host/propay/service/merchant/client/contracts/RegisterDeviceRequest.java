package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object to attempt to register the mobile device
 */
public class RegisterDeviceRequest extends SessionValidationRequest {



    private String Username;


    private ChallengeAnswer[] Answers;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public ChallengeAnswer[] getChallengeAnswers() {
        return Answers;
    }

    public void setChallengeAnswers(ChallengeAnswer[] challengeAnswers) {
        Answers = challengeAnswers;
    }
}
