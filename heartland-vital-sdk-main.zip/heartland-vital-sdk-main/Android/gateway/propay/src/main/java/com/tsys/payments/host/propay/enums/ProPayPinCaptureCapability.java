package com.tsys.payments.host.propay.enums;

/**
 * Indicates the form factor of the PIN pad used the capture PIN if available.
 */
public enum ProPayPinCaptureCapability {
    NONE(48),
    PIN_4_CHAR(52),
    PIN_5_CHAR(53),
    PIN_6_CHAR(54),
    PIN_7_CHAR(55),
    PIN_8_CHAR(56),
    PIN_9_CHAR(57),
    PIN_10_CHAR(65),
    PIN_11_CHAR(66),
    PIN_12_CHAR(67);

    public final int value;

    ProPayPinCaptureCapability(int value) {
        this.value = value;
    }
}
