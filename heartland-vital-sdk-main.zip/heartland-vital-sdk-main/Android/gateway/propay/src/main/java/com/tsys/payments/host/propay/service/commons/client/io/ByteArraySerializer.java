package com.tsys.payments.host.propay.service.commons.client.io;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;

/**
 * Serializes / Deserializes byte[] data for the JSON format
 *
 * @author joates this class is a shameless copy from the mercury project. If we
 *         make any more than two android apps, we'll want to create a shared library.
 */
public class ByteArraySerializer implements JsonSerializer<byte[]>, JsonDeserializer<byte[]> {

    @Override
    public JsonElement serialize(byte[] bytes, Type typeOfT, JsonSerializationContext context) {
        // int[] unsignedBytes = DotNetConversion
        // .convertBytesToUnsignedBytes(bytes);
        JsonArray array = new JsonArray();

        // for (int currentByte : unsignedBytes) {
        // array.add(new JsonPrimitive(currentByte));
        // }
        for (int currentByte : bytes) {
            array.add(new JsonPrimitive((int)currentByte));
        }

        return array;
        // return new JsonPrimitive(Base64.encode(bytes,
        // Base64.DEFAULT).toString());
    }

    @Override
    public byte[] deserialize(JsonElement element, Type typeOfT, JsonDeserializationContext arg2)
            throws JsonParseException {
        JsonArray array = element.getAsJsonArray();
        byte[] bytes = new byte[array.size()];
        for (int i = 0; i < array.size(); i++) {
            JsonPrimitive primitive = (JsonPrimitive)array.get(i);
            byte currentByte = primitive.getAsByte();
            bytes[i] = currentByte;
        }

        return bytes;
        // String instance = element.getAsString();
        // return Base64.decode(instance, Base64.DEFAULT);
    }
}
