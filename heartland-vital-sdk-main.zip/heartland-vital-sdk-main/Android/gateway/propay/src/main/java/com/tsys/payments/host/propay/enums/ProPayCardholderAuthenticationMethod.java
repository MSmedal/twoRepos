package com.tsys.payments.host.propay.enums;

import androidx.annotation.NonNull;

import com.tsys.payments.library.enums.CvmResult;

/**
 * Specifies the method by which the cardholder authentication is performed.
 */
public enum ProPayCardholderAuthenticationMethod {
    NOT_AUTHENTICATED(48),
    PIN(49),
    ELECTRONIC_SIGNATURE(50),
    MANUAL_SIGNATURE(53),
    OTHER_MANUAL(54),
    OTHER_SYSTEMATIC(83),
    ELECTRONIC_TICKET(84);

    public final int value;

    ProPayCardholderAuthenticationMethod(int value) {
        this.value = value;
    }

    public static ProPayCardholderAuthenticationMethod fromCvmResult(@NonNull CvmResult cvmResult) {
        if (cvmResult != null) {
            switch (cvmResult) {
                case PIN_OFFLINE_PLAIN:
                case PIN_ONLINE:
                    return PIN;
                case SIGNATURE_REQUIRED:
                    return MANUAL_SIGNATURE;
                default:
                    return NOT_AUTHENTICATED;
            }
        } else {
            return NOT_AUTHENTICATED;
        }
    }
}
