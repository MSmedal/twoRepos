package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the result of an attempt to change a password for a user
 */
public class ChangePasswordResponse extends BaseResponse {
}
