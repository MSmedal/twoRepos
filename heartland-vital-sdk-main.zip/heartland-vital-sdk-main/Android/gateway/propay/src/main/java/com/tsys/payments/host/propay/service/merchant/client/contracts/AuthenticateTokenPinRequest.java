package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A request object that contains the PIN data used for authenticating the client
 */
public class AuthenticateTokenPinRequest extends CallerValidationRequest {

    private String PinToken;

    private String Pin;

    public String getPinToken() {
        return PinToken;
    }

    public void setPinToken(String pinToken) {
        PinToken = pinToken;
    }

    public String getPin() {
        return Pin;
    }

    public void setPin(String pin) {
        Pin = pin;
    }
}
