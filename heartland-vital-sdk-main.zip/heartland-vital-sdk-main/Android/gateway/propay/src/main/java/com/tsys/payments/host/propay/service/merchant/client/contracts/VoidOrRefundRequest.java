package com.tsys.payments.host.propay.service.merchant.client.contracts;

import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.model.MobileEmvPayload;
;
;

/**
 * A request object for voiding or refunding a financial transaction associated with a user's sessions
 */
public class VoidOrRefundRequest extends SessionValidationRequest {



    @SerializedName("Amount")
    private long mAmount;


    @SerializedName("Comment1")
    private String mComment1;


    @SerializedName("Comment2")
    private String mComment2;


    @SerializedName("InvoiceNumber")
    private String mInvoiceNumber;


    @SerializedName("MerchantProfileId")
    private long mMerchantProfileId;


    @SerializedName("AttemptNumber")
    private int mAttemptNumber;


    @SerializedName("EmvPayloadData")
    private MobileEmvPayload mMobileEmvPayload;

    public long getAmount() {
        return mAmount;
    }

    public void setAmount(long amount) {
        mAmount = amount;
    }

    public String getComment1() {
        return mComment1;
    }

    public void setComment1(String comment1) {
        mComment1 = comment1;
    }

    public String getComment2() {
        return mComment2;
    }

    public void setComment2(String comment2) {
        mComment2 = comment2;
    }

    public String getInvoiceNumber() {
        return mInvoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        mInvoiceNumber = invoiceNumber;
    }

    public long getMerchantProfileId() {
        return mMerchantProfileId;
    }

    public void setMerchantProfileId(long merchantProfileId) {
        mMerchantProfileId = merchantProfileId;
    }

    public int getAttemptNumber() {
        return mAttemptNumber;
    }

    public void setAttemptNumber(int attemptNumber) {
        mAttemptNumber = attemptNumber;
    }

    public MobileEmvPayload getMobileEmvPayload() {
        return mMobileEmvPayload;
    }

    public void setMobileEmvPayload(@Nullable MobileEmvPayload mobileEmvPayload) {
        mMobileEmvPayload = mobileEmvPayload;
    }
}
