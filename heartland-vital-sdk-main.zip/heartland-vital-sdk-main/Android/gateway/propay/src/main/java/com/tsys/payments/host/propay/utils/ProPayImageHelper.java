package com.tsys.payments.host.propay.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.annotation.DrawableRes;
import android.widget.ImageView;

import java.nio.ByteBuffer;

public final class ProPayImageHelper {
    private static final String TAG = ProPayImageHelper.class.getName();

    private static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    private static Bitmap decodeSampledBitmapFromResource(Resources res, @DrawableRes int resId,
            int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, resId, options);
    }

    public static Bitmap decodeSampledBitmapFromFile(String path,
            int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(path, options);
    }

    public static Bitmap decodeSampledBitmapFromByteArray(byte[] imageData,
            int reqWidth, int reqHeight) {
        if (imageData == null) return null;

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(imageData, 0, imageData.length, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(imageData, 0, imageData.length, options);
    }

    public static final void setSampledImage(ImageView imageView, Context context,
            @DrawableRes int drawableId) {
        imageView.setImageBitmap(decodeSampledBitmapFromResource(context.getResources(), drawableId,
                imageView.getWidth(), imageView.getHeight()));
    }

    /**
     * Returns an array of integers representing the image data for the given bitmap.
     *
     * @param bitmap {@link Bitmap} image to obtain the bytes for.
     */
    public static int[] getBytesAsIntArray(Bitmap bitmap) {
        if (bitmap == null) return null;

        int byteCount = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB_MR1) {
            byteCount = bitmap.getByteCount();
        } else {
            byteCount = bitmap.getRowBytes() * bitmap.getHeight();
        }

        ByteBuffer buffer = ByteBuffer.allocate(byteCount); //Create a new buffer
        bitmap.copyPixelsToBuffer(buffer); //Move the byte data to the buffer
        byte[] byteArray = buffer.array();

        int[] pixels = new int[byteArray.length];
        for (int i = 0; i < pixels.length; i++) {
            pixels[i] = byteArray[i] & 0xFF;
        }

        return pixels;
    }

    /**
     * Returns an array of bytes representing the image data for the given bitmap.
     *
     * @param bitmap {@link Bitmap} image to obtain the bytes for.
     */
    public static byte[] getBytes(Bitmap bitmap) {
        if (bitmap == null) return null;

        int byteCount = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB_MR1) {
            byteCount = bitmap.getByteCount();
        } else {
            byteCount = bitmap.getRowBytes() * bitmap.getHeight();
        }

        ByteBuffer buffer = ByteBuffer.allocate(byteCount); //Create a new buffer
        bitmap.copyPixelsToBuffer(buffer); //Move the byte data to the buffer
        return buffer.array();
    }
}
