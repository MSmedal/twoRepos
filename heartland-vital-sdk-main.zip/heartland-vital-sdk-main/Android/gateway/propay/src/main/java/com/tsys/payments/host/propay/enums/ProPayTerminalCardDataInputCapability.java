package com.tsys.payments.host.propay.enums;

/**
 * Indicates the different mediums that the terminal contains for supplying card data.
 */
public enum ProPayTerminalCardDataInputCapability {
    UNDEFINED(0),
    MANUAL_VOICE_ARU(49),
    MAG_STRIPE_READER_ONLY(50),
    BARCODE_OR_PAYMENT_CODE(51),
    OPTIONAL_CHARACTER_READER(52),
    ICC_ONLY(53),
    KEY_ENTRY_ONLY(54),
    PAN_AUTO_ENTRY_VIA_CONTACTLESS_MAG_STRIPE(65),
    MAG_STRIPE_AND_KEY_ENTRY(66),
    ICC_MAG_STRIPE_AND_KEY_ENTRY(67),
    ICC_AND_MAG_STRIPE(68),
    ICC_AND_KEY_ENTRY(69),
    ICC_CONTACTLESS_MAG_STRIPE_AND_MANUAL(72),
    PAN_AUTO_ENTRY_VIA_CONTACTLESS_CHIP(77),
    OTHER(86);

    public final int value;

    ProPayTerminalCardDataInputCapability(int value) {
        this.value = value;
    }
}
