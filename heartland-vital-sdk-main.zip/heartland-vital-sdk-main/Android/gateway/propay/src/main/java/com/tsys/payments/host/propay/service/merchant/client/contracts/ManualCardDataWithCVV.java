package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains the basic credit card metadata for processing a credit card manually with a CVV
 */
public class ManualCardDataWithCVV extends ManualCardData {



    private String CVV;

    public String getCVV() {
        return CVV;
    }

    public void setCVV(String cVV) {
        CVV = cVV;
    }
}
