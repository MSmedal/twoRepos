package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains the basic credit card metadata that was captured for the billable transaction
 */
public class CaptureCardData {



    private long Amount;


    private long TipAmount;


    private String Comment1;


    private String Comment2;


    private long MerchantProfileId;

    public long getAmount() {
        return Amount;
    }

    public void setAmount(long amount) {
        Amount = amount;
    }

    public long getTipAmount() {
        return TipAmount;
    }

    public void setTipAmount(long tipAmount) {
        TipAmount = tipAmount;
    }

    public String getComment1() {
        return Comment1;
    }

    public void setComment1(String comment1) {
        Comment1 = comment1;
    }

    public String getComment2() {
        return Comment2;
    }

    public void setComment2(String comment2) {
        Comment2 = comment2;
    }

    public long getMerchantProfileId() {
        return MerchantProfileId;
    }

    public void setMerchantProfileId(long merchantProfileId) {
        MerchantProfileId = merchantProfileId;
    }
}
