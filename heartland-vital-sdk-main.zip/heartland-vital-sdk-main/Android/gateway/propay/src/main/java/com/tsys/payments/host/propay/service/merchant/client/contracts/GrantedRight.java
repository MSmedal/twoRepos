package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;

/**
 * Contains the granted permission associated with the CAMS framework
 */
public class GrantedRight {

    @SerializedName("RightName")
    private String mRightName;
    @SerializedName("SystemId")
    private String mSystemId;
    @SerializedName("CamsSystemId")
    private CamsSystem mCamsSystemId;
    @SerializedName("AccountId")
    private String mAccountId;

    public GrantedRight() {
    }

    public GrantedRight(String rightName, CamsSystem system) {
        this.mRightName = rightName;
        this.mCamsSystemId = system;
    }

    public String getRightName() {
        return mRightName;
    }

    public void setRightName(String rightName) {
        mRightName = rightName;
    }

    public String getSystemId() {
        return mSystemId;
    }

    public void setSystemId(String systemId) {
        mSystemId = systemId;
    }

    public CamsSystem getCamsSystemId() {
        return mCamsSystemId;
    }

    public void setCamsSystemId(CamsSystem camsSystemId) {
        mCamsSystemId = camsSystemId;
    }

    public String getAccountId() {
        return mAccountId;
    }

    public void setAccountId(String accountId) {
        mAccountId = accountId;
    }
}
