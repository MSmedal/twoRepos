package com.tsys.payments.host.propay.service.commons.client.io;

import android.util.Log;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;
import java.util.Date;

/**
 * Serializes / Deserializes java.util.Date object to / from the JSON format
 *
 * @author joates this class is a shameless copy from the mercury project. If we
 *         make any more than two android apps, we'll want to create a shared library.
 */
public class DateSerializer implements JsonSerializer<Date>, JsonDeserializer<Date> {

    @Override
    public JsonElement serialize(Date date, Type typeOfT, JsonSerializationContext context) {
        return new JsonPrimitive("/Date(" + date.getTime() + ")/");
    }

    @Override
    public Date deserialize(JsonElement element, Type typeOfT, JsonDeserializationContext arg2)
            throws JsonParseException {
        try {
            String instance = element.getAsString();
            String dateTimeMilliseconds = instance.substring(6, instance.length() - 2);

            long milliseconds = 0;

            String parsedMilliseconds = parseByDelimiter(dateTimeMilliseconds, "-");

            if (parsedMilliseconds == null) {
                parsedMilliseconds = parseByDelimiter(dateTimeMilliseconds, "+");

                if (parsedMilliseconds == null) {
                    milliseconds = Long.parseLong(dateTimeMilliseconds);
                } else {
                    milliseconds = Long.parseLong(parsedMilliseconds);
                }
            } else {
                milliseconds = Long.parseLong(parsedMilliseconds);
            }

            return new Date(milliseconds);
        } catch (Exception e) {
            Log.d("Date Parse Error", e.getMessage());
            return new Date();
        }
    }

    private String parseByDelimiter(String input, String delimiter) {
        if (input.contains(delimiter)) {
            int offset = input.indexOf("-");
            return input.substring(0, offset);
        }

        return null;
    }
}
