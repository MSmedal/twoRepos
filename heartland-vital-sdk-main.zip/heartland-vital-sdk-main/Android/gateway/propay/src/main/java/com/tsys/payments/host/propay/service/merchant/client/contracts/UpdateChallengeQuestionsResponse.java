package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the success or failure of an attempt to update the user's security challenge
 * question
 * and answer pairs
 */
public class UpdateChallengeQuestionsResponse extends BaseResponse {
}
