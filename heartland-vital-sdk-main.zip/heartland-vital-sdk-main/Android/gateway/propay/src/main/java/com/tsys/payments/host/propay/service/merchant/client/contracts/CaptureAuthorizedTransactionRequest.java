package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object that contains credit card data that was captured for a billable transaction
 */
public class CaptureAuthorizedTransactionRequest extends SessionValidationRequest {



    private CaptureCardData CardData;


    private int AttemptNumber;


    private CaptureBillingData BillingData;


    private int[] SignatureBlock;

    public CaptureCardData getCardData() {
        return CardData;
    }

    public void setCardData(CaptureCardData cardData) {
        CardData = cardData;
    }

    public int getAttemptNumber() {
        return AttemptNumber;
    }

    public void setAttemptNumber(int attemptNumber) {
        AttemptNumber = attemptNumber;
    }

    public CaptureBillingData getBillingData() {
        return BillingData;
    }

    public void setBillingData(CaptureBillingData billingData) {
        BillingData = billingData;
    }

    public void setSignatureBlock(int[] signatureBlock) {
        SignatureBlock = signatureBlock;
    }

    public int[] getSignatureBlock() {
        return SignatureBlock;
    }
}
