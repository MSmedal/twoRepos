package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * Definitions of the mobile types known to the ProPay system
 */
public enum MobileDeviceType {
    Unknown(0), IPhone(1), Android(2);

    public final int value;

    MobileDeviceType(int value) {
        this.value = value;
    }

    public static MobileDeviceType parse(int currentValue) {
        switch (currentValue) {
            case 1:
                return IPhone;
            case 2:
                return Android;
            default:
                return Unknown;
        }
    }
}
