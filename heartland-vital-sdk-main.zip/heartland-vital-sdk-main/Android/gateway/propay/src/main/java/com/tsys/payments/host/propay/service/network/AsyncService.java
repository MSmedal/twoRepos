package com.tsys.payments.host.propay.service.network;

import android.os.AsyncTask;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
import com.tsys.payments.host.propay.service.network.exception.NullResponseException;

public class AsyncService<T extends BaseResponse> {

    private WebServiceAsyncTask mWebServiceAsyncTask;

    protected AsyncService() {
    }

    public void call(ResponseHandler<T> handler) {
        if (mWebServiceAsyncTask != null) {
            // Already called
            return;
        }

        mWebServiceAsyncTask = new WebServiceAsyncTask(handler);
        mWebServiceAsyncTask.execute();
    }

    private class WebServiceAsyncTask extends AsyncTask<Void, Void, Object> {

        protected final ResponseHandler<T> mResponseHandler;

        public WebServiceAsyncTask(ResponseHandler<T> responseHandler) {
            this.mResponseHandler = responseHandler;
        }

        @Override
        protected Object doInBackground(Void... params) {
            try {
                return mResponseHandler.executeService();
            } catch (Exception e) {
                e.printStackTrace();
                return e;
            }
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void onPostExecute(Object response) {
            if (response instanceof Exception || response == null) {
                mResponseHandler.handleException(response == null ? new NullResponseException() : (Exception)response);
            } else if (response instanceof BaseResponse) {
                mResponseHandler.handleResponse((T)response);
            }
        }

        @Override
        protected void onCancelled(Object result) {
        }
    }
}
