package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;

public class RegisterForPushRequest extends SessionValidationRequest {

    public static final String DEVICE_TYPE_ANDROID = "2";

    private String NotificationToken;
    private String DeviceType;

    public RegisterForPushRequest() {
        DeviceType = DEVICE_TYPE_ANDROID;
    }

    public String getNotificationToken() {
        return NotificationToken;
    }

    public void setNotificationToken(String notificationToken) {
        NotificationToken = notificationToken;
    }

    public String getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(String deviceType) {
        DeviceType = deviceType;
    }
}
