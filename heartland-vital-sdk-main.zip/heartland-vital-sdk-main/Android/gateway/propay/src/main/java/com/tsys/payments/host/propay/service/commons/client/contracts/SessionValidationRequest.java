package com.tsys.payments.host.propay.service.commons.client.contracts;

;

/**
 * A request object that contains the session data between the client and the server
 */
public class SessionValidationRequest {


    private String SessionGuid;

    public String getSessionGuid() {
        return SessionGuid;
    }

    public void setSessionGuid(String sessionGuid) {
        SessionGuid = sessionGuid;
    }

}
