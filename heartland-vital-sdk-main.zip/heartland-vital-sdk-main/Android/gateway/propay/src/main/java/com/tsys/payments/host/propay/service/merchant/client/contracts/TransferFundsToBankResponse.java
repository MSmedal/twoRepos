package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the success or failure of an attempt to transfer funds associated with a user's
 * session
 */
public class TransferFundsToBankResponse extends BaseResponse {
}
