package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A response object that contains the result of authenticating a credit card that was processed through a credit card
 * swiper
 */
public class AuthorizeCardSwipeResponse extends ProcessAndStoreCardSwipeResponse {

}
