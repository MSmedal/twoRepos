package com.tsys.payments.host.propay;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.tsys.payments.host.propay.constants.ProPayGatewayApplicationId;
import com.tsys.payments.host.propay.enums.ProPayCardDataInputMode;
import com.tsys.payments.host.propay.enums.ProPayCardDataOutputCapability;
import com.tsys.payments.host.propay.enums.ProPayCardPresentData;
import com.tsys.payments.host.propay.enums.ProPayCardholderAuthenticationEntity;
import com.tsys.payments.host.propay.enums.ProPayCardholderAuthenticationMethod;
import com.tsys.payments.host.propay.enums.ProPayCardholderPresentData;
import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;
import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;
import com.tsys.payments.host.propay.enums.ProPayLastChipRead;
import com.tsys.payments.host.propay.enums.ProPayPinCaptureCapability;
import com.tsys.payments.host.propay.enums.ProPayTerminalCardCaptureCapability;
import com.tsys.payments.host.propay.enums.ProPayTerminalCardDataInputCapability;
import com.tsys.payments.host.propay.enums.ProPayTerminalCardholderAuthenticationCapability;
import com.tsys.payments.host.propay.enums.ProPayTerminalDataOutputCapability;
import com.tsys.payments.host.propay.enums.ProPayTerminalOperatingEnvironment;
import com.tsys.payments.host.propay.enums.VoidReason;
import com.tsys.payments.host.propay.service.commons.client.contracts.Result;
import com.tsys.payments.host.propay.service.merchant.client.MerchantResultCodes;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizationBillingData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizationCardData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.AuthorizeManualEntryRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.BillingData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CaptureAuthorizedTransactionRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CaptureAuthorizedTransactionResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CaptureBillingData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CaptureCardData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.EncryptedTracks;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ManualCardData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ManualCardDataWithCVV;
import com.tsys.payments.host.propay.service.merchant.client.contracts.PointOfSaleData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessCardData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessStoredCardRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.ProcessStoredCardResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.StoreCardSwipeRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.StoreCardSwipeResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.SwipeCardData;
import com.tsys.payments.host.propay.service.merchant.client.contracts.VoidOrRefundRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.VoidOrRefundResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvFallbackRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvResponse;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.CardDataSource;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.model.EmvResponsePayload;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.model.MobileEmvPayload;
import com.tsys.payments.host.propay.utils.ProPayCardHelper;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CvmResult;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvUtils;
import com.tsys.payments.library.utils.ByteUtils;
import com.tsys.payments.library.utils.CreditCardHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Entry point for converting to and from host-specific and core sdk library objects.
 */
class ProPayModelConverter {
    private static final String SUCCESS_MESSAGE = "TRANSACTION APPROVED";
    private static final String BATCH_CLOSE_SUCCESS_MESSAGE = "Batch Close Successful";

    /**
     * Construct a {@link AuthorizeCardSwipeRequest} for a standard MSR transaction.
     */
    static AuthorizeCardSwipeRequest toGatewayAuth(@NonNull GatewayRequest request,
            @NonNull ProPayCurrencyCode currencyCode) {
        AuthorizeCardSwipeRequest authRequest = new AuthorizeCardSwipeRequest();
        setBaseAuthorizeRequestData(request, authRequest, currencyCode);
        authRequest.setSwipeCardData(toGatewayAuthSwipeCardData(request));
        authRequest.setCardDataSource(CardDataSource.Msr);
        authRequest.setApplicationId(
                getGatewayAppId(ProPayEncryptingDeviceType.
                        fromTerminalType(request.getTerminalInfo().getTerminalType())));
        authRequest.setShouldStoreCardData(request.isGenerateToken());
        authRequest.setPointOfSaleData(getPointOfSaleDataFromSdkRequest(request));
        if (authRequest.getSwipeCardData().getEncryptedTrackData() != null) {
            authRequest.getSwipeCardData().getEncryptedTrackData()
                    .setDeviceType(
                            ProPayEncryptingDeviceType.fromTerminalType(request.getTerminalInfo().
                                    getTerminalType()));
        }
        return authRequest;
    }

    /**
     * Construct a {@link AuthorizeEmvRequest} for an EMV insert transaction.
     */
    static AuthorizeEmvRequest toGatewayEmvAuth(@NonNull GatewayRequest request,
            @NonNull ProPayCurrencyCode currencyCode) {
        AuthorizeEmvRequest emvRequest = new AuthorizeEmvRequest();
        emvRequest.setPointOfSaleData(getPointOfSaleDataFromSdkRequest(request));
        emvRequest.setCardDataSource(CardDataSource.Insert);
        ProPayEncryptingDeviceType proPayEncryptingDeviceType =
                ProPayEncryptingDeviceType
                        .fromTerminalType(request.getTerminalInfo().getTerminalType());
        emvRequest.setApplicationId(getGatewayAppId(proPayEncryptingDeviceType));
        emvRequest.setMobileEmvPayload(toEmvPayloadData(request));
        setBaseAuthorizeRequestData(request, emvRequest, currencyCode);
        if (emvRequest.getMobileEmvPayload() != null) {
            emvRequest.getMobileEmvPayload().setDeviceType(proPayEncryptingDeviceType);
        }
        return emvRequest;
    }

    /**
     * Construct a {@link VoidOrRefundRequest} for a reversal transaction.
     */
    static VoidOrRefundRequest toReversalRequest(@NonNull GatewayRequest gatewayRequest,
            @Nullable GatewayResponse authResponse) {
        VoidOrRefundRequest reversalRequest = new VoidOrRefundRequest();
        if (authResponse != null && !TextUtils.isEmpty(authResponse.getGatewayTransactionId())) {
            reversalRequest
                    .setAttemptNumber(Integer.valueOf(authResponse.getGatewayTransactionId()));
        } else if (!TextUtils.isEmpty(gatewayRequest.getGatewayTransactionId())) {
            reversalRequest
                    .setAttemptNumber(Integer.valueOf(gatewayRequest.getGatewayTransactionId()));
        }
        reversalRequest.setAmount(gatewayRequest.getTotal());
        CardData cardData = gatewayRequest.getCardData();
        if (cardData != null && cardData.getCardDataSource() == CardDataSourceType.SCR) {
            final MobileEmvPayload emvPayload = new MobileEmvPayload();
            if (gatewayRequest.getTerminalInfo() != null) {
                emvPayload.setDeviceType(
                        ProPayEncryptingDeviceType
                                .fromTerminalType(
                                        gatewayRequest.getTerminalInfo().getTerminalType()));
            }
            emvPayload.setLastChipRead(ProPayLastChipRead.SUCCESSFUL.value);
            emvPayload.setCardDataInputMode(ProPayCardDataInputMode.ONLINE_CHIP.value);
            emvPayload.setVoidReason(
                    VoidReason.fromSdkVoid(gatewayRequest.getReversalReason()).value);
            reversalRequest.setMobileEmvPayload(emvPayload);
        }

        return reversalRequest;
    }

    @NonNull
    private static PointOfSaleData getPointOfSaleDataFromSdkRequest(
            @NonNull GatewayRequest gatewayRequest) {
        if (gatewayRequest.getCardData() != null &&
                gatewayRequest.getCardData().getCardDataSource() != null) {
            CardDataSourceType cardDataSource = gatewayRequest.getCardData().getCardDataSource();
            if (cardDataSource == CardDataSourceType.KEYED ||
                    cardDataSource == CardDataSourceType.PHONE ||
                    cardDataSource == CardDataSourceType.INTERNET
                    || cardDataSource == CardDataSourceType.MAIL) {
                return getBaseManualPointOfSaleData();
            }

            TerminalType terminalType = gatewayRequest.getTerminalInfo().getTerminalType();
            if ((terminalType == TerminalType.INGENICO_MOBY_8500
                    || terminalType == TerminalType.INGENICO_MOBY_3000
                    || terminalType == TerminalType.INGENICO_MOBY_3000_PROPAY) &&
                    gatewayRequest.getCardData() != null) {
                switch (cardDataSource) {
                    case SCR:
                        return getBaseEmvPointOfSaleData(gatewayRequest.getCardData());
                    case FALLBACK:
                        return getBaseEmvFallbackPointOfSaleData();
                    case MSR:
                        return getBaseMsrPointOfSaleData();
                    default:
                        return new PointOfSaleData();
                }
            }
        }
        return new PointOfSaleData();
    }

    /**
     * Construct a {@link VoidOrRefundRequest} for a reversal transaction.
     */
    static VoidOrRefundRequest toRefundRequest(@NonNull GatewayRequest gatewayRequest) {
        VoidOrRefundRequest reversalRequest = new VoidOrRefundRequest();
        reversalRequest.setAmount(gatewayRequest.getTotal());
        CardData cardData = gatewayRequest.getCardData();
        if (cardData != null && cardData.getCardDataSource() == CardDataSourceType.SCR) {
            final MobileEmvPayload emvPayload = new MobileEmvPayload();
            emvPayload.setDeviceType(
                    ProPayEncryptingDeviceType
                            .fromTerminalType(gatewayRequest.getTerminalInfo().getTerminalType()));
            emvPayload.setLastChipRead(ProPayLastChipRead.SUCCESSFUL.value);
            emvPayload.setCardDataInputMode(ProPayCardDataInputMode.ONLINE_CHIP.value);
            emvPayload
                    .setTerminalCardDataInputCapability(
                            ProPayTerminalCardDataInputCapability.ICC_AND_MAG_STRIPE.value);
            emvPayload.setTlvData(TlvUtils.getIccDataString(cardData.getEmvTlvData()));
            reversalRequest.setMobileEmvPayload(emvPayload);
        }
        return reversalRequest;
    }

    /**
     * Construct a {@link AuthorizeEmvFallbackRequest} for an EMV MSR fallback transaction.
     */
    static AuthorizeEmvFallbackRequest toGatewayEmvFallback(@NonNull GatewayRequest request,
            @NonNull ProPayCurrencyCode currencyCode) {
        AuthorizeEmvFallbackRequest emvFallbackRequest = new AuthorizeEmvFallbackRequest();
        setBaseAuthorizeRequestData(request, emvFallbackRequest, currencyCode);
        emvFallbackRequest.setPointOfSaleData(getPointOfSaleDataFromSdkRequest(request));
        emvFallbackRequest.setSwipeCardData(toGatewayAuthSwipeCardData(request));
        emvFallbackRequest.setCardDataSource(CardDataSource.MsrFallback);
        emvFallbackRequest.setLastChipRead(ProPayLastChipRead.NOT_A_CHIP_TRANSACTION.value);
        emvFallbackRequest.setApplicationId(
                getGatewayAppId(ProPayEncryptingDeviceType
                        .fromTerminalType(request.getTerminalInfo().getTerminalType())
                ));
        emvFallbackRequest.setTerminalCardDataInputCapability(
                ProPayTerminalCardDataInputCapability.ICC_AND_MAG_STRIPE.
                        value);
        emvFallbackRequest.setShouldStoreCardData(request.isGenerateToken());
        if (emvFallbackRequest.getSwipeCardData().getEncryptedTrackData() != null) {
            emvFallbackRequest.getSwipeCardData().getEncryptedTrackData()
                    .setDeviceType(ProPayEncryptingDeviceType
                            .fromTerminalType(request.getTerminalInfo().getTerminalType
                                    ()));
        }
        switch (request.getCardData().getFallbackReason()) {
            case EMPTY_CANDIDATE_LIST:
                emvFallbackRequest.setCardDataInputMode(
                        ProPayCardDataInputMode.EMPTY_CANDIDATE_LIST_FALLBACK.value);
                break;
            case ICC_ERROR:
                emvFallbackRequest.setCardDataInputMode(
                        ProPayCardDataInputMode.TRACK_READ_FALLBACK_UNREADABLE_CHIP_CARD_DATA.value);
                break;
            default:
                break;
        }
        emvFallbackRequest.getPointOfSaleData()
                .setCardDataInputMode(emvFallbackRequest.getCardDataInputMode());
        return emvFallbackRequest;
    }

    /**
     * Construct a {@link AuthorizeEmvFallbackRequest} for an EMV MSR fallback transaction.
     */
    static AuthorizeManualEntryRequest toGatewayManualAuth(@NonNull GatewayRequest request,
            @NonNull ProPayCurrencyCode currencyCode) {
        AuthorizeManualEntryRequest req = new AuthorizeManualEntryRequest();
        req.setPointOfSaleData(getPointOfSaleDataFromSdkRequest(request));
        req.setShouldStoreCardData(request.isGenerateToken());
        AuthorizationBillingData billingData = new AuthorizationBillingData();
        String postalCode = null;
        if (request.getCardholderAddress() != null) {
            postalCode = request.getCardholderAddress().getPostalCode();
        } else if (request.getCardData() != null &&
                request.getCardData().getCardholderAddress() != null) {
            postalCode = request.getCardData().getCardholderAddress().getPostalCode();
        }
        billingData.setPostalCode(postalCode == null ? "" : postalCode);
        req.setBillingData(billingData);

        AuthorizationCardData cardData = new AuthorizationCardData();
        cardData.setAmount(request.getTotal());
        if (request.getTax() != null) {
            cardData.setTaxAmount(request.getTax());
        }
        cardData.setCurrencyCode(currencyCode);

        cardData.setInvoiceNumber(
                request.getInvoiceNumber() == null ? "" : request.getInvoiceNumber());
        cardData.setComment1("");
        cardData.setComment2("");
        req.setCardData(cardData);

        ManualCardData manualData;
        CardData sdkCardData = request.getCardData();
        if (sdkCardData != null) {
            if (TextUtils.isEmpty(sdkCardData.getCvv2())) {
                manualData = new ManualCardData();
                manualData.setCardNumber(sdkCardData.getPan());
                new com.tsys.payments.host.propay.service.merchant.client.contracts.ManualCardData();
            } else {
                manualData = new ManualCardDataWithCVV();
                manualData.setCardNumber(sdkCardData.getPan());
                ((ManualCardDataWithCVV)manualData).setCVV(sdkCardData.getCvv2());
                if (CreditCardHelper.isAmericanExpress(manualData.getCardNumber())) {
                    req.getPointOfSaleData().setCardDataInputMode(
                            ProPayCardDataInputMode.MANUAL_ENTRY_WITH_KEYED_CID.
                                    value);
                }
            }
            manualData.setExpirationDate(
                    ProPayCardHelper.toPropayExpDateFormat(sdkCardData.getExpirationDate()));
            req.setManualCardData(manualData);
            if (sdkCardData.getCardholderName() != null) {
                manualData.setName(sdkCardData.getCardholderName());
            } else {
                manualData.setName("");
            }
        }
        if (request.getCustomer() != null
                && request.getCustomer().getEmail() != null) {
            req.setEmail(request.getCustomer().getEmail());
        } else {
            req.setEmail("");
        }

        return req;
    }

    private static void setBaseAuthorizeRequestData(@NonNull GatewayRequest paymentRequest,
            @NonNull AuthorizeCardSwipeRequest authRequest,
            @NonNull ProPayCurrencyCode currencyCode) {
        final AuthorizationCardData authCardData = toGatewayAuthCardData(paymentRequest);
        // API Requires that these fields be present in the CardData Object. Cannot use GSON deserialize nulls method
        // since it would add a field that should not be included in the AuthorizeEmvRequest object.
        authCardData.setCurrencyCode(currencyCode);
        authCardData.setComment1("");
        authCardData.setComment2("");

        authCardData.setInvoiceNumber(
                paymentRequest.getInvoiceNumber() == null ? "" : paymentRequest.getInvoiceNumber());

        final AuthorizationBillingData billingData = new AuthorizationBillingData();

        String postalCode = null;
        if (paymentRequest.getCardholderAddress() != null) {
            postalCode = paymentRequest.getCardholderAddress().getPostalCode();
        }
        billingData.setPostalCode(postalCode == null ? "" : postalCode);
        billingData.setCountryCode(currencyCode.getCurrencyNumber());

        authRequest.setBillingData(billingData);
        authRequest.setCardData(authCardData);
    }

    private static AuthorizationCardData toGatewayAuthCardData(@NonNull GatewayRequest request) {
        AuthorizationCardData cardData = new AuthorizationCardData();
        cardData.setAmount(request.getTotal());
        if (request.getTax() != null) {
            cardData.setTaxAmount(request.getTax());
        }
        return cardData;
    }

    private static SwipeCardData toGatewayAuthSwipeCardData(@NonNull GatewayRequest request) {
        SwipeCardData swipeCardData = new SwipeCardData();
        EncryptedTracks encryptedTracks = new EncryptedTracks();
        CardData sdkCardData = request.getCardData();
        if (sdkCardData != null) {
            // For ProPay MSR requests, EncryptedTrackData is set to the PackedEncrypedTrack data.
            encryptedTracks.setEncryptedTrack2Data(
                    ByteUtils.hexStringToShortArray(sdkCardData.getTrack2()));
            if (TextUtils.isEmpty(sdkCardData.getTrack1())) {
                encryptedTracks.setEncryptedTrackData(encryptedTracks.getEncryptedTrack2Data());
            } else {
                encryptedTracks.setEncryptedTrackData(
                        ByteUtils.hexStringToShortArray(sdkCardData.getTrack1()));
            }
            encryptedTracks
                    .setKeySerialNumber(ByteUtils.hexStringToShortArray(sdkCardData.getKsn()));
            if (!TextUtils.isEmpty(sdkCardData.getCardholderName())) {
                swipeCardData.setName(sdkCardData.getCardholderName());
            }
        }
        swipeCardData.setEncryptedTrackData(encryptedTracks);
        if (request.getTerminalInfo() != null) {
            encryptedTracks
                    .setDeviceType(ProPayEncryptingDeviceType
                            .fromTerminalType(request.getTerminalInfo().getTerminalType
                                    ()));
        }
        return swipeCardData;
    }

    private static MobileEmvPayload toEmvPayloadData(@NonNull GatewayRequest request) {
        MobileEmvPayload emvPayload = new MobileEmvPayload();
        if (request.getCardData() != null) {
            emvPayload.setTlvData(TlvUtils.getIccDataString(
                    filterEmvTagList(request.getCardData().getEmvTlvData())));
        }
        emvPayload.setCardDataInputMode(ProPayCardDataInputMode.ONLINE_CHIP.value);
        emvPayload.setLastChipRead(ProPayLastChipRead.SUCCESSFUL.value);
        emvPayload.setTerminalCardDataInputCapability(
                ProPayTerminalCardDataInputCapability.ICC_AND_MAG_STRIPE.value);
        return emvPayload;
    }

    private static List<TlvObject> filterEmvTagList(List<TlvObject> emvTags) {
        List<TlvObject> emvTagList = new ArrayList<>();
        if (emvTags != null) {
            for (TlvObject tlvObject : emvTags) {
                if (tlvObject.getTagDescriptor() != EmvTagDescriptor.CARDHOLDER_NAME) {
                    emvTagList.add(tlvObject);
                }
            }
        }

        return emvTagList;
    }

    static ProcessStoredCardRequest toProcessStoredCardRequest(@NonNull GatewayRequest request,
            @NonNull ProPayCurrencyCode currencyCode) {
        ProcessStoredCardRequest storedCardRequest = new ProcessStoredCardRequest();
        setBaseProcessStoredCardRequestData(request, storedCardRequest, currencyCode);
        if (request.getToken() != null && request.getCardHolderId() != null) {
            storedCardRequest.setPayerId(Long.valueOf(request.getCardHolderId()));
            storedCardRequest.setPaymentMethodId(request.getToken());
        }
        return storedCardRequest;
    }

    private static void setBaseProcessStoredCardRequestData(@NonNull GatewayRequest paymentRequest,
            @NonNull ProcessStoredCardRequest storedCardRequest,
            @NonNull ProPayCurrencyCode currencyCode) {
        final ProcessCardData processCardData = toProcessCardDataRequest(paymentRequest);
        // API Requires that these fields be present in the CardData Object. Cannot use GSON deserialize nulls method
        // since it would add a field that should not be included in the AuthorizeEmvRequest object.
        processCardData.setCurrencyCode(currencyCode);
        processCardData.setComment1("");
        processCardData.setComment2("");

        processCardData.setInvoiceNumber(
                paymentRequest.getInvoiceNumber() == null ? "" : paymentRequest.getInvoiceNumber());

        final BillingData billingData = new BillingData();

        String postalCode = null;
        if (paymentRequest.getCardholderAddress() != null) {
            postalCode = paymentRequest.getCardholderAddress().getPostalCode();
        }
        billingData.setPostalCode(postalCode == null ? "" : postalCode);
        billingData.setCountryCode(currencyCode.getCurrencyNumber());

        storedCardRequest.setBillingData(billingData);
        storedCardRequest.setProcessCardData(processCardData);
    }

    private static ProcessCardData toProcessCardDataRequest(@NonNull GatewayRequest request) {
        ProcessCardData cardData = new ProcessCardData();
        cardData.setAmount(request.getTotal());
        if (request.getTax() != null) {
            cardData.setTaxAmount(request.getTax());
        }
        if (request.getTip() != null) {
            cardData.setTipAmount(request.getTip());
        }
        return cardData;
    }

    /**
     * Converts an {@link ProcessStoredCardResponse} authorization response sent from the ProPay gateway to an sdk
     * {@link GatewayResponse}.
     */
    static GatewayResponse toGatewayResponse(
            @NonNull ProcessStoredCardResponse gatewayResponse) {
        GatewayResponse hostResponse = new GatewayResponse(GatewayAction.CAPTURE);
        hostResponse
                .setApproved(isGatewayApproved(Integer.toString(gatewayResponse.getResultCode())));
        hostResponse.setAuthCode(gatewayResponse.getAuthorizationCode());
        hostResponse.setGatewayResponseCode(Integer.toString(gatewayResponse.getResultCode()));
        if (gatewayResponse.getResult() != null) {
            setGatewayResponseText(hostResponse, gatewayResponse.getResult());
        }
        return hostResponse;
    }

    /**
     * Converts an {@link AuthorizeCardSwipeResponse} authorization response sent from the ProPay gateway to an sdk
     * {@link GatewayResponse}.
     */
    static GatewayResponse toGatewayResponse(
            @NonNull AuthorizeCardSwipeResponse gatewayResponse) {
        GatewayResponse hostResponse = new GatewayResponse(GatewayAction.AUTH);
        hostResponse.setGatewayTransactionId(Integer.toString(gatewayResponse.getAttemptNumber()));
        hostResponse
                .setApproved(isGatewayApproved(Integer.toString(gatewayResponse.getResultCode())));
        hostResponse.setGatewayResponseCode(Integer.toString(gatewayResponse.getResultCode()));
        hostResponse.setAuthCode(gatewayResponse.getAuthorizationCode());
        if (gatewayResponse.getResult() != null) {
            setGatewayResponseText(hostResponse, gatewayResponse.getResult());
        }

        hostResponse.setToken(gatewayResponse.getPaymentMethodId());
        hostResponse.setCardHolderId(gatewayResponse.getPayerId());

        return hostResponse;
    }

    /**
     * Converts an {@link AuthorizeCardSwipeResponse} authorization response sent from the ProPay gateway to an sdk
     * {@link GatewayResponse}.
     */
    static GatewayResponse toGatewayResponse(
            @NonNull CaptureAuthorizedTransactionResponse gatewayResponse) {
        GatewayResponse hostResponse = new GatewayResponse(GatewayAction.CAPTURE);
        hostResponse.setGatewayTransactionId(Integer.toString(gatewayResponse.getAttemptNumber()));
        hostResponse.setAuthCode(gatewayResponse.getAuthorizationCode());
        hostResponse
                .setApproved(isGatewayApproved(Integer.toString(gatewayResponse.getResultCode())));
        hostResponse.setGatewayResponseCode(Integer.toString(gatewayResponse.getResultCode()));
        if (gatewayResponse.getResult() != null) {
            setGatewayResponseText(hostResponse, gatewayResponse.getResult());
        }
        return hostResponse;
    }

    /**
     * Converts an {@link AuthorizeEmvResponse} authorization response sent from the ProPay gateway to an sdk {@link
     * GatewayResponse}.
     */
    static GatewayResponse toGatewayResponse(
            @NonNull AuthorizeEmvResponse gatewayResponse) {
        GatewayResponse hostResponse = new GatewayResponse(GatewayAction.AUTH);
        hostResponse.setGatewayTransactionId(Integer.toString(gatewayResponse.getAttemptNumber()));
        hostResponse
                .setApproved(isGatewayApproved(Integer.toString(gatewayResponse.getResultCode())));
        hostResponse.setGatewayResponseCode(Integer.toString(gatewayResponse.getResultCode()));
        hostResponse.setAuthCode(gatewayResponse.getAuthorizationCode());
        if (gatewayResponse.getResult() != null) {
            setGatewayResponseText(hostResponse, gatewayResponse.getResult());
        }
        if (gatewayResponse.getEmvResponsePayload() != null) {
            EmvResponsePayload emvResponsePayload = gatewayResponse.getEmvResponsePayload();
            hostResponse.setEmvIssuerAuthCode(emvResponsePayload.getEmvResponseCode());
            hostResponse.setEmvIssuerAuthenticationData(
                    emvResponsePayload.getEmvIssuerAuthenticationData());
            StringBuilder issuerScriptsBuilder = new StringBuilder();
            if (!TextUtils.isEmpty(emvResponsePayload.getEmvIssuerScriptTemplate1())) {
                issuerScriptsBuilder.append(emvResponsePayload.getEmvIssuerScriptTemplate1());
            }
            if (!TextUtils.isEmpty(emvResponsePayload.getEmvIssuerScriptTemplate2())) {
                issuerScriptsBuilder.append(emvResponsePayload.getEmvIssuerScriptTemplate2());
            }
            hostResponse.setEmvIssuerScripts(issuerScriptsBuilder.toString());
        } else if (!hostResponse.isApproved()) {
            hostResponse.setEmvIssuerAuthenticationData("8A023035");
            hostResponse.setEmvIssuerAuthCode("8A023035");
        }

        return hostResponse;
    }

    /**
     * Converts an {@link VoidOrRefundResponse} reversal response sent from the ProPay gateway to an sdk {@link
     * GatewayResponse}.
     */
    static GatewayResponse toGatewayResponse(
            @NonNull VoidOrRefundResponse voidOrRefundResponse) {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.VOID);
        sdkResponse.setApproved(
                isGatewayApproved(Integer.toString(voidOrRefundResponse.getResultCode())));
        sdkResponse.setGatewayResponseCode(Integer.toString(voidOrRefundResponse.getResultCode()));
        if (voidOrRefundResponse.getResult() != null) {
            sdkResponse.setGatewayResponseText(voidOrRefundResponse.getResult().getResultMessage());
        }
        return sdkResponse;
    }

    /**
     * Converts a {@link StoreCardSwipeResponse} response sent from the ProPay gateway to an sdk{@link
     * GatewayResponse}.
     */
    static GatewayResponse toGatewayResponse(@NonNull StoreCardSwipeResponse gatewayResponse) {
        GatewayResponse hostResponse = new GatewayResponse(GatewayAction.TOKENIZE_CARD);
        hostResponse
                .setApproved(isGatewayApproved(Integer.toString(gatewayResponse.getResultCode())));
        hostResponse.setGatewayResponseCode(Integer.toString(gatewayResponse.getResultCode()));
        if (gatewayResponse.getResult() != null) {
            setGatewayResponseText(hostResponse, gatewayResponse.getResult());
        }

        hostResponse.setToken(gatewayResponse.getPaymentMethodId());
        hostResponse.setCardHolderId(String.valueOf(gatewayResponse.getPayerId()));

        return hostResponse;
    }

    /**
     * The ProPay gateway does not support a Batch Close action. For modularity between modules a mocked successful
     * response was created.
     */
    static GatewayResponse getSuccessfulBatchCloseResponse() {
        GatewayResponse sdkResponse = new GatewayResponse(GatewayAction.BATCH_CLOSE);
        sdkResponse.setApproved(true);
        sdkResponse.setGatewayResponseText(BATCH_CLOSE_SUCCESS_MESSAGE);
        return sdkResponse;
    }

    @NonNull
    static CaptureAuthorizedTransactionRequest convertSdkDataToGatewayCapture(
            @NonNull GatewayRequest request) {
        final CaptureAuthorizedTransactionRequest captureRequest =
                new CaptureAuthorizedTransactionRequest();
        CaptureCardData cardData = new CaptureCardData();
        if (request.getTip() != null) {
            cardData.setTipAmount(request.getTip());
        }

        long transactionAmount = request.getTotal();
        cardData.setAmount(transactionAmount);
        captureRequest.setCardData(cardData);

        captureRequest.setAttemptNumber(TextUtils.isEmpty(request.getGatewayTransactionId()) ? 0 :
                Integer.valueOf(request.getGatewayTransactionId()));
        CaptureBillingData billingData = new CaptureBillingData();
        captureRequest.setBillingData(billingData);
        captureRequest.setSignatureBlock(request.getSignatureBitmap());
        return captureRequest;
    }

    @NonNull
    static CaptureAuthorizedTransactionRequest convertSdkDataToGatewayCapture(
            @NonNull GatewayRequest gatewayRequest, @NonNull GatewayResponse response) {
        final CaptureAuthorizedTransactionRequest captureRequest =
                new CaptureAuthorizedTransactionRequest();
        CaptureCardData cardData = new CaptureCardData();
        if (gatewayRequest.getTip() != null) {
            cardData.setTipAmount(gatewayRequest.getTip());
        }

        long transactionAmount = gatewayRequest.getTotal();
        cardData.setAmount(transactionAmount);
        captureRequest.setCardData(cardData);

        captureRequest.setAttemptNumber(TextUtils.isEmpty(response.getGatewayTransactionId()) ? 0 :
                Integer.valueOf(response.getGatewayTransactionId()));
        CaptureBillingData billingData = new CaptureBillingData();
        captureRequest.setBillingData(billingData);
        if (gatewayRequest.getSignatureBitmap() != null) {
            captureRequest.setSignatureBlock(gatewayRequest.getSignatureBitmap());
        } else {
            String signatureFileLocation = gatewayRequest.getSignatureFileLocation();
            if (!TextUtils.isEmpty(signatureFileLocation)) {
                captureRequest.setSignatureBlock(ProPaySignatureHelper
                        .getSignatureBlock(signatureFileLocation));
            }
        }
        return captureRequest;
    }

    static StoreCardSwipeRequest convertSdkToStoreSwipeRequest(
            @NonNull GatewayRequest paymentGatewayRequest,
            @NonNull ProPayCurrencyCode currencyCode) {

        StoreCardSwipeRequest request = new StoreCardSwipeRequest();
        BillingData billingData = new BillingData();
        CardData sdkCardData = paymentGatewayRequest.getCardData();
        String postalCode = null;
        if (paymentGatewayRequest.getCardholderAddress() != null) {
            postalCode = paymentGatewayRequest.getCardholderAddress().getPostalCode();
        }
        billingData.setPostalCode(postalCode == null ? "" : postalCode);
        billingData.setCountryCode(currencyCode.getCurrencyNumber());

        request.setBillingData(billingData);

        SwipeCardData swipeData = new SwipeCardData();
        EncryptedTracks trackData = new EncryptedTracks();

        trackData.setKeySerialNumber(
                ByteUtils.hexStringToShortArray(sdkCardData.getKsn()));
        trackData.setEncryptedTrackData(
                ByteUtils.hexStringToShortArray(sdkCardData.getTrack1()));
        trackData.setEncryptedTrack2Data(
                ByteUtils.hexStringToShortArray(sdkCardData.getTrack2()));
        trackData.setDeviceType(ProPayEncryptingDeviceType.
                fromTerminalType(paymentGatewayRequest.getTerminalInfo().getTerminalType()));

        swipeData.setEncryptedTrackData(trackData);
        swipeData.setName(sdkCardData.getCardholderName());
        request.setSwipeCardData(swipeData);
        request.setTag(paymentGatewayRequest.getPosReferenceNumber());

        return request;
    }

    private static int getLastChipReadFromSdk(GatewayRequest gatewayRequest) {
        // TODO: Validate that this approach matches the expected result.
        if (gatewayRequest.getCardData().getFallbackReason() == null) {
            return ProPayLastChipRead.SUCCESSFUL.value;
        } else {
            return ProPayLastChipRead.NOT_A_CHIP_TRANSACTION.value;
        }
    }

    private static boolean isGatewayApproved(String gatewayResponseCode) {
        if (!TextUtils.isEmpty(gatewayResponseCode)) {
            return Integer.toString(MerchantResultCodes.SUCCESS).equals(gatewayResponseCode);
        }
        return false;
    }

    private static void setGatewayResponseText(@NonNull GatewayResponse hostResponse,
            @NonNull Result result) {
        if (hostResponse.isApproved()) {
            hostResponse.setGatewayResponseText(SUCCESS_MESSAGE);
        } else {
            hostResponse.setGatewayResponseText(result.getResultMessage());
        }
    }

    private static PointOfSaleData getBaseMsrPointOfSaleData() {
        PointOfSaleData posData = new PointOfSaleData();
        posData.setTerminalCardDataInputCapability(
                ProPayTerminalCardDataInputCapability.ICC_AND_MAG_STRIPE.value);
        posData.setTerminalCardholderAuthenticationCapability(
                ProPayTerminalCardholderAuthenticationCapability.NO_CAPABILITY.value);
        posData.setTerminalCardCaptureCapability(ProPayTerminalCardCaptureCapability.NONE.value);
        posData.setTerminalOperatingEnvironment(ProPayTerminalOperatingEnvironment.
                OFF_MERCHANT_PREMISES_CARDHOLDER_MOBILE_POS.value);
        posData.setCardholderPresentData(ProPayCardholderPresentData.PRESENT.value);
        posData.setCardPresentData(ProPayCardPresentData.PRESENT.value);
        posData.setCardDataInputMode(
                ProPayCardDataInputMode.MAG_STRIPE_READER_TRACK_CAPTURED.value);
        posData.setCardholderAuthenticationMethod(
                ProPayCardholderAuthenticationMethod.NOT_AUTHENTICATED.value);
        posData.setCardholderAuthenticationEntity(
                ProPayCardholderAuthenticationEntity.NOT_AUTHENTICATED.value);
        posData.setCardDataOutputCapability(
                ProPayCardDataOutputCapability.INTEGRATED_CHIP_CARD.value);
        posData.setTerminalDataOutputCapability(
                ProPayTerminalDataOutputCapability.DISPLAY_ONLY.value);
        posData.setPinCaptureCapability(ProPayPinCaptureCapability.NONE.value);
        return posData;
    }

    private static PointOfSaleData getBaseManualPointOfSaleData() {
        PointOfSaleData posData = new PointOfSaleData();
        posData.setTerminalCardDataInputCapability(
                ProPayTerminalCardDataInputCapability.ICC_AND_MAG_STRIPE.value);
        posData.setTerminalCardholderAuthenticationCapability(
                ProPayTerminalCardholderAuthenticationCapability.NO_CAPABILITY.value);
        posData.setTerminalCardCaptureCapability(ProPayTerminalCardCaptureCapability.NONE.value);
        posData.setTerminalOperatingEnvironment(ProPayTerminalOperatingEnvironment.
                OFF_MERCHANT_PREMISES_CARDHOLDER_MOBILE_POS.value);
        posData.setCardholderPresentData(ProPayCardholderPresentData.PRESENT.value);
        posData.setCardPresentData(ProPayCardPresentData.PRESENT.value);
        posData.setCardDataInputMode(ProPayCardDataInputMode.KEY_ENTRY.value);
        posData.setCardholderAuthenticationMethod(
                ProPayCardholderAuthenticationMethod.NOT_AUTHENTICATED.value);
        posData.setCardholderAuthenticationEntity(
                ProPayCardholderAuthenticationEntity.NOT_AUTHENTICATED.value);
        posData.setCardDataOutputCapability(
                ProPayCardDataOutputCapability.INTEGRATED_CHIP_CARD.value);
        posData.setTerminalDataOutputCapability(
                ProPayTerminalDataOutputCapability.DISPLAY_ONLY.value);
        posData.setPinCaptureCapability(ProPayPinCaptureCapability.NONE.value);
        return posData;
    }

    private static PointOfSaleData getBaseEmvPointOfSaleData(CardData cardData) {
        PointOfSaleData posData = new PointOfSaleData();
        posData.setTerminalCardDataInputCapability(
                ProPayTerminalCardDataInputCapability.ICC_AND_MAG_STRIPE.value);
        posData.setTerminalCardholderAuthenticationCapability(
                ProPayTerminalCardholderAuthenticationCapability.NO_CAPABILITY.value);
        posData.setTerminalCardCaptureCapability(ProPayTerminalCardCaptureCapability.NONE.value);
        posData.setTerminalOperatingEnvironment(ProPayTerminalOperatingEnvironment.
                OFF_MERCHANT_PREMISES_CARDHOLDER_MOBILE_POS.value);
        posData.setCardholderPresentData(ProPayCardholderPresentData.PRESENT.value);
        posData.setCardPresentData(ProPayCardPresentData.PRESENT.value);
        posData.setCardDataInputMode(ProPayCardDataInputMode.ONLINE_CHIP.value);

        CvmResult cvmResult = null;
        if (cardData.getEmvTlvData() != null) {
            for (TlvObject tag : cardData.getEmvTlvData()) {
                if (tag.getTagDescriptor() == EmvTagDescriptor.CVM_RESULT) {
                    cvmResult = CvmResult.fromTlv(tag.getValueAsHexString(false));
                }
            }
        }
        posData.setCardholderAuthenticationMethod(
                ProPayCardholderAuthenticationMethod.fromCvmResult(cvmResult).value);
        posData.setCardholderAuthenticationEntity(
                ProPayCardholderAuthenticationEntity.fromCvmResult(cvmResult).value);
        posData.setCardDataOutputCapability(
                ProPayCardDataOutputCapability.INTEGRATED_CHIP_CARD.value);
        posData.setTerminalDataOutputCapability(
                ProPayTerminalDataOutputCapability.DISPLAY_ONLY.value);
        posData.setPinCaptureCapability(ProPayPinCaptureCapability.NONE.value);
        return posData;
    }

    private static final String getGatewayAppId(ProPayEncryptingDeviceType deviceType) {
        if (deviceType == ProPayEncryptingDeviceType.MobyBdk) {
            return ProPayGatewayApplicationId.ANDROID_MOBY_EMV;
        } else {
            // TODO: The BIN values are not set in stone and Moby is the only one we're interested in for this
            // certification. This return logic may change.
            return ProPayGatewayApplicationId.ANDROID_NON_EMV;
        }
    }

    private static PointOfSaleData getBaseEmvFallbackPointOfSaleData() {
        PointOfSaleData posData = new PointOfSaleData();
        posData.setTerminalCardDataInputCapability(
                ProPayTerminalCardDataInputCapability.ICC_AND_MAG_STRIPE.value);
        posData.setTerminalCardholderAuthenticationCapability(
                ProPayTerminalCardholderAuthenticationCapability.NO_CAPABILITY.value);
        posData.setTerminalCardCaptureCapability(ProPayTerminalCardCaptureCapability.NONE.value);
        posData.setTerminalOperatingEnvironment(ProPayTerminalOperatingEnvironment.
                OFF_MERCHANT_PREMISES_CARDHOLDER_MOBILE_POS.value);
        posData.setCardholderPresentData(ProPayCardholderPresentData.PRESENT.value);
        posData.setCardPresentData(ProPayCardPresentData.PRESENT.value);
        posData.setCardDataInputMode(
                ProPayCardDataInputMode.TRACK_READ_FALLBACK_UNREADABLE_CHIP_CARD_DATA.value);
        posData.setCardholderAuthenticationMethod(
                ProPayCardholderAuthenticationMethod.NOT_AUTHENTICATED.value);
        posData.setCardholderAuthenticationEntity(
                ProPayCardholderAuthenticationEntity.NOT_AUTHENTICATED.value);
        posData.setCardDataOutputCapability(
                ProPayCardDataOutputCapability.INTEGRATED_CHIP_CARD.value);
        posData.setTerminalDataOutputCapability(
                ProPayTerminalDataOutputCapability.DISPLAY_ONLY.value);
        posData.setPinCaptureCapability(ProPayPinCaptureCapability.NONE.value);
        return posData;
    }
}
