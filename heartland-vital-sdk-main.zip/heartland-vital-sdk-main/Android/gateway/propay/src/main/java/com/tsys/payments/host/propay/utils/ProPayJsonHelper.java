package com.tsys.payments.host.propay.utils;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tsys.payments.host.propay.service.commons.client.io.ByteArraySerializer;
import com.tsys.payments.host.propay.service.commons.client.io.DateSerializer;
import com.tsys.payments.host.propay.service.merchant.client.contracts.CamsSystem;
import com.tsys.payments.host.propay.service.merchant.client.contracts.MobileDeviceType;
import com.tsys.payments.host.propay.service.merchant.client.contracts.TransactionStatus;
import com.tsys.payments.host.propay.service.merchant.client.io.CamsSystemSerializer;
import com.tsys.payments.host.propay.service.merchant.client.io.EncryptingDeviceTypeSerializer;
import com.tsys.payments.host.propay.service.merchant.client.io.ExternalTransactionStatusSerializer;
import com.tsys.payments.host.propay.service.merchant.client.io.ISOCurrencyCodeSerializer;
import com.tsys.payments.host.propay.service.merchant.client.io.MobileDeviceTypeSerializer;
import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;
import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;

import java.util.Date;

public final class ProPayJsonHelper {

    private ProPayJsonHelper() {

    }

    /**
     * Returns the standard Gson object used for custom serialization and deserialization of ProPay gateway API
     * objects.
     */
    @NonNull
    public static Gson getGson(boolean serializeNulls) {
        GsonBuilder gsonb = new GsonBuilder();
        DateSerializer dateSerializer = new DateSerializer();
        ByteArraySerializer byteArraySerializer = new ByteArraySerializer();
        MobileDeviceTypeSerializer deviceTypeSerializer = new MobileDeviceTypeSerializer();
        EncryptingDeviceTypeSerializer encryptingDeviceTypeSerializer = new EncryptingDeviceTypeSerializer();
        ExternalTransactionStatusSerializer externalTransactionStatusSerializer =
                new ExternalTransactionStatusSerializer();
        ISOCurrencyCodeSerializer isoCurrencyTypeSerializer = new ISOCurrencyCodeSerializer();
        CamsSystemSerializer camsSystemSerializer = new CamsSystemSerializer();

        gsonb.registerTypeAdapter(Date.class, dateSerializer);
        gsonb.registerTypeAdapter(byte[].class, byteArraySerializer);
        gsonb.registerTypeAdapter(MobileDeviceType.class, deviceTypeSerializer);
        gsonb.registerTypeAdapter(ProPayEncryptingDeviceType.class, encryptingDeviceTypeSerializer);
        gsonb.registerTypeAdapter(TransactionStatus.class,
                externalTransactionStatusSerializer);
        gsonb.registerTypeAdapter(ProPayCurrencyCode.class, isoCurrencyTypeSerializer);
        gsonb.registerTypeAdapter(CamsSystem.class, camsSystemSerializer);
        if (serializeNulls) {
            gsonb.serializeNulls();
        }
        return gsonb.create();
    }
}
