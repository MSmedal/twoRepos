package com.tsys.payments.host.propay.service.merchant.client.io;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.tsys.payments.host.propay.service.merchant.client.contracts.MobileDeviceType;

import java.lang.reflect.Type;

/**
 * Serializes / Deserializes {@link MobileDeviceType MobileDeviceType} enum to / from the JSON format
 *
 * @author joates this class is a shameless copy from the mercury project. If we
 *         make any more than two android apps, we'll want to create a shared library.
 */

// NOTE: We have a single serializer per type of enum because we could not easily determine the type
// of enum we were using and translate the int to enum (because of the way Java handles enums).
// We could have just used longs all over but a typesafe version of this was preferable
// and the serializers aren't too large.
public class MobileDeviceTypeSerializer
        implements JsonSerializer<MobileDeviceType>, JsonDeserializer<MobileDeviceType> {

    @Override
    public JsonElement serialize(MobileDeviceType sourceEnum, Type typeOfT, JsonSerializationContext context) {
        return new JsonPrimitive(sourceEnum.value);
    }

    @Override
    public MobileDeviceType deserialize(JsonElement element, Type typeOfT, JsonDeserializationContext arg2)
            throws JsonParseException {
        return MobileDeviceType.parse(element.getAsInt());
    }
}
