package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * Contains the approval or denial response for requesting a forgotten password flow
 */
public class ForgotPasswordResponse extends BaseResponse {
}
