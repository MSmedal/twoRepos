package com.tsys.payments.host.propay.enums;

/**
 * Indicates the cardholder presence at the time of the transaction.
 */
public enum ProPayCardholderPresentData {
    PRESENT(48),
    NOT_PRESENT_UNSPECIFIED_REASON(49),
    NOT_PRESENT_MAIL_TRANSACTION(50),
    NOT_PRESENT_PHONE_TRANSACTION(51),
    NOT_PRESENT_RECURRING_TRANSACTION(52),
    NOT_PRESENT_ELECTRONIC_COMMERCE(53),
    NOT_PRESENT_RECURRING_BILL(56),
    RE_AUTH_FULL_AMOUNT(65),
    PARTIAL_SHIPMENT(80),
    RECURRING_PURCHASE(82),
    DISCOVERY_PAY_BUTTON(84);

    public final int value;

    ProPayCardholderPresentData(int value) {
        this.value = value;
    }
}
