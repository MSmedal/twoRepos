package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;
import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.CardDataSource;

/**
 * A request object that contains the credit card data obtained from swiping a credit card through a credit card
 * reader.
 */
public class AuthorizeCardSwipeRequest extends SessionValidationRequest {

    @SerializedName("SwipeCardData")
    private SwipeCardData mSwipeCardData;

    @SerializedName("CardData")
    private AuthorizationCardData mCardData;

    @SerializedName("BillingData")
    private AuthorizationBillingData mBillingData;

    @SerializedName("ShouldStoreCardData")
    private boolean mShouldStoreCardData;
    @CardDataSource.Type
    @SerializedName("CardDataSource")
    private int mCardDataSource = CardDataSource.Insert;
    @SerializedName("ApplicationId")
    private String mApplicationId;
    @SerializedName("PointOfSaleData")
    private PointOfSaleData mPointOfSaleData;

    public SwipeCardData getSwipeCardData() {
        return mSwipeCardData;
    }

    public void setSwipeCardData(SwipeCardData swipeCardData) {
        mSwipeCardData = swipeCardData;
    }

    public AuthorizationCardData getCardData() {
        return mCardData;
    }

    public void setCardData(AuthorizationCardData cardData) {
        mCardData = cardData;
    }

    public AuthorizationBillingData getBillingData() {
        return mBillingData;
    }

    public void setBillingData(AuthorizationBillingData billingData) {
        mBillingData = billingData;
    }

    public boolean isShouldStoreCardData() {
        return mShouldStoreCardData;
    }

    public void setShouldStoreCardData(boolean shouldStoreCardData) {
        mShouldStoreCardData = shouldStoreCardData;
    }

    public int getCardDataSource() {
        return mCardDataSource;
    }

    public void setCardDataSource(@CardDataSource.Type int cardDataSource) {
        mCardDataSource = cardDataSource;
    }

    public String getApplicationId() {
        return mApplicationId;
    }

    public void setApplicationId(String applicationId) {
        mApplicationId = applicationId;
    }

    public PointOfSaleData getPointOfSaleData() {
        return mPointOfSaleData;
    }

    public void setPointOfSaleData(PointOfSaleData pointOfSaleData) {
        mPointOfSaleData = pointOfSaleData;
    }
}
