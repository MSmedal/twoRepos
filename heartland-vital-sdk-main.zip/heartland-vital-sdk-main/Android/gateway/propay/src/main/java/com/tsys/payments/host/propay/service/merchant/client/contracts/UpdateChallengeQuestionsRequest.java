package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
;
;

/**
 * A request object that contains the security challenge question and answer pairs to update
 */
public class UpdateChallengeQuestionsRequest extends SessionValidationRequest {



    private ChallengeQuestionAnswer[] ChallengeQuestions;

    public ChallengeQuestionAnswer[] getChallengeQuestions() {
        return ChallengeQuestions;
    }

    public void setChallengeQuestions(ChallengeQuestionAnswer[] challengeQuestions) {
        ChallengeQuestions = challengeQuestions;
    }
}
