package com.tsys.payments.host.propay.service.merchant.client.contracts;

public class AuthenticateUserAccountRequest extends CallerValidationRequest {

    private String mCertString;

    private String mAccountClass;

    private AccountMetaData mAccountMetaData;

    public String getCertString() {
        return mCertString;
    }

    public void setCertString(String certString) {
        mCertString = certString;
    }

    public String getAccountClass() {
        return mAccountClass;
    }

    public void setAccountClass(String accountClass) {
        mAccountClass = accountClass;
    }

    public AccountMetaData getAccountMetaData() {
        return mAccountMetaData;
    }

    public void setAccountMetaData(
            AccountMetaData accountMetaData) {
        mAccountMetaData = accountMetaData;
    }

    public static class AccountMetaData {
        private int mAccountNumber;

        private String mTransactionType;

        public int getAccountNumber() {
            return mAccountNumber;
        }

        public void setAccountNumber(int accountNumber) {
            mAccountNumber = accountNumber;
        }

        public String getTransactionType() {
            return mTransactionType;
        }

        public void setTransactionType(String transactionType) {
            mTransactionType = transactionType;
        }
    }
}
