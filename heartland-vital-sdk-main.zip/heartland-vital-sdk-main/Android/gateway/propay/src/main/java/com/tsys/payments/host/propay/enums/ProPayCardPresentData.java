package com.tsys.payments.host.propay.enums;

/**
 * Indicates whether or not a physical card or some other medium containing card data is present.
 */
public enum ProPayCardPresentData {
    NOT_PRESENT(48),
    PRESENT(49),
    TRANSPONDER(87),
    CONTACTLESS_CHIP(88),
    DIGITAL_WALLET(90);

    public final int value;

    ProPayCardPresentData(int value) {
        this.value = value;
    }
}
