package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;

public class UnregisterForPushRequest extends SessionValidationRequest {

    private String RegistrationId;
    private String NotificationToken;
    private String SessionGuid;

    public UnregisterForPushRequest() {
    }

    public String getRegistrationId() {
        return RegistrationId;
    }

    public void setRegistrationId(String registrationId) {
        RegistrationId = registrationId;
    }

    public String getNotificationToken() {
        return NotificationToken;
    }

    public void setNotificationToken(String notificationToken) {
        NotificationToken = notificationToken;
    }

    @Override
    public String getSessionGuid() {
        return SessionGuid;
    }

    @Override
    public void setSessionGuid(String sessionGuid) {
        SessionGuid = sessionGuid;
    }
}
