package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A request object to update a user's security PIN
 */
public class SetPinRequest extends CallerValidationRequest {
    private String Username;
    private String Password;
    private String Pin;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        this.Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        this.Password = password;
    }

    public String getPin() {
        return Pin;
    }

    public void setPin(String pin) {
        this.Pin = pin;
    }
}
