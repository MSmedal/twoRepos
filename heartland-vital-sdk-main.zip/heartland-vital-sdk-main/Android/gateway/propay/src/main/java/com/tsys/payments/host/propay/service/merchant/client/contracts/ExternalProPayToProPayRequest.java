package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.SessionValidationRequest;
import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;

/**
 * Contains data necessary for performing a transfer of funds from one ProPay account to another.
 */
public class ExternalProPayToProPayRequest extends SessionValidationRequest {

    private int Amount;

    private ProPayCurrencyCode CurrencyCode;

    private String InvoiceNumber;

    private boolean ShouldStore;

    private String MerchantProfileId;

    private String Comment1;

    private ProPayToProPayAddData ExternalPaymentMethodProPayToProPayAddData;

    private com.tsys.payments.host.propay.service.merchant.client.contracts.PropayToPropayBillingData
            PropayToPropayBillingData;

    public int getAmount() {
        return Amount;
    }

    public void setAmount(int amount) {
        Amount = amount;
    }

    public ProPayCurrencyCode getCurrencyCode() {
        return CurrencyCode;
    }

    public void setCurrencyCode(ProPayCurrencyCode currencyCode) {
        CurrencyCode = currencyCode;
    }

    public String getInvoiceNumber() {
        return InvoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        InvoiceNumber = invoiceNumber;
    }

    public boolean isShouldStore() {
        return ShouldStore;
    }

    public void setShouldStore(boolean shouldStore) {
        ShouldStore = shouldStore;
    }

    public String getMerchantProfileId() {
        return MerchantProfileId;
    }

    public void setMerchantProfileId(String merchantProfileId) {
        MerchantProfileId = merchantProfileId;
    }

    public String getComment1() {
        return Comment1;
    }

    public void setComment1(String comment1) {
        Comment1 = comment1;
    }

    public ProPayToProPayAddData getExternalPaymentMethodProPayToProPayAddData() {
        return ExternalPaymentMethodProPayToProPayAddData;
    }

    public void setExternalPaymentMethodProPayToProPayAddData(
            ProPayToProPayAddData externalPaymentMethodProPayToProPayAddData) {
        ExternalPaymentMethodProPayToProPayAddData = externalPaymentMethodProPayToProPayAddData;
    }

    public PropayToPropayBillingData getPropayToPropayBillingData() {
        return PropayToPropayBillingData;
    }

    public void setPropayToPropayBillingData(PropayToPropayBillingData propayToPropayBillingData) {
        PropayToPropayBillingData = propayToPropayBillingData;
    }
}
