package com.tsys.payments.host.propay.service.merchant.client.io;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.tsys.payments.host.propay.enums.ProPayCurrencyCode;

import java.lang.reflect.Type;

/**
 * Serializes / Deserializes {@link ProPayCurrencyCode ISOCurrencyCode} enum to / from the JSON format
 */
public class ISOCurrencyCodeSerializer implements JsonSerializer<ProPayCurrencyCode>, JsonDeserializer<
        ProPayCurrencyCode> {

    @Override
    public JsonElement serialize(ProPayCurrencyCode sourceEnum, Type typeOfT, JsonSerializationContext context) {
        return new JsonPrimitive(sourceEnum.getCurrencyNumber());
    }

    @Override
    public ProPayCurrencyCode deserialize(JsonElement element, Type typeOfT, JsonDeserializationContext context)
            throws JsonParseException {
        return ProPayCurrencyCode.find(element.getAsInt());
    }
}
