package com.tsys.payments.host.propay.service.merchant.client.contracts.emv.model;

import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

/**
 * Defines the type of data sent in response to an EMV transaction that requested online processing.
 */
public final class EmvResponsePayload {
    @Nullable
    @SerializedName("EmvIssuerAuthenticationData")
    private String mEmvIssuerAuthenticationData;
    @Nullable
    @SerializedName("EmvIssuerScriptTemplate1")
    private String mEmvIssuerScriptTemplate1;
    @Nullable
    @SerializedName("EmvIssuerScriptTemplate2")
    private String mEmvIssuerScriptTemplate2;
    @Nullable
    @SerializedName("EmvResponseCode")
    private String mEmvResponseCode;

    @Nullable
    public String getEmvIssuerAuthenticationData() {
        return mEmvIssuerAuthenticationData;
    }

    public void setEmvIssuerAuthenticationData(@Nullable String emvIssuerAuthenticationData) {
        mEmvIssuerAuthenticationData = emvIssuerAuthenticationData;
    }

    @Nullable
    public String getEmvIssuerScriptTemplate1() {
        return mEmvIssuerScriptTemplate1;
    }

    public void setEmvIssuerScriptTemplate1(@Nullable String emvIssuerScriptTemplate1) {
        mEmvIssuerScriptTemplate1 = emvIssuerScriptTemplate1;
    }

    @Nullable
    public String getEmvIssuerScriptTemplate2() {
        return mEmvIssuerScriptTemplate2;
    }

    public void setEmvIssuerScriptTemplate2(@Nullable String emvIssuerScriptTemplate2) {
        mEmvIssuerScriptTemplate2 = emvIssuerScriptTemplate2;
    }

    @Nullable
    public String getEmvResponseCode() {
        return mEmvResponseCode;
    }

    public void setEmvResponseCode(@Nullable String emvResponseCode) {
        mEmvResponseCode = emvResponseCode;
    }
}
