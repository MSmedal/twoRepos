package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.google.gson.annotations.SerializedName;

/**
 * Contains the basic metadata associated with a financial billing transaction
 */
public class BillingData {

    @SerializedName("Email")
    private String mEmail;
    @SerializedName("PostalCode")
    private String mPostalCode;
    @SerializedName("CountryCode")
    private Integer mCountryCode;

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getPostalCode() {
        return mPostalCode;
    }

    public void setPostalCode(String postalCode) {
        mPostalCode = postalCode;
    }

    public Integer getCountryCode() {
        return mCountryCode;
    }

    public void setCountryCode(Integer countryCode) {
        mCountryCode = countryCode;
    }
}
