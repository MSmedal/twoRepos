package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * Definitions of the possible values for a ProPay financial transaction
 */
public enum TransactionStatus {

    PROPAY_STATUS_UNKNOWN(0, "Unknown"),
    PROPAY_STATUS_PENDING(1, "Pending"),
    PROPAY_STATUS_COMPLETED(2, "Completed"),
    // These two don't come from their API enums, but we use them after
    // parsing their 140+ type/status strings.
    PROPAY_STATUS_VOID_REFUND(3, "Void Refund"),
    PROPAY_STATUS_DECLINED(4, "Declined"),
    PROPAY_STATUS_P2P(5, "Completed");

    public final int value;
    public final String mDescription;

    TransactionStatus(int value, String description) {
        this.value = value;
        this.mDescription = description;
    }

    public String getDescription() {
        return mDescription;
    }

    public static TransactionStatus parse(int currentValue) {
        switch (currentValue) {
            default:
            case 0:
                return PROPAY_STATUS_UNKNOWN;
            case 1:
                return PROPAY_STATUS_PENDING;
            case 2:
                return PROPAY_STATUS_COMPLETED;
            case 3:
                return PROPAY_STATUS_VOID_REFUND;
            case 4:
                return PROPAY_STATUS_DECLINED;
            case 5:
                return PROPAY_STATUS_P2P;
        }
    }

}
