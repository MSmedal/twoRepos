package com.tsys.payments.host.propay.service.merchant.client;

import com.google.gson.Gson;
import com.tsys.payments.host.propay.service.merchant.client.contracts.VoidOrRefundRequest;
import com.tsys.payments.host.propay.service.merchant.client.contracts.emv.AuthorizeEmvRequest;
import com.tsys.payments.host.propay.utils.ProPayJsonHelper;

import timber.log.Timber;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

abstract class BaseRestClient {

    private static final String TAG = BaseRestClient.class.getSimpleName();
    private static final String TRANSPORT_TAG = "TRANSPORT";
    private static final String TRANSPORT_RESPONSE = "TRANSPORT RESPONSE:";

    private static final int CONNECTION_TIMEOUT = 20000;
    private String mBaseEndpointUrl;

    public String getBaseEndpointUrl() {
        return mBaseEndpointUrl;
    }

    /**
     * Set the base endpoint url for accessing a ProPay service.
     *
     * @param baseEndpointUrl The endpoint for the host of the service. For example, 'https://instance.propay.com/'
     */
    public void setBaseEndpointUrl(String baseEndpointUrl) {
        mBaseEndpointUrl = baseEndpointUrl;
    }

    <TRequest, TResponse> TResponse invokeRemoteMethod(String endpointUrl,
            TRequest request, Class<? extends Object> responseType)
            throws Exception {

        Gson gson;
        if (request instanceof AuthorizeEmvRequest
                || request instanceof VoidOrRefundRequest) {
            // Do not serialize null values.
            gson = ProPayJsonHelper.getGson(false);
        } else {
            gson = ProPayJsonHelper.getGson(true);
        }

        String jsonRequest = gson.toJson(request);

        URL url = new URL(endpointUrl);
        HttpsURLConnection secureConnection = (HttpsURLConnection)url.openConnection();
        secureConnection.setRequestMethod("POST");
        secureConnection.setDoOutput(true);
        secureConnection.setConnectTimeout(CONNECTION_TIMEOUT);
        secureConnection.addRequestProperty("Content-type", "application/json");
        secureConnection.addRequestProperty("Accept", "application/json");
        secureConnection.setFixedLengthStreamingMode(jsonRequest.length());

        Timber.d(secureConnection.getURL().toString());
        Timber.d(jsonRequest);
        Timber.d(secureConnection.getURL().toString() + "\n" + jsonRequest);

        writeRequest(secureConnection, jsonRequest);
        String response = null;
        try {
            response = convertInStreamToString(secureConnection.getInputStream());
        } catch (IOException e) {
            Timber.e(e.getMessage());
        }

        try {
            Timber.d("Response code: %s", secureConnection.getResponseCode());
            if (secureConnection.getResponseCode() != 200) {
                Timber.w("HTTP connection was not successful");
            }
        } finally {
            secureConnection.disconnect();
        }

        return deserializeResponse(response, responseType);
    }

    private void writeRequest(HttpsURLConnection urlConnection, String body) throws IOException {
        OutputStream outStream =
                new BufferedOutputStream(urlConnection.getOutputStream());
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outStream));
        writer.write(body);
        writer.close();
        outStream.close();
    }

    private String convertInStreamToString(InputStream inputStream) throws IOException {
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader reader = new BufferedReader(inputStreamReader);
        StringBuilder stringBuilder = new StringBuilder();

        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line).append("\n");
        }

        reader.close();
        inputStream.close();
        return stringBuilder.toString();
    }

    @SuppressWarnings("unchecked")
    private <TResponse> TResponse deserializeResponse(String response,
            Class<?> responseType) {
        TResponse deserializedResponse =
                (TResponse)ProPayJsonHelper.getGson(true).fromJson(response, responseType);
        Gson gson = ProPayJsonHelper.getGson(true);
        Timber.d(gson.toJson(deserializedResponse));

        return deserializedResponse;
    }
}
