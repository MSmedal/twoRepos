package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the result of the attempt to update a user's security PIN
 */
public class SetPinResponse extends BaseResponse {

    private String PinToken;
    private String SessionToken;
    private com.tsys.payments.host.propay.service.merchant.client.contracts.IdentityDetail IdentityDetail;
    private TipRule TipRule;

    public String getPinToken() {
        return PinToken;
    }

    public void setPinToken(String pinToken) {
        PinToken = pinToken;
    }

    public String getSessionToken() {
        return SessionToken;
    }

    public void setSessionToken(String sessionToken) {
        SessionToken = sessionToken;
    }

    public com.tsys.payments.host.propay.service.merchant.client.contracts.IdentityDetail getIdentityDetail() {
        return IdentityDetail;
    }

    public void setIdentityDetail(
            com.tsys.payments.host.propay.service.merchant.client.contracts.IdentityDetail identityDetail) {
        IdentityDetail = identityDetail;
    }

    public TipRule getTipRule() {
        return TipRule;
    }

    public void setTipRule(TipRule tipRule) {
        TipRule = tipRule;
    }
}
