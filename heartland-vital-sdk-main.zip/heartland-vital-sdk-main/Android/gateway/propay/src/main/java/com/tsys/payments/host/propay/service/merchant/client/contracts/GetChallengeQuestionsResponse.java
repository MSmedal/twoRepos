package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;
;
;

/**
 * A response object that contains the security challenge questions associated with a user
 */
public class GetChallengeQuestionsResponse extends BaseResponse {



    private ChallengeQuestion[] ChallengeQuestions;

    public ChallengeQuestion[] getChallengeQuestions() {
        return ChallengeQuestions;
    }

    public void setChallengeQuestions(ChallengeQuestion[] challengeQuestions) {
        ChallengeQuestions = challengeQuestions;
    }
}
