package com.tsys.payments.host.propay.service.merchant.client.contracts;

;
;

/**
 * Contains metadata about a ProPay-to-ProPay money transfer.
 */
public class ProPayToProPayAddData {


    private String Description;



    private int Priority = 1;



    private boolean Protected;

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public int getPriority() {
        return Priority;
    }

    public void setPriority(int priority) {
        Priority = priority;
    }

    public boolean isProtected() {
        return Protected;
    }

    public void setProtected(boolean aProtected) {
        Protected = aProtected;
    }
}
