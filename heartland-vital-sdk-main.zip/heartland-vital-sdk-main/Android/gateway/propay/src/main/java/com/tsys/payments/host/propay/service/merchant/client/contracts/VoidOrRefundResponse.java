package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the success or failure of an attempt to process a void or issue a refund for
 * transaction associated with a user's session
 */
public class VoidOrRefundResponse extends BaseResponse {
}
