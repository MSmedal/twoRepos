package com.tsys.payments.host.propay.service.commons.client.contracts;

import com.google.gson.annotations.SerializedName;
;

/**
 * Contains the result codes and result messages for a response
 */
public class Result {


    @SerializedName("ArgumentId")
    private int mArgumentId;

    @SerializedName("ResultCode")
    private int mResultCode;

    @SerializedName("ResultMessage")
    private String mResultMessage;

    /**
     * Possible values for a Result
     */
    public enum ResultType {
        Undefined,
        Success,
        CredentialLocked,
        AuthenticationFailure,
        TokenNotFound,
        AuthorizationFailure,
        BadAccountState,
        NoBankAccountOnFile
    }

    /**
     * Getter for the type of result for the response
     *
     * @return ResultType
     */
    public ResultType getResultType() {
        if (mResultCode == 0) {
            return ResultType.Success;
        } else if (mResultCode == 541) {
            return ResultType.NoBankAccountOnFile;
        } else if (mResultCode >= 500 && mResultCode <= 599) {
            return ResultType.BadAccountState;
        } else if (mResultCode == 330) {
            return ResultType.AuthorizationFailure;
        } else if (mResultCode == 300) {
            return ResultType.AuthenticationFailure;
        } else if (mResultCode == 333) {
            return ResultType.CredentialLocked;
        } else if (mResultCode == 331) {
            return ResultType.TokenNotFound;
        }
        return ResultType.Undefined;
    }

    public String toClientFacingMessage() {
        ResultType resultType = getResultType();
        switch (resultType) {
            case Success:
                return "Success";
            case AuthenticationFailure:
                return "Authentication Error";
            case AuthorizationFailure:
                return "Authorization Error";
            case Undefined:
            default:
                return this.mResultMessage;
        }
    }

    public int getArgumentId() {
        return mArgumentId;
    }

    public void setArgumentId(int argumentId) {
        mArgumentId = argumentId;
    }

    public int getResultCode() {
        return mResultCode;
    }

    public void setResultCode(int resultCode) {
        mResultCode = resultCode;
    }

    public String getResultMessage() {
        return mResultMessage;
    }

    public void setResultMessage(String resultMessage) {
        mResultMessage = resultMessage;
    }
}
