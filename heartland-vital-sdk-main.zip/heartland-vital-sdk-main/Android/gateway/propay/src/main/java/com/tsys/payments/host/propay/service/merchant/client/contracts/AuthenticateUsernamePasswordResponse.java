package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the client's authentication result
 */
public class AuthenticateUsernamePasswordResponse extends BaseResponse {

    private String ChangeKey;

    private String PinToken;

    /**
     * Getter for the ChangeKey value, which denotes the action one may have to take regarding their authentication
     * credentials
     *
     * @return ChangeKey
     */
    public String getChangeKey() {
        return ChangeKey;
    }

    public void setChangeKey(String changeKey) {
        ChangeKey = changeKey;
    }

    /**
     * Getter for the PinToken value, which denotes the action one may have to take regarding their authentication
     * credentials
     *
     * @return PinToken
     */
    public String getPinToken() {
        return PinToken;
    }

    public void setPinToken(String pinToken) {
        PinToken = pinToken;
    }
}
