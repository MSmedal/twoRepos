package com.tsys.payments.host.propay.enums;

/**
 * Indicates whether or not the terminal has a means for capturing card data.
 */
public enum ProPayTerminalCardCaptureCapability {
    NONE(48),
    TERMINAL_CAPTURES_CARD(49);

    public final int value;

    ProPayTerminalCardCaptureCapability(int value) {
        this.value = value;
    }
}
