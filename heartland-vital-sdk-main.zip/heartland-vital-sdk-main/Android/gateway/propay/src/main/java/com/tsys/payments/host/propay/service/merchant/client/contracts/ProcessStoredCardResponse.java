package com.tsys.payments.host.propay.service.merchant.client.contracts;

/**
 * A response object that contains the identifiers associated to a credit card that has been successfully processed and
 * stored
 */
public class ProcessStoredCardResponse extends BaseTransactionResponse {
}
