package com.tsys.payments.host.propay.service.merchant.client.contracts;

import com.tsys.payments.host.propay.service.commons.client.contracts.BaseResponse;

/**
 * A response object that contains the success or failure result for the attempt to save a user's security challenge
 * questions and answers
 */
public class SetChallengeQuestionsResponse extends BaseResponse {
}
