package com.tsys.payments.host.propay;

import com.tsys.payments.host.propay.utils.ProPayCardHelper;

import org.junit.Assert;
import org.junit.Test;

/**
 * Describe tests scenarios for card expiration formats for the Propay gateway.
 */
public class PropayCardHelperTest {
    private String desiredExpDate = "0222";

    @Test
    public void toPropayExpDateFormat_mmyy(){
        String givenExpDate = "0222";
        Assert.assertEquals(ProPayCardHelper.toPropayExpDateFormat(givenExpDate), desiredExpDate);
    }

    @Test
    public void toPropayExpDateFormat_mmSyy(){
        String givenExpDate = "02/22";
        Assert.assertEquals(ProPayCardHelper.toPropayExpDateFormat(givenExpDate), desiredExpDate);
    }

    @Test
    public void toPropayExpDateFormat_mmSyyyy(){
        String givenExpDate = "02/2022";
        Assert.assertEquals(ProPayCardHelper.toPropayExpDateFormat(givenExpDate), desiredExpDate);
    }

    @Test
    public void toPropayExpDateFormat_mmyyyy(){
        String givenExpDate = "022022";
        Assert.assertEquals(ProPayCardHelper.toPropayExpDateFormat(givenExpDate), desiredExpDate);
    }

    @Test
    public void toPropayExpDateFormat_formatNotExpected(){
        String givenExpDate = "Jun 20 2021";
        Assert.assertEquals(ProPayCardHelper.toPropayExpDateFormat(givenExpDate), givenExpDate);
    }
}
