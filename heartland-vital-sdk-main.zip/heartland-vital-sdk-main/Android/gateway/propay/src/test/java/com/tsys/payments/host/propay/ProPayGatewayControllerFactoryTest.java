package com.tsys.payments.host.propay;

import com.tsys.payments.library.enums.TerminalType;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class ProPayGatewayControllerFactoryTest {

    @Test
    public void test_propaySupportsG5x() {
        ProPayGatewayControllerFactory factory = new ProPayGatewayControllerFactory();
        TerminalType[] supportedTerminals = factory.getSupportedTerminals();
        Assert.assertNotNull(supportedTerminals);
        boolean supportsG5x = false;
        for (TerminalType terminal : supportedTerminals) {
            if (terminal == TerminalType.ROAM_G5X_TSYS_DECRYPTION) {
                supportsG5x = true;
                break;
            }
        }
        Assert.assertTrue(supportsG5x);
    }

    @Test
    public void test_propaySupportsMagtekADynamo() {
        ProPayGatewayControllerFactory factory = new ProPayGatewayControllerFactory();
        TerminalType[] supportedTerminals = factory.getSupportedTerminals();
        Assert.assertNotNull(supportedTerminals);
        boolean supportsMagtek = false;
        for (TerminalType terminal : supportedTerminals) {
            if (terminal == TerminalType.MAGTEK_ADYNAMO) {
                supportsMagtek = true;
                break;
            }
        }
        Assert.assertTrue(supportsMagtek);
    }

    @Test
    public void test_propaySupportsC2X() {
        ProPayGatewayControllerFactory factory = new ProPayGatewayControllerFactory();
        TerminalType[] supportedTerminals = factory.getSupportedTerminals();
        Assert.assertNotNull(supportedTerminals);
        boolean supportsC2X = false;
        for (TerminalType terminal : supportedTerminals) {
            if (terminal == TerminalType.BBPOS_C2X) {
                supportsC2X = true;
                break;
            }
        }
        Assert.assertTrue(supportsC2X);
    }
}
