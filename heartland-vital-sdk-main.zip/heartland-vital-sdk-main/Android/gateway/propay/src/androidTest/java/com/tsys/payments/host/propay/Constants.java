package com.tsys.payments.host.propay;

class Constants {
    static final String PROPAY_USERNAME = "7ebefd240d984fc9b402@propaytest.com";
    static final String PROPAY_PASSWORD = "Aa222222";
    static final String PROPAY_PIN = "1111";
}
