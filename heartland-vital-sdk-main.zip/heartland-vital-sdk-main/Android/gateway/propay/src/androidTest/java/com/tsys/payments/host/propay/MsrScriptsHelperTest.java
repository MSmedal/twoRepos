package com.tsys.payments.host.propay;

import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(BlockJUnit4ClassRunner.class)
public class MsrScriptsHelperTest {

    @Test
    public void test_getGatewayRequest_Amex_Keyed_() {
        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(0, 0L,
                MsrScriptsHelper.CardType.Amex, CardDataSourceType.KEYED,null, GatewayAction.SALE);

        GatewayRequest request = builder.build();

        CardData cardData = request.getCardData();
        assertNotNull(cardData);
        assertEquals(cardData.getCardDataSource(), CardDataSourceType.KEYED);
        assertEquals(cardData.getPan(), MsrScriptsConstants.SCRIPT_AMEX_PAN);
    }

    @Test
    public void test_getGatewayRequest_Amex_Swiped() {
        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(0, 0L,
                MsrScriptsHelper.CardType.Amex, CardDataSourceType.MSR,null, GatewayAction.SALE);

        GatewayRequest request = builder.build();

        CardData cardData = request.getCardData();
        assertNotNull(cardData);
        assertEquals(cardData.getCardDataSource(), CardDataSourceType.MSR);
        assertEquals(cardData.getKsn(), MsrScriptsConstants.SCRIPT_AMEX_C2X_KSN_HEX);
        assertEquals(cardData.getTrack1(), MsrScriptsConstants.SCRIPT_AMEX_C2X_TRACK_1_HEX);
        assertEquals(cardData.getTrack2(), MsrScriptsConstants.SCRIPT_AMEX_C2X_TRACK_2_HEX);
    }

    @Test
    public void test_getGatewayRequest_Discover_Keyed_() {
        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(0, 0L,
                MsrScriptsHelper.CardType.Discover, CardDataSourceType.KEYED,null, GatewayAction.SALE);

        GatewayRequest request = builder.build();

        CardData cardData = request.getCardData();
        assertNotNull(cardData);
        assertEquals(cardData.getCardDataSource(), CardDataSourceType.KEYED);
        assertEquals(cardData.getPan(), MsrScriptsConstants.SCRIPT_DISCOVER_PAN);
        assertEquals(cardData.getExpirationDate(),
                String.valueOf(MsrScriptsConstants.SCRIPT_DISCOVER_EXP_MONTH) +
                        MsrScriptsConstants.SCRIPT_DISCOVER_EXP_YEAR);
    }

    @Test
    public void test_getGatewayRequest_Discover_Swiped() {
        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(0, 0L,
                MsrScriptsHelper.CardType.Discover, CardDataSourceType.MSR,null, GatewayAction.SALE);

        GatewayRequest request = builder.build();

        CardData cardData = request.getCardData();
        assertNotNull(cardData);
        assertEquals(cardData.getCardDataSource(), CardDataSourceType.MSR);
        assertEquals(cardData.getKsn(), MsrScriptsConstants.SCRIPT_DISCOVER_C2X_KSN_HEX);
        assertEquals(cardData.getTrack1(), MsrScriptsConstants.SCRIPT_DISCOVER_C2X_TRACK_1_HEX);
        assertEquals(cardData.getTrack2(), MsrScriptsConstants.SCRIPT_DISCOVER_C2X_TRACK_2_HEX);
    }

    @Test
    public void test_getGatewayRequest_Jcb_Keyed_() {
        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(0, 0L,
                MsrScriptsHelper.CardType.Jcb, CardDataSourceType.KEYED, null, GatewayAction.SALE);

        GatewayRequest request = builder.build();

        CardData cardData = request.getCardData();
        assertNotNull(cardData);
        assertEquals(cardData.getCardDataSource(), CardDataSourceType.KEYED);
        assertEquals(cardData.getPan(), MsrScriptsConstants.SCRIPT_JCB_PAN);
        assertEquals(cardData.getExpirationDate(),
                String.valueOf(MsrScriptsConstants.SCRIPT_JCB_EXP_MONTH) +
                        MsrScriptsConstants.SCRIPT_JCB_EXP_YEAR);
    }

    @Test
    public void test_getGatewayRequest_Jcb_Swiped() {
        GatewayRequest.Builder builder = MsrScriptsHelper.getGatewayRequest(0, 0L,
                MsrScriptsHelper.CardType.Jcb, CardDataSourceType.MSR, null,GatewayAction.SALE);

        GatewayRequest request = builder.build();

        CardData cardData = request.getCardData();
        assertNotNull(cardData);
        assertEquals(cardData.getCardDataSource(), CardDataSourceType.MSR);
        assertEquals(cardData.getKsn(), MsrScriptsConstants.SCRIPT_JCB_C2X_KSN_HEX);
        assertEquals(cardData.getTrack1(), MsrScriptsConstants.SCRIPT_JCB_C2X_TRACK_1_HEX);
        assertEquals(cardData.getTrack2(), MsrScriptsConstants.SCRIPT_JCB_C2X_TRACK_2_HEX);
    }
}
