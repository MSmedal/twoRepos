package com.tsys.payments.host.propay;

import com.tsys.payments.library.domain.Address;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

class MsrScriptsHelper {

    enum CardType {
        Visa,
        Discover,
        Amex,
        Jcb
    }

    static GatewayRequest.Builder getGatewayRequest(long total,
            @Nullable Long tipAmount,
            @Nullable String hostTransactionId,
            @NonNull GatewayAction gatewayAction) {
        return getGatewayRequest(total, tipAmount, null, null, null, null, hostTransactionId,
                gatewayAction);
    }

    static GatewayRequest.Builder getGatewayRequest(long total,
            @Nullable Long tipAmount,
            @NonNull GatewayAction gatewayAction) {
        return getGatewayRequest(total, tipAmount, null, null, null, null, null,
                gatewayAction);
    }

    static GatewayRequest.Builder getGatewayRequest(long total,
            @Nullable Long tipAmount,
            @Nullable CardType cardType,
            @Nullable CardDataSourceType cardDataSourceType,
            @Nullable String cvvCode,
            @NonNull GatewayAction gatewayAction) {
        return getGatewayRequest(total, tipAmount, cardType, cardDataSourceType, null, null,
                gatewayAction);
    }

    static GatewayRequest.Builder getGatewayRequest(long total,
            @Nullable Long tipAmount,
            @Nullable CardType cardType,
            @Nullable CardDataSourceType cardDataSourceType,
            @Nullable String cvvCode,
            @Nullable Address address,
            @NonNull GatewayAction gatewayAction) {
        return getGatewayRequest(total, tipAmount, cardType, cardDataSourceType, cvvCode,
                address,
                null,
                gatewayAction);
    }

    static GatewayRequest.Builder getGatewayRequest(long total,
            @Nullable Long tipAmount,
            @Nullable CardType cardType,
            @Nullable CardDataSourceType cardDataSourceType,
            @Nullable String cvvCode,
            @Nullable Address address,
            @Nullable String hostTransactionId,
            @NonNull GatewayAction gatewayAction) {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(gatewayAction);
        builder.setTotal(total)
                .setTip(tipAmount)
                .setAddress(address)
                .setHostTransactionId(hostTransactionId)
                .setCardData(getCardData(cardType, cardDataSourceType, cvvCode));
        return builder;
    }

    @Nullable
    private static CardData getCardData(@Nullable CardType cardType,
            @Nullable CardDataSourceType cardDataSourceType, @Nullable String cvvCode) {
        if (cardType == null
                || cardDataSourceType == null) {
            return null;
        }

        CardData cardData = new CardData();
        cardData.setCardholderName("John Doe");
        cardData.setCardDataSource(cardDataSourceType);
        populateCardData(cardData, cardType, cvvCode);

        return cardData;
    }

    private static CardData populateCardData(@NonNull CardData cardData,
            @Nullable CardType cardType, @Nullable String cvvCode) {
        if (cardType != null) {
            switch (cardType) {
                case Visa:
                    cardData.setPan(MsrScriptsConstants.SCRIPT_VISA_PAN);
                    cardData.setExpirationDate(
                            String.valueOf(MsrScriptsConstants.SCRIPT_VISA_EXP_MONTH) +
                                    MsrScriptsConstants.SCRIPT_VISA_EXP_YEAR);
                    cardData.setKsn(MsrScriptsConstants.SCRIPT_VISA_C2X_KSN_HEX);
                    cardData.setTrack1(MsrScriptsConstants.SCRIPT_VISA_C2X_TRACK_1_HEX);
                    cardData.setTrack2(MsrScriptsConstants.SCRIPT_VISA_C2X_TRACK_2_HEX);
                    cardData.setCvv2(cvvCode);
                    break;
                case Discover:
                    cardData.setPan(MsrScriptsConstants.SCRIPT_DISCOVER_PAN);
                    cardData.setExpirationDate(
                            String.valueOf(MsrScriptsConstants.SCRIPT_DISCOVER_EXP_MONTH) +
                                    MsrScriptsConstants.SCRIPT_DISCOVER_EXP_YEAR);
                    cardData.setKsn(MsrScriptsConstants.SCRIPT_DISCOVER_C2X_KSN_HEX);
                    cardData.setTrack1(MsrScriptsConstants.SCRIPT_DISCOVER_C2X_TRACK_1_HEX);
                    cardData.setTrack2(MsrScriptsConstants.SCRIPT_DISCOVER_C2X_TRACK_2_HEX);
                    cardData.setCvv2(cvvCode);
                    break;
                case Amex:
                    cardData.setPan(MsrScriptsConstants.SCRIPT_AMEX_PAN);
                    cardData.setKsn(MsrScriptsConstants.SCRIPT_AMEX_C2X_KSN_HEX);
                    cardData.setTrack1(MsrScriptsConstants.SCRIPT_AMEX_C2X_TRACK_1_HEX);
                    cardData.setTrack2(MsrScriptsConstants.SCRIPT_AMEX_C2X_TRACK_2_HEX);
                    cardData.setCvv2(cvvCode);
                    break;
                case Jcb:
                    cardData.setPan(MsrScriptsConstants.SCRIPT_JCB_PAN);
                    cardData.setExpirationDate(
                            String.valueOf(MsrScriptsConstants.SCRIPT_JCB_EXP_MONTH) +
                                    MsrScriptsConstants.SCRIPT_JCB_EXP_YEAR);
                    cardData.setKsn(MsrScriptsConstants.SCRIPT_JCB_C2X_KSN_HEX);
                    cardData.setTrack1(MsrScriptsConstants.SCRIPT_JCB_C2X_TRACK_1_HEX);
                    cardData.setTrack2(MsrScriptsConstants.SCRIPT_JCB_C2X_TRACK_2_HEX);
                    cardData.setCvv2(cvvCode);
                    break;
            }
        }

        return cardData;
    }
}
