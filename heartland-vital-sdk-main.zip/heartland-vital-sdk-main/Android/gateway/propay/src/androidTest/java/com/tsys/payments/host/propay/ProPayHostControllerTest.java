package com.tsys.payments.host.propay;

import android.text.TextUtils;
import android.util.Log;

import com.tsys.payments.library.domain.Address;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.GatewayConfiguration;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.GatewayController;
import com.tsys.payments.library.gateway.GatewayListener;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import com.tsys.payments.library.utils.LibraryConfigHelper;

import org.jetbrains.annotations.NotNull;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import androidx.test.runner.AndroidJUnit4;
import timber.log.Timber;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.concurrent.CountDownLatch;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class ProPayHostControllerTest {
    private static final String TAG = ProPayHostControllerTest.class.getName();
    private static final String TEST_USERNAME = "test@imobile3.com";
    private static final String TEST_PASSWORD = "Aa111111";
    private static final String TEST_PIN = "1111";
    private static final String TEST_POSTAL_CODE = "30308";
    private static final long TEST_SUBTOTAL = 500;
    private static final long TEST_TAX = 300;
    private static final String TEST_ENDPOINT = "https://imobile3.propay.com/";

    private static final String VISA_KSN = "9010240B4811A5000085";
    private static final String VISA_ENCRYPTED_DATA =
            "CA754F62CC199A7FD1045BCA1BACB18449158A1C8202E7DD8B0A820FB2250683B05CDB2FAEF81D5B";

    private static final String VISA_PAN = "4012002000060016";
    private static final String VISA_EXPIRATION_DATE = "1220";
    private static final String VISA_CVV = "999";
    private static final String VISA_CARDHOLDER_NAME = "Visa";
    private static final String TEST_CARD_HOLDER_NAME = "Johnathan Doe";

    private GatewayController mHostController;

    private ResponseHandler mHostListener = new ResponseHandler();

    @Before
    public void setUp() throws InitializationException {
        LibraryConfigHelper.setDebugMode(true);
        // log server requests/responses
        LibraryConfigHelper.addLogTree(
                new Timber.Tree() {
                    @Override
                    protected void log(int priority, @org.jetbrains.annotations.Nullable String tag,
                            @NotNull String message, @org.jetbrains.annotations.Nullable Throwable t) {
                        Log.d(TAG, message);
                    }
                }
        );

        GatewayConfiguration gatewayConfiguration = new GatewayConfiguration();
        gatewayConfiguration.setCredentials(new HashMap<String, String>());
        gatewayConfiguration.getCredentials().put(ProPayCredentialKeys.PIN, TEST_PIN);
        gatewayConfiguration.getCredentials().put(ProPayCredentialKeys.PASSWORD, TEST_PASSWORD);
        gatewayConfiguration.getCredentials().put(ProPayCredentialKeys.USERNAME, TEST_USERNAME);
        mHostController =
                new ProPayGatewayControllerFactory().create(gatewayConfiguration, mHostListener);
    }

    @Test
    public void testMsrAuthorization() {
        final CountDownLatch latch = new CountDownLatch(1);
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setKsn(VISA_KSN);
        cardData.setEncryptedData(VISA_ENCRYPTED_DATA);
        cardData.setCardDataSource(CardDataSourceType.MSR);
        cardData.setTrack2(VISA_ENCRYPTED_DATA);
        builder.setTerminalInfo(new TerminalInfo() {{
            {
                setTerminalType(TerminalType.MAGTEK_ADYNAMO);
            }
        }});
        builder.setCardData(cardData);
        builder.setTenderType(TenderType.CREDIT);
        builder.setSubtotal(TEST_SUBTOTAL);
        builder.setTax(TEST_TAX);
        builder.setTotal(TEST_SUBTOTAL + TEST_TAX);

        Address address = new Address();
        address.setPostalCode(TEST_POSTAL_CODE);
        builder.setAddress(address);

        mHostListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                if (response.getGatewayAction() == GatewayAction.AUTH) {
                    assertTrue(response.isApproved());
                }
                latch.countDown();
            }
        });
        mHostController.sendRequest(builder.build());

        try {
            latch.await();
        } catch (InterruptedException e) {
            Timber.e(e);
        }
    }

    @Test
    public void testManualAuthorization() {
        final CountDownLatch latch = new CountDownLatch(1);
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setPan(VISA_PAN);
        cardData.setExpirationDate(VISA_EXPIRATION_DATE);
        cardData.setCvv2(VISA_CVV);
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        builder.setTerminalInfo(new TerminalInfo() {{
            {
                setTerminalType(TerminalType.MAGTEK_ADYNAMO);
            }
        }});
        builder.setCardData(cardData);
        builder.setTenderType(TenderType.CREDIT);
        builder.setSubtotal(TEST_SUBTOTAL);
        builder.setTax(TEST_TAX);
        builder.setTotal(TEST_SUBTOTAL + TEST_TAX);

        Address address = new Address();
        address.setPostalCode(TEST_POSTAL_CODE);
        builder.setAddress(address);

        mHostListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                if (response.getGatewayAction() == GatewayAction.AUTH) {
                    assertTrue(response.isApproved());
                }
                latch.countDown();
            }
        });
        mHostController.sendRequest(builder.build());

        try {
            latch.await();
        } catch (InterruptedException e) {
            Timber.e(e);
        }
    }

    @Test
    public void testPayWithTokenizedCard() {
        final CountDownLatch latch = new CountDownLatch(1);
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.CAPTURE);
        builder.setToken("9ad2490a-5bb8-40dd-8cc6-fbac83c9beaf");
        builder.setCardHolderId("5349520196517350");
        builder.setSubtotal(TEST_SUBTOTAL);
        builder.setTax(TEST_TAX);
        builder.setTotal(TEST_SUBTOTAL + TEST_TAX);

        Address address = new Address();
        address.setPostalCode(TEST_POSTAL_CODE);
        builder.setAddress(address);

        mHostListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                if (response.getGatewayAction() == GatewayAction.CAPTURE) {
                    assertTrue(response.isApproved());
                }
                latch.countDown();
            }
        });
        mHostController.sendRequest(builder.build());

        try {
            latch.await();
        } catch (InterruptedException e) {
            Timber.e(e);
        }
    }

    @Test
    public void testReversal() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.AUTH);
        CardData cardData = new CardData();
        cardData.setKsn(VISA_KSN);
        cardData.setEncryptedData(VISA_ENCRYPTED_DATA);
        cardData.setCardDataSource(CardDataSourceType.MSR);
        cardData.setTrack2(VISA_ENCRYPTED_DATA);
        builder.setTerminalInfo(new TerminalInfo() {{
            {
                setTerminalType(TerminalType.MAGTEK_ADYNAMO);
            }
        }});
        builder.setCardData(cardData);
        builder.setTenderType(TenderType.CREDIT);
        builder.setSubtotal(TEST_SUBTOTAL);
        builder.setTax(TEST_TAX);
        builder.setTotal(TEST_SUBTOTAL + TEST_TAX);

        Address address = new Address();
        address.setPostalCode(TEST_POSTAL_CODE);
        builder.setAddress(address);

        mHostListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                if (response.getGatewayAction() == GatewayAction.AUTH) {
                    assertTrue(response.isApproved());

                    GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.VOID);
                    builder.setHostTransactionId(response.getGatewayTransactionId());
                    builder.setTotal(TEST_SUBTOTAL + TEST_TAX);
                    mHostController.sendRequest(builder.build());
                } else if (response.getGatewayAction() == GatewayAction.VOID) {
                    assertTrue(response.isApproved());

                    latch.countDown();
                }
            }
        });
        mHostController.sendRequest(builder.build());

        try {
            latch.await();
        } catch (InterruptedException e) {
            Timber.e(e);
        }
    }

    @Test
    public void test_verifyGatewayActionUnsupported() throws InterruptedException {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.VERIFY);
        CardData cardData = new CardData();
        cardData.setCardholderName(TEST_CARD_HOLDER_NAME);
        cardData.setPan(VISA_PAN);
        cardData.setExpirationDate(VISA_EXPIRATION_DATE);
        cardData.setCvv2(VISA_CVV);
        cardData.setCardDataSource(CardDataSourceType.KEYED);
        builder.setTerminalInfo(new TerminalInfo() {{
            {
                setTerminalType(TerminalType.MAGTEK_ADYNAMO);
            }
        }});
        builder.setCardData(cardData);
        builder.setTenderType(TenderType.CREDIT);

        mHostListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                assertTrue(response.getErrorMessage()
                        .equalsIgnoreCase("Action Not Supported."));
                latch.countDown();
            }
        });
        mHostController.sendRequest(builder.build());
        latch.await();
    }

    @Test
    public void testTokenizeSwipedCard() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.TOKENIZE_CARD);
        CardData cardData = new CardData();
        cardData.setKsn(VISA_KSN);
        cardData.setEncryptedData(VISA_ENCRYPTED_DATA);
        cardData.setCardDataSource(CardDataSourceType.MSR);
        cardData.setTrack1(VISA_ENCRYPTED_DATA);
        builder.setTerminalInfo(new TerminalInfo() {{
            {
                setTerminalType(TerminalType.MAGTEK_ADYNAMO);
            }
        }});
        builder.setCardData(cardData);
        builder.setTenderType(TenderType.CREDIT);

        Address address = new Address();
        address.setPostalCode(TEST_POSTAL_CODE);
        builder.setAddress(address);

        mHostListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                if (response.getGatewayAction() == GatewayAction.TOKENIZE_CARD) {
                    assertTrue(response.isApproved());
                    assertNotNull(response.getToken());
                }
                latch.countDown();
            }
        });
        mHostController.sendRequest(builder.build());

        try {
            latch.await();
        } catch (InterruptedException e) {
            Timber.e(e);
        }
    }

    @Test
    public void testAuthWithTokenizedSwipedCard() {
        final CountDownLatch latch = new CountDownLatch(1);

        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.TOKENIZE_CARD);
        CardData cardData = new CardData();
        cardData.setKsn(VISA_KSN);
        cardData.setEncryptedData(VISA_ENCRYPTED_DATA);
        cardData.setCardDataSource(CardDataSourceType.MSR);
        cardData.setTrack1(VISA_ENCRYPTED_DATA);
        builder.setTerminalInfo(new TerminalInfo() {{
            {
                setTerminalType(TerminalType.MAGTEK_ADYNAMO);
            }
        }});
        builder.setCardData(cardData);
        builder.setTenderType(TenderType.CREDIT);

        Address address = new Address();
        address.setPostalCode(TEST_POSTAL_CODE);
        builder.setAddress(address);

        mHostListener.setResponseProcessor(new ResponseProcessor() {
            @Override
            public void processResponse(GatewayResponse response) {
                if (response.getGatewayAction() == GatewayAction.TOKENIZE_CARD) {
                    assertTrue(response.isApproved());
                    assertNotNull(response.getToken());

                    final GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.AUTH);
                    builder.setToken(response.getToken());
                    builder.setCardHolderId(response.getCardHolderId());
                    builder.setSubtotal(TEST_SUBTOTAL);
                    builder.setTax(TEST_TAX);
                    builder.setTotal(TEST_SUBTOTAL + TEST_TAX);
                    mHostController.sendRequest(builder.build());
                } else if (response.getGatewayAction() == GatewayAction.CAPTURE) {
                    assertTrue(response.isApproved());
                    latch.countDown();
                }
            }
        });
        mHostController.sendRequest(builder.build());

        try {
            latch.await();
        } catch (InterruptedException e) {
            Timber.e(e);
        }
    }

    private class ResponseHandler implements GatewayListener {

        private ResponseProcessor mResponseProcessor;

        public ResponseProcessor getResponseProcessor() {

            return mResponseProcessor;
        }

        public void setResponseProcessor(ResponseProcessor responseProcessor) {
            mResponseProcessor = responseProcessor;
        }

        @Override
        public void onGatewayResponse(GatewayResponse gatewayResponse) {
            assertNotNull(gatewayResponse);
            if (gatewayResponse.getGatewayAction() != GatewayAction.VERIFY) {
                // For an un-supported action error will always be non-null
                assertFalse(gatewayResponse.isError());
            }
            switch (gatewayResponse.getGatewayAction()) {
                case AUTHENTICATE:
                    assertFalse(gatewayResponse.isError());
                    assertTrue(TextUtils.isEmpty(gatewayResponse.getErrorMessage()));
                    break;
                case AUTH:
                case CAPTURE:
                case VOID:
                    assertTrue(gatewayResponse.isApproved());
                    break;
                case VERIFY:
                    assertFalse(gatewayResponse.isApproved());
                    break;
            }
            mResponseProcessor.processResponse(gatewayResponse);
        }
    }

    private interface ResponseProcessor {
        void processResponse(GatewayResponse response);
    }
}
