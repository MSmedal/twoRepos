package com.tsys.payments.database.portico;

import com.tsys.payments.library.db.entity.SafTokenizedCard;
import com.tsys.payments.library.db.entity.SafTransaction;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(version = 2,
        entities = {
                SafTransaction.class,
                SafTokenizedCard.class,
        })
public abstract class SafDatabase extends RoomDatabase {
    public static final String TAG = SafDatabase.class.getName();

    @NonNull
    public abstract SafTransactionDao getSafTransactionDao();

    @NonNull
    public abstract SafTokenizedCardDao getSafTokenizedCardDao();
}
