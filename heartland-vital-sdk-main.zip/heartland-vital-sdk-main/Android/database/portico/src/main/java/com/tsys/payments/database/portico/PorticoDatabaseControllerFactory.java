package com.tsys.payments.database.portico;

import com.tsys.payments.library.db.DatabaseConfig;
import com.tsys.payments.library.db.DatabaseController;
import com.tsys.payments.library.db.DatabaseControllerFactory;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.enums.GatewayType;

import androidx.annotation.Nullable;

public class PorticoDatabaseControllerFactory implements DatabaseControllerFactory {
    @Nullable
    @Override
    public DatabaseController create(DatabaseConfig databaseConfig) throws InitializationException {
        PorticoDatabaseController porticoDatabaseController = new PorticoDatabaseController();
        porticoDatabaseController.init(databaseConfig);
        return porticoDatabaseController;
    }

    @Override
    public GatewayType[] getSupportedGateways() {
        return new GatewayType[] {GatewayType.PORTICO};
    }
}
