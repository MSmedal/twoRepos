package com.tsys.payments.database.portico;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/**
 * Purges all the expired data in the {@link PorticoDatabaseController}'s internal database
 */
public class PurgeExpiredDataWorker extends Worker {
    public PurgeExpiredDataWorker(@NonNull Context context,
            @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        PorticoDatabaseController.getInstance().purgeExpiredData();
        return Result.success();
    }
}
