package com.tsys.payments.database.portico;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.tsys.payments.library.db.entity.SafTransaction;
import com.tsys.payments.library.domain.Address;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.UUID;

class PorticoDatabaseModelConverter {

    public static final int STATUS_NONE = -1;
    public static final int STATUS_DECLINED = 1;
    public static final int STATUS_PENDING = 2;
    public static final int STATUS_COMPLETE = 3;

    public static final int TYPE_NONE = -1;
    public static final int TYPE_SWIPE = 1;
    public static final int TYPE_CASH = 2;
    public static final int TYPE_KEY = 3;
    public static final int TYPE_STORED = 4;
    public static final int TYPE_TRANSFER = 5;
    public static final int TYPE_EMV = 6;
    public static final int TYPE_TOKENIZE = 7;
    public static final int TYPE_REFUND = 8;
    public static final int TYPE_VOID = 9;
    public static final int TYPE_ADJUST = 10;
    public static final int TYPE_AUTH = 11;

    public static final int TRANSACTION_STATE_NONE = -1;
    public static final int TRANSACTION_STATE_AUTH = 1;
    public static final int TRANSACTION_STATE_CAPTURE = 3;
    public static final int TRANSACTION_STATE_COMPLETED = 4;
    public static final int TRANSACTION_STATE_CANCEL = 5;

    @NonNull
    public static SafTransaction convertGatewayRequestToSafTransaction(
            @NonNull GatewayRequest gatewayRequest) {
        SafTransaction safTransaction = new SafTransaction();
        safTransaction.setSAFUniqueId("P" + UUID.randomUUID().toString());
        safTransaction.setSAFOrigDT(getDateTimeString());
        safTransaction.setTip(gatewayRequest.getTip() == null ? BigDecimal.valueOf(0L) :
                BigDecimal.valueOf(gatewayRequest.getTip()));
        safTransaction.setTax(gatewayRequest.getTax() == null ? BigDecimal.valueOf(0L) :
                BigDecimal.valueOf(gatewayRequest.getTax()));
        safTransaction.setAmount(BigDecimal.valueOf(gatewayRequest.getTotal()));
        safTransaction.setInvoiceNumber(gatewayRequest.getInvoiceNumber());
        safTransaction.setTransactionTime(new Date(System.currentTimeMillis()));
        safTransaction.setTransactionType(
                convertSdkTransactionTypeToSafType(gatewayRequest.getGatewayAction()));
        safTransaction.setStatus(STATUS_PENDING);
        safTransaction.setTransactionId(gatewayRequest.getGatewayTransactionId());
        safTransaction.setAllowDuplicates(gatewayRequest.isAllowDuplicates());
        if (gatewayRequest.getCardholderAddress() != null) {
            safTransaction.setZipCode(gatewayRequest.getCardholderAddress().getPostalCode());
        }
        if (gatewayRequest.getCardData() != null) {
            safTransaction.setExpDate(gatewayRequest.getCardData().getExpirationDate());
            safTransaction.setCardHolderName(gatewayRequest.getCardData().getCardholderName());
            safTransaction.setCardNumber(gatewayRequest.getCardData().getPan());
            safTransaction.setCardType(getCreditCardType(gatewayRequest.getCardData().getPan()));
            safTransaction.setCvvCode(gatewayRequest.getCardData().getCvv2());

            safTransaction.setTrack1(gatewayRequest.getCardData().getTrack1());
            safTransaction.setTrack2(gatewayRequest.getCardData().getTrack2());
            safTransaction.setTrack3(gatewayRequest.getCardData().getTrack3());
            safTransaction.setKsn(gatewayRequest.getCardData().getKsn());
            safTransaction.setTerminalType(gatewayRequest.getTerminalInfo().getTerminalType().ordinal());

            //emv data, if applicable
            if (gatewayRequest.getCardData().getEmvTlvData() != null) {
                //store the tag data
                safTransaction.setEmvTlvDataList(gatewayRequest.getCardData().getEmvTlvData());

                if (gatewayRequest.getCardData().getCardDataSource() == CardDataSourceType.CONTACTLESS_MSR
                        || gatewayRequest.getCardData().getCardDataSource() == CardDataSourceType.CONTACTLESS_EMV) {
                    safTransaction.setEntryMethod(CardDataSourceType.CONTACTLESS_EMV.ordinal());
                } else {
                    safTransaction.setEntryMethod(CardDataSourceType.SCR.ordinal());
                }
            } else {
                safTransaction.setEntryMethod(CardDataSourceType.MSR.ordinal());
            }
        } else {
            safTransaction.setToken(gatewayRequest.getToken());
            safTransaction.setCardBrandTxnId(gatewayRequest.getCardBrandTxnId());
            safTransaction.setCardholderId(gatewayRequest.getCardHolderId());
        }

        safTransaction.setStoreCard(gatewayRequest.isGenerateToken());
        safTransaction.setCardHolderSignatureFileName(gatewayRequest.getSignatureFileLocation());

        return safTransaction;
    }

    @NonNull
    public static GatewayRequest convertSafTransactionToGatewayRequest(
            @NonNull SafTransaction safTransaction) {
        TerminalInfo terminalInfo = new TerminalInfo();
        terminalInfo.setTerminalType(TerminalType.values()[safTransaction.getTerminalType()]);
        GatewayRequest.Builder gatewayRequest = new GatewayRequest
                .Builder(convertSafTypeToSdkTransactionType(safTransaction.getTransactionType()))
                .setTenderType(TenderType.CREDIT)
                .setTotal(safTransaction.getAmount() == null ? 0L :
                        safTransaction.getAmount().longValue())
                .setTip(safTransaction.getTip() == null ? 0L : safTransaction.getTip().longValue())
                .setInvoiceNumber(safTransaction.getInvoiceNumber())
                .setTax(safTransaction.getTax() == null ? 0L : safTransaction.getTax().longValue())
                .setGenerateToken(safTransaction.isStoreCard())
                .setAddress(buildAddress(safTransaction))
                .setAllowDuplicates(safTransaction.isAllowDuplicates())
                .setTerminalInfo(terminalInfo);

        gatewayRequest.setHostTransactionId(safTransaction.getTransactionId());

        if (safTransaction.getToken() != null) {
            gatewayRequest.setToken(safTransaction.getToken());
            gatewayRequest.setCardBrandTxnId(safTransaction.getCardBrandTxnId());
            if (safTransaction.getCardholderId() != null) {
                gatewayRequest.setCardHolderId(safTransaction.getCardholderId());
            }
        } else {
            CardData cardData = buildCardDataFromSafTransaction(safTransaction);
            gatewayRequest.setCardData(cardData);
        }
        if (!TextUtils.isEmpty(safTransaction.getCardHolderSignatureFileName())) {
            gatewayRequest
                    .setSignatureFilelocation(safTransaction.getCardHolderSignatureFileName());
        }

        gatewayRequest.setSAFOrigDT(safTransaction.getSAFOrigDT());
        gatewayRequest.setSAFIndicator(true);

        return gatewayRequest.build();
    }

    private static int convertSdkTransactionTypeToSafType(@Nullable GatewayAction action) {
        if (action == null) {
            return TYPE_NONE;
        }
        switch (action) {
            case SALE:
                return TYPE_SWIPE;
            case AUTH:
                return TYPE_AUTH;
            case CAPTURE:
                return TYPE_STORED;
            case TOKENIZE_CARD:
                return TYPE_TOKENIZE;
            case REFUND:
                return TYPE_REFUND;
            case VOID:
                return TYPE_VOID;
            case TIP_ADJUST:
                return TYPE_ADJUST;
            default:
                return TYPE_NONE;
        }
    }

    @Nullable
    private static GatewayAction convertSafTypeToSdkTransactionType(int safType) {
        switch (safType) {
            case TYPE_SWIPE:
                return GatewayAction.SALE;
            case TYPE_AUTH:
                return GatewayAction.AUTH;
            case TYPE_STORED:
                return GatewayAction.CAPTURE;
            case TYPE_TOKENIZE:
                return GatewayAction.TOKENIZE_CARD;
            case TYPE_REFUND:
                return GatewayAction.REFUND;
            case TYPE_VOID:
                return GatewayAction.VOID;
            case TYPE_ADJUST:
                return GatewayAction.TIP_ADJUST;
            default:
                return null;
        }
    }

    private static CardData buildCardDataFromSafTransaction(
            @NonNull SafTransaction safTransaction) {
        CardData cardData = new CardData();
        cardData.setExpirationDate(safTransaction.getExpDate());
        cardData.setCardholderName(safTransaction.getCardHolderName());
        cardData.setPan(safTransaction.getCardNumber());
        cardData.setCvv2(safTransaction.getCvvCode());
        cardData.setTrack1(safTransaction.getTrack1());
        cardData.setTrack2(safTransaction.getTrack2());
        cardData.setTrack3(safTransaction.getTrack3());
        cardData.setKsn(safTransaction.getKsn());
        cardData.setEmvTlvData(safTransaction.getEmvTlvDataList());
        cardData.setCardDataSource(CardDataSourceType.values()[safTransaction.getEntryMethod()]);
        return cardData;
    }

    @NonNull
    private static Address buildAddress(@NonNull SafTransaction safTransaction) {
        Address address = new Address();
        address.setPostalCode(safTransaction.getZipCode());
        return address;
    }

    /**
     * Info on how the iin works is found here:
     * http://en.wikipedia.org/wiki/Credit_card_numbers Some info on the regex
     * involved: http://www.regular-expressions.info/creditcard.html Determines
     * what type of card the given cardnumber belongs to.
     *
     * @param iin The unmasked card number. If the card number is masked, it may
     * not be possible to identify the given card, which will result
     * in a {@link CardType#UNKNOWN}
     * @return An CardTypes enum value for the type of credit card
     */
    public static int getCreditCardType(String iin) {
        // remove spaces
        int result = CardType.UNKNOWN.ordinal();
        if (!TextUtils.isEmpty(iin)) {
            iin = iin.replace(" ", "");
            if (TextUtils.isEmpty(iin) || iin.charAt(0) == '*') {
                return result;
            }

            // grab the integers at the given length
            // done this way because the regex for the >= and <= would have been
            // much less legible
            int iinLength = iin.length();
            int firstOne;
            try {
                firstOne = (iinLength >= 1) ? Integer.parseInt(iin.substring(0, 1)) : 0;
            } catch (NumberFormatException e) {
                firstOne = 0;
            }
            int firstTwo;
            try {
                firstTwo = (iinLength >= 2) ? Integer.parseInt(iin.substring(0, 2)) : 0;
            } catch (NumberFormatException e) {
                firstTwo = 0;
            }
            int firstThree;
            try {
                firstThree = (iinLength >= 3) ? Integer.parseInt(iin.substring(0, 3)) : 0;
            } catch (NumberFormatException e) {
                firstThree = 0;
            }
            int firstFour;
            try {
                firstFour = (iinLength >= 4) ? Integer.parseInt(iin.substring(0, 4)) : 0;
            } catch (NumberFormatException e) {
                firstFour = 0;
            }

            // after 4 digits, it's possible that we're getting a masked card
            // number. We should still try to identify it as the first four may give
            // us a match.
            int firstFive;
            try {
                firstFive = (iinLength >= 5) ? Integer.parseInt(iin.substring(0, 5)) : 0;
            } catch (NumberFormatException e) {
                firstFive = 0;
            }
            int firstSix;
            try {
                firstSix = (iinLength >= 6) ? Integer.parseInt(iin.substring(0, 6)) : 0;
            } catch (NumberFormatException e) {
                firstSix = 0;
            }

            if (isVisa(firstOne)) {
                result = CardType.VISA.ordinal();
            } else if (isAmex(firstTwo)) {
                result = CardType.AMERICAN_EXPRESS.ordinal();
            } else if (isMasterCard(firstTwo, firstFour)) {
                result = CardType.MASTERCARD.ordinal();
            } else if (isDiscover(firstThree, firstFive, firstSix)) {
                result = CardType.DISCOVER.ordinal();
            } else if (isJcb(firstFour)) {
                result = CardType.JCB.ordinal();
            }
        }

        return result;
    }

    private static boolean isUnionPay(int firstFour, int firstSix) {
        return (firstSix >= 622126 && firstSix <= 622925)
                || (firstFour >= 6240 && firstFour <= 6269)
                || (firstFour >= 6282 && firstFour <= 6288);
    }

    private static boolean isMaestro(int firstFour) {
        return firstFour == 5018 || firstFour == 5020 || firstFour == 5038
                || firstFour == 6304 || firstFour == 6759 || firstFour == 6761
                || firstFour == 6763;
    }

    private static boolean isJcb(int firstFour) {
        return firstFour >= 3528 && firstFour <= 3589;
    }

    private static boolean isDiscover(int firstThree, int firstFive, int firstSix) {
        return (firstFive == 60110)
                || (firstFive >= 60112 && firstFive <= 60114)
                || (firstSix == 601175 || firstSix == 601177)
                || (firstSix >= 601186 && firstSix <= 601199)
                || (firstThree >= 644 && firstThree <= 659)
                || (firstThree >= 601 && firstThree <= 659)
                // this line will cause false positives, but TSYS wanted it. Be
                // aware.
                || (firstThree >= 600 && firstThree <= 699);
    }

    private static boolean isDinersCard(int firstTwo, int firstThree, int firstFour) {
        return (firstThree >= 300 && firstThree <= 305) || firstTwo == 36
                || firstFour == 3095 || firstTwo == 38 || firstTwo == 39;
    }

    private static boolean isMasterCard(int firstTwo, int firstFour) {
        return (firstTwo >= 51 && firstTwo <= 59) || (firstFour >= 2221 && firstFour <= 2720);
    }

    private static boolean isAmex(int firstTwo) {
        return (firstTwo == 34 || firstTwo == 37)
                || (firstTwo >= 70 && firstTwo <= 79);
    }

    private static boolean isVisa(int firstOne) {
        return firstOne == 4;
    }

    private static String getDateTimeString() {
        GregorianCalendar dateTime = new GregorianCalendar();
        dateTime.setTimeZone(TimeZone.getTimeZone("UTC"));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        String date = sdf.format(dateTime.getTime());
        return date;
    }
}
