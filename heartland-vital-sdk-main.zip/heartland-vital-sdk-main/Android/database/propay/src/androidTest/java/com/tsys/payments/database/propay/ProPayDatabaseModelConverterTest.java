package com.tsys.payments.database.propay;

import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;
import com.tsys.payments.host.propay.utils.ProPayCardHelper;
import com.tsys.payments.library.db.entity.SafTransaction;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.enums.EncryptionType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class ProPayDatabaseModelConverterTest {
    private static final String SCRIPT_VISA_PAN = "4012002000060016";
    private static final String SCRIPT_VISA_EXP_DATE = "202512";
    private static final String SCRIPT_VISA_C2X_TRACK_1_HEX =
            "CEAF02088722FAE86A0FCD8445055D4C38B8323300" +
                    "254DE45630969AE9AAAFF920D2FBAAC37B105602F212AF078C3F7963D301F5EF4EDF532A20DF33D2EE50" +
                    "0B978A9078DA402E062ABBB025F5A917C0";
    private static final String SCRIPT_VISA_C2X_TRACK_2_HEX =
            "EAEE38A9412062416897825C1B302E9503D0D7A27D" +
                    "F4B73FAF9BDA24F26BF426623757A42E751C2E";
    private static final String SCRIPT_VISA_C2X_KSN_HEX = "0000987654321060031F";

    private static final String CARDHOLDER_ID = "XTY-1243-12";
    private static final String PAYMENT_TOKEN = "188219992011111";

    private static final BigDecimal TOTAL = new BigDecimal(10000);
    private static final BigDecimal TIP = new BigDecimal(20000);

    @Test
    public void testConvertGatewayRequestToSafTransaction_convertsGatewayAuthMsrTransactions() {
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);
        cardData.setExpirationDate(SCRIPT_VISA_EXP_DATE);
        cardData.setPan(SCRIPT_VISA_PAN);
        cardData.setCardType(CardType.VISA);
        cardData.setEncryptionType(EncryptionType.TDES);
        cardData.setKsn(SCRIPT_VISA_C2X_KSN_HEX);
        cardData.setTrack1(SCRIPT_VISA_C2X_TRACK_1_HEX);
        cardData.setTrack2(SCRIPT_VISA_C2X_TRACK_2_HEX);

        TerminalInfo terminalInfo = new TerminalInfo();
        terminalInfo.setTerminalType(TerminalType.BBPOS_C2X);

        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.SALE);
        builder.setCardData(cardData)
                .setTerminalInfo(terminalInfo)
                .setTip(TIP.longValue())
                .setTotal(TOTAL.longValue());

        SafTransaction storedTransaction =
                ProPayDatabaseModelConverter.convertGatewayRequestToSafTransaction(builder.build());
        assertNotNull(storedTransaction);
        assertNotNull(storedTransaction.getAmount());
        assertNotNull(storedTransaction.getTip());
        assertEquals(TOTAL, storedTransaction.getAmount());
        assertEquals(TIP, storedTransaction.getTip());
        assertEquals(SCRIPT_VISA_PAN, storedTransaction.getCardNumber());
        assertEquals(ProPayCardHelper.CARD_VISA, storedTransaction.getCardType());
        assertEquals(SCRIPT_VISA_C2X_TRACK_1_HEX, storedTransaction.getTrack1());
        assertEquals(SCRIPT_VISA_C2X_TRACK_2_HEX, storedTransaction.getTrack2());
        assertEquals(ProPayDatabaseModelConverter.STATUS_PENDING, storedTransaction.getStatus());
        assertEquals(ProPayDatabaseModelConverter.TYPE_SWIPE,
                storedTransaction.getTransactionType());
    }

    @Test
    public void testConvertGatewayRequestToSafTransaction_convertsGatewayCaptureTransactionsWithToken() {
        GatewayRequest.Builder builder = new GatewayRequest.Builder(GatewayAction.CAPTURE);
        builder.setTip(TIP.longValue())
                .setTotal(TOTAL.longValue())
                .setCardHolderId(CARDHOLDER_ID)
                .setToken(PAYMENT_TOKEN);

        SafTransaction storedTransaction =
                ProPayDatabaseModelConverter.convertGatewayRequestToSafTransaction(builder.build());
        assertNotNull(storedTransaction);
        assertNotNull(storedTransaction.getAmount());
        assertNotNull(storedTransaction.getTip());
        assertEquals(TOTAL, storedTransaction.getAmount());
        assertEquals(TIP, storedTransaction.getTip());
        assertEquals(PAYMENT_TOKEN, storedTransaction.getToken());
        assertEquals(CARDHOLDER_ID, storedTransaction.getCardholderId());
        assertEquals(ProPayDatabaseModelConverter.STATUS_PENDING, storedTransaction.getStatus());
        assertEquals(ProPayDatabaseModelConverter.TYPE_STORED,
                storedTransaction.getTransactionType());
    }

    @Test
    public void testConvertSafTransactionToGatewayRequest_convertsSafSaleMsrTransactions() {
        SafTransaction safTransaction = new SafTransaction();
        safTransaction.setCardNumber(SCRIPT_VISA_PAN);
        safTransaction.setTip(TIP);
        safTransaction.setAmount(TOTAL);
        safTransaction.setCardType(ProPayCardHelper.CARD_VISA);
        safTransaction.setExpDate(SCRIPT_VISA_EXP_DATE);
        safTransaction.setTransactionType(ProPayDatabaseModelConverter.TYPE_SWIPE);
        safTransaction.setTerminalType(ProPayEncryptingDeviceType.Bbpos.value);
        safTransaction.setTrack1(SCRIPT_VISA_C2X_TRACK_1_HEX);
        safTransaction.setTrack2(SCRIPT_VISA_C2X_TRACK_2_HEX);
        safTransaction.setKsn(SCRIPT_VISA_C2X_KSN_HEX);

        GatewayRequest request =
                ProPayDatabaseModelConverter.convertSafTransactionToGatewayRequest(safTransaction);
        assertNotNull(request);
        assertEquals(GatewayAction.SALE, request.getGatewayAction());
        assertEquals(TOTAL.longValue(), request.getTotal());
        assertNotNull(request.getTip());
        assertEquals(TIP.longValue(), request.getTip().longValue());
        TerminalInfo terminalInfo = request.getTerminalInfo();
        assertNotNull(terminalInfo);
        assertEquals(TerminalType.BBPOS_C2X, terminalInfo.getTerminalType());
        CardData cardData = request.getCardData();
        assertNotNull(cardData);
        assertEquals(SCRIPT_VISA_C2X_TRACK_1_HEX, cardData.getTrack1());
        assertEquals(SCRIPT_VISA_C2X_TRACK_2_HEX, cardData.getTrack2());
        assertEquals(SCRIPT_VISA_C2X_KSN_HEX, cardData.getKsn());
    }

    @Test
    public void testConvertSafTransactionToGatewayRequest_convertsSafCaptureTransactions() {
        SafTransaction safTransaction = new SafTransaction();
        safTransaction.setTip(TIP);
        safTransaction.setAmount(TOTAL);
        safTransaction.setTransactionType(ProPayDatabaseModelConverter.TYPE_STORED);
        safTransaction.setCardholderId(CARDHOLDER_ID);
        safTransaction.setToken(PAYMENT_TOKEN);

        GatewayRequest request =
                ProPayDatabaseModelConverter.convertSafTransactionToGatewayRequest(safTransaction);
        assertNotNull(request);
        assertEquals(GatewayAction.CAPTURE, request.getGatewayAction());
        assertEquals(TOTAL.longValue(), request.getTotal());
        assertNotNull(request.getTip());
        assertEquals(TIP.longValue(), request.getTip().longValue());
        assertEquals(CARDHOLDER_ID, request.getCardHolderId());
        assertEquals(PAYMENT_TOKEN, request.getToken());
    }
}
