package com.tsys.payments.library.db

import androidx.test.runner.AndroidJUnit4
import org.junit.Rule
import org.junit.runner.RunWith
import androidx.room.testing.MigrationTestHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.platform.app.InstrumentationRegistry
import com.tsys.payments.database.propay.SafDatabase

@RunWith(AndroidJUnit4::class)
class MigrationTest {
    val CONFIG_DB = "migration-test";

    @Rule
    var mHelper: MigrationTestHelper;

    constructor() {
        mHelper = MigrationTestHelper(InstrumentationRegistry.getInstrumentation(),
                SafDatabase::class.qualifiedName,
                FrameworkSQLiteOpenHelperFactory())
    }
}
