package com.tsys.payments.library.db;

import android.util.Log;

import com.tsys.payments.database.propay.ProPayDatabaseController;
import com.tsys.payments.database.propay.ProPayDatabaseControllerFactory;
import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;
import com.tsys.payments.host.propay.utils.ProPayCardHelper;
import com.tsys.payments.library.db.entity.SafTokenizedCard;
import com.tsys.payments.library.db.entity.SafTransaction;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.enums.GatewayType;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.work.Configuration;
import androidx.work.testing.SynchronousExecutor;
import androidx.work.testing.TestDriver;
import androidx.work.testing.WorkManagerTestInitHelper;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class PropayDatabaseControllerTest {
    private ProPayDatabaseControllerFactory factory;
    private static final String VISA_KSN = "FFFFFF00060B93A0001B";
    private static final String VISA_PAN = "4012000098765439";
    private static final String VISA_TRACK_1 =
            "2542343834373138000000000000383232385E524543495049454E542F47494654204" +
                    "34152445E32333036353231000000000000000000000000000000003F";
    private static final String VISA_TRACK_2 =
            "3B343834373138000000000000383232383D3233303635323100000000000000003F";
    private static final String VISA_EXPIRATION_DATE = "1220";
    private static final String VISA_CVV = "999";
    private static final String TEST_CARD_HOLDER_NAME = "Johnathan Doe";
    private static final long TEST_SUBTOTAL = 500;
    private static final long TEST_TAX = 300;
    private static final String TEST_POSTAL_CODE = "30308";

    @Before
    public void setup() {
        factory = new ProPayDatabaseControllerFactory();
        Configuration config = new Configuration.Builder()
                .setMinimumLoggingLevel(Log.DEBUG)
                .setExecutor(new SynchronousExecutor())
                .build();

        // Initialize WorkManager for instrumentation tests.
        WorkManagerTestInitHelper
                .initializeTestWorkManager(
                        InstrumentationRegistry.getInstrumentation().getContext(), config);
    }

    @Test
    public void testStoreSafTransaction() throws InitializationException {
        String dbName = "saf-database";
        // Start with a new database
        InstrumentationRegistry.getInstrumentation().getContext().deleteDatabase(dbName);

        // Create database controller with 30 days expiration time
        SafDatabaseConfig safDbConfig = new SafDatabaseConfig(true, 30, TimeUnit.DAYS);
        DatabaseConfig dbConfig =
                new DatabaseConfig(InstrumentationRegistry.getInstrumentation().getContext(),
                        dbName,
                        "password", safDbConfig, GatewayType.PROPAY);
        ProPayDatabaseController dbController = (ProPayDatabaseController)factory.create(dbConfig);
        Assert.assertNotNull(dbController);

        // Build SAF Transaction
        SafTransaction safTransaction = new SafTransaction();

        // Set transaction details
        safTransaction.setTax(BigDecimal.valueOf(TEST_TAX));
        safTransaction.setAmount(BigDecimal.valueOf(TEST_SUBTOTAL));
        safTransaction.setTransactionTime(new Date(System.currentTimeMillis()));

        // Set transaction type as swipe
        safTransaction.setTransactionType(1);
        // Set transaction status as pending
        safTransaction.setStatus(2);
        // Set card data
        safTransaction.setCardNumber(VISA_PAN);
        safTransaction.setCardType(ProPayCardHelper.getCreditCardType(VISA_PAN));
        safTransaction.setCvvCode(VISA_CVV);
        safTransaction.setExpDate(VISA_EXPIRATION_DATE);
        safTransaction.setZipCode(TEST_POSTAL_CODE);
        safTransaction.setCardHolderName(TEST_CARD_HOLDER_NAME);
        safTransaction.setTrack1(VISA_TRACK_1);
        safTransaction.setTrack2(VISA_TRACK_2);
        safTransaction.setKsn(VISA_KSN);
        safTransaction.setTerminalType(ProPayEncryptingDeviceType.
                fromTerminalType(TerminalType.INGENICO_MOBY_3000_PROPAY).value);

        // Store transaction
        dbController.storeSafTransaction(safTransaction);

        // Get transaction list
        List<SafTransaction> safTransactionList = dbController.getAllSafTransactions();

        Assert.assertNotNull(safTransactionList);
        SafTransaction retrievedTransaction = safTransactionList.get(0);
        Assert.assertEquals(retrievedTransaction.getSafLocalId(), 1);

        // Verify transaction information
        Assert.assertEquals(retrievedTransaction.getAmount(), BigDecimal.valueOf(TEST_SUBTOTAL));
        Assert.assertEquals(retrievedTransaction.getTax(), BigDecimal.valueOf(TEST_TAX));
        Assert.assertEquals(retrievedTransaction.getStatus(), 2);
        Assert.assertEquals(retrievedTransaction.getTransactionType(), 1);

        // Verify card data
        Assert.assertEquals(retrievedTransaction.getCardHolderName(), TEST_CARD_HOLDER_NAME);
        Assert.assertEquals(retrievedTransaction.getCardNumber(), VISA_PAN);
        Assert.assertEquals(retrievedTransaction.getCvvCode(), VISA_CVV);
        Assert.assertEquals(retrievedTransaction.getKsn(), VISA_KSN);
        Assert.assertEquals(retrievedTransaction.getTrack1(), VISA_TRACK_1);
        Assert.assertEquals(retrievedTransaction.getTrack2(), VISA_TRACK_2);
        Assert.assertEquals(retrievedTransaction.getCardType(), ProPayCardHelper.CARD_VISA);
    }

    @Test
    public void testGetAllSafTransactions_returnsOnlyUnexpired()
            throws InitializationException, AssertionError {
        String dbName = "saf-database";
        // Start with a new database
        InstrumentationRegistry.getInstrumentation().getContext().deleteDatabase(dbName);

        // Create database controller with 30 days expiration time
        SafDatabaseConfig safDbConfig = new SafDatabaseConfig(true, 30, TimeUnit.DAYS);
        DatabaseConfig dbConfig =
                new DatabaseConfig(InstrumentationRegistry.getInstrumentation().getContext(),
                        "saf-database",
                        "password", safDbConfig, GatewayType.PROPAY);
        ProPayDatabaseController dbController = (ProPayDatabaseController)factory.create(dbConfig);
        Assert.assertNotNull(dbController);

        // Store transaction expired > 30 days ago
        SafTransaction safTransactionExpired = new SafTransaction();
        safTransactionExpired.setSafLocalId(1);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -31);
        safTransactionExpired.setTransactionTime(calendar.getTime());
        dbController.storeSafTransaction(safTransactionExpired);

        // Store new transaction that is not yet expired
        SafTransaction safTransactionNotExpired = new SafTransaction();
        safTransactionNotExpired.setSafLocalId(2);
        safTransactionNotExpired.setTransactionTime(new Date());
        dbController.storeSafTransaction(safTransactionNotExpired);

        Assert.assertEquals(dbController.getAllSafTransactions().get(0).getSafLocalId(), 2);
    }

    @Test
    public void testGetAllSafTokenizedCards_returnsOnlyUnexpired()
            throws InitializationException, AssertionError {
        String dbName = "saf-database";
        // Start with a new database
        InstrumentationRegistry.getInstrumentation().getContext().deleteDatabase(dbName);

        // Create database controller with 30 days expiration time
        SafDatabaseConfig safDbConfig = new SafDatabaseConfig(true, 30, TimeUnit.DAYS);
        DatabaseConfig dbConfig =
                new DatabaseConfig(InstrumentationRegistry.getInstrumentation().getContext(),
                        dbName,
                        "password", safDbConfig, GatewayType.PROPAY);
        ProPayDatabaseController dbController = (ProPayDatabaseController)factory.create(dbConfig);
        Assert.assertNotNull(dbController);

        // Store transaction expired > 30 days ago
        SafTokenizedCard safTokenizedCardExpired = new SafTokenizedCard();
        safTokenizedCardExpired.setId("1");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -31);
        safTokenizedCardExpired.setCaptureTime(calendar.getTime());
        dbController.storeSafTokenizedCard(safTokenizedCardExpired);

        // Store new transaction that is not yet expired
        SafTokenizedCard safTokenizedCardNotExpired = new SafTokenizedCard();
        safTokenizedCardNotExpired.setId("2");
        safTokenizedCardNotExpired.setCaptureTime(new Date());
        dbController.storeSafTokenizedCard(safTokenizedCardNotExpired);

        Assert.assertEquals(dbController.getAllSafTokenizedCards().get(0).getId(), "2");
    }

    @Test
    public void testPurgeExpiredData_purgesAllExpiredData()
            throws InitializationException, AssertionError {
        String dbName = "saf-database";
        // Start with a new database
        InstrumentationRegistry.getInstrumentation().getContext().deleteDatabase(dbName);

        // Create database controller with 30 days expiration time
        SafDatabaseConfig safDbConfig = new SafDatabaseConfig(true, 30, TimeUnit.DAYS);
        DatabaseConfig dbConfig =
                new DatabaseConfig(InstrumentationRegistry.getInstrumentation().getContext(),
                        dbName,
                        "password", safDbConfig, GatewayType.PROPAY);
        ProPayDatabaseController dbController = (ProPayDatabaseController)factory.create(dbConfig);
        Assert.assertNotNull(dbController);

        // Store transaction expired > 30 days ago
        SafTransaction safTransactionExpired = new SafTransaction();
        safTransactionExpired.setSafLocalId(1);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -31);
        safTransactionExpired.setTransactionTime(calendar.getTime());
        dbController.storeSafTransaction(safTransactionExpired);

        // Store new transaction that is not yet expired
        SafTransaction safTransactionNotExpired = new SafTransaction();
        safTransactionNotExpired.setSafLocalId(2);
        safTransactionNotExpired.setTransactionTime(new Date());
        dbController.storeSafTransaction(safTransactionNotExpired);

        // Store transaction expired > 30 days ago
        SafTokenizedCard safTokenizedCardExpired = new SafTokenizedCard();
        safTokenizedCardExpired.setId("1");
        calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -31);
        safTokenizedCardExpired.setCaptureTime(calendar.getTime());
        dbController.storeSafTokenizedCard(safTokenizedCardExpired);

        // Store new transaction that is not yet expired
        SafTokenizedCard safTokenizedCardNotExpired = new SafTokenizedCard();
        safTokenizedCardNotExpired.setId("2");
        safTokenizedCardNotExpired.setCaptureTime(new Date());
        dbController.storeSafTokenizedCard(safTokenizedCardNotExpired);

        Assert.assertEquals(dbController.getAllUnfilteredSafTransactions().size(), 2);
        Assert.assertEquals(dbController.getAllUnfilteredSafTransactions().size(), 2);
        Assert.assertEquals(dbController.getAllUnfilteredSafTokenizedCards().size(), 2);
        Assert.assertEquals(dbController.getAllUnfilteredSafTokenizedCards().size(), 2);

        dbController.purgeExpiredData();

        Assert.assertEquals(dbController.getAllUnfilteredSafTransactions().size(), 1);
        Assert.assertEquals(dbController.getAllUnfilteredSafTransactions().size(), 1);
        Assert.assertEquals(dbController.getAllUnfilteredSafTokenizedCards().size(), 1);
        Assert.assertEquals(dbController.getAllUnfilteredSafTokenizedCards().size(), 1);
    }

    @Test
    public void testPurgeExpiredData_autoPurgesAllExpiredData()
            throws InitializationException, AssertionError {
        String dbName = "saf-database";
        // Start with a new database
        InstrumentationRegistry.getInstrumentation().getContext().deleteDatabase(dbName);

        // Create database controller with 30 days expiration time
        SafDatabaseConfig safDbConfig = new SafDatabaseConfig(true, 30, TimeUnit.DAYS);
        DatabaseConfig dbConfig =
                new DatabaseConfig(InstrumentationRegistry.getInstrumentation().getContext(),
                        dbName,
                        "password", safDbConfig, GatewayType.PROPAY);
        ProPayDatabaseController dbController = (ProPayDatabaseController)factory.create(dbConfig);
        Assert.assertNotNull(dbController);

        // Store transaction expired > 30 days ago
        SafTransaction safTransactionExpired = new SafTransaction();
        safTransactionExpired.setSafLocalId(1);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -31);
        safTransactionExpired.setTransactionTime(calendar.getTime());
        dbController.storeSafTransaction(safTransactionExpired);

        // Store new transaction that is not yet expired
        SafTransaction safTransactionNotExpired = new SafTransaction();
        safTransactionNotExpired.setSafLocalId(2);
        safTransactionNotExpired.setTransactionTime(new Date());
        dbController.storeSafTransaction(safTransactionNotExpired);

        // Store transaction expired > 30 days ago
        SafTokenizedCard safTokenizedCardExpired = new SafTokenizedCard();
        safTokenizedCardExpired.setId("1");
        calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -31);
        safTokenizedCardExpired.setCaptureTime(calendar.getTime());
        dbController.storeSafTokenizedCard(safTokenizedCardExpired);

        // Store new transaction that is not yet expired
        SafTokenizedCard safTokenizedCardNotExpired = new SafTokenizedCard();
        safTokenizedCardNotExpired.setId("2");
        safTokenizedCardNotExpired.setCaptureTime(new Date());
        dbController.storeSafTokenizedCard(safTokenizedCardNotExpired);

        Assert.assertEquals(dbController.getAllUnfilteredSafTransactions().size(), 2);
        Assert.assertEquals(dbController.getAllUnfilteredSafTransactions().size(), 2);
        Assert.assertEquals(dbController.getAllUnfilteredSafTokenizedCards().size(), 2);
        Assert.assertEquals(dbController.getAllUnfilteredSafTokenizedCards().size(), 2);

        // Initialize testDriver
        TestDriver testDriver =
                WorkManagerTestInitHelper
                        .getTestDriver(InstrumentationRegistry.getInstrumentation().getContext());
        // Tells the testing framework the period delay is met, this will execute your code in doWork() in MyWorker class
        testDriver.setPeriodDelayMet(dbController.getPeriodicWorkRequest().getId());

        Assert.assertEquals(dbController.getAllUnfilteredSafTransactions().size(), 1);
        Assert.assertEquals(dbController.getAllUnfilteredSafTransactions().size(), 1);
        Assert.assertEquals(dbController.getAllUnfilteredSafTokenizedCards().size(), 1);
        Assert.assertEquals(dbController.getAllUnfilteredSafTokenizedCards().size(), 1);
    }
}
