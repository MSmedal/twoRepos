package com.tsys.payments.database.propay;

import android.text.TextUtils;

import com.tsys.payments.host.propay.enums.ProPayEncryptingDeviceType;
import com.tsys.payments.host.propay.utils.ProPayCardHelper;
import com.tsys.payments.library.db.entity.SafTransaction;
import com.tsys.payments.library.domain.Address;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.TenderType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import java.math.BigDecimal;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

class ProPayDatabaseModelConverter {

    public static final int STATUS_NONE = -1;
    public static final int STATUS_DECLINED = 1;
    public static final int STATUS_PENDING = 2;
    public static final int STATUS_COMPLETE = 3;

    public static final int TYPE_NONE = -1;
    public static final int TYPE_SWIPE = 1;
    public static final int TYPE_CASH = 2;
    public static final int TYPE_KEY = 3;
    public static final int TYPE_STORED = 4;
    public static final int TYPE_TRANSFER = 5;
    public static final int TYPE_EMV = 6;
    public static final int TYPE_TOKENIZE = 7;

    public static final int TRANSACTION_STATE_NONE = -1;
    public static final int TRANSACTION_STATE_AUTH = 1;
    public static final int TRANSACTION_STATE_CAPTURE = 3;
    public static final int TRANSACTION_STATE_COMPLETED = 4;
    public static final int TRANSACTION_STATE_CANCEL = 5;

    @NonNull
    public static SafTransaction convertGatewayRequestToSafTransaction(
            @NonNull GatewayRequest gatewayRequest) {
        SafTransaction safTransaction = new SafTransaction();
        safTransaction.setTip(gatewayRequest.getTip() == null ? BigDecimal.valueOf(0L) :
                BigDecimal.valueOf(gatewayRequest.getTip()));
        safTransaction.setTax(gatewayRequest.getTax() == null ? BigDecimal.valueOf(0L) :
                BigDecimal.valueOf(gatewayRequest.getTax()));
        safTransaction.setAmount(BigDecimal.valueOf(gatewayRequest.getTotal()));
        safTransaction.setInvoiceNumber(gatewayRequest.getInvoiceNumber());
        safTransaction.setTransactionTime(new Date(System.currentTimeMillis()));
        safTransaction.setTransactionType(
                convertSdkTransactionTypeToSafType(gatewayRequest.getGatewayAction()));
        safTransaction.setStatus(STATUS_PENDING);
        if (gatewayRequest.getCardholderAddress() != null) {
            safTransaction.setZipCode(gatewayRequest.getCardholderAddress().getPostalCode());
        }
        if (gatewayRequest.getCardData() != null) {
            safTransaction.setExpDate(gatewayRequest.getCardData().getExpirationDate());
            safTransaction.setCardHolderName(gatewayRequest.getCardData().getCardholderName());
            safTransaction.setCardNumber(gatewayRequest.getCardData().getPan());
            safTransaction.setCardType(ProPayCardHelper
                    .getCreditCardType(gatewayRequest.getCardData().getPan()));
            safTransaction.setCvvCode(gatewayRequest.getCardData().getCvv2());

            safTransaction.setTrack1(gatewayRequest.getCardData().getTrack1());
            safTransaction.setTrack2(gatewayRequest.getCardData().getTrack2());
            safTransaction.setTrack3(gatewayRequest.getCardData().getTrack3());
            safTransaction.setKsn(gatewayRequest.getCardData().getKsn());
            safTransaction.setTerminalType(ProPayEncryptingDeviceType
                    .fromTerminalType(gatewayRequest.getTerminalInfo().getTerminalType()).value);
        } else {
            safTransaction.setToken(gatewayRequest.getToken());
            safTransaction.setCardholderId(gatewayRequest.getCardHolderId());
        }

        safTransaction.setStoreCard(gatewayRequest.isGenerateToken());
        safTransaction.setCardHolderSignatureFileName(gatewayRequest.getSignatureFileLocation());

        return safTransaction;
    }

    @NonNull
    public static GatewayRequest convertSafTransactionToGatewayRequest(
            @NonNull SafTransaction safTransaction) {
        TerminalInfo terminalInfo = new TerminalInfo();
        terminalInfo.setTerminalType(
                terminalTypeFromProPayEncryptingDeviceTypeValue(safTransaction.getTerminalType()));
        GatewayRequest.Builder gatewayRequest = new GatewayRequest
                .Builder(convertSafTypeToSdkTransactionType(safTransaction.getTransactionType()))
                .setTenderType(TenderType.CREDIT)
                .setTotal(safTransaction.getAmount() == null ? 0L :
                        safTransaction.getAmount().longValue())
                .setTip(safTransaction.getTip() == null ? 0L : safTransaction.getTip().longValue())
                .setInvoiceNumber(safTransaction.getInvoiceNumber())
                .setTax(safTransaction.getTax() == null ? 0L : safTransaction.getTax().longValue())
                .setGenerateToken(safTransaction.isStoreCard())
                .setAddress(buildAddress(safTransaction))
                .setTerminalInfo(terminalInfo);

        if (safTransaction.getToken() != null && safTransaction.getCardholderId() != null) {
            gatewayRequest.setToken(safTransaction.getToken())
                    .setCardHolderId(safTransaction.getCardholderId());
        } else {
            gatewayRequest.setCardData(buildCardDataFromSafTransaction(safTransaction));
        }
        if (!TextUtils.isEmpty(safTransaction.getCardHolderSignatureFileName())) {
            gatewayRequest
                    .setSignatureFilelocation(safTransaction.getCardHolderSignatureFileName());
        }

        return gatewayRequest.build();
    }

    private static int convertSdkTransactionTypeToSafType(@Nullable GatewayAction action) {
        if (action == null) {
            return TYPE_NONE;
        }
        switch (action) {
            case SALE:
            case AUTH:
                return TYPE_SWIPE;
            case CAPTURE:
                return TYPE_STORED;
            case TOKENIZE_CARD:
                return TYPE_TOKENIZE;
            default:
                return TYPE_NONE;
        }
    }

    @Nullable
    private static GatewayAction convertSafTypeToSdkTransactionType(int safType) {
        switch (safType) {
            case TYPE_SWIPE:
                return GatewayAction.SALE;
            case TYPE_STORED:
                return GatewayAction.CAPTURE;
            case TYPE_TOKENIZE:
                return GatewayAction.TOKENIZE_CARD;
            default:
                return null;
        }
    }

    private static CardData buildCardDataFromSafTransaction(
            @NonNull SafTransaction safTransaction) {
        CardData cardData = new CardData();
        cardData.setExpirationDate(safTransaction.getExpDate());
        cardData.setCardholderName(safTransaction.getCardHolderName());
        cardData.setPan(safTransaction.getCardNumber());
        cardData.setCvv2(safTransaction.getCvvCode());
        cardData.setTrack1(safTransaction.getTrack1());
        cardData.setTrack2(safTransaction.getTrack2());
        cardData.setTrack3(safTransaction.getTrack3());
        cardData.setKsn(safTransaction.getKsn());
        cardData.setCardDataSource(CardDataSourceType.MSR);
        return cardData;
    }

    @NonNull
    private static Address buildAddress(@NonNull SafTransaction safTransaction) {
        Address address = new Address();
        address.setPostalCode(safTransaction.getZipCode());
        return address;
    }

    @Nullable
    private static TerminalType terminalTypeFromProPayEncryptingDeviceTypeValue(int value) {
        switch (ProPayEncryptingDeviceType.parse(value)) {
            case MagTekADynamo:
                return TerminalType.MAGTEK_ADYNAMO;
            case RoamData:
                return TerminalType.ROAM_G5X_TSYS_DECRYPTION;
            case Bbpos:
                return TerminalType.BBPOS_C2X;
            case MobyBdk:
                return TerminalType.INGENICO_MOBY_8500;
            case Moby3000:
                return TerminalType.INGENICO_MOBY_3000;
            case Moby3000_ProPay:
                return TerminalType.INGENICO_MOBY_3000_PROPAY;
            default:
                return null;
        }
    }
}
