package com.tsys.payments.database.propay;

import com.tsys.payments.library.db.entity.SafTransaction;

import org.jetbrains.annotations.TestOnly;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface SafTransactionDao {
    @Insert
    long storeSafTransaction(SafTransaction safTransaction);

    @TestOnly
    @Query("SELECT * FROM saf_transaction")
    List<SafTransaction> getAllSafTransactions();

    /**
     * Get the unexpired SAF transactions
     *
     * @param millisExpiryTime The expiration time for SAF transaction in milliseconds for this database
     */
    @Query("SELECT * FROM saf_transaction WHERE TRANSACTION_TIME + :millisExpiryTime > :millisCurrentTime")
    List<SafTransaction> getAllValidSafTransactions(long millisExpiryTime, long millisCurrentTime);

    @Query("SELECT * FROM saf_transaction WHERE SAF_LOCAL_ID IN (:safLocalIdList) AND " +
            "TRANSACTION_TIME + :millisExpiryTime > :millisCurrentTime")
    List<SafTransaction> getValidSafTransactionByLocalIdList(List<Long> safLocalIdList,
                                                                      long millisExpiryTime, long millisCurrentTime);

    @Query("SELECT SAF_LOCAL_ID, TRANSACTION_TIME, AMOUNT, SALES_TAX, TIP, FEE, CARD_HOLDER_NAME, " +
            "GATEWAY_TRANSACTION_ID, STATUS, TRANSACTION_TYPE, TRANSACTION_STATE, CARD_TYPE, ENCRYPTION_TYPE, " +
            "TERMINAL_TYPE, RUN_OFFLINE, SIGNATURE_FILE_NAME, TENDERED, STORE_CARD" +
            " FROM saf_transaction WHERE TRANSACTION_TIME + :millisExpiryTime > :millisCurrentTime")
    List<SafTransaction> getAllValidSafTransactionsMetadata(long millisExpiryTime, long millisCurrentTime);

    @Query("DELETE FROM saf_transaction WHERE TRANSACTION_TIME + :millisExpiryTime <= :millisCurrentTime")
    int purgeExpiredTransactions(long millisExpiryTime, long millisCurrentTime);

    @Query("SELECT * FROM saf_transaction WHERE SAF_LOCAL_ID = :safLocalId AND " +
            "TRANSACTION_TIME + :millisExpiryTime > :millisCurrentTime")
    SafTransaction getSafTransactionByLocalId(long millisExpiryTime, long millisCurrentTime,
                                                       long safLocalId);

    @Query("DELETE FROM saf_transaction WHERE SAF_LOCAL_ID = :safLocalId")
    void deleteSafTransactionByLocalId(long safLocalId);
}
