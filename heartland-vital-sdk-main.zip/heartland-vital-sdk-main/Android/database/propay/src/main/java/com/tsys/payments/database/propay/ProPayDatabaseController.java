package com.tsys.payments.database.propay;

import com.tsys.payments.library.db.DatabaseConfig;
import com.tsys.payments.library.db.DatabaseController;
import com.tsys.payments.library.db.entity.SafTokenizedCard;
import com.tsys.payments.library.db.entity.SafTransaction;
import com.tsys.payments.library.gateway.domain.GatewayRequest;
import com.tsys.payments.library.gateway.enums.GatewayAction;

import net.sqlcipher.database.SupportFactory;

import org.jetbrains.annotations.TestOnly;

import androidx.annotation.VisibleForTesting;
import androidx.room.Room;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class ProPayDatabaseController implements DatabaseController {
    private static ProPayDatabaseController sInstance;
    private final long PURGE_EXPIRED_DATA_INTERVAL = 15;
    private final TimeUnit PURGE_EXPIRED_DATA_INTERVAL_TIME_UNIT = TimeUnit.MINUTES;
    private SafDatabase mDatabase;
    private DatabaseConfig mDatabaseConfig;
    @VisibleForTesting
    private PeriodicWorkRequest mTestPeriodicWorkRequest;

    ProPayDatabaseController() {
        sInstance = this;
    }

    public static ProPayDatabaseController getInstance() {
        return sInstance;
    }

    @Override
    public void init(DatabaseConfig databaseConfig) {
        mDatabaseConfig = databaseConfig;

        if (mDatabaseConfig.getEncryptionPassword() != null) {
            byte[] passphrase = mDatabaseConfig.getEncryptionPassword().getBytes();
            SupportFactory factory = new SupportFactory(passphrase);
            mDatabase =
                    Room.databaseBuilder(mDatabaseConfig.getContext(), SafDatabase.class, mDatabaseConfig.getDbName())
                            .openHelperFactory(factory)
                            .build();
        } else {
            mDatabase =
                    Room.databaseBuilder(mDatabaseConfig.getContext(), SafDatabase.class, mDatabaseConfig.getDbName())
                            .build();
        }

        startPeriodicAutoPurge();
    }

    /**
     * Starts the {@link PeriodicWorkRequest} to periodically purge the database of all expired data.
     */
    private void startPeriodicAutoPurge() {
        // create the PeriodicWorkRequest to purge expired data
        mTestPeriodicWorkRequest = new PeriodicWorkRequest.Builder(PurgeExpiredDataWorker.class,
                PURGE_EXPIRED_DATA_INTERVAL, PURGE_EXPIRED_DATA_INTERVAL_TIME_UNIT).build();

        // if the request is started, keep it and do not create another one until it is completed
        WorkManager.getInstance(mDatabaseConfig.getContext())
                .enqueueUniquePeriodicWork("periodic_purge_expired_data", ExistingPeriodicWorkPolicy.KEEP,
                        mTestPeriodicWorkRequest);
    }

    @VisibleForTesting
    public PeriodicWorkRequest getPeriodicWorkRequest() {
        return mTestPeriodicWorkRequest;
    }

    @Override
    public long storeSafTransaction(SafTransaction safTransaction) {
        return mDatabase.getSafTransactionDao().storeSafTransaction(safTransaction);
    }

    @Override
    public List<SafTransaction> getAllSafTransactions() {
        return mDatabase.getSafTransactionDao()
                .getAllValidSafTransactions(getMillisExpiryTime(), System.currentTimeMillis());
    }

    @Override
    public List<SafTransaction> getSafTransactionsByLocalIdList(List<Long> safLocalIds) {
        return mDatabase.getSafTransactionDao().getValidSafTransactionByLocalIdList(safLocalIds,
                getMillisExpiryTime(), System.currentTimeMillis());
    }

    @Override
    public List<SafTransaction> getAllSafTransactionsMetadata() {
        return mDatabase.getSafTransactionDao()
                .getAllValidSafTransactionsMetadata(getMillisExpiryTime(), System.currentTimeMillis());
    }

    @TestOnly
    public List<SafTransaction> getAllUnfilteredSafTransactions() {
        return mDatabase.getSafTransactionDao().getAllSafTransactions();
    }

    @Override
    public void storeSafTokenizedCard(SafTokenizedCard safTokenizedCard) {
        mDatabase.getSafTokenizedCardDao().storeSafTokenizedCard(safTokenizedCard);
    }

    @Override
    public List<SafTokenizedCard> getAllSafTokenizedCards() {
        return mDatabase.getSafTokenizedCardDao()
                .getAllValidSafTokenizedCards(getMillisExpiryTime(), System.currentTimeMillis());
    }

    @TestOnly
    public List<SafTokenizedCard> getAllUnfilteredSafTokenizedCards() {
        return mDatabase.getSafTokenizedCardDao().getAllSafTokenizedCards();
    }

    @Override
    public SafTransaction convertGatewayRequestToSafTransaction(GatewayRequest gatewayRequest) {
        return ProPayDatabaseModelConverter.convertGatewayRequestToSafTransaction(gatewayRequest);
    }

    @Override
    public GatewayRequest convertSafTransactionToGatewayRequest(SafTransaction safTransaction) {
        return ProPayDatabaseModelConverter.convertSafTransactionToGatewayRequest(safTransaction);
    }

    @Override
    public GatewayAction[] getSupportedGatewayActions() {
        return new GatewayAction[] {GatewayAction.CAPTURE, GatewayAction.AUTH, GatewayAction.SALE,
                GatewayAction.TOKENIZE_CARD};
    }

    @Override
    public SafTransaction getSafTransactionByLocalId(long safLocalId) {
        return mDatabase.getSafTransactionDao().getSafTransactionByLocalId(getMillisExpiryTime(),
                System.currentTimeMillis(), safLocalId);
    }

    @Override
    public void deleteSafTransactionByLocalId(long safLocalId) {
        mDatabase.getSafTransactionDao().deleteSafTransactionByLocalId(safLocalId);
    }

    @VisibleForTesting(otherwise = VisibleForTesting.PACKAGE_PRIVATE)
    public void purgeExpiredData() {
        mDatabase.getSafTransactionDao().purgeExpiredTransactions(getMillisExpiryTime(), System.currentTimeMillis());
        mDatabase.getSafTokenizedCardDao()
                .purgeExpiredTokenizedCards(getMillisExpiryTime(), System.currentTimeMillis());
    }

    private long getMillisExpiryTime() {
        return TimeUnit.MILLISECONDS.convert(mDatabaseConfig.getSafDatabaseConfig().getSafTransactionPurgeTime(),
                        mDatabaseConfig.getSafDatabaseConfig().getSafTransactionPurgeTimeUnit());
    }
}
