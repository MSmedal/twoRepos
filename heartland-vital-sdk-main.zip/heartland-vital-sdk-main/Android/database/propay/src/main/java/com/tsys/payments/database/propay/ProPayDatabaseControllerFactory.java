package com.tsys.payments.database.propay;

import com.tsys.payments.library.db.DatabaseConfig;
import com.tsys.payments.library.db.DatabaseController;
import com.tsys.payments.library.db.DatabaseControllerFactory;
import com.tsys.payments.library.exceptions.InitializationException;
import com.tsys.payments.library.gateway.enums.GatewayType;

import androidx.annotation.Nullable;

public class ProPayDatabaseControllerFactory implements DatabaseControllerFactory {
    @Nullable
    @Override
    public DatabaseController create(DatabaseConfig databaseConfig) throws InitializationException {
        ProPayDatabaseController propayDatabaseController = new ProPayDatabaseController();
        propayDatabaseController.init(databaseConfig);
        return propayDatabaseController;
    }

    @Override
    public GatewayType[] getSupportedGateways() {
        return new GatewayType[] {GatewayType.PROPAY};
    }
}
