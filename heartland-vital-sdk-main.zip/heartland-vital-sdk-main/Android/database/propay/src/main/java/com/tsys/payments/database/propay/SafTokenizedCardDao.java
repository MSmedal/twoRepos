package com.tsys.payments.database.propay;

import com.tsys.payments.library.db.entity.SafTokenizedCard;

import org.jetbrains.annotations.TestOnly;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface SafTokenizedCardDao {
    @Insert
    void storeSafTokenizedCard(SafTokenizedCard safTokenizedCard);

    @TestOnly
    @Query("SELECT * FROM saf_tokenized_card")
    List<SafTokenizedCard> getAllSafTokenizedCards();

    /**
     * Get the unexpired SAF tokenized cards
     *
     * @param millisExpiryTime The expiration time for SAF tokenized cards in milliseconds for this database
     */
    @Query("SELECT * FROM saf_tokenized_card WHERE CAPTURE_TIME + :millisExpiryTime > :millisCurrentTime")
    List<SafTokenizedCard> getAllValidSafTokenizedCards(long millisExpiryTime, long millisCurrentTime);

    @Query("DELETE FROM saf_tokenized_card WHERE CAPTURE_TIME + :millisExpiryTime <= :millisCurrentTime")
    int purgeExpiredTokenizedCards(long millisExpiryTime, long millisCurrentTime);
}
