package com.tsys.payments.database.propay;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/**
 * Purges all the expired data in the {@link ProPayDatabaseController}'s internal database
 */
public class PurgeExpiredDataWorker extends Worker {
    public PurgeExpiredDataWorker(@NonNull Context context,
            @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        ProPayDatabaseController.getInstance().purgeExpiredData();
        return Result.success();
    }
}
