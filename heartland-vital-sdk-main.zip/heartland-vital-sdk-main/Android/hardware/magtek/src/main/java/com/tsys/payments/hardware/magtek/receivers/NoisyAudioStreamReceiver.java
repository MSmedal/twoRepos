package com.tsys.payments.hardware.magtek.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;

import com.magtek.mobile.android.mtlib.MTConnectionType;
import com.magtek.mobile.android.mtlib.MTSCRA;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Manages handling of events triggered when the Magtek card reader is unplugged.
 */
public class NoisyAudioStreamReceiver extends BroadcastReceiver {

    private MTSCRA mMagtekDriver;
    private MTConnectionType mMagtekConnectionType;
    private Callbacks mCallbacks;

    public NoisyAudioStreamReceiver(@NonNull MTSCRA driver,
            @Nullable MTConnectionType connectionType,
            @NonNull Callbacks callbacks) {
        mMagtekDriver = driver;
        mMagtekConnectionType = connectionType;
        mCallbacks = callbacks;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        /*
         * If the device is unplugged, this will immediately detect that
         * action, and close the device.
         */
        if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())) {
            if (mMagtekConnectionType == MTConnectionType.Audio) {
                if (mMagtekDriver.isDeviceConnected()) {
                    mCallbacks.onDeviceUnplugged();
                }
            }
        }
    }

    public interface Callbacks {
        void onDeviceUnplugged();
    }
}
