package com.tsys.payments.hardware.magtek;

import android.content.Context;

import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.terminal.TerminalController;
import com.tsys.payments.library.terminal.TerminalControllerFactory;
import com.tsys.payments.library.terminal.TerminalListener;

import androidx.annotation.Nullable;

public class MagtekControllerFactory implements TerminalControllerFactory {

    @Nullable
    @Override
    public TerminalType[] getSupportedTerminalTypes() {
        return new TerminalType[] {TerminalType.MAGTEK_ADYNAMO};
    }

    @Nullable
    @Override
    public ConnectionType[] getSupportedConnectionTypes(TerminalType terminalType)
            throws IllegalArgumentException {
        if (terminalType == TerminalType.MAGTEK_ADYNAMO) {
            return new ConnectionType[] {ConnectionType.AUDIO_JACK};
        } else {
            throw new IllegalArgumentException(
                    "getSupportedConnectionTypes() called with unsupported TerminalType.");
        }
    }

    @Nullable
    @Override
    public TerminalController create(Context context, TerminalConfiguration terminalConfiguration,
            TransactionConfiguration transactionConfiguration, TerminalListener listener)
            throws IllegalArgumentException {
        // TODO: Add any necessary pre-condition checks once devices are available for testing.
        return new MagtekController(context, terminalConfiguration, transactionConfiguration,
                listener);
    }
}
