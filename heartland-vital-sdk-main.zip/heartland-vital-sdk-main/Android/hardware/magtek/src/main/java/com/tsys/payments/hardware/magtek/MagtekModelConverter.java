package com.tsys.payments.hardware.magtek;

import com.magtek.mobile.android.mtlib.MTSCRA;
import com.tsys.payments.hardware.magtek.models.MagtekCardData;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardDataSourceType;

import androidx.annotation.NonNull;

/**
 * Handle conversion between data supplied by Magtek SDK to format needed for GlobalMobileSDK
 */
class MagtekModelConverter {

    static CardData magtekCardDataToSDKCardData(MagtekCardData magtekCardData) {
        CardData cardData = new CardData();
        cardData.setCardDataSource(CardDataSourceType.MSR);

        if (magtekCardData != null) {
            cardData.setTrack1(magtekCardData.getTrack1Data());
            cardData.setTrack2(magtekCardData.getTrack2Data());
            cardData.setKsn(magtekCardData.getKsn());
            cardData.setCvv2(magtekCardData.getSecurityCode());
            cardData.setPan(magtekCardData.getMaskedPan());
            cardData.setCardholderName(magtekCardData.getCardholderName());
            cardData.setExpirationDate(
                    magtekCardData.getExpirationMonth() + magtekCardData.getExpirationYear());
        }

        return cardData;
    }
}
