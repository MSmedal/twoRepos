package com.tsys.payments.hardware.magtek.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;

import com.magtek.mobile.android.mtlib.MTConnectionType;

import androidx.annotation.NonNull;

public final class HeadsetBroadcastReceiver extends BroadcastReceiver {

    private Callbacks mCallbacks;

    public HeadsetBroadcastReceiver(@NonNull Callbacks callbacks) {
        mCallbacks = callbacks;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if ((action.compareTo(Intent.ACTION_HEADSET_PLUG)) == 0) {

            int headsetState = intent.getIntExtra("state", 0);
            int hasMicrophone = intent.getIntExtra("microphone", 0);// get

            if ((headsetState == 1) && (hasMicrophone == 1)) {
                mCallbacks.onHeadsetDetected();
            } else {
                mCallbacks.onHeadsetRemoved(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
            }
        }
    }

    public interface Callbacks {
        void onHeadsetDetected();

        void onHeadsetRemoved(String headsetIntentAction);
    }
}
