package com.tsys.payments.hardware.magtek;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.magtek.mobile.android.mtlib.MTCardDataState;
import com.magtek.mobile.android.mtlib.MTConnectionState;
import com.magtek.mobile.android.mtlib.MTConnectionType;
import com.magtek.mobile.android.mtlib.MTSCRA;
import com.magtek.mobile.android.mtlib.MTSCRAEvent;
import com.tsys.payments.hardware.magtek.models.MagtekCardData;
import com.tsys.payments.hardware.magtek.receivers.HeadsetBroadcastReceiver;
import com.tsys.payments.hardware.magtek.receivers.NoisyAudioStreamReceiver;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.EncryptionType;
import com.tsys.payments.library.enums.ErrorType;
import com.tsys.payments.library.enums.TerminalError;
import com.tsys.payments.library.enums.TerminalSettingType;
import com.tsys.payments.library.enums.TerminalUpdateType;
import com.tsys.payments.library.exceptions.Error;
import com.tsys.payments.library.terminal.AvailableVersionsListener;
import com.tsys.payments.library.terminal.TerminalController;
import com.tsys.payments.library.terminal.TerminalListener;
import com.tsys.payments.library.terminal.TerminalReadSettingListener;
import com.tsys.payments.library.terminal.TerminalUpdateSettingListener;
import com.tsys.payments.library.terminal.UpdateListener;
import com.tsys.payments.library.terminal.domain.TerminalInteractionRequest;
import com.tsys.payments.library.terminal.domain.TerminalInteractionResult;
import com.tsys.payments.library.terminal.domain.TerminalRequest;
import com.tsys.payments.library.terminal.domain.TerminalResponse;
import com.tsys.payments.library.terminal.enums.TerminalAction;
import com.tsys.payments.library.terminal.enums.TerminalInteractionType;
import com.tsys.payments.library.terminal.enums.TerminalStatus;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

class MagtekController implements TerminalController {
    private static final String TAG = MagtekController.class.getSimpleName();

    private static final String SUCCESSFUL_TRACK_READ = "000002";
    private static final String ENCRYPTION_TYPE_TDES = "1";
    private static final int TRACK_1_DATA_MIN_LENGTH = 21;
    private static final int CARD_EXP_DATE_LENGTH = 4;

    private Context mContext;
    private MTSCRA mMtscra;
    private Handler mSCRADataHandler = new Handler(new SCRAHandlerCallback());
    private MTConnectionType mConnectionType = MTConnectionType.Audio;

    private TerminalListener mTerminalListener;
    private TerminalConfiguration mTerminalConfiguration;
    private TerminalRequest mTerminalRequest;
    private MagtekCardData mMagtekCardData;

    private int mIntCurrentVolume;
    private boolean mMaxVolumeSet;
    private boolean mHeadsetReady;
    private boolean mConnected;
    private AtomicBoolean mDeviceInitializationInProgress = new AtomicBoolean();

    private boolean mUserConfirmationForHostProcessingEnabled;

    private MagtekConfigurationManager mConfigurationManager;

    private HeadsetBroadcastReceiver mHeadsetBroadcastReceiver;
    private NoisyAudioStreamReceiver mNoisyAudioStreamReceiver;
    private Set<BroadcastReceiver> mRegisteredReceivers = new HashSet<>(2);
    private HeadsetBroadcastReceiver.Callbacks mHeadsetReceiverCallbacks =
            new HeadsetBroadcastReceiver.Callbacks() {
                @Override
                public void onHeadsetDetected() {
                    mHeadsetReady = true;
                    if (!mMtscra.isDeviceConnected()) {
                        openDevice();
                    }
                }

                @Override
                public void onHeadsetRemoved(String headsetIntentAction) {
                    minVolume();
                    if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(headsetIntentAction)) {
                        if (mConnectionType == MTConnectionType.Audio) {
                            if (mMtscra.isDeviceConnected()) {
                                closeDevice();
                            }
                        }
                    }
                }
            };

    private NoisyAudioStreamReceiver.Callbacks mNoisyAudioCallbacks =
            new NoisyAudioStreamReceiver.Callbacks() {
                @Override
                public void onDeviceUnplugged() {
                    if (mConnectionType == MTConnectionType.Audio) {
                        if (mMtscra.isDeviceConnected()) {
                            callbackOnTerminalDisconnected();
                            minVolume();
                            closeDevice();
                        }
                    }
                }
            };

    private TerminalInteractionRequest mHostProcessingRequest;

    MagtekController(@NonNull Context context, @NonNull TerminalConfiguration terminalConfiguration,
            @NonNull TransactionConfiguration transactionConfiguration,
            @NonNull TerminalListener listener) {
        mTerminalListener = listener;
        mContext = context;
        mMtscra = new MTSCRA(context.getApplicationContext(), mSCRADataHandler);
        mIntCurrentVolume = 0;
        mTerminalConfiguration = terminalConfiguration;
        mUserConfirmationForHostProcessingEnabled =
                transactionConfiguration.isUserConfirmationForHostProcessingEnabled();
        mMtscra.clearBuffers();

        mConfigurationManager = new MagtekConfigurationManager(mMtscra, mContext,
                new MagtekConfigurationManager.Callbacks() {
                    @Override
                    public void onComplete() {
                        Timber.d("Terminal configuration complete.");
                    }

                    @Override
                    public void onError() {
                        Timber.e(
                                "Terminal could not be configured. Ensure that network connectivity is available.");
                        callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                                "Terminal could not be configured. Ensure that network connectivity is available.");
                    }
                });

        mHeadsetBroadcastReceiver = new HeadsetBroadcastReceiver(mHeadsetReceiverCallbacks);
        mNoisyAudioStreamReceiver =
                new NoisyAudioStreamReceiver(mMtscra, mConnectionType, mNoisyAudioCallbacks);
        mContext.registerReceiver(mHeadsetBroadcastReceiver,
                new IntentFilter(Intent.ACTION_HEADSET_PLUG));
        mContext.registerReceiver(mNoisyAudioStreamReceiver, new IntentFilter(
                AudioManager.ACTION_AUDIO_BECOMING_NOISY));

        mRegisteredReceivers.add(mHeadsetBroadcastReceiver);
        mRegisteredReceivers.add(mNoisyAudioStreamReceiver);
    }

    @Override
    public void connect() {
        Timber.d("connect() called");
        if (mDeviceInitializationInProgress.get()) {
            Timber.w("Device initialization is in progress. Please wait.");
            return;
        }
        if (mMtscra != null &&
                !mMtscra.isDeviceConnected()) {
            if (mHeadsetReady) {
                openDevice();
            } else {
                Timber.w("Terminal should be plugged in to continue connection.");
            }
        }
    }

    private void openDevice() {
        Timber.d("openDevice() called");
        if (mDeviceInitializationInProgress.get()) {
            Timber.d("Device opening in progress...");
            return;
        }

        if (mMtscra != null) {
            mDeviceInitializationInProgress.set(true);
            mMtscra.setConnectionType(mConnectionType);
            if (!mConfigurationManager.isConfigurationComplete()) {
                mConfigurationManager.startConfiguration();
            } else {
                // A Looper must be created if there is not one. The mMtsrca.openDevice() call
                // spawns a Handler and requires that a Looper is setup on the thread that calls it.
                if (Looper.myLooper() == null) {
                    Looper.prepare();
                }
                mMtscra.openDevice();
            }
        }
    }

    private void closeDevice() {
        Timber.d("closeDevice() called");
        if (mMtscra != null) {
            mMtscra.closeDevice();
        }
    }

    @Override
    public void sendRequest(TerminalRequest terminalRequest) {
        mTerminalRequest = terminalRequest;
        TerminalAction action = mTerminalRequest.getTerminalAction();
        switch (action) {
            case SETUP:
                TerminalResponse response = new TerminalResponse(TerminalAction.SETUP);
                callbackOnTerminalResponse(response);
                break;
            case INFO:
                mTerminalRequest = null;
                if (mConnected) {
                    callbackOnTerminalInfo(getDefaultTerminalInfo());
                } else {
                    Timber.e("Terminal must be connected in order to retrieve info");
                    callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                            "The terminal is not connected.");
                }
                break;
            case TENDER_GOODS:
            case TENDER_SERVICES:
            case TENDER_REFUND:
                handleStartTransaction();
                break;
        }
    }

    private void handleStartTransaction() {
        Timber.d("handleStartTransaction() called");
        if (mConnected) {
            callbackOnTerminalStatusUpdated(TerminalStatus.WAITING_FOR_CARD);
        } else {
            callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                    "Device is disconnected. Cannot proceed with transaction.");
        }
    }

    @Override
    public void sendTerminalInteractionResult(TerminalInteractionResult terminalInteractionResult) {
        Timber.d("sendTerminalInteractionResult() called with terminalInteractionResult=%s",
                terminalInteractionResult);
        if (terminalInteractionResult.getInteractionType() ==
                TerminalInteractionType.REQUEST_PROCEED_HOST_PROCESSING
                && terminalInteractionResult.getContinueHostProcessingConfirmed()) {
            callbackOnTerminalInteractionRequest(mHostProcessingRequest);
        } else {
            Timber.w("Unsupported TerminalInteractionResult type=%s", terminalInteractionResult);
        }
    }

    @Override
    public void cancel() {
        Timber.d("cancel() called");
        mTerminalRequest = null;
        mMtscra.closeDevice();
        mMtscra.clearBuffers();
    }

    @Override
    public void disconnect() {
        Timber.d("disconnected() called");
        mTerminalRequest = null;
        mMtscra.closeDevice();
        mMtscra.clearBuffers();

        if (mRegisteredReceivers.contains(mHeadsetBroadcastReceiver)) {
            mContext.unregisterReceiver(mHeadsetBroadcastReceiver);
            mRegisteredReceivers.remove(mHeadsetBroadcastReceiver);
        }
        if (mRegisteredReceivers.contains(mNoisyAudioStreamReceiver)) {
            mContext.unregisterReceiver(mNoisyAudioStreamReceiver);
            mRegisteredReceivers.remove(mNoisyAudioStreamReceiver);
        }
    }

    @Override
    public void updateTerminalSetting(TerminalSettingType terminalSettingsType, String terminalSettingsValue,
            TerminalUpdateSettingListener terminalUpdateSettingListener) {
        Timber.d("updateTerminalSetting() called but not supported by %s.", TAG);

        if (terminalUpdateSettingListener != null) {
            terminalUpdateSettingListener.onError(new Error() {
                @Override
                public ErrorType getType() {
                    return ErrorType.TERMINAL_ERROR;
                }

                @Override
                public String getMessage() {
                    return "Update terminal settings not supported.";
                }
            });
        }
    }

    @Override
    public void readTerminalSetting(TerminalSettingType terminalSettingsType,
            TerminalReadSettingListener terminalReadSettingListener) {
        Timber.d("readTerminalSetting() called but not supported by %s.", TAG);

        if (terminalReadSettingListener != null) {
            terminalReadSettingListener.onError(new Error() {
                @Override
                public ErrorType getType() {
                    return ErrorType.TERMINAL_ERROR;
                }

                @Override
                public String getMessage() {
                    return "Read terminal settings not supported.";
                }
            });
        }
    }

    @Override
    public void getAvailableTerminalVersions(@NonNull TerminalUpdateType terminalUpdateType,
            @Nullable Map<String, String> credentials, @NonNull AvailableVersionsListener availableVersionsListener) {
        Timber.d("getAvailableTerminalVersions() called but not supported by %s.", TAG);
         availableVersionsListener.onTerminalVersionInfoError(TerminalError.INVALID_REQUEST,"Retrieving terminal " +
                 "versions is not supported");
    }

    @Override
    public void updateTerminal(@NonNull TerminalUpdateType terminalUpdateType,
            @Nullable Map<String, String> credentials, @Nullable String version,
            @NonNull UpdateListener updateListener) {
        Timber.d("updateTerminal() called but not supported by %s", TAG);
         updateListener.onTerminalUpdateError(TerminalError.INVALID_REQUEST,"Terminal update " +
                    "functionality is not supported");

    }

    /**
     * Converts card data obtained from the {@link MagtekController} via a swipe to a {@link
     * MagtekCardData} intermediate card information object used by the {@link MagtekController}.
     */
    @Nullable
    private MagtekCardData convertTerminalDataMapToCardData(@NonNull MTSCRA magtekReader) {
        MagtekCardData cardData = new MagtekCardData();

        boolean trackDecodeSuccess = true;

        String status = magtekReader.getTrackDecodeStatus();

        if (status != null && !status.equals(SUCCESSFUL_TRACK_READ)) {
            trackDecodeSuccess = false;
        }

        String element = magtekReader.getCardName();
        cardData.setCardholderName(element == null ? "" : element);

        // Extract cared expiration date
        element = magtekReader.getCardExpDate();
        if (element != null && element.length() == CARD_EXP_DATE_LENGTH) {
            cardData.setExpirationMonth((String)element.subSequence(2, CARD_EXP_DATE_LENGTH));
            cardData.setExpirationYear((String)element.subSequence(0, 2));
        } else {
            trackDecodeSuccess = false;
        }

        // Extract PAN
        String iin = magtekReader.getCardIIN() != null ? magtekReader.getCardIIN() : "";
        String last4 = magtekReader.getCardLast4() != null ? magtekReader.getCardLast4() : "";
        int panLength = magtekReader.getCardPANLength();

        String maskedCard = iin;
        for (int i = 0; i < panLength - last4.length() - iin.length(); i++) {
            maskedCard += "*";
        }
        maskedCard += last4;
        cardData.setMaskedPan(maskedCard);

        element = magtekReader.getKSN();
        if (element != null) {
            cardData.setKsn(element);
        } else {
            trackDecodeSuccess = false;
        }

        // Extract track data
        element = magtekReader.getTrack1();
        if (element != null && element.length() >= TRACK_1_DATA_MIN_LENGTH) {
            cardData.setTrack1Data(element);
        } else {
            trackDecodeSuccess = false;
            cardData.setTrack1Data("");
        }

        element = magtekReader.getTrack2();
        cardData.setTrack2Data(element == null ? "" : element);

        element = magtekReader.getCapMagStripeEncryption();
        if (element != null && element.equals(ENCRYPTION_TYPE_TDES)) {
            cardData.setEncryptionType(EncryptionType.TDES);
        } else {
            cardData.setEncryptionType(EncryptionType.NONE);
        }
        cardData.setBadRead(!trackDecodeSuccess);

        return cardData;
    }

    private void handleDeviceConnectionStateChanged(MTConnectionState state) {
        Timber.d("handleDeviceConnectionStateChanged() called with state->%s", state.name());

        switch (state) {
            case Connected:
                if (mHeadsetReady) {
                    mDeviceInitializationInProgress.set(false);
                    callbackOnTerminalConnected();
                    maxVolume();
                } else {
                    minVolume();
                }
                break;
            case Disconnected:
                callbackOnTerminalDisconnected();
                minVolume();
                break;
        }
    }

    private void handleCardDataStateChanged(MTCardDataState state) {
        Timber.d("handleCardDataStateChanged() called with state->%s", state);
        // card swiped
        switch (state) {
            case DataNotReady:
            case DataReady:
                break;
            case DataError:
                callbackOnTerminalStatusUpdated(TerminalStatus.CARD_READ_ERROR);
                break;
        }
    }

    private void handleCardDataReceived() {
        Timber.d("handleCardDataReceived() called");

        if (mTerminalRequest != null) {
            mMagtekCardData = convertTerminalDataMapToCardData(mMtscra);

            if (mMagtekCardData != null && !mMagtekCardData.isBadRead()) {
                callbackOnTerminalStatusUpdated(TerminalStatus.CARD_DETECTED);

                CardData sdkCardData =
                        MagtekModelConverter.magtekCardDataToSDKCardData(mMagtekCardData);
                TerminalInteractionRequest request = new TerminalInteractionRequest(
                        TerminalInteractionType.HOST_PROCESSING);
                request.setCardData(sdkCardData);
                if (!mUserConfirmationForHostProcessingEnabled) {
                    callbackOnTerminalInteractionRequest(request);
                } else {
                    mHostProcessingRequest = request;
                    TerminalInteractionRequest terminalInteractionRequest =
                            new TerminalInteractionRequest(
                                    TerminalInteractionType.REQUEST_PROCEED_HOST_PROCESSING);
                    CardData cardData = new CardData();
                    cardData.setCardDataSource(CardDataSourceType.MSR);
                    terminalInteractionRequest.setCardData(cardData);
                    callbackOnTerminalInteractionRequest(terminalInteractionRequest);
                }
            } else {
                Timber.d("Card read failure");
                callbackOnTerminalStatusUpdated(TerminalStatus.CARD_READ_ERROR);
            }
        } else {
            Timber.w("Swipe detected but a transaction is not in progress.");
        }
    }

    //region Volume Management
    private void maxVolume() {
        Timber.d("maxVolume() called");
        mMaxVolumeSet = true;

        final AudioManager mAudioMgr = (AudioManager)mContext
                .getSystemService(Context.AUDIO_SERVICE);
        mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC,
                mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI);
    }

    private void minVolume() {
        Timber.d("minVolume() called");
        final AudioManager mAudioMgr = (AudioManager)mContext
                .getSystemService(Context.AUDIO_SERVICE);
        if (mMaxVolumeSet || mAudioMgr.getStreamVolume(AudioManager.STREAM_MUSIC) ==
                mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)) {
            mMaxVolumeSet = false;
            mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, mIntCurrentVolume,
                    AudioManager.FLAG_SHOW_UI);
        }
    }
    //endregion

    private TerminalInfo getDefaultTerminalInfo() {
        TerminalInfo info = new TerminalInfo();
        info.setTerminalType(mTerminalConfiguration.getTerminalType());
        info.setBatteryLevel(1);
        return info;
    }

    //region TerminalListener callbacks.
    private void callbackOnTerminalDisconnected() {
        Timber.d("callbackOnTerminalDisconnected() called.");
        mConnected = false;
        mTerminalListener.onDisconnected();
    }

    private void callbackOnTerminalConnected() {
        mConnected = true;
        Timber.d("callbackOnTerminalConnected() called.");
        mTerminalListener.onConnected(getDefaultTerminalInfo());
    }

    private void callbackOnTerminalInfo(final TerminalInfo terminalInfo) {
        Timber.d("callbackOnTerminalInfo() called with: terminalInfo=[%s]",
                terminalInfo);
        mTerminalListener.onTerminalInfo(terminalInfo);
    }

    private void callbackOnTerminalStatusUpdated(final TerminalStatus status) {
        Timber.d("callbackOnTerminalStatusUpdated() called with: status=[%s]", status);
        mTerminalListener.onTerminalStatusUpdate(status);
    }

    private void callbackOnTerminalInteractionRequest(final TerminalInteractionRequest request) {
        Timber.d("callbackOnTerminalInteractionRequest() called with: request=[%s]",
                request);
        mTerminalListener.onTerminalInteractionRequested(request);
    }

    private void callbackOnTerminalResponse(final TerminalResponse terminalResponse) {
        Timber.d("callbackOnTerminalResponse() called with: terminalResponse=[%s]",
                terminalResponse);
        mTerminalListener.onTerminalResponseReceived(terminalResponse);
    }

    private void callbackOnTerminalInteractionError(final TerminalError errorType,
            final String error) {
        Timber.d("callbackOnTerminalInteractionError() called with: errorType=[%s]",
                errorType);
        mTerminalListener.onError(errorType, error);
    }
    //endregion

    private class SCRAHandlerCallback implements Handler.Callback {
        public boolean handleMessage(Message msg) {
            Timber.d("*** Callback %s", msg.what);
            switch (msg.what) {
                case MTSCRAEvent.OnDeviceConnectionStateChanged:
                    handleDeviceConnectionStateChanged((MTConnectionState)msg.obj);
                    break;
                case MTSCRAEvent.OnCardDataStateChanged:
                    handleCardDataStateChanged((MTCardDataState)msg.obj);
                    break;
                case MTSCRAEvent.OnDataReceived:
                    handleCardDataReceived();
                    break;
            }

            return true;
        }
    }
}
