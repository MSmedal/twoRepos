package com.tsys.payments.hardware.magtek.models;

import com.tsys.payments.library.enums.EncryptionType;

import java.util.Objects;

import androidx.annotation.Nullable;

public class MagtekCardData {
    @Nullable
    private String mCardholderName;

    @Nullable
    private String mExpirationMonth;

    @Nullable
    private String mExpirationYear;

    @Nullable
    private String mMaskedPan;

    @Nullable
    private String mKsn;

    @Nullable
    private String mTrack1Data;

    @Nullable
    private String mTrack2Data;

    @Nullable
    private String mSecurityCode;

    @Nullable
    private EncryptionType mEncryptionType;

    private boolean mBadRead;

    @Nullable
    public String getCardholderName() {
        return mCardholderName;
    }

    public void setCardholderName(@Nullable String cardholderName) {
        mCardholderName = cardholderName;
    }

    @Nullable
    public String getExpirationMonth() {
        return mExpirationMonth;
    }

    public void setExpirationMonth(@Nullable String expirationMonth) {
        mExpirationMonth = expirationMonth;
    }

    @Nullable
    public String getExpirationYear() {
        return mExpirationYear;
    }

    public void setExpirationYear(@Nullable String expirationYear) {
        mExpirationYear = expirationYear;
    }

    @Nullable
    public String getMaskedPan() {
        return mMaskedPan;
    }

    public void setMaskedPan(@Nullable String maskedPan) {
        mMaskedPan = maskedPan;
    }

    @Nullable
    public String getKsn() {
        return mKsn;
    }

    public void setKsn(@Nullable String ksn) {
        mKsn = ksn;
    }

    @Nullable
    public String getTrack1Data() {
        return mTrack1Data;
    }

    public void setTrack1Data(@Nullable String track1Data) {
        mTrack1Data = track1Data;
    }

    @Nullable
    public String getTrack2Data() {
        return mTrack2Data;
    }

    public void setTrack2Data(@Nullable String track2Data) {
        mTrack2Data = track2Data;
    }

    @Nullable
    public EncryptionType getEncryptionType() {
        return mEncryptionType;
    }

    public void setEncryptionType(@Nullable EncryptionType encryptionType) {
        mEncryptionType = encryptionType;
    }

    public boolean isBadRead() {
        return mBadRead;
    }

    public void setBadRead(boolean badRead) {
        mBadRead = badRead;
    }

    @Nullable
    public String getSecurityCode() {
        return mSecurityCode;
    }

    public void setSecurityCode(@Nullable String securityCode) {
        mSecurityCode = securityCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MagtekCardData that = (MagtekCardData)o;
        return mBadRead == that.mBadRead &&
                Objects.equals(mCardholderName, that.mCardholderName) &&
                Objects.equals(mExpirationMonth, that.mExpirationMonth) &&
                Objects.equals(mExpirationYear, that.mExpirationYear) &&
                Objects.equals(mMaskedPan, that.mMaskedPan) &&
                Objects.equals(mKsn, that.mKsn) &&
                Objects.equals(mTrack1Data, that.mTrack1Data) &&
                Objects.equals(mTrack2Data, that.mTrack2Data) &&
                Objects.equals(mSecurityCode, that.mSecurityCode) &&
                mEncryptionType == that.mEncryptionType;
    }

    @Override
    public int hashCode() {
        return Objects
                .hash(mCardholderName, mExpirationMonth, mExpirationYear, mMaskedPan, mKsn,
                        mTrack1Data,
                        mTrack2Data, mSecurityCode, mEncryptionType, mBadRead);
    }

    @Override
    public String toString() {
        return "MagtekCardData{" +
                "mCardholderName='" + mCardholderName + '\'' +
                ", mExpirationMonth='" + mExpirationMonth + '\'' +
                ", mExpirationYear='" + mExpirationYear + '\'' +
                ", mMaskedPan='" + mMaskedPan + '\'' +
                ", mKsn='" + mKsn + '\'' +
                ", mTrack1Data='" + mTrack1Data + '\'' +
                ", mTrack2Data='" + mTrack2Data + '\'' +
                ", mSecurityCode='" + mSecurityCode + '\'' +
                ", mEncryptionType=" + mEncryptionType +
                ", mBadRead=" + mBadRead +
                '}';
    }
}
