package com.tsys.payments.hardware.magtek;

import android.content.Context;
import android.text.TextUtils;

import com.magtek.mobile.android.mtlib.MTSCRA;
import com.magtek.mobile.android.mtlib.MTSCRAException;
import com.magtek.mobile.android.mtlib.config.MTSCRAConfig;
import com.magtek.mobile.android.mtlib.config.ProcessMessageResponse;
import com.magtek.mobile.android.mtlib.config.SCRAConfigurationDeviceInfo;
import com.tsys.payments.library.terminal.domain.TerminalRequest;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

class MagtekConfigurationManager {
    private static final String PLATFORM_ANDROID = "Android";
    private static final int CONFIGWS_READERTYPE = 0;
    private static final String CONFIGWS_USERNAME = "magtek";
    private static final String CONFIGWS_PASSWORD = "p@ssword";
    private static final int CONFIGWS_TIMEOUT = 10000;
    private static final String SCRA_CONFIG_VERSION = "101.22";
    private static final String CONFIG_FILE = "MTSCRAAudioConfig.cfg";
    private static final String CONFIGWS_URL = "https://deviceconfig.magensa.net/service.asmx";

    private Context mContext;
    private MTSCRA mMagtekDriver;
    private String mLocalConfig;
    private boolean mConfigurationComplete;

    private Callbacks mCallbacks;

    MagtekConfigurationManager(@NonNull MTSCRA driver, @NonNull Context context,
            Callbacks callbacks) {
        mMagtekDriver = driver;
        mContext = context;
        mCallbacks = callbacks;
    }

    void startConfiguration() {
        Timber.d("startConfiguration() called");
        loadAudioConfigFromFile();
    }

    boolean isConfigurationComplete() {
        return mConfigurationComplete;
    }

    private void loadAudioConfigFromFile() {
        String xmlConfig = getAudioConfigFromFile();

        if (!TextUtils.isEmpty(xmlConfig)) {
            mLocalConfig = xmlConfig;
            mConfigurationComplete = true;
            onAudioConfigReceived(xmlConfig);
        } else {
            loadAudioConfigFromServer();
        }
    }

    private String getAudioConfigFromFile() {
        String config = "";
        try {
            config = readSettings(mContext.getApplicationContext(), CONFIG_FILE);
            if (config == null) {
                config = "";
            }
        } catch (Exception ex) {
            Timber.e(ex);
        }
        return config;
    }

    private void onAudioConfigReceived(String xmlConfig) {
        Timber.d("onAudioConfigReceived() called with xmlConfig=>%s", xmlConfig);
        try {
            if (mMagtekDriver != null) {
                String config = "";
                try {
                    if (!TextUtils.isEmpty(xmlConfig)) {
                        String model = android.os.Build.MODEL.toUpperCase();
                        Timber.d("*** Model=%s", model);
                        MTSCRAConfig scraConfig = new MTSCRAConfig(SCRA_CONFIG_VERSION);

                        ProcessMessageResponse configurationResponse =
                                scraConfig.getConfigurationResponse(xmlConfig);

                        Timber.d("*** ProcessMessageResponse Count =%d",
                                configurationResponse.getPropertyCount());

                        config = scraConfig.getConfigurationParams(model, configurationResponse);
                    }

                    Timber.d("*** Config=%s", config);
                    if (!TextUtils.isEmpty(config)) {
                        mConfigurationComplete = true;
                        mMagtekDriver.setDeviceConfiguration(config);
                    }
                    mMagtekDriver.openDevice();
                    mCallbacks.onComplete();
                    return;
                } catch (Exception e) {
                    Timber.e(e);
                }

                // Use fallback audio config if config from file and server fail
                if (TextUtils.isEmpty(config) && TextUtils.isEmpty(mLocalConfig)) {
                    mMagtekDriver.setDeviceConfiguration(getManualAudioConfig());
                } else {
                    mCallbacks.onError();
                }
            }
        } catch (Exception e) {
            Timber.e(e);
        }
    }

    private String getManualAudioConfig() {
        String config = "";

        try {
            String model = android.os.Build.MODEL.toUpperCase();

            if (model.contains("DROID RAZR") || model.contains("XT910")) {
                config = "INPUT_SAMPLE_RATE_IN_HZ=48000,";
            } else if ((model.equals("DROID PRO")) ||
                    (model.equals("MB508")) ||
                    (model.equals("DROIDX")) ||
                    (model.equals("DROID2")) ||
                    (model.equals("MB525"))) {
                config = "INPUT_SAMPLE_RATE_IN_HZ=32000,";
            } else if ((model.equals("GT-I9300")) ||//S3 GSM Unlocked
                    (model.equals("SPH-L710")) ||//S3 Sprint
                    (model.equals("SGH-T999")) ||//S3 T-Mobile
                    (model.equals("SCH-I535")) ||//S3 Verizon
                    (model.equals("SCH-R530")) ||//S3 US Cellular
                    (model.equals("SAMSUNG-SGH-I747")) ||// S3 AT&T
                    (model.equals("M532")) ||//Fujitsu
                    (model.equals("GT-N7100")) ||//Notes 2
                    (model.equals("GT-N7105")) ||//Notes 2
                    (model.equals("SAMSUNG-SGH-I317")) ||// Notes 2
                    (model.equals("SCH-I605")) ||// Notes 2
                    (model.equals("SCH-R950")) ||// Notes 2
                    (model.equals("SGH-T889")) ||// Notes 2
                    (model.equals("SPH-L900")) ||// Notes 2
                    (model.equals("GT-P3113")))//Galaxy Tab 2, 7.0
            {
                config = "INPUT_AUDIO_SOURCE=VRECOG,";
            } else if ((model.equals("XT907"))) {
                config = "INPUT_WAVE_FORM=0,";
            } else {
                config = "INPUT_AUDIO_SOURCE=VRECOG,";
            }
        } catch (Exception e) {
            Timber.e(e);
        }

        return config;
    }

    private void saveAudioConfigToFile(String xmlConfig) {
        Timber.d("saveAudioConfigToFile() called with xmlConfig=>%s", xmlConfig);
        try {
            writeSettings(mContext.getApplicationContext(), xmlConfig, CONFIG_FILE);
        } catch (Exception e) {
            Timber.e(e);
        }
    }

    private void loadAudioConfigFromServer() {
        Timber.d("loadAudioConfigFromServer() called");
        String xmlConfig = "";
        String model = android.os.Build.MODEL.toUpperCase();

        Timber.d("*** Model=%s", model);

        MTSCRAConfig scraConfig = new MTSCRAConfig(SCRA_CONFIG_VERSION);

        SCRAConfigurationDeviceInfo deviceInfo = new SCRAConfigurationDeviceInfo();
        deviceInfo.setProperty(SCRAConfigurationDeviceInfo.PROP_PLATFORM, PLATFORM_ANDROID);
        deviceInfo.setProperty(SCRAConfigurationDeviceInfo.PROP_MODEL, model);

        try {
            xmlConfig = scraConfig.getConfigurationXML(CONFIGWS_USERNAME, CONFIGWS_PASSWORD,
                    CONFIGWS_READERTYPE, deviceInfo,
                    CONFIGWS_URL, CONFIGWS_TIMEOUT);
        } catch (MTSCRAException e) {
            Timber.e(e);
        }

        Timber.d("*** XML Config=%s", xmlConfig);

        saveAudioConfigToFile(xmlConfig);
        onAudioConfigReceived(xmlConfig);
    }

    @Nullable
    private String readSettings(Context context, String file) throws IOException {
        Timber.d("readSettings() called");
        FileInputStream fis = context.openFileInput(file);
        InputStreamReader isr = new InputStreamReader(fis);
        String data = null;
        char[] inputBuffer = new char[fis.available()];
        int bytesRead = isr.read(inputBuffer);
        if (bytesRead > 0) {
            data = new String(inputBuffer);
        }
        isr.close();
        fis.close();
        return data;
    }

    private void writeSettings(Context context, String data, String file) throws IOException {
        Timber.d("writeSettings() called");
        FileOutputStream fos = context.openFileOutput(file, Context.MODE_PRIVATE);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        osw.write(data);
        osw.close();
        fos.close();
    }

    public interface Callbacks {
        void onComplete();

        void onError();
    }
}
