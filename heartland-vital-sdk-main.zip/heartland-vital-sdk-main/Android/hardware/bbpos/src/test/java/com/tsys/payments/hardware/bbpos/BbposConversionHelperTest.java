package com.tsys.payments.hardware.bbpos;

import com.bbpos.bbdevice.BBDeviceController;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CurrencyCode;
import com.tsys.payments.library.terminal.enums.TerminalAction;
import com.tsys.payments.library.tlv.ConstructedTlvObject;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvObjectBuilder;
import com.tsys.payments.library.utils.ByteUtils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(PowerMockRunner.class)
public class BbposConversionHelperTest {

    @Test
    public void test_getFormattedCurrencyCodeSupportsUsd() {
        final String expectedOutput = "0840";
        String formattedCurrencyCode =
                BbposConversionHelper.getFormattedCurrencyCode(CurrencyCode.USD);
        assertEquals(expectedOutput, formattedCurrencyCode);
    }

    @Test
    public void test_conversionHelperSupportsGoodsTransactions() {
        BBDeviceController.TransactionType transactionType =
                BbposConversionHelper.getTransactionType(TerminalAction.TENDER_GOODS);
        assertEquals(transactionType, BBDeviceController.TransactionType.GOODS);
    }

    @Test
    public void test_conversionHelperSupportsServicesTransactions() {
        BBDeviceController.TransactionType transactionType =
                BbposConversionHelper.getTransactionType(TerminalAction.TENDER_SERVICES);
        assertEquals(transactionType, BBDeviceController.TransactionType.SERVICES);
    }

    @Test
    public void test_conversionHelperSupportsRefundTransactions() {
        BBDeviceController.TransactionType transactionType =
                BbposConversionHelper.getTransactionType(TerminalAction.TENDER_REFUND);
        assertEquals(BBDeviceController.TransactionType.REFUND, transactionType);
    }

    @Test
    public void test_getCardDataSourceTypeFromTlv_handlesContactEmv() {
        byte[] entryMode =
                ByteUtils.hexStringToByteArray(BbposConversionHelper.PAN_ENTRY_MODE_CONTACT_EMV);
        assertNotNull(entryMode);

        TlvObject posEntryMode = TlvObjectBuilder
                .create(EmvTagDescriptor.POS_ENTRY_MODE)
                .setValue(entryMode)
                .build();
        assertEquals(CardDataSourceType.SCR,
                BbposConversionHelper.getCardDataSourceTypeFromTlv(posEntryMode));
    }

    @Test
    public void test_getCardDataSourceTypeFromTlv_handlesContactlessEmv() {
        byte[] entryMode = ByteUtils
                .hexStringToByteArray(BbposConversionHelper.PAN_ENTRY_MODE_CONTACTLESS_EMV);
        assertNotNull(entryMode);

        TlvObject posEntryMode = TlvObjectBuilder
                .create(EmvTagDescriptor.POS_ENTRY_MODE)
                .setValue(entryMode)
                .build();
        assertEquals(CardDataSourceType.CONTACTLESS_EMV,
                BbposConversionHelper.getCardDataSourceTypeFromTlv(posEntryMode));
    }

    @Test
    public void test_getCardDataSourceTypeFromTlv_handlesContactlessMsr() {
        byte[] entryMode = ByteUtils
                .hexStringToByteArray(BbposConversionHelper.PAN_ENTRY_MODE_CONTACTLESS_MSR);
        assertNotNull(entryMode);

        TlvObject posEntryMode = TlvObjectBuilder
                .create(EmvTagDescriptor.POS_ENTRY_MODE)
                .setValue(entryMode)
                .build();
        assertEquals(CardDataSourceType.CONTACTLESS_MSR,
                BbposConversionHelper.getCardDataSourceTypeFromTlv(posEntryMode));
    }

    @Test
    public void test_contactless_extractMaskedPanFromTlv() {
        final String expectedMaskedPan = "414709FFFFFF7159";
        final String contactlessTvData =
                "C00A0001064680407320009AC408414709FFFFFF7159C2820180968561773F8AD1E1AFB40F0A617AD6" +
                        "4FDD839B0B6F9F7391AF7B0CF54BB85120509F14E3C1F9FE2396D34C6EB8D60C3918C6841B" +
                        "0207B0B743654343DF77B382D62260A23C21E49184BAFCDD36D9A2ADA9D17FCD540DBE970D" +
                        "D0E2F26EC8D5BC7F175D35E6280586C3C3E3319A3E6E7C4BDD5BF11B03C28726819BFAA060" +
                        "F2AAB8DEA1913DCB9A42A81367AD70FAA421C46372C00044A14480E3098DA5866C840EB942" +
                        "B368CC45A5025886B5FEF64776C28F37D790264A8884499E0483F097CD3543DFD032E78A7B" +
                        "5C497418C460B711C6F1683091F88A09921C39BF9B8634E97F7FEAFDDA6CC06F366BC84E83" +
                        "E871E7E01C0D218D3212EB0B0D14638CE2D9CFA50473217332A1AE1B05552C735DE44BEA1B" +
                        "FDFBDBAC299C84C57DF698F3A48ADCF0DF5C692DCFBDD99AA52C47CC8C4EC67B9C048994E6" +
                        "E7AB95CD024FD2DA8DDD5241A49FB7CD4F8EB02F4F2010EDDCB807C47334C2697BBE498814" +
                        "35BE105B910DC2434C02DD8F5CD6434FF64849C7A1F6181D6493D1A8A012091926AE6EF1C7" +
                        "0AFFFF3D3F81000F80007FC81848619BA426CF79B5FC2813E13D5A77E1C8EEA1AA1EC02925" +
                        "4F07A0000000031010500B56495341204352454449545F24032404305F2A0208405F340101" +
                        "820220008407A0000000031010950500000000009A032007159B0200009C01009F02060000" +
                        "000060009F03060000000000009F0607A00000000310109F0902008C9F100706010A03A000" +
                        "009F12104341504954414C204F4E4520564953419F1A0208409F1C0831313232333334349F" +
                        "1E0831323334353637389F260889DF64768F9217C99F2701809F33036028C89F34033F0000" +
                        "9F3501219F3602018D9F37046E1EE1A69F3901079F40057E0000A0019F41030001549F6E0" +
                        "420700000DF826E0F434842323034383436303039303733DF834F0F4348423230343834363" +
                        "03039303733";

        List<TlvObject> tlvList = ConstructedTlvObject.parse(contactlessTvData);
        assertNotNull(tlvList);
        assertTrue(tlvList.size() > 0);
        String maskedPan = BbposConversionHelper.extractMaskedPanFromTlv(tlvList);
        assertEquals(expectedMaskedPan, maskedPan);
    }
}
