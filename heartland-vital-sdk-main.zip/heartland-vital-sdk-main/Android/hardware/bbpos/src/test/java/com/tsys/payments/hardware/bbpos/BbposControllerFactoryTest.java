package com.tsys.payments.hardware.bbpos;

import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.TerminalType;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(PowerMockRunner.class)
public class BbposControllerFactoryTest {

    @Test
    public void test_supportedTerminalTypeIsBbposC2X() {
        BbposControllerFactory factory = new BbposControllerFactory();
        TerminalType[] terminalTypes = factory.getSupportedTerminalTypes();
        assertNotNull(terminalTypes);
        assertEquals(terminalTypes.length, 1);
        assertEquals(terminalTypes[0], TerminalType.BBPOS_C2X);
    }

    @Test
    public void test_supportedConnectionTypeC2XIsBluetooth() {
        BbposControllerFactory factory = new BbposControllerFactory();
        ConnectionType[] connectionTypes =
                factory.getSupportedConnectionTypes(TerminalType.BBPOS_C2X);
        assertNotNull(connectionTypes);
        assertEquals(connectionTypes.length, 2);
        assertEquals(connectionTypes[0], ConnectionType.BLUETOOTH);
        assertEquals(connectionTypes[1], ConnectionType.USB);
    }
}
