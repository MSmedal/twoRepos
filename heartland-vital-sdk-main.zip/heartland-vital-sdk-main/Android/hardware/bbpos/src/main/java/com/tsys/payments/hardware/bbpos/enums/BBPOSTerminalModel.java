package com.tsys.payments.hardware.bbpos.enums;

import androidx.annotation.Nullable;

/**
 * Identifies the model for an AnywhereCommerce BBPOS Terminal. The models are identified by unique prefixes in the
 * serial numbers.
 */
public enum BBPOSTerminalModel {
    WALKER_2_0_BT("Walker 2.0 BT", new String[] {"CHB10"}),
    WALKER_C2X("Walker C2X", new String[] {"CHC2X"}),
    WALKER_C2X_BT("Walker C2X BT", new String[] {"CHB20", "CHB2A"});

    public final String friendlyName;
    public final String[] prefixes;

    BBPOSTerminalModel(String friendlyName, String[] prefixes) {
        this.friendlyName = friendlyName;
        this.prefixes = prefixes;
    }

    @Nullable
    public static BBPOSTerminalModel fromSerialNumber(@Nullable String serialNumber) {
        if (serialNumber != null) {
            for (BBPOSTerminalModel model : BBPOSTerminalModel.values()) {
                for (String prefix : model.prefixes) {
                    if (serialNumber.startsWith(prefix)) {
                        return model;
                    }
                }
            }
        }

        return null;
    }
}
