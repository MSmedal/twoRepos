package com.tsys.payments.hardware.bbpos.model;

import java.util.Objects;

import androidx.annotation.Nullable;

/**
 * Encapsulates card data returned by BBPOS payment terminal.
 */
public final class BbposCardData {
    private String mCardholderName;
    private String mEncryptedTrack1;
    private String mEncryptedTrack2;
    private String mEncryptedTrack3;
    private String mEncryptedTracks;
    private String mExpiryData;
    private String mFormatId;
    private String mKsn;
    private String mMaskedPan;
    private String mPosEntryMode;
    private String mIccData;

    @Nullable
    public String getCardholderName() {
        return mCardholderName;
    }

    public void setCardholderName(@Nullable String cardholderName) {
        mCardholderName = cardholderName;
    }

    @Nullable
    public String getEncryptedTrack1() {
        return mEncryptedTrack1;
    }

    public void setEncryptedTrack1(@Nullable String encryptedTrack1) {
        mEncryptedTrack1 = encryptedTrack1;
    }

    @Nullable
    public String getEncryptedTrack2() {
        return mEncryptedTrack2;
    }

    public void setEncryptedTrack2(@Nullable String encryptedTrack2) {
        mEncryptedTrack2 = encryptedTrack2;
    }

    @Nullable
    public String getEncryptedTrack3() {
        return mEncryptedTrack3;
    }

    public void setEncryptedTrack3(@Nullable String encryptedTrack3) {
        mEncryptedTrack3 = encryptedTrack3;
    }

    @Nullable
    public String getExpiryData() {
        return mExpiryData;
    }

    public void setExpiryData(@Nullable String expiryData) {
        mExpiryData = expiryData;
    }

    @Nullable
    public String getFormatId() {
        return mFormatId;
    }

    public void setFormatId(@Nullable String formatId) {
        mFormatId = formatId;
    }

    @Nullable
    public String getKsn() {
        return mKsn;
    }

    public void setKsn(@Nullable String ksn) {
        mKsn = ksn;
    }

    @Nullable
    public String getMaskedPan() {
        return mMaskedPan;
    }

    public void setMaskedPan(@Nullable String maskedPan) {
        mMaskedPan = maskedPan;
    }

    @Nullable
    public String getPosEntryMode() {
        return mPosEntryMode;
    }

    public void setPosEntryMode(@Nullable String posEntryMode) {
        mPosEntryMode = posEntryMode;
    }

    @Nullable
    public String getEncryptedTracks() {
        return mEncryptedTracks;
    }

    public void setEncryptedTracks(@Nullable String encryptedTracks) {
        mEncryptedTracks = encryptedTracks;
    }

    @Nullable
    public String getIccData() {
        return mIccData;
    }

    public void setIccData(@Nullable String iccData) {
        mIccData = iccData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BbposCardData that = (BbposCardData)o;
        return Objects.equals(mCardholderName, that.mCardholderName) &&
                Objects.equals(mEncryptedTrack1, that.mEncryptedTrack1) &&
                Objects.equals(mEncryptedTrack2, that.mEncryptedTrack2) &&
                Objects.equals(mEncryptedTrack3, that.mEncryptedTrack3) &&
                Objects.equals(mEncryptedTracks, that.mEncryptedTracks) &&
                Objects.equals(mExpiryData, that.mExpiryData) &&
                Objects.equals(mFormatId, that.mFormatId) &&
                Objects.equals(mKsn, that.mKsn) &&
                Objects.equals(mMaskedPan, that.mMaskedPan) &&
                Objects.equals(mPosEntryMode, that.mPosEntryMode) &&
                Objects.equals(mIccData, that.mIccData);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mCardholderName, mEncryptedTrack1, mEncryptedTrack2, mEncryptedTrack3,
                mEncryptedTracks, mExpiryData, mFormatId, mKsn, mMaskedPan, mPosEntryMode,
                mIccData);
    }

    @Override
    public String toString() {
        return "BbposCardData{" +
                "mCardholderName='" + mCardholderName + '\'' +
                ", mEncryptedTrack1='" + mEncryptedTrack1 + '\'' +
                ", mEncryptedTrack2='" + mEncryptedTrack2 + '\'' +
                ", mEncryptedTrack3='" + mEncryptedTrack3 + '\'' +
                ", mEncryptedTracks='" + mEncryptedTracks + '\'' +
                ", mExpiryData='" + mExpiryData + '\'' +
                ", mFormatId='" + mFormatId + '\'' +
                ", mKsn='" + mKsn + '\'' +
                ", mMaskedPan='" + mMaskedPan + '\'' +
                ", mPosEntryMode='" + mPosEntryMode + '\'' +
                ", mIccData='" + mIccData + '\'' +
                '}';
    }
}
