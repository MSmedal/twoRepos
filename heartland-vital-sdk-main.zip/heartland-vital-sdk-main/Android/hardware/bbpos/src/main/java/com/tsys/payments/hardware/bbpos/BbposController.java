package com.tsys.payments.hardware.bbpos;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;

import com.bbpos.bbdevice.BBDeviceController;
import com.bbpos.bbdevice.BBDeviceController.AmountInputResult;
import com.bbpos.bbdevice.BBDeviceController.ManualPanEntryType;
import com.bbpos.bbdevice.BBDeviceController.PinPadTouchEvent;
import com.bbpos.bbdevice.CAPK;
import com.bbpos.bbdevice.ota.BBDeviceControllerNotSetException;
import com.bbpos.bbdevice.ota.BBDeviceControllerNotSupportOTAException;
import com.bbpos.bbdevice.ota.BBDeviceNotConnectedException;
import com.bbpos.bbdevice.ota.BBDeviceOTAController;
import com.bbpos.bbdevice.ota.NoInternetConnectionException;
import com.bbpos.bbdevice.ota.OTAServerURLNotSetException;
import com.tsys.payments.hardware.bbpos.constants.BbposOTADefaults;
import com.tsys.payments.hardware.bbpos.constants.BbposOTAKeys;
import com.tsys.payments.hardware.bbpos.constants.Formats;
import com.tsys.payments.hardware.bbpos.constants.Keys;
import com.tsys.payments.hardware.bbpos.constants.Keys.StartEmv;
import com.tsys.payments.hardware.bbpos.enums.BBPOSTerminalModel;
import com.tsys.payments.hardware.bbpos.enums.TerminalMode;
import com.tsys.payments.hardware.bbpos.model.BbposAuthorizationData;
import com.tsys.payments.hardware.bbpos.model.BbposCardData;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CurrencyCode;
import com.tsys.payments.library.enums.ErrorType;
import com.tsys.payments.library.enums.FallbackReason;
import com.tsys.payments.library.enums.LastChipRead;
import com.tsys.payments.library.enums.TerminalError;
import com.tsys.payments.library.enums.TerminalSettingType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.enums.TerminalUpdateType;
import com.tsys.payments.library.enums.TransactionType;
import com.tsys.payments.library.exceptions.Error;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.terminal.AvailableVersionsListener;
import com.tsys.payments.library.terminal.TerminalController;
import com.tsys.payments.library.terminal.TerminalListener;
import com.tsys.payments.library.terminal.TerminalReadSettingListener;
import com.tsys.payments.library.terminal.TerminalUpdateSettingListener;
import com.tsys.payments.library.terminal.UpdateListener;
import com.tsys.payments.library.terminal.domain.TerminalInteractionRequest;
import com.tsys.payments.library.terminal.domain.TerminalInteractionResult;
import com.tsys.payments.library.terminal.domain.TerminalRequest;
import com.tsys.payments.library.terminal.domain.TerminalResponse;
import com.tsys.payments.library.terminal.enums.TerminalAction;
import com.tsys.payments.library.terminal.enums.TerminalDecisionType;
import com.tsys.payments.library.terminal.enums.TerminalInteractionType;
import com.tsys.payments.library.terminal.enums.TerminalStatus;
import com.tsys.payments.library.tlv.ConstructedTlvObject;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvObjectBuilder;
import com.tsys.payments.library.tlv.TlvUtils;
import com.tsys.payments.library.utils.ByteUtils;
import com.tsys.payments.library.utils.LibraryConfigHelper;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

class BbposController implements TerminalController, BBDeviceController.BBDeviceControllerListener {
    public static final int HEX_BASE = 16;
    private static final String EMV_RESPONSE_CODE_UNABLE_TO_GO_ONLINE = "8A025A33";
    private static final String[] DEVICE_NAMES =
            new String[] {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O",
                    "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4",
                    "5", "6", "7", "8", "9"};
    /**
     * L2 Version needed for creating a tag needed for ProPay endpoint
     */
    private static final String L2_CONFIG_VERSION = "1.1";
    private static final String MANUFACTURER = "AnywhereCommerce";
    private static final String OTA_SERVER_URL = "https://api.emms.bbpos.com/";
    /**
     * Default for indexed selections indicating no selected index.
     */
    private static final int NO_VALUE = -1;
    /**
     * Maximum time, in seconds, that the internal BBDeviceController bluetooth scanner should check for bluetooth BBPOS
     * devices.
     */
    private static final int DEFAULT_BLUETOOTH_SCAN_TIMEOUT = 50;
    /**
     * Maximum time that the BBPOS device should listen for card actions.
     */
    private static final int CHECK_CARD_TIMEOUT = 120;
    /**
     * Indicates that the BBPOS SDK should detect for the presence of a chipped card after the timeout has elapsed. In
     * the case of checking for card removal, this should be instantaneous and set to 0.
     */
    private static final int CHECK_CARD_CARD_REMOVAL_TIMEOUT = 0;
    private static final int MAX_BAD_READ_COUNT = 3;
    private static final int QUICK_CHIP = 2;
    /**
     * Indicate the timeout that the device wait to throw a time out on processing
     */
    private static final int PROCESSING_TIMEOUT = 60;
    private final Context mContext;
    private TerminalConfiguration mTerminalConfiguration;
    private TerminalListener mTerminalListener;
    private TerminalInteractionRequest mHostProcessingInteractionRequest;
    private TransactionConfiguration mTransactionConfiguration;
    private TerminalInfo mTerminalInfo;
    @Nullable
    private String mHostAddress;
    @Nullable
    private String mTerminalResultBatchTlv;
    @Nullable
    private String mOnlineRequestTlv;
    @Nullable
    private LastChipRead mLastChipRead;
    private BBDeviceController mBbDeviceController;
    private BBDeviceOTAController mBbDeviceOTAController;
    private BBDeviceController.CheckCardResult mCheckCardResult;
    private boolean mConnected;
    private boolean mConnectionPendingCompletion;
    private BbposCardData mBbposCardData;
    private BbposAuthorizationData mBbposAuthorizationData;

    /**
     * Indicates that contactless interface should be enabled in card reader.
     */
    private boolean mContactlessEnabled;

    /**
     * Indicates that a card was successfully inserted or tapped.
     */
    private boolean mCardDetected;

    /**
     * Indicates that an EMV card was swiped.
     */
    private boolean mUseIcc;
    private TerminalMode mTerminalMode;
    /**
     * Indicates that the transaction is at a state where a request has been made to process the transaction online.
     * This indicates that the transaction should be reversed in the event of a host timeout or some other host error. A
     * host decline is not a situation that would require a reversal. A reversal is only required in situations where
     * the transaction went online, but a response was not received or the transaction was approved online but declined
     * by the chip, or prematurely terminated by the user before the host response could be received.
     */
    private boolean mPossibleReversalRequired;

    /**
     * Indicator that the card reader is in an active session. This will be set to true when starting a transaction and
     * false when a transaction result is returned or an error occurs. This is needed because in the latest firmware
     * config update, Quick Chip is enabled by default and the card reader may still be active even after the host
     * response is written back to the terminal. If the card is removed, onReturnCheckCardResult() gets called but
     * should not proceed with the usual flow if a transaction is in progress. In the usual flow,
     * BBPOSDeviveController.checkCard() would be called right away after the card removal, thus starting a whole new
     * interaction flow.
     */
    private boolean mReaderInteractionSessionInProgress;

    /**
     * Indicates that the transaction is in a state of being aborted.
     */
    private boolean mAbortTransaction;
    /**
     * This variable is used with the card removal handling. It means the reader is in a state where it is listening for
     * card removal as the next step.
     */
    private boolean mCardRemovalRequired;
    /**
     * Indicates that a bad chip read has just occurred and that no other bad chip reads should be processed until after
     * the user has removed the card. This will prevent situations where the user leaves the card in and all 3 bad chip
     * reads are detected before the user has removed the card.
     */
    private boolean mAwaitingCardRemovalAfterBadChipRead;

    /**
     * Indicates that the terminal has completed transaction processing. At this point, the results can be sent to the
     * app or used to perform a reversal, depending on the circumstances leading up to the result return.
     */
    private boolean mTransactionResultReturned;
    /**
     * Indicates that the SDK is in a state of waiting for card removal after transaction completion.
     */
    private boolean mAwaitingCardRemovalAfterTransaction;
    /**
     * Keeps track of the number of bad chip reads. Once 3 occur, a fallback swipe is required.
     */
    private int mIccBadReadCount;
    @Nullable
    private FallbackReason mFallbackCondition;
    private TerminalRequest mTerminalRequest;
    private TerminalResponse mTerminalResponse;
    private int mSelectedApplication = NO_VALUE;
    private GatewayResponse mGatewayResponse;

    /**
     * Final transaction amount. Since this value can be provided independent of the initial TerminalRequest, a variable
     * for tracking it is provided.
     */
    private long mFinalTransactionAmount;

    /**
     * Keeps track of information from the card used in this transaction to report EMV tags and card data source type to
     * the consuming application in the transaction response.
     */
    private CardData mCardData;
    private boolean mIsProcessingRefund;

    private boolean mUserConfirmationForHostProcessingEnabled;

    /**
     * Set during the {@link #updateTerminalSetting(TerminalSettingType, String, TerminalUpdateSettingListener)} and
     * invoke when a update result is received from Terminal.
     */
    private TerminalUpdateSettingListener mTerminalUpdateSettingListener;
    /**
     * Set during the {@link #readTerminalSetting(TerminalSettingType, TerminalReadSettingListener)} and invoke when a
     * read result is received from Terminal.
     */
    private TerminalReadSettingListener mTerminalReadSettingListener;
    /**
     * Keeps track of the setting type send by the consumer, that needs to be used when a result comes from terminal and
     * {@link #mTerminalReadSettingListener} is invoked.
     */
    private TerminalSettingType mTerminalSettingType;
    /**
     * Keeps track of the setting value send by the consumer, that needs to be used when a result comes from terminal
     * and {@link #mTerminalUpdateSettingListener} is invoked.
     */
    private Object mTerminalSettingValue;

    private OtaListener mOtaListener;
    private String mTargetUpdateVersion;
    private TerminalUpdateType mTerminalUpdateType;
    private UpdateListener mTerminalVersionUpdateListener;
    private AvailableVersionsListener mAvailableVersionsListener;

    BbposController(@NonNull Context context, @NonNull TerminalConfiguration terminalConfiguration,
            @NonNull TransactionConfiguration transactionConfiguration,
            @NonNull TerminalListener listener) {
        mTerminalConfiguration = terminalConfiguration;
        mTransactionConfiguration = transactionConfiguration;
        mUserConfirmationForHostProcessingEnabled =
                mTransactionConfiguration.isUserConfirmationForHostProcessingEnabled();
        mTerminalListener = listener;
        mContext = context.getApplicationContext();
        mHostAddress = mTerminalConfiguration.getHost();
        mContactlessEnabled = mTransactionConfiguration.isContactlessEnabled();
        initializeBbDeviceController();
        initializeBbOTAController();
        BBDeviceController.setDebugLogEnabled(
                LibraryConfigHelper.isLoggingEnabled() && LibraryConfigHelper.isDebug());
    }

    private void initializeBbDeviceController() {
        Timber.d("initializeBbDeviceController() called.");
        mBbDeviceController = BBDeviceController.getInstance(mContext, this);
    }

    private void initializeBbOTAController() {
        Timber.d("initializeBbOTAController() called.");
        mOtaListener = new OtaListener();
        mBbDeviceOTAController = BBDeviceOTAController.getInstance(mContext,
                mOtaListener);
        mBbDeviceOTAController.setOTAServerURL(OTA_SERVER_URL);
        try {
            mBbDeviceOTAController.setBBDeviceController(mBbDeviceController);
        } catch (BBDeviceControllerNotSupportOTAException e) {
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR, e.getMessage());
        }
    }

    @Override
    public void connect() {
        Timber.d("connect() called.");
        if (mBbDeviceController == null) {
            initializeBbDeviceController();
            initializeBbOTAController();
        }
        connectTerminal();
    }

    private void connectTerminal() {
        Timber.d("connectTerminal() called.");
        if (mBbDeviceController == null) {
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                    "Unable to connect to terminal because device controller is not initialized.");
            Timber.d("connectTerminal() :: deviceController is null.");
        } else if (mContext == null) {
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                    "Unable to connect to terminal because context is missing.");
            Timber.d("connectTerminal() :: Context is null.");
        } else if (mTerminalConfiguration.getTerminalType() == TerminalType.BBPOS_C2X) {
            if (mConnected) {
                handleTerminalConnected();
            } else {
                switch (mTerminalConfiguration.getConnectionType()) {
                    case BLUETOOTH:
                        mBbDeviceController
                                .startBTScan(DEVICE_NAMES,
                                        DEFAULT_BLUETOOTH_SCAN_TIMEOUT);
                        break;
                    case USB:
                        if (mTerminalConfiguration.getHost() != null) {
                            mBbDeviceController.startUsbWithDeviceName(mTerminalConfiguration.getHost());
                        } else {
                            mBbDeviceController.startUsb();
                        }
                        break;
                }
            }
        } else {
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                    "Invalid terminal type specified.");
        }
    }

    private void handleTerminalConnected() {
        Timber.d("handleTerminalConnected() called.");
        callbackOnTerminalConnected();
    }

    @Override
    public void sendRequest(TerminalRequest terminalRequest) {
        Timber.d("sendRequest() called with: terminalRequest=[%s]", terminalRequest);
        mTerminalRequest = terminalRequest;
        if (terminalRequest == null) {
            Timber.e("sendRequest() called with missing terminalRequest");
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "No terminal request is provided.");
        } else if (terminalRequest.getTerminalAction() == null) {
            Timber.e("Terminal request is missing an action.");
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "No terminal action is provided.");
        } else {
            processTerminalAction(terminalRequest.getTerminalAction());
        }
    }

    private void processTerminalAction(TerminalAction action) {
        Timber.d("processTerminalAction() called with: action=[%s]", action);
        switch (action) {
            case SETUP:
                handleTerminalSetup();
                break;
            case INFO:
                handleTerminalInfoRequest();
                break;
            case TENDER_GOODS:
            case TENDER_SERVICES:
            case TENDER_REFUND:

                handleStartEmv();
                break;
        }
    }

    private void handleTerminalSetup() {
        Timber.d("handleTerminalSetup() called.");
        // Return immediately because there is no programmatic setup involved with BBPOS terminals.
        callbackOnTerminalResponse(new TerminalResponse(TerminalAction.SETUP));
    }

    private void handleTerminalInfoRequest() {
        Timber.d("handleTerminalInfoRequest() called.");
        if (mBbDeviceController != null) {
            mBbDeviceController.getDeviceInfo();
        } else {
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "Terminal controller is not instantiated. Request cannot be completed.");
        }
    }

    private void handleStartEmv() {
        Timber.d("handleStartEmv() called.");
        if (mAbortTransaction) {
            cancelCheckCard();
        } else {
            // checkCard() must be called before startEmv(). This is the first step in card detection.
            mReaderInteractionSessionInProgress = true;
            checkCard(getInitialCheckCardMode());
        }
    }

    /**
     * EMV transactions must be continued after a successful EMV card insertion. This is done so by invoking the
     * startEmv() command on the {@link BBDeviceController}
     */
    private void continueEmvTransaction() {
        Timber.d("continueEmvTransaction() called.");
        setAmounts();
        if (mBbDeviceController != null) {
            mBbDeviceController.startEmv(getStartEmvConfiguration());
        } else {
            Timber.e("Terminal cannot start transaction because device controller is null");
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "Terminal controller is not instantiated. Device is unable to initiate transaction.");
        }
    }

    private Hashtable<String, Object> getStartEmvConfiguration() {
        Hashtable<String, Object> startEmvMap = new Hashtable<>();
        startEmvMap.put(Keys.StartEmv.EMV_OPTION,
                BBDeviceController.EmvOption.START);
        startEmvMap.put(Keys.StartEmv.TERMINAL_TIME,
                Formats.TERMINAL_TIME_FORMAT.format(new Date()));
        startEmvMap.put(Keys.StartEmv.CHECK_CARD_MODE,
                BBDeviceController.CheckCardMode.SWIPE_OR_INSERT);
        startEmvMap.put(Keys.StartEmv.DISABLE_QUICK_CHIP, !isTransactionQuickChipEnabled());
        startEmvMap.put(StartEmv.ONLINE_PROCESS_TIMEOUT, PROCESSING_TIMEOUT);
        if (isTransactionQuickChipEnabled()) {
            startEmvMap.put(StartEmv.QUICK_CHIP_OPTION, QUICK_CHIP);
        }
        return startEmvMap;
    }

    /**
     * Contactless transactions must be continued after a successful tap is detected. This is done so by invoking the
     * startEmv() command on the {@link BBDeviceController}
     */
    private void continueContactlessTransaction() {
        Timber.d("continueContactlessTransaction() called.");
        setAmounts();
        if (mBbDeviceController != null) {
            mBbDeviceController.startEmv(getStartContactlessConfiguration());
        } else {
            Timber.e("Terminal cannot start transaction because device controller is null");
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "Terminal controller is not instantiated. Device is unable to initiate transaction.");
        }
    }

    private Hashtable<String, Object> getStartContactlessConfiguration() {
        Hashtable<String, Object> startEmvMap = new Hashtable<>();
        startEmvMap.put(Keys.StartEmv.EMV_OPTION,
                BBDeviceController.EmvOption.START);
        startEmvMap.put(Keys.StartEmv.TERMINAL_TIME,
                Formats.TERMINAL_TIME_FORMAT.format(new Date()));
        startEmvMap.put(Keys.StartEmv.CHECK_CARD_MODE,
                BBDeviceController.CheckCardMode.SWIPE_OR_INSERT_OR_TAP);
        startEmvMap.put(Keys.StartEmv.DISABLE_QUICK_CHIP, !isTransactionQuickChipEnabled());
        startEmvMap.put(StartEmv.ONLINE_PROCESS_TIMEOUT, PROCESSING_TIMEOUT);
        if (isTransactionQuickChipEnabled()) {
            startEmvMap.put(StartEmv.QUICK_CHIP_OPTION, QUICK_CHIP);
        }
        return startEmvMap;
    }

    /**
     * Returns the initial interface startup conditions for the reader. Depending on whether or not contactless is
     * enabled, the initial state will indicate swipe, insert and tap, or will just indicate swipe and insert.
     *
     * @return {@link com.bbpos.bbdevice.BBDeviceController.CheckCardMode} indicating the default mode for the reader
     * startup.
     */
    private BBDeviceController.CheckCardMode getInitialCheckCardMode() {
        /*
          Considering making this the base method for all check card mode logic.
         */
        if (mContactlessEnabled) {
            return BBDeviceController.CheckCardMode.SWIPE_OR_INSERT_OR_TAP;
        } else {
            return BBDeviceController.CheckCardMode.SWIPE_OR_INSERT;
        }
    }

    private void checkCard(BBDeviceController.CheckCardMode checkCardMode) {
        Timber.d("checkCard() called with: checkCardMode=[%s]", checkCardMode);
        checkCard(checkCardMode, CHECK_CARD_TIMEOUT);
    }

    private void checkCard(@NonNull BBDeviceController.CheckCardMode checkCardMode,
            int checkCardTimeout) {
        Timber.d("checkCard() called with: checkCardMode=[%s],checkCardTimeout=[%s]", checkCardMode,
                checkCardTimeout);
        mTerminalMode = TerminalMode.WAITING_FOR_CARD;
        if (mBbDeviceController != null) {
            Hashtable<String, Object> checkCardMap = new Hashtable<>();
            checkCardMap.put(Keys.CheckCard.MODE, checkCardMode);
            checkCardMap.put(Keys.CheckCard.TIMEOUT, checkCardTimeout);
            mBbDeviceController.checkCard(checkCardMap);
        } else {
            Timber.e(
                    "BBPOS device controller checkCard() cannot be called because the controller is null. Transaction is aborted.");
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "Device controller is missing. Transaction cannot continue.");
        }
    }

    private void cancelCheckCard() {
        Timber.d("cancelCheckCard() called.");
        if (mBbDeviceController != null) {
            mBbDeviceController.cancelCheckCard();
        } else {
            Timber.w(
                    "cancelCheckCard() could not be performed because the device controller is null");
        }
    }

    private void setAmounts() {
        Timber.d("setAmounts() called.");
        if (mTerminalRequest == null) {
            Timber.e("Transaction amounts cannot be set because TerminalRequest is null.");
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "A terminal request must be receivved before this method is called.");
            return;
        }

        setTempMemoryOnlyTerminalRequestTotal();

        if (mTerminalRequest.getTotalAmount() == null) {
            /**
             * In a scenario where the transaction amount is not provided in the initial TerminalRequest
             * the BBPOS SDK will callback with {@link com.bbpos.bbdevice.BBDeviceController.BBDeviceControllerListener#onRequestSetAmount()}.
             * The amounts can be set at that time.
             */
            Timber.w("No transaction amount provided.");
        } else {
            setAmount(mTerminalRequest.getTotalAmount(), mTerminalRequest.getCashBackAmount());
        }
    }

    private void setAmount(@NonNull Long total, @Nullable Long cashback) {
        BigDecimal transactionAmount = new BigDecimal(total);
        BigDecimal cashbackAmount = null;
        mFinalTransactionAmount = total;

        if (cashback != null) {
            cashbackAmount = new BigDecimal(cashback);
        }

        BigDecimal finalCashbackAmount = cashbackAmount;
        Hashtable<String, Object> inputData = new Hashtable<String, Object>() {{
            put("amount", transactionAmount.movePointLeft(2).toPlainString());
            put("cashbackAmount", finalCashbackAmount == null ? BigDecimal.ZERO.movePointLeft(2).toPlainString() :
                    finalCashbackAmount.movePointLeft(2).toPlainString());
            put("currencyCode", mTransactionConfiguration.getCurrencyCode() == null ?
                    CurrencyCode.USD.currencyCode : BbposConversionHelper
                    .getFormattedCurrencyCode(mTransactionConfiguration.getCurrencyCode()));
            put("transactionType", BbposConversionHelper.getTransactionType(mTerminalRequest.getTerminalAction()));
        }};

        mBbDeviceController.setAmount(inputData);
    }

    @Override
    public void sendTerminalInteractionResult(TerminalInteractionResult terminalInteractionResult) {
        Timber.d("sendTerminalInteractionResult() called with terminalInteractionResult=[%s]",
                terminalInteractionResult);
        if (terminalInteractionResult.getInteractionType() != null) {
            switch (terminalInteractionResult.getInteractionType()) {
                case EMV_APPLICATION_SELECTION:
                    sendApplicationSelectionResult(
                            terminalInteractionResult.getSelectedApplicationIndex());
                    break;
                case FINAL_AMOUNT_REQUEST:
                    setFinalAmount(terminalInteractionResult);
                    break;
                case FINAL_AMOUNT_CONFIRMATION:
                    sendConfirmationResult(terminalInteractionResult.getFinalAmountConfirmed());
                    break;
                case HOST_PROCESSING:
                    sendHostProcessingResult(terminalInteractionResult.getGatewayResponse());
                    break;
                case REQUEST_PROCEED_HOST_PROCESSING:
                    proceedWithHostProcessing();
                    break;
            }
        }
    }

    private void setFinalAmount(TerminalInteractionResult result) {
        if (result.getFinalAmount() == null) {
            callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                    "Transaction cannot continue " +
                            "because no amount is provided for the terminal.");
        } else {
            setAmount(result.getFinalAmount(), result.getCashbackAmount());
        }
    }

    private void proceedWithHostProcessing() {
        Timber.d("proceedWithHostProcessing() called");
        requestHostProcessing();
        if (mBbposAuthorizationData != null) {
            if (TextUtils.isEmpty(mBbposAuthorizationData.getIccData())) {
                // No ICC data means that this is an MSR transaction and terminal interaction can be terminated.
                resetController();
            }
        } else {
            Timber.e(
                    "Unable to proceed with host processing. Terminal authorization data missing.");
            callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                    "A card reader occurred. Please retry the payment attempt.");
            resetController();
        }
    }

    private void sendConfirmationResult(boolean approved) {
        Timber.d("sendConfirmationResult() called with: approved=[%s]", approved);
        if (mBbDeviceController != null) {
            mBbDeviceController.sendFinalConfirmResult(approved);
            if (!approved) {
                cancel();
            }
        } else {
            /* The controller should not be reset or disconnected here because the reader will
               timeout the transaction if the amount is not sent. There are standard flows that should
               NOT be intercepted with our own error handling. Once the transaction is in progress
               on the terminal, allow the device to timeout and end the transaction itself instead
               of forcing a disconnect.
             */
            Timber.e("Device controller is null. Amount confirmation cannot be sent.");
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "Confirmation result cannot be sent. Device controller missing.");
        }
    }

    private void sendApplicationSelectionResult(int index) {
        Timber.d("sendApplicationSelectionResult() called with: index=[%s]", index);
        mTerminalMode = TerminalMode.TRANSACTION;
        mSelectedApplication = index;
        if (mBbDeviceController != null) {
            mBbDeviceController.selectApplication(index);
        }
    }

    private void sendHostProcessingResult(GatewayResponse gatewayResponse) {
        Timber.d("sendHostProcessingResult() called with: gatewayResponse=[%s]",
                gatewayResponse);
        mGatewayResponse = gatewayResponse;
        if (gatewayResponse.isGatewayTimeout()) {
            if (mHostProcessingInteractionRequest != null) {
                mCardData = mHostProcessingInteractionRequest.getCardData();
                if (mCardData.getCardDataSource() == CardDataSourceType.SCR &&
                        isTransactionQuickChipEnabled()) {
                    TerminalResponse response = new TerminalResponse(TerminalAction.TENDER_GOODS);
                    response.setCardData(mCardData);
                    response.setTerminalDecisionType(TerminalDecisionType.REVERSAL_REQUIRED);
                    callbackOnTerminalResponse(response);
                    resetController();
                    return;
                }
            }

            Timber.d(
                    "sendHostProcessingResult(): gateway timed out. Do nothing and let the reader timeout while waiting for online processing response. Once it times out," +
                            "a timeout reversal decision will be returned.");
        } else if (mBbDeviceController != null) {
            TerminalResponse terminalResponse =
                    new TerminalResponse(mTerminalRequest.getTerminalAction());
            terminalResponse.setTerminalDecisionType(mGatewayResponse.isApproved() ?
                        TerminalDecisionType.APPROVED_ONLINE : TerminalDecisionType.DECLINED_ONLINE);
            terminalResponse.setCardData(mCardData);
            callbackOnTerminalResponse(terminalResponse);

            mBbDeviceController.sendOnlineProcessResult(
                    BbposConversionHelper.getOnlineEmvProcessingResult(gatewayResponse));
        } else {
            callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                    "Device is missing. EMV transaction processing cannot complete.");
        }
    }

    @Override
    public void cancel() {
        Timber.d("cancel() called.");
        mAbortTransaction = true;
        if (mBbDeviceController != null) {
            if (mTerminalMode == TerminalMode.WAITING_FOR_APPLICATION_SELECTION) {
                mBbDeviceController.cancelSelectApplication();
            } else if (mTerminalMode == TerminalMode.WAITING_FOR_CARD) {
                cancelCheckCard();
            } else {
                dispatchCancelTransactionResponse();
            }

            resetController();
        } else {
            Timber.w("cancel() called. Device controller is null. There is nothing to cancel");
        }
    }

    private void dispatchCancelTransactionResponse() {
        Timber.d("dispatchCancelTransactionResponse() called.");
        TerminalResponse response = new TerminalResponse(
                mTerminalRequest == null ? TerminalAction.SETUP :
                        mTerminalRequest.getTerminalAction());
        response.setTerminalDecisionType(TerminalDecisionType.TRANSACTION_CANCELLED);
        callbackOnTerminalResponse(response);
    }

    @Override
    public void disconnect() {
        Timber.d("disconnect() called.");
        cancel();
        if (mBbDeviceController != null) {
            BBDeviceController.setDebugLogEnabled(false);
            mBbDeviceController.releaseBBDeviceController();
        } else {
            Timber.w("disconnect() called. Terminal controller is null");
        }

        mBbDeviceController = null;
    }

    @Override
    public void updateTerminalSetting(TerminalSettingType terminalSettingsType, String terminalSettingsValue,
            TerminalUpdateSettingListener terminalUpdateSettingListener) {
        mTerminalSettingType = terminalSettingsType;
        mTerminalSettingValue = terminalSettingsValue;
        mTerminalUpdateSettingListener = terminalUpdateSettingListener;

        try {
            // Convert terminalSettingsValue into byte
            byte tlvValue = Byte.parseByte(terminalSettingsValue, HEX_BASE);

            if (mBbDeviceController != null) {
                switch (terminalSettingsType) {
                    case NORMAL_MODE_TIMEOUT:
                        TlvObject normalTimeoutTLV =
                                TlvObjectBuilder.create(EmvTagDescriptor.BBPOS_NORMAL_MODE_TIMEOUT)
                                        .setValue(tlvValue).build();
                        mBbDeviceController.updateTerminalSetting(normalTimeoutTLV.asHexString());
                        break;
                    case BLUETOOTH_DISCOVERY_TIMEOUT:
                        TlvObject bluetoothTimeoutTLV =
                                TlvObjectBuilder.create(EmvTagDescriptor.BBPOS_BLUETOOTH_DISCOVERY_TIMEOUT)
                                        .setValue(tlvValue).build();
                        mBbDeviceController.updateTerminalSetting(bluetoothTimeoutTLV.asHexString());
                        break;
                    case STANDBY_MODE_TIMEOUT:
                        TlvObject standbyTimeoutTLV =
                                TlvObjectBuilder.create(EmvTagDescriptor.BBPOS_STANDBY_MODE_TIMEOUT)
                                        .setValue(tlvValue).build();
                        mBbDeviceController.updateTerminalSetting(standbyTimeoutTLV.asHexString());
                        break;
                }
            } else if (mTerminalUpdateSettingListener == null) {
                Timber.w("updateTerminalSetting() called. TerminalUpdateListener is null");
                callbackOnTerminalInteractionError(TerminalError.CONFIGURATION_ERROR,
                        "Unexpected error cannot update terminal settings.");
            } else {
                Timber.w("updateTerminalSetting() called. Terminal controller is null");
                callbackOnUpdateTerminalInteractionError(ErrorType.TERMINAL_CONFIG_NOT_SUPPORTED, mTerminalSettingType);
            }
        } catch (NumberFormatException e) {
            callbackOnTerminalInteractionError(TerminalError.CONFIGURATION_ERROR,
                    "Unexpected error, terminalSettingsValue = [" + terminalSettingsValue + "] is invalid");
        }
    }

    @Override
    public void readTerminalSetting(TerminalSettingType terminalSettingsType,
            TerminalReadSettingListener terminalReadSettingListener) {
        mTerminalSettingType = terminalSettingsType;
        mTerminalReadSettingListener = terminalReadSettingListener;
        if (mBbDeviceController != null) {
            switch (terminalSettingsType) {
                case NORMAL_MODE_TIMEOUT:
                    mBbDeviceController.readTerminalSetting(EmvTagDescriptor.BBPOS_NORMAL_MODE_TIMEOUT.asHexString());
                    break;
                case BLUETOOTH_DISCOVERY_TIMEOUT:
                    mBbDeviceController
                            .readTerminalSetting(EmvTagDescriptor.BBPOS_BLUETOOTH_DISCOVERY_TIMEOUT.asHexString());
                    break;
                case STANDBY_MODE_TIMEOUT:
                    mBbDeviceController.readTerminalSetting(EmvTagDescriptor.BBPOS_STANDBY_MODE_TIMEOUT.asHexString());
                    break;
            }
        } else if (terminalReadSettingListener == null) {
            Timber.w("readTerminalSetting() called. TerminalReadSettingListener is null");
            callbackOnTerminalInteractionError(TerminalError.CONFIGURATION_ERROR,
                    "Unexpected error cannot read terminal settings.");
        } else {
            Timber.w("readTerminalSetting() called. Terminal controller is null");
            mTerminalReadSettingListener.onError(new Error() {
                @Override
                public ErrorType getType() {
                    return ErrorType.TERMINAL_CONFIG_NOT_SUPPORTED;
                }

                @Override
                public String getMessage() {
                    return "Terminal controller is null";
                }
            });
        }
    }

    //region OTA
    @Override
    public void getAvailableTerminalVersions(TerminalUpdateType terminalUpdateType,
            Map<String, String> credentials,
            AvailableVersionsListener availableVersionsListener) {
        Timber.d("getAvailableTerminalVersions() called with terminalUpdateType=%s", terminalUpdateType);
        /*
          Flow:
          1. mBbDeviceOTAController.getTargetVersionWithData(getRemoteTerminalVersionsQueryInputMap());
          2. OTAListener listens for OTA response and invokes availableVersionsListener response
         */
        mTerminalUpdateType = terminalUpdateType;
        mAvailableVersionsListener = availableVersionsListener;
        mOtaListener.setTerminalUpdateFlowInitiated(false);
        getRemoteAvailableTerminalVersions();
    }

    private void getRemoteAvailableTerminalVersions() {
        Timber.d("getRemoteAvailableTerminalVersions() called");
        try {
            mBbDeviceOTAController.getTargetVersionWithData(getRemoteTerminalVersionsQueryInputMap());
        } catch (BBDeviceControllerNotSetException | OTAServerURLNotSetException |
                BBDeviceNotConnectedException | NoInternetConnectionException e) {
            Timber.e(e);
            mAvailableVersionsListener.onTerminalVersionInfoError(TerminalError.SERVER_COMM_ERROR, e.getMessage());
        }
    }

    @Override
    public void updateTerminal(@NonNull TerminalUpdateType terminalUpdateType,
            @Nullable Map<String, String> credentials, @Nullable String version,
            @NonNull UpdateListener updateListener) {
        Timber.d("updateTerminal() called with terminalUpdateType=%s, credentials=%s, version=%s",
                terminalUpdateType, credentials, version);
        mTerminalVersionUpdateListener = updateListener;
        mTargetUpdateVersion = version;
        mTerminalUpdateType = terminalUpdateType;

        if (mTerminalUpdateType == TerminalUpdateType.RKI) {
            startRemoteTerminalUpdate();
            return;
        }

        /*
          Flow
          1. Check to see if version is supplied. If version is not supplied, proceed to step 2, or else
          skip to step 3.
          2. Get target version.   getRemoteAvailableVersions()
          2a. OTAListener processes result
          2b. Proceed to step 3
          3. Set target version    setRemoteTargetUpdateVersion()
          3a. OTAListener listens for result
          3b. on success, proceed to step 4
          4. Perform update - startRemoteTerminalUpdate()
         */
        if (TextUtils.isEmpty(mTargetUpdateVersion)) {
            mOtaListener.setTerminalUpdateFlowInitiated(true);
            getRemoteAvailableTerminalVersions();
        } else {
            setRemoteTargetUpdateVersion();
        }
    }

    private void startRemoteTerminalUpdate() {
        Timber.d("startRemoteTerminalUpdate() called");
        try {
            if (mTerminalUpdateType == TerminalUpdateType.FIRMWARE) {
                mBbDeviceOTAController.startRemoteFirmwareUpdate(getRemoteVersionUpdateInputMap(mTerminalUpdateType));
            } else if (mTerminalUpdateType == TerminalUpdateType.RKI) {
                //For remote key injection(RKI)
                mBbDeviceOTAController.startRemoteKeyInjection(getRemoteKeyInjectionInputMap());
            } else {
                mBbDeviceOTAController.startRemoteConfigUpdate(getRemoteVersionUpdateInputMap(mTerminalUpdateType));
            }
        } catch (BBDeviceControllerNotSetException | OTAServerURLNotSetException e) {
            Timber.e(e);
            mTerminalVersionUpdateListener.onTerminalUpdateError(TerminalError.INITIALIZATION_ERROR, e.getMessage());
        } catch (BBDeviceNotConnectedException e) {
            Timber.e(e);
            callbackOnTerminalDisconnected();
        } catch (NoInternetConnectionException e) {
            Timber.e(e);
            callbackOnTerminalInteractionError(TerminalError.SERVER_COMM_ERROR, e.getMessage());
        }
    }

    private void setRemoteTargetUpdateVersion() {
        Timber.d("setRemoteTargetUpdateVersion() called");
        try {
            mBbDeviceOTAController.setTargetVersionWithData(getSetRemoteTargetUpdateVersionInputMap());
        } catch (BBDeviceControllerNotSetException | OTAServerURLNotSetException e) {
            Timber.e(e);
            mTerminalVersionUpdateListener.onTerminalUpdateError(TerminalError.INITIALIZATION_ERROR, e.getMessage());
        } catch (BBDeviceNotConnectedException e) {
            Timber.e(e);
            callbackOnTerminalDisconnected();
        } catch (NoInternetConnectionException e) {
            Timber.e(e);
            callbackOnTerminalInteractionError(TerminalError.SERVER_COMM_ERROR, e.getMessage());
        }
    }

    private Hashtable<String, String> getRemoteTerminalVersionsQueryInputMap() {
        Timber.d("getRemoteTerminalVersionsQueryInputMap() called");
        Hashtable<String, String> input = new Hashtable<>();
        input.put(BbposOTAKeys.VENDOR_ID, BbposOTADefaults.VENDOR_ID);
        input.put(BbposOTAKeys.APP_ID, BbposOTADefaults.APP_ID);
        input.put(BbposOTAKeys.VENDOR_SECRET, BbposOTADefaults.VENDOR_SECRET);
        input.put(BbposOTAKeys.APP_SECRET, BbposOTADefaults.APP_SECRET);
        return input;
    }

    private Hashtable<String, Object> getSetRemoteTargetUpdateVersionInputMap() {
        Timber.d("getSetTargetUpdateVersionInputMap() called");
        Hashtable<String, Object> input = new Hashtable<>();
        input.put(BbposOTAKeys.VENDOR_ID, BbposOTADefaults.VENDOR_ID);
        input.put(BbposOTAKeys.APP_ID, BbposOTADefaults.APP_ID);
        input.put(BbposOTAKeys.VENDOR_SECRET, BbposOTADefaults.VENDOR_SECRET);
        input.put(BbposOTAKeys.APP_SECRET, BbposOTADefaults.APP_SECRET);
        if (mTerminalUpdateType == TerminalUpdateType.FIRMWARE) {
            input.put(BbposOTAKeys.FIRMWARE_VERSION, mTargetUpdateVersion);
            input.put(BbposOTAKeys.TARGET_VERSION_TYPE, BBDeviceOTAController.TargetVersionType.FIRMWARE);
        } else if (mTerminalUpdateType == TerminalUpdateType.KERNEL) {
            input.put(BbposOTAKeys.DEVICE_SETTING_VERSION, mTargetUpdateVersion);
            input.put(BbposOTAKeys.TERMINAL_SETTING_VERSION, mTargetUpdateVersion);
            input.put(BbposOTAKeys.TARGET_VERSION_TYPE, BBDeviceOTAController.TargetVersionType.CONFIG);
        }
        return input;
    }

    private Hashtable<String, Object> getRemoteKeyInjectionInputMap() {
        TerminalUpdateType terminalUpdateType = TerminalUpdateType.RKI;
        return getRemoteVersionUpdateInputMap(terminalUpdateType);
    }

    private Hashtable<String, Object> getRemoteVersionUpdateInputMap(TerminalUpdateType terminalUpdateType) {
        Hashtable<String, Object> input = new Hashtable<>();
        input.put(BbposOTAKeys.VENDOR_ID, BbposOTADefaults.VENDOR_ID);
        input.put(BbposOTAKeys.APP_ID, BbposOTADefaults.APP_ID);
        input.put(BbposOTAKeys.VENDOR_SECRET, BbposOTADefaults.VENDOR_SECRET);
        input.put(BbposOTAKeys.APP_SECRET, BbposOTADefaults.APP_SECRET);
        input.put(BbposOTAKeys.FORCE_UPDATE, BbposOTADefaults.FORCE_UPDATE);
        if (terminalUpdateType == TerminalUpdateType.FIRMWARE) {
            input.put(BbposOTAKeys.FIRMWARE_TYPE, BbposOTADefaults.FIRMWARE_TYPE);
        }

        return input;
    }

    //endregion

    private void resetController() {
        Timber.d("resetController() called");
        mTerminalMode = TerminalMode.IDLE;
        mSelectedApplication = NO_VALUE;
        mTerminalResultBatchTlv = null;
        mUseIcc = false;
        mFallbackCondition = null;
        mBbposCardData = null;
        mIsProcessingRefund = false;
        mIccBadReadCount = 0;
        mTransactionResultReturned = false;
        mTerminalResponse = null;
        mCardRemovalRequired = false;
        mCardData = null;
        mLastChipRead = null;
        mAbortTransaction = false;
        mAwaitingCardRemovalAfterTransaction = false;
        mBbposAuthorizationData = null;
        mTerminalResponse = null;
        mCheckCardResult = null;
        mConnectionPendingCompletion = false;
        mPossibleReversalRequired = false;
        mHostProcessingInteractionRequest = null;
    }

    //region BBDeviceController callbacks These callbacks are performed asynchronously by the BBPOS SDK

    /**
     * This callback is fired in response to the {@link BBDeviceController#checkCard(Hashtable)} method invocation.
     * <p>
     * The reason for the logic inside this callback is described below using the following standard scenario:
     * <p>
     * See {@link BbposController#onReturnCheckCardResult(BBDeviceController.CheckCardResult, Hashtable)} .
     * <ol>
     * <li>{@link BBDeviceController#checkCard(Hashtable)} is called to prompt the user to insert
     * or
     * swipe a card.</li>
     * <li> {@link BBDeviceController.CheckCardResult#MSR is detected in onReturnCheckCardResult()
     * </li>
     * <li>shouldUseIcc() is called to check the card's service code. If it returns true, mUseIcc
     * is
     * set to true and checkCard() is called again.</li>
     * <li> {@link BBDeviceController.BBDeviceControllerListener#onWaitingForCard(BBDeviceController.CheckCardMode)}
     * is invoked.</li>
     * <li>mUseIcc is true. Prompt the user to insert because an EMV card was swiped.</li>
     * </ol>
     */
    @Override
    public void onWaitingForCard(BBDeviceController.CheckCardMode checkCardMode) {
        Timber.d("onWaitingForCard() called with: checkCardCode=[%s]", checkCardMode.name());
        if (mCardRemovalRequired) return;

        if (mFallbackCondition != null) {
            // Indicates that fallback swipe is enabled.
            // TODO: Handle fallback from contactless to contact
            callbackOnTerminalStatusUpdated(TerminalStatus.TECHNICAL_FALLBACK_INITIATED);
        } else if (mUseIcc) {
            // Indicates that the previous swipe detected that the card has an EMV chip.
            callbackOnTerminalStatusUpdated(TerminalStatus.ICC_SWIPE_DETECTED);
        } else {
            callbackOnTerminalStatusUpdated(TerminalStatus.WAITING_FOR_CARD);
        }

        mUseIcc = false;
    }

    @Override
    public void onBTReturnScanResults(List<BluetoothDevice> list) {
        Timber.d("onBTReturnScanResults() called with :: list=%s", list);
        if (mBbDeviceController != null) {
            if (list == null || list.isEmpty()) {
                callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                        "No bluetooth devices found.");
                mBbDeviceController.stopBTScan();
                return;
            }
            for (BluetoothDevice device : list) {
                if (device.getAddress().equals(mHostAddress)) {
                    mBbDeviceController.connectBT(device);
                    return;
                }
            }
        } else {
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                    "Cannot connect to discovered bluetooth device. Device controller is null.");
        }
    }

    @Override
    public void onBTScanTimeout() {
        Timber.d("onBTScanTimeout() called.");
        resetController();
        callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                "Attempts to connect to bluetooth terminal timed out. Please try again.");
    }

    @Override
    public void onBTScanStopped() {
        Timber.d("onBTScanStopped() called.");
    }

    @Override
    public void onBTConnected(BluetoothDevice bluetoothDevice) {
        Timber.d("onBTConnected() called.");
        mConnected = true;
        mConnectionPendingCompletion = true;
        if (mBbDeviceController != null) {
            mBbDeviceController.getDeviceInfo();
        } else {
            Timber.w(
                    "Completed terminal connection but unable to retrieve terminal info. Device controller is null.");
            handleTerminalConnected();
        }
    }

    @Override
    public void onBTDisconnected() {
        Timber.d("onBTDisconnected() called.");
        mConnected = false;
        callbackOnTerminalDisconnected();
    }

    @MainThread
    @Override
    public void onReturnCheckCardResult(BBDeviceController.CheckCardResult checkCardResult,
            Hashtable<String, String> cardData) {
        Timber.d("onReturnCheckCardResult() called with :: checkCardResult=%s, hashtable=%s",
                checkCardResult, cardData);
        if (!mReaderInteractionSessionInProgress) return;
        mTerminalMode = TerminalMode.IDLE;
        mCheckCardResult = checkCardResult;
        if (mAwaitingCardRemovalAfterTransaction) {
            /* Check card must be called in order to detect card removal. So a check is made to
               determine if the card is removed. */
            if (checkCardResult == BBDeviceController.CheckCardResult.NO_CARD) {
                mAwaitingCardRemovalAfterTransaction = false;
                /* TODO: Determine if a notification needs to be sent indicating that the card
                   was removed. Previously, this decision was made for business reasons. */
            }
        } else {
            switch (checkCardResult) {
                case INSERTED_CARD:
                    // Called when the  EMV chip has been successfully read.
                    mIccBadReadCount = 0;
                    mLastChipRead = LastChipRead.SUCCESSFUL;
                    if (mBbDeviceController != null) {
                        // Call is made to retrieve cardholder name and other basic card information.
                        mBbDeviceController.getEmvCardData();
                    }
                    break;
                case BAD_SWIPE:
                    mIccBadReadCount = 0;
                    callbackOnTerminalStatusUpdated(TerminalStatus.CARD_READ_ERROR);
                    checkCard(getInitialCheckCardMode());
                    break;
                case NO_CARD:
                    mCardRemovalRequired = false;
                    mCardDetected = false;
                    mAwaitingCardRemovalAfterBadChipRead = false;
                    if (!mTransactionResultReturned) {
                        checkCard(getInitialCheckCardMode());
                    }
                    break;
                case NOT_ICC:
                    if (!mAwaitingCardRemovalAfterBadChipRead) {
                        mIccBadReadCount++;
                        mCardRemovalRequired = true;
                        mLastChipRead = LastChipRead.NOT_A_CHIP_TRANSACTION;
                        if (mFallbackCondition != null) {
                            checkCard(BBDeviceController.CheckCardMode.SWIPE_OR_INSERT);
                            return;
                        } else if (mIccBadReadCount == MAX_BAD_READ_COUNT) {
                            Timber.d("Initiating technical fallback because of chip error.");
                            mFallbackCondition = FallbackReason.ICC_ERROR;
                            callbackOnTerminalStatusUpdated(
                                    TerminalStatus.TECHNICAL_FALLBACK_INITIATED);
                            mIccBadReadCount = 0;
                            mAwaitingCardRemovalAfterBadChipRead = false;
                            detectCardRemoval();
                            return;
                        } else {
                            callbackOnTerminalStatusUpdated(TerminalStatus.CARD_READ_ERROR);
                        }

                        mAwaitingCardRemovalAfterBadChipRead = true;
                    }

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            detectCardRemoval();
                        }
                    }, 500);
                    break;
                case USE_ICC_CARD:
                    mIccBadReadCount = 0;
                    checkCard(BBDeviceController.CheckCardMode.SWIPE_OR_INSERT, CHECK_CARD_TIMEOUT);
                    break;
                case MSR:
                    mIccBadReadCount = 0;
                    if (shouldUseIcc(cardData)) {
                        /* A chip card was swiped. The service code indicated that the user should
                           insert the card. As a result, the CHECK_CARD command must be sent to the
                           device to prompt the user again. */
                        mUseIcc = true;
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                checkCard(BBDeviceController.CheckCardMode.SWIPE_OR_INSERT);
                            }
                        }, 1000);
                    } else {
                        // Swipe is for a valid non-EMV card.
                        mLastChipRead = LastChipRead.NOT_A_CHIP_TRANSACTION;
                        callbackOnTerminalStatusUpdated(TerminalStatus.CARD_DETECTED);
                        handleMsrData(cardData);
                    }
                    break;
                case TAP_CARD_DETECTED:
                    Timber.d("Tap card detected.");
                    mCardDetected = true;
                    /*
                     TODO: Figure out another approach for getting cardholder name. Using
                     the getEmvCardData() for contactless results in the interface being briefly
                     powered off while the call is made, leading to confusion for the user.
                     */
                    continueContactlessTransaction();
                    break;
                case MAG_HEAD_FAIL:
                    // TODO: Implementation needed.
                    break;
                default:
                    Timber.e("Unrecognized checkCardResult() aborting transaction.");
                    callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                            "Terminal operation error. Aborting transaction.");
            }
        }
    }

    private boolean shouldUseIcc(Hashtable<String, String> cardData) {
        Timber.d("shouldUseIcc() called with: cardData=[%s]", cardData);
        if (mLastChipRead == LastChipRead.NOT_A_CHIP_TRANSACTION ||
                mLastChipRead == LastChipRead.FAILED ||
                mFallbackCondition != null) {
            return false;
        }

        final String keyServiceCode = "serviceCode";

        if (TextUtils.isEmpty(cardData.get(keyServiceCode))) return false;
        return isServiceCodeWithinIccRange(Integer.parseInt(cardData.get(keyServiceCode)));
    }

    private boolean isServiceCodeWithinIccRange(int serviceCode) {
        Timber.d("isServiceCodeWithinIccRange() called with: serviceCode=[%s]", serviceCode);
        return ((serviceCode > 199 && serviceCode < 300) ||
                (serviceCode > 599 && serviceCode < 700));
    }

    /**
     * Invoked when it must be known that the card is removed.
     */
    private void detectCardRemoval() {
        Timber.d("detectCardRemoval() called.");
        checkCard(BBDeviceController.CheckCardMode.SWIPE_OR_INSERT,
                CHECK_CARD_CARD_REMOVAL_TIMEOUT);
    }

    private void handleMsrData(@NonNull Hashtable<String, String> cardData) {
        Timber.d("handleMsrData() called with cardData=[%s]", cardData);
        mBbposCardData = BbposConversionHelper.convertTerminalDataMapToCardData(cardData);
        mBbposAuthorizationData = new BbposAuthorizationData();

        mBbposAuthorizationData.setCardData(mBbposCardData);
        mBbposAuthorizationData.setFallbackCondition(mFallbackCondition);
        callbackOnTerminalStatusUpdated(TerminalStatus.DEVICE_BUSY);
        if (!mUserConfirmationForHostProcessingEnabled) {
            requestHostProcessing();
            resetController();
        } else {
            CardData data = new CardData();
            data.setCardDataSource(CardDataSourceType.MSR);
            requestUserConfirmationForHostProcessing(data);
        }
    }

    private void requestUserConfirmationForHostProcessing(CardData cardData) {
        TerminalInteractionRequest request = new TerminalInteractionRequest(
                TerminalInteractionType.REQUEST_PROCEED_HOST_PROCESSING);
        request.setCardData(cardData);
        callbackOnTerminalInteractionRequest(request);
    }

    @Override
    public void onReturnCancelCheckCardResult(boolean result) {
        Timber.d("onReturnCancelCheckCardResult() called with: result=[%s]", result);
        if (result) {
            mTerminalMode = TerminalMode.IDLE;
            dispatchCancelTransactionResponse();
        } else {
            Timber.d("Unable to cancel checkCard()");
        }
    }

    @Override
    public void onReturnDeviceInfo(Hashtable<String, String> hashtable) {
        Timber.d("onReturnDeviceInfoCalled() with :: hashtable=%s", hashtable);
        final String keySerialNumber = "serialNumber";
        final String keyBatteryPercentage = "batteryPercentage";
        final String keyFirmwareVersion = "firmwareVersion";

        TerminalInfo terminalInfo = new TerminalInfo();

        if (hashtable.containsKey(keySerialNumber)) {
            final String serialNumber = hashtable.get(keySerialNumber);
            terminalInfo.setSerialNumber(serialNumber);
            BBPOSTerminalModel model = BBPOSTerminalModel.fromSerialNumber(serialNumber);
            if (model != null) {
                terminalInfo.setModel(model.friendlyName);
            }
        }
        terminalInfo.setManufacturer(MANUFACTURER);
        if (hashtable.containsKey(keyBatteryPercentage)) {
            String batteryPercentage = hashtable.get(keyBatteryPercentage);
            if (!TextUtils.isEmpty(batteryPercentage)) {
                terminalInfo.setBatteryLevel(Integer.parseInt(batteryPercentage));
            }
        }
        if (hashtable.containsKey(keyFirmwareVersion)) {
            final String firmwareVersion = hashtable.get(keyFirmwareVersion);
            terminalInfo.setFirmwareVersion(firmwareVersion);
        }

        if (mConnectionPendingCompletion) {
            mConnectionPendingCompletion = false;
            mTerminalInfo = terminalInfo;
            handleTerminalConnected();
        } else {
            callbackOnTerminalInfo(terminalInfo);
        }
    }

    @Override
    public void onReturnTransactionResult(BBDeviceController.TransactionResult transactionResult) {
        Timber.d("onReturnTransactionResult() called with :: transactionResult=%s",
                transactionResult.name());
        mReaderInteractionSessionInProgress = false;
        mTransactionResultReturned = true;

        switch (transactionResult) {
            case NOT_ICC:
            case NO_EMV_APPS:
                handleFallbackRequiredResult(transactionResult);
                break;
            case DECLINED:
                handleTerminalTransactionResult(transactionResult);
                break;
            case CARD_BLOCKED:
            case APPROVED:
            case TERMINATED:
            case CANCELED:
            case TIMEOUT:
            case CANCELED_OR_TIMEOUT:
            case ICC_CARD_REMOVED:
            case CAPK_FAIL:
            case CARD_NOT_SUPPORTED:
            case MISSING_MANDATORY_DATA:
            case INVALID_ICC_DATA:
            case DEVICE_ERROR:
            case CARD_SCHEME_NOT_MATCHED:
                handleTerminalTransactionResult(transactionResult);
                break;
        }
    }

    private void handleFallbackRequiredResult(
            @NonNull BBDeviceController.TransactionResult transactionFallbackRequiredResult) {
        Timber.d("handleFallbackCondition() called with: transactionFallbackRequiredResult=[%s]",
                transactionFallbackRequiredResult);
        if (transactionFallbackRequiredResult == BBDeviceController.TransactionResult.NO_EMV_APPS) {
            /* Indicates that there were no AIDS mutually supported by both the terminal and the
               EMV chip. */
            mFallbackCondition = FallbackReason.EMPTY_CANDIDATE_LIST;
        } else {
            // Fallback due to faulty EMV chip.
            mFallbackCondition = FallbackReason.ICC_ERROR;
        }

        checkCard(BBDeviceController.CheckCardMode.SWIPE_OR_INSERT);
    }

    public void setCardData(@NonNull CardData cardData) {
        mCardData = cardData;
    }

    private void handleTerminalTransactionResult(
            @NonNull BBDeviceController.TransactionResult transactionResult) {
        Timber.d("handleTerminalInteractionResult() called with: transactionResult=[%s]",
                transactionResult);
        if (mIsProcessingRefund) {
            Timber.d("Processing as a refund transaction online. Terminal response is not needed.");
            resetController();
            return;
        }
        if (mTerminalResponse == null) {
            mTerminalResponse = new TerminalResponse(TerminalAction.TENDER_GOODS);
        }

        /**
         * Prepare final CardData object for consumption in TransactionManager after terminal response
         * is ready.
         */
        if (mHostProcessingInteractionRequest != null) {
            mCardData = mHostProcessingInteractionRequest.getCardData();
        } else {
            mCardData = new CardData();
        }
        if (!TextUtils.isEmpty(mTerminalResultBatchTlv)) {
            mCardData.setEmvTlvData(ConstructedTlvObject.parse(mTerminalResultBatchTlv));
        }

        mTerminalResponse.setCardData(mCardData);
        switch (transactionResult) {
            case APPROVED:
                mTerminalResponse.setTerminalDecisionType(TerminalDecisionType.APPROVED_ONLINE);
                break;
            case DECLINED:
                if (mGatewayResponse != null) {
                    if (EMV_RESPONSE_CODE_UNABLE_TO_GO_ONLINE
                            .equals(mGatewayResponse.getEmvIssuerAuthCode())) {
                        // Unable to go online. The decline was initiated through the SDK
                        mTerminalResponse
                                .setTerminalDecisionType(TerminalDecisionType.DECLINED_OFFLINE);
                        mTerminalResponse.setMessage("Unable to go online");
                        Timber.d(
                                "handleTerminalInteractionResult() -> Transaction declined due to being unable to go online.");
                    } else {
                        mTerminalResponse
                                .setTerminalDecisionType(TerminalDecisionType.DECLINED_ONLINE);
                    }
                } else {
                    // Terminal declined before host response could be received.
                    mTerminalResponse
                            .setTerminalDecisionType(TerminalDecisionType.DECLINED_OFFLINE);
                }
                break;
            case CARD_BLOCKED:
                mTerminalResponse.setTerminalDecisionType(TerminalDecisionType.DECLINED_OFFLINE);
                mTerminalResponse.setMessage("Card blocked.");
                break;
            case TERMINATED:
            case CANCELED:
            case CANCELED_OR_TIMEOUT:
            case ICC_CARD_REMOVED:
            case TIMEOUT:
                mTerminalResponse
                        .setTerminalDecisionType(TerminalDecisionType.TRANSACTION_CANCELLED);
                break;
            case DEVICE_ERROR:
                // TODO: Implementation pending.
                break;
        }

        validateIfReversalRequired(mGatewayResponse, mTerminalResponse);
        callbackOnTerminalResponse(mTerminalResponse);
        resetController();
    }

    private void validateIfReversalRequired(@Nullable GatewayResponse gatewayResponse,
            TerminalResponse terminalResponse) {
        switch (terminalResponse.getTerminalDecisionType()) {
            case DECLINED_ONLINE:
                if (mPossibleReversalRequired && gatewayResponse != null &&
                        gatewayResponse.isApproved()) {
                    mTerminalResponse
                            .setTerminalDecisionType(TerminalDecisionType.REVERSAL_REQUIRED);
                }
                break;
            case HOST_UNREACHABLE:
                // TODO: Implementation required
                break;
            case TRANSACTION_CANCELLED:
            case DECLINED_OFFLINE:
                if (mPossibleReversalRequired) {
                    if (gatewayResponse == null || !EMV_RESPONSE_CODE_UNABLE_TO_GO_ONLINE
                            .equals(gatewayResponse.getEmvIssuerAuthCode())) {
                        mTerminalResponse
                                .setTerminalDecisionType(TerminalDecisionType.REVERSAL_REQUIRED);
                    }
                }
        }
    }

    @Override
    public void onReturnBatchData(String batchData) {
        Timber.d("onReturnBatchData() called with batchData=[%s]", batchData);
        mTerminalResultBatchTlv = batchData;
    }

    @Override
    public void onReturnReversalData(String tlv) {
        Timber.d("onReturnReversalData() called with tlv=[%s]", tlv);
    }

    @Override
    public void onReturnAmountConfirmResult(boolean result) {
        Timber.d("onReturnAmountConfirmResult() called with result :: %s", result);
    }

    @Override
    public void onReturnUpdateTerminalSettingResult(
            BBDeviceController.TerminalSettingStatus terminalSettingStatus) {
        Timber.d(
                "onReturnUpdateTerminalSettingResult() called with: terminalSettingStatus = [" + terminalSettingStatus +
                        "]");
        if (mTerminalUpdateSettingListener != null) {
            if (terminalSettingStatus == BBDeviceController.TerminalSettingStatus.SUCCESS) {
                mTerminalUpdateSettingListener.onTerminalSettingUpdated(mTerminalSettingType, mTerminalSettingValue);
            } else {
                callbackOnUpdateTerminalInteractionError(ErrorType.TERMINAL_CONFIG_NOT_SUPPORTED,
                        mTerminalSettingType);
            }
        } else {
            callbackOnTerminalInteractionError(TerminalError.CONFIGURATION_ERROR,
                    "Unexpected error cannot update terminal settings.");
        }

        mTerminalSettingType = null;
        mTerminalSettingValue = null;
    }

    @Override
    public void onReturnUpdateTerminalSettingsResult(
            Hashtable<String, BBDeviceController.TerminalSettingStatus> hashtable) {
        Timber.d("onReturnUpdateTerminalSettingsResult() called with: hashtable = [" + hashtable + "]");
        if (mTerminalUpdateSettingListener != null) {
            if (hashtable.containsKey(EmvTagDescriptor.BBPOS_NORMAL_MODE_TIMEOUT.asHexString())) {
                Object objectValue = hashtable.get(EmvTagDescriptor.BBPOS_NORMAL_MODE_TIMEOUT.asHexString());
                if (objectValue != null) {
                    Integer objectIntegerValue = Integer.parseInt(objectValue.toString(), HEX_BASE);
                    mTerminalUpdateSettingListener
                            .onTerminalSettingUpdated(TerminalSettingType.NORMAL_MODE_TIMEOUT, objectIntegerValue);
                }
            } else if (hashtable.containsKey(EmvTagDescriptor.BBPOS_BLUETOOTH_DISCOVERY_TIMEOUT.asHexString())) {
                Object objectValue = hashtable.get(EmvTagDescriptor.BBPOS_BLUETOOTH_DISCOVERY_TIMEOUT.asHexString());
                if (objectValue != null) {
                    Integer objectIntegerValue = Integer.parseInt(objectValue.toString(), HEX_BASE);
                    mTerminalUpdateSettingListener
                            .onTerminalSettingUpdated(TerminalSettingType.BLUETOOTH_DISCOVERY_TIMEOUT,
                                    objectIntegerValue);
                }
            } else if (hashtable.containsKey(EmvTagDescriptor.BBPOS_STANDBY_MODE_TIMEOUT.asHexString())) {
                Object objectValue = hashtable.get(EmvTagDescriptor.BBPOS_STANDBY_MODE_TIMEOUT.asHexString());
                if (objectValue != null) {
                    Integer objectIntegerValue = Integer.parseInt(objectValue.toString(), HEX_BASE);
                    mTerminalUpdateSettingListener
                            .onTerminalSettingUpdated(TerminalSettingType.STANDBY_MODE_TIMEOUT, objectIntegerValue);
                }
            }
        } else {
            callbackOnTerminalInteractionError(TerminalError.CONFIGURATION_ERROR,
                    "Unexpected error cannot update terminal settings.");
        }

        mTerminalSettingType = null;
        mTerminalSettingValue = null;
    }

    @Override
    public void onReturnReadTerminalSettingResult(Hashtable<String, Object> hashtable) {
        Timber.d("onReturnReadTerminalSettingResult() called with: hashtable = [" + hashtable + "]");
        if (mTerminalReadSettingListener != null) {
            if (hashtable.containsKey(EmvTagDescriptor.BBPOS_NORMAL_MODE_TIMEOUT.asHexString())) {
                Object objectValue = hashtable.get(EmvTagDescriptor.BBPOS_NORMAL_MODE_TIMEOUT.asHexString());
                if (objectValue != null) {
                    Integer objectIntegerValue = Integer.parseInt(objectValue.toString());
                    mTerminalReadSettingListener
                            .onTerminalSettingRead(TerminalSettingType.NORMAL_MODE_TIMEOUT, objectIntegerValue);
                }
            } else if (hashtable.containsKey(EmvTagDescriptor.BBPOS_BLUETOOTH_DISCOVERY_TIMEOUT.asHexString())) {
                Object objectValue = hashtable.get(EmvTagDescriptor.BBPOS_BLUETOOTH_DISCOVERY_TIMEOUT.asHexString());
                if (objectValue != null) {
                    Integer objectIntegerValue = Integer.parseInt(objectValue.toString());
                    mTerminalReadSettingListener
                            .onTerminalSettingRead(TerminalSettingType.BLUETOOTH_DISCOVERY_TIMEOUT, objectIntegerValue);
                }
            } else if (hashtable.containsKey(EmvTagDescriptor.BBPOS_STANDBY_MODE_TIMEOUT.asHexString())) {
                Object objectValue = hashtable.get(EmvTagDescriptor.BBPOS_STANDBY_MODE_TIMEOUT.asHexString());
                if (objectValue != null) {
                    Integer objectIntegerValue = Integer.parseInt(objectValue.toString());
                    mTerminalReadSettingListener
                            .onTerminalSettingRead(TerminalSettingType.STANDBY_MODE_TIMEOUT, objectIntegerValue);
                }
            } else {
                callbackOnReadTerminalInteractionError(ErrorType.TERMINAL_CONFIG_NOT_SUPPORTED, mTerminalSettingType);
            }
        } else {
            callbackOnTerminalInteractionError(TerminalError.GENERAL_ERROR,
                    "Unexpected error cannot read terminal settings.");
        }

        mTerminalSettingType = null;
        mTerminalSettingValue = null;
    }

    @Override
    public void onReturnEmvReportList(Hashtable<String, String> hashtable) {
        // Unused
    }

    @Override
    public void onReturnEmvReport(String s) {
        // Unused
    }

    @Override
    public void onReturnEmvCardDataResult(boolean b, String result) {
        Timber.d("onReturnEmvCardDataResult() called with result :: %s", result);
        mOnlineRequestTlv = result;
        decodeEmvCardData(result);
        if (!mCardDetected) {
            /*
            This needs to be fired only for contact transactions. Contactless transactions
            have a different flow for indicating that the card tap was successfully processed.
             */
            if (mCheckCardResult == BBDeviceController.CheckCardResult.INSERTED_CARD) {
                callbackOnTerminalStatusUpdated(TerminalStatus.CARD_DETECTED);
            }
        }
        mCardDetected = true;

        /*
         After retrieving card data elements such as the cardholder name if available, the
         contact or contactless transaction is continued.
         */
        if (mCheckCardResult == BBDeviceController.CheckCardResult.INSERTED_CARD) {
            continueEmvTransaction();
        } else {
            continueContactlessTransaction();
        }
    }

    private void decodeEmvCardData(@Nullable String emvCardDataTlv) {
        Timber.d("decodeEmvCardData() called with: emvCardDataTlv=[%s]", emvCardDataTlv);

         /* At this step, the standard magstripe data can be retrieved. Extract the KSN, cardholder
           name and masked PAN. This TLV data batch does not include all of the TLV tags that
            will be sent to the host after 1st Gen AC. */
        if (!TextUtils.isEmpty(emvCardDataTlv) && mBbDeviceController != null) {
            Hashtable<String, String> tlvTags = BBDeviceController.decodeTlv(emvCardDataTlv);
            Timber.d("decodeEmvCardData() :: Map-> %s", tlvTags);
            mBbposCardData = new BbposCardData();
            if (tlvTags.containsKey(Keys.EmvCardData.KSN)) {
                mBbposCardData.setKsn(tlvTags.get(Keys.EmvCardData.KSN));
            }
            if (tlvTags.containsKey(Keys.EmvCardData.CARDHOLDER_NAME)) {
                mBbposCardData.setCardholderName(
                        new String(TlvUtils.hexStringToByteArray(
                                tlvTags.get(Keys.EmvCardData.CARDHOLDER_NAME))));
            }
            if (tlvTags.containsKey(Keys.EmvCardData.MASKED_PAN)) {
                String maskedPan = tlvTags.get(Keys.EmvCardData.MASKED_PAN);
                mBbposCardData.setMaskedPan(maskedPan);
                if (!TextUtils.isEmpty(maskedPan)) {
                    mBbposCardData.setMaskedPan(maskedPan.replace("F", "X"));
                }
            }
        }
    }

    @Override
    public void onReturnEmvCardNumber(boolean b, String s) {
        // Unused
    }

    @Override
    public void onRequestSelectApplication(ArrayList<String> list) {
        Timber.d("onRequestSelectApplication() called with list :: %s", list);
        if (mAbortTransaction) {
            if (mBbDeviceController != null) {
                mBbDeviceController.cancelSelectApplication();
            }
        } else {
            if (list.size() == 1) {
                if (mBbDeviceController != null) {
                    mBbDeviceController.selectApplication(0);
                }
            } else if (mSelectedApplication != NO_VALUE) {
                /* The value is stored here to avoid showing the application selection prompt twice.
                   After the card is detected, onRequestSelectApplication() is fired and it is also
                   fired after calling startEmv. This situation only happens when there are multiple
                    applications present. */
                if (mBbDeviceController != null) {
                    mBbDeviceController.selectApplication(mSelectedApplication);
                }
            } else {
                mTerminalMode = TerminalMode.WAITING_FOR_APPLICATION_SELECTION;

                TerminalInteractionRequest request = new TerminalInteractionRequest(
                        TerminalInteractionType.EMV_APPLICATION_SELECTION);
                request.setApplicationNames(getApplicationPreferredNames(list));
                callbackOnTerminalInteractionRequest(request);
            }
        }
    }

    @Override
    public void onRequestSelectAccountType() {
        // Unused
    }

    private String[] getApplicationPreferredNames(ArrayList<String> aidTlvList) {
        Timber.d("getApplicationPreferredNames() called with: aidTlvList=[%s]", aidTlvList);
        String initialItem = aidTlvList.get(0);
        List<TlvObject> aidComponents = ConstructedTlvObject.parse(initialItem);

        if (aidComponents == null ||
                (TlvUtils.findTlv(EmvTagDescriptor.APP_LABEL, aidComponents) == null &&
                        TlvUtils.findTlv(EmvTagDescriptor.APPLICATION_PREFERRED_NAME,
                                aidComponents) == null)) {
            // AID names are provided alone.
            return aidTlvList.toArray(new String[0]);
        } else {
            // Entries are TLV-formatted and must be parsed individually.
            String[] appNames = new String[aidTlvList.size()];

            for (int i = 0; i < aidTlvList.size(); i++) {
                List<TlvObject> components = ConstructedTlvObject.parse(aidTlvList.get(i));

                TlvObject target =
                        TlvUtils.findTlv(EmvTagDescriptor.APPLICATION_PREFERRED_NAME, components);
                if (target != null) {
                    appNames[i] = ByteUtils.bytesToUtf8String(target.getValue());
                } else {
                    target = TlvUtils.findTlv(EmvTagDescriptor.APP_LABEL, components);
                    appNames[i] = ByteUtils.bytesToUtf8String(target.getValue());
                }
            }

            return appNames;
        }
    }

    @Override
    public void onRequestSetAmount() {
        Timber.d("onRequestSetAmount() called.");
        TerminalInteractionRequest request = new TerminalInteractionRequest(
                TerminalInteractionType.FINAL_AMOUNT_REQUEST);
        callbackOnTerminalInteractionRequest(request);
    }

    @Override
    public void onRequestOnlineProcess(String iccData) {
        Timber.d("onRequestOnlineProcess()  called with iccData :: %s", iccData);

        mPossibleReversalRequired = true;
        mBbposAuthorizationData = new BbposAuthorizationData();
        mFallbackCondition = null;

        StringBuilder finalIccBuilder = new StringBuilder();
        finalIccBuilder.append(TextUtils.isEmpty(iccData) ? mOnlineRequestTlv : iccData);
        finalIccBuilder.append(getDeviceConfigTlv());
        final String finalIccTlv = finalIccBuilder.toString();

        mBbposAuthorizationData.setIccData(finalIccTlv);
        mBbposAuthorizationData.setCardData(mBbposCardData);
        callbackOnTerminalStatusUpdated(TerminalStatus.DEVICE_BUSY);
        mTerminalMode = TerminalMode.PROCESSING;

        if (!mUserConfirmationForHostProcessingEnabled) {
            requestHostProcessing();
            if (mTerminalRequest != null &&
                    mTerminalRequest.getTransactionType() == TransactionType.REFUND
                    || mTerminalRequest.getTransactionType() == TransactionType.PARTIAL_REFUND) {
                mIsProcessingRefund = true;
                mBbDeviceController.sendOnlineProcessResult(EMV_RESPONSE_CODE_UNABLE_TO_GO_ONLINE);
            }
        } else {
            CardData data = new CardData();
            data.setCardDataSource(CardDataSourceType.SCR);
            requestUserConfirmationForHostProcessing(data);
        }
    }

    private String getDeviceConfigTlv() {
        StringBuilder builder = new StringBuilder();

        TlvObject emvL2ConfigTlv =
                TlvObjectBuilder.create(EmvTagDescriptor.BBPOS_KERNEL_VERSION_NUMBER)
                        .setValue(L2_CONFIG_VERSION.getBytes()).build();
        builder.append(emvL2ConfigTlv.asHexString());

        if (mTerminalInfo != null) {
            final String serialNumber = mTerminalInfo.getSerialNumber();
            if (!TextUtils.isEmpty(serialNumber)) {
                TlvObject deviceSerialNumberTlv =
                        TlvObjectBuilder.create(EmvTagDescriptor.BBPOS_DEVICE_SERIAL_NUMBER)
                                .setValue(serialNumber.getBytes()).build();
                builder.append(deviceSerialNumberTlv.asHexString());
            }
        }

        return builder.toString();
    }

    private void requestHostProcessing() {
        Timber.d("requestHostProcessing() called.");
        if (mBbposAuthorizationData != null) {
            mBbposAuthorizationData.setLastChipRead(mLastChipRead);
            mHostProcessingInteractionRequest =
                    BbposConversionHelper.convertTerminalAuthDataToHostProcessingRequest(
                            mBbposAuthorizationData);
            callbackOnTerminalInteractionRequest(mHostProcessingInteractionRequest);
        } else {
            Timber.e("Card authorization data is null. Aborting transaction.");
            callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                    "Unexpected terminal error. Transaction canceled.");
            /* TODO: Determine if resets should be called here or anywhere where a terminal interaction
             error is sent. The problem with resetting it prematurely is that the device may be
             busy in an operation. It is better to let the device timeout as it will do when
             waiting for a request and end normally.
             For now it is recommended to let the device finish certain functions because the terminal will
             automatically end the transaction when timeouts occur.
             */
        }
    }

    @Override
    public void onRequestTerminalTime() {
        Timber.d("onRequestTerminalTime() called.");
        if (mBbDeviceController != null) {
            mBbDeviceController.sendTerminalTime(Formats.TERMINAL_TIME_FORMAT.format(new Date()));
        }
    }

    @Override
    public void onRequestDisplayText(BBDeviceController.DisplayText displayText, String details) {
        Timber.d("onRequestDisplayText() called with :: displayText=%s", displayText);

        /* Most of these are not used since our SDK controls the status updates without explicitly
           waiting for the third party SDK to tell us what to display.  */
        switch (displayText) {
            case PLEASE_WAIT:
                callbackOnTerminalStatusUpdated(TerminalStatus.DEVICE_BUSY);
                break;
            case PRESENT_CARD_AGAIN:
                callbackOnTerminalStatusUpdated(TerminalStatus.CARD_READ_ERROR);
                break;
            case REMOVE_CARD:
                if (mTransactionResultReturned) {
                    mAwaitingCardRemovalAfterTransaction = true;
                    mTransactionResultReturned = false;
                }
                callbackOnTerminalStatusUpdated(TerminalStatus.REMOVE_CARD);
                break;
            case NO_EMV_APPS:
                mFallbackCondition = FallbackReason.EMPTY_CANDIDATE_LIST;
                break;
            case REFER_TO_YOUR_PAYMENT_DEVICE:
                callbackOnTerminalStatusUpdated(TerminalStatus.SEE_PHONE);
                break;
            case INSERT_OR_SWIPE_CARD:
                callbackOnTerminalStatusUpdated(
                        TerminalStatus.CONTACTLESS_INTERFACE_FAILED_TRY_CONTACT);
                break;
            case NOT_ICC_CARD:
                 /*
                  The below edge case occurs when the user inserts the EMV card backwards, but the
                  card reader detects it as a successful contactless tap due to the proximity
                  of the NFC interface on the card to the contactless interface on the card reader.
                  */
                if (mCheckCardResult == BBDeviceController.CheckCardResult.TAP_CARD_DETECTED) {
                    Timber.w(
                            "User inserted a chip card backwards, but the reader detected the contactless interface on the card.");
                }
                break;
            case INSERT_SWIPE_OR_TRY_ANOTHER_CARD:
                callbackOnTerminalStatusUpdated(TerminalStatus.INSERT_SWIPE_OR_TRY_ANOTHER_CARD);
                break;
            case MULTIPLE_CARDS_DETECTED:
                callbackOnTerminalStatusUpdated(TerminalStatus.MULTIPLE_CARDS_DETECTED);
                break;
            default:
                Timber.d("No handling setup for: displayText=[%s", displayText);
        }
    }

    @Override
    public void onRequestDisplayAsterisk(String s, int i) {

    }

    /*@Override
    public void onRequestDisplayAsterisk(int i) {

    }*/

    //    @Override
    //    public void onRequestDisplayAsterisk(String s, int i) {
    //
    //    }

    @Override
    public void onRequestFinalConfirm() {
        Timber.d("onRequestFinalConfirm() called.");
        if (mAbortTransaction) {
            if (mBbDeviceController != null) {
                mBbDeviceController.sendFinalConfirmResult(false);
            } else {
                Timber.e(
                        "Final confirmation result cannot be sent becaude device controller is null.");
                callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                        "Cannot sent request. Device controller is missing.");
            }
        } else {
            TerminalInteractionRequest request = new TerminalInteractionRequest(
                    TerminalInteractionType.FINAL_AMOUNT_CONFIRMATION);

            // Set the amount to be confirmed as $0.00 for Verify transaction types
            if (TransactionType.VERIFY == mTerminalRequest.getTransactionType()) {
                request.setFinalAmount(0L);
            } else {
                request.setFinalAmount(mFinalTransactionAmount);
            }

            callbackOnTerminalInteractionRequest(request);
        }
    }

    @Override
    public void onBatteryLow(BBDeviceController.BatteryStatus batteryStatus) {
        Timber.d("onBatteryLow() called with batteryStatus=[%s]", batteryStatus);
        callbackOnTerminalInteractionError(TerminalError.BATTERY_TOO_LOW, "Low battery.");
    }

    @Override
    public void onError(BBDeviceController.Error error, String message) {
        Timber.d("onError() called with error :: %s, message :: %s", error, message);
        mReaderInteractionSessionInProgress = false;
        if (BBDeviceController.Error.PAIRING_ERROR_ALREADY_PAIRED_WITH_ANOTHER_DEVICE.equals(error)) {
            callbackOnTerminalInteractionError(TerminalError.BT_READER_ALREADY_PAIRED, message);
        } else if (BBDeviceController.Error.FAIL_TO_START_BT.equals(error)) {
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR, message);
        } else {
            callbackOnTerminalInteractionError(TerminalError.GENERAL_ERROR, message);
        }
    }

    @Override
    public void onRequestStartEmv() {
        Timber.d("onRequestStartEmv() called.");
    }

    @Override
    public void onPowerDown() {
        Timber.d("onPowerDown() called.");
    }

    @Override
    public void onPowerButtonPressed() {
        Timber.d("onPowerButtonPressed() called.");
    }

    //endregion

    // region Utils
    private boolean isTransactionQuickChipEnabled() {
        return mTransactionConfiguration != null && mTransactionConfiguration.isQuickChipEnabled();
    }

    /**
     * For a {@link TransactionType#VERIFY} no amount is required by a host in order to verify a card with the issuer
     * but the current hardware implementation for {@link BBDeviceController} throws a {@link
     * BBDeviceController.Error#INPUT_INVALID} when $0 amount is set for {@link CardDataSourceType#SCR} card types.
     * <p>
     * Initially a $0.01 amount is sent to {@link BBDeviceController} in order to complete the amount confirmation flow
     * where $0 would be the confirmed amount and once confirmed it's reset to $0 and no amount is sent to the
     * underlying host implementation.
     */
    private void setTempMemoryOnlyTerminalRequestTotal() {
        if (TransactionType.VERIFY == mTerminalRequest.getTransactionType()) {
            mTerminalRequest.setTotalAmount(1L);
        }
    }
    //endregion

    //region TerminalListener callbacks.
    private void callbackOnTerminalDisconnected() {
        Timber.d("callbackOnTerminalDisconnected() called.");
        mTerminalListener.onDisconnected();
    }

    private void callbackOnTerminalConnected() {
        Timber.d("callbackOnTerminalConnected() called.");
        if (mTerminalInfo == null) {
            mTerminalInfo = new TerminalInfo();
            mTerminalInfo.setTerminalType(mTerminalConfiguration.getTerminalType());
        }
        mTerminalListener.onConnected(mTerminalInfo);
    }

    private void callbackOnTerminalInfo(final TerminalInfo terminalInfo) {
        Timber.d("callbackOnTerminalInfo() called with: terminalInfo=[%s]",
                terminalInfo);
        mTerminalListener.onTerminalInfo(terminalInfo);
    }

    private void callbackOnTerminalStatusUpdated(final TerminalStatus status) {
        Timber.d("callbackOnTerminalStatusUpdated() called with: status=[%s]", status);
        mTerminalListener.onTerminalStatusUpdate(status);
    }

    private void callbackOnTerminalInteractionRequest(final TerminalInteractionRequest request) {
        Timber.d("callbackOnTerminalInteractionRequest() called with: request=[%s]",
                request);
        mTerminalListener.onTerminalInteractionRequested(request);
    }

    private void callbackOnTerminalResponse(final TerminalResponse terminalResponse) {
        Timber.d("callbackOnTerminalResponse() called with: terminalResponse=[%s]",
                terminalResponse);
        mTerminalListener.onTerminalResponseReceived(terminalResponse);
    }

    private void callbackOnTerminalInteractionError(final TerminalError errorType,
            final String error) {
        Timber.d("callbackOnTerminalInteractionError() called with: errorType=[%s]",
                errorType);
        mTerminalListener.onError(errorType, error);
    }

    private void callbackOnUpdateTerminalInteractionError(final ErrorType errorType,
            final TerminalSettingType terminalSettingType) {
        Timber.d("callbackOnUpdateTerminalInteractionError() called with: errorType = [" + errorType +
                "], terminalSettingType = [" + terminalSettingType + "]");

        mTerminalUpdateSettingListener.onError(new Error() {
            @Override
            public ErrorType getType() {
                return errorType;
            }

            @Override
            public String getMessage() {
                return terminalSettingType.name();
            }
        });
    }

    private void callbackOnReadTerminalInteractionError(final ErrorType errorType,
            final TerminalSettingType terminalSettingType) {
        Timber.d("callbackOnReadTerminalInteractionError() called with: errorType = [" + errorType +
                "], terminalSettingType = [" + terminalSettingType + "]");

        mTerminalReadSettingListener.onError(new Error() {
            @Override
            public ErrorType getType() {
                return errorType;
            }

            @Override
            public String getMessage() {
                return terminalSettingType.name();
            }
        });
    }
    //endregion

    //region Unimplemented/Unused BBDeviceController.BBDeviceControllerListener callbacks
    @Override
    public void onBTRequestPairing() {
        // TODO: Determine if needed.
    }

    @Override
    public void onReturnDisableAccountSelectionResult(boolean b) {
        // Unused
    }

    @Override
    public void onReturnDisableInputAmountResult(boolean b) {
        // Unused
    }

    @Override
    public void onReturnDisableBluetoothResult(boolean b) {

    }

    @Override
    public void onReturnPhoneNumber(BBDeviceController.PhoneEntryResult phoneEntryResult,
            String s) {
        // Unused
    }

    @Override
    public void onRequestDisplayLEDIndicator(
            BBDeviceController.ContactlessStatus contactlessStatus) {
        // Unused
    }

    @Override
    public void onRequestProduceAudioTone(
            BBDeviceController.ContactlessStatusTone contactlessStatusTone) {
        // Unused
    }

    @Override
    public void onRequestClearDisplay() {
        // Unused
    }

    @Override
    public void onReturnEncryptPinResult(boolean b, Hashtable<String, String> hashtable) {
        // Unused
    }

    @Override
    public void onReturnEncryptDataResult(boolean b, Hashtable<String, String> hashtable) {
        // Unused
    }

    @Override
    public void onReturnInjectSessionKeyResult(boolean b, Hashtable<String, String> hashtable) {
        // Unused
    }

    @Override
    public void onReturnPowerOnIccResult(boolean b, String s, String s1, int i) {
        // Unused
    }

    @Override
    public void onReturnPowerOffIccResult(boolean b) {
        // Unused
    }

    @Override
    public void onReturnApduResult(boolean b, Hashtable<String, Object> hashtable) {
        // Unused
    }

    @Override
    public void onReturnUpdateDisplayStringResult(boolean b, String s) {
        // Unused
    }

    @Override
    public void onReturnReadDisplayStringResult(boolean b, Hashtable<String, String> hashtable) {
        // Unused
    }

    @Override
    public void onReturnReadDisplaySettingsResult(boolean b, Hashtable<String, Object> hashtable) {
        // Unused
    }

    @Override
    public void onReturnReadAIDResult(Hashtable<String, Object> result) {
        Timber.d("onReturnReadAIDResult() called with result :: %s", result);
    }

    @Override
    public void onReturnEnableAccountSelectionResult(boolean b) {
        // Unused
    }

    @Override
    public void onReturnEnableInputAmountResult(boolean b) {
        // Unused
    }

    @Override
    public void onReturnEnableBluetoothResult(boolean b) {

    }

    @Override
    public void onReturnCAPKList(List<CAPK> list) {
        // Unused
    }

    @Override
    public void onReturnCAPKDetail(CAPK capk) {
        // Unused
    }

    @Override
    public void onReturnCAPKLocation(String s) {
        // Unused
    }

    @Override
    public void onReturnUpdateCAPKResult(boolean b) {
        // Unused
    }

    @Override
    public void onReturnRemoveCAPKResult(boolean b) {
        // Unused
    }

    @Override
    public void onUsbConnected() {
        Timber.d("onUsbConnected() called.");
        mConnected = true;
        mConnectionPendingCompletion = true;
        if (mBbDeviceController != null) {
            mBbDeviceController.getDeviceInfo();
        } else {
            Timber.w(
                    "Completed terminal connection but unable to retrieve terminal info. Device controller is null.");
            handleTerminalConnected();
        }
    }

    @Override
    public void onUsbDisconnected() {
        Timber.d("onUsbDisconnected() called.");
        mConnected = false;
        callbackOnTerminalDisconnected();
    }

    @Override
    public void onSerialConnected() {
        // Unused
    }

    @Override
    public void onSerialDisconnected() {
        // Unused
    }

    @Override
    public void onWaitingReprintOrPrintNext() {
        // Unused
    }

    @Override
    public void onReturnPinEntryResult(BBDeviceController.PinEntryResult pinEntryResult,
            Hashtable<String, String> hashtable) {
        // Unused
    }

    @Override
    public void onReturnPrintResult(BBDeviceController.PrintResult printResult) {
        // Unused
    }

    @Override
    public void onReturnAccountSelectionResult(
            BBDeviceController.AccountSelectionResult accountSelectionResult, int i) {
        // Unused
    }

    @Override
    public void onReturnAmount(AmountInputResult amountInputResult, Hashtable<String, String> hashtable) {

    }

    @Override
    public void onReturnUpdateAIDResult(Hashtable<String, Object> hashtable) {

    }

    @Override
    public void onRequestOtherAmount(BBDeviceController.AmountInputType amountInputType) {
        // Unused
    }

    @Override
    public void onRequestPinEntry(BBDeviceController.PinEntrySource pinEntrySource) {
        // Unused
    }

    @Override
    public void onRequestManualPanEntry(ManualPanEntryType manualPanEntryType) {

    }

    //    @Override
    //    public void onRequestManualPanEntry(ManualPanEntryType manualPanEntryType) {
    //
    //    }

    @Override
    public void onReturnSetPinPadButtonsResult(boolean b) {
        // Unused
    }

    @Override
    public void onReturnSetPinPadOrientationResult(boolean b) {
        // Unused
    }

    @Override
    public void onReturnAccessiblePINPadTouchEvent(PinPadTouchEvent pinPadTouchEvent) {
        // Unused
    }

    @Override
    public void onReturnUpdateDisplaySettingsProgress(double v) {
        // Unused
    }

    @Override
    public void onReturnUpdateDisplaySettingsResult(boolean b, String s) {
        // Unused
    }

    @Override
    public void onDeviceDisplayingPrompt() {
        // Unused
    }

    @Override
    public void onRequestKeypadResponse() {
        // Unused
    }

    @Override
    public void onReturnDisplayPromptResult(
            BBDeviceController.DisplayPromptResult displayPromptResult) {
        // Unused
    }

    @Override
    public void onReturnFunctionKey(BBDeviceController.FunctionKey functionKey) {
        // Unused
    }

    @Override
    public void onHardwareFunctionalTestResult(int i, int i1, String s) {
        // Unused
    }

    @Override
    public void onBarcodeReaderConnected() {
        // Unused
    }

    @Override
    public void onBarcodeReaderDisconnected() {
        // Unused
    }

    @Override
    public void onReturnBarcode(String s) {
        // Unused
    }

    @Override
    public void onRequestVirtuCryptPEDIResponse(boolean b, Hashtable<String, String> hashtable) {

    }

    @Override
    public void onReturnVirtuCryptPEDICommandResult(boolean b, Hashtable<String, String> hashtable) {

    }

    @Override
    public void onRequestVirtuCryptPEDKResponse(boolean b, Hashtable<String, String> hashtable) {

    }

    @Override
    public void onReturnVirtuCryptPEDKCommandResult(boolean b, Hashtable<String, String> hashtable) {

    }

    @Override
    public void onPowerConnected(BBDeviceController.PowerSource powerSource,
            BBDeviceController.BatteryStatus batteryStatus) {
        // Unused
    }

    @Override
    public void onPowerDisconnected(BBDeviceController.PowerSource powerSource) {
        // Unused
    }

    @Override
    public void onDeviceReset(boolean b, BBDeviceController.DeviceResetReason deviceResetReason) {
        // Unused
    }

    @Override
    public void onDeviceResetAlert(int i) {
        // Unused
    }

    @Override
    public void onEnterStandbyMode() {
        // Unused
    }

    @Override
    public void onReturnWatchdogTimerReset() {

    }

    @Override
    public void onReturnNfcDataExchangeResult(boolean b, Hashtable<String, String> hashtable) {
        // Unused
    }

    @Override
    public void onReturnNfcDetectCardResult(
            BBDeviceController.NfcDetectCardResult nfcDetectCardResult,
            Hashtable<String, Object> hashtable) {
        // Unused
    }

    @Override
    public void onReturnControlLEDResult(boolean b, String s) {
        // Unused
    }

    @Override
    public void onReturnVasResult(BBDeviceController.VASResult vasResult,
            Hashtable<String, Object> hashtable) {
        // Unused
    }

    @Override
    public void onRequestAmountConfirm(Hashtable<String, String> hashtable) {
        // Unused
    }

    @Override
    public void onRequestPrintData(int i, boolean b) {
        // Unused
    }

    @Override
    public void onPrintDataCancelled() {
        // Unused
    }

    @Override
    public void onPrintDataEnd() {
        // Unused
    }

    @Override
    public void onDeviceHere(boolean deviceHere) {
        Timber.d("onDeviceHere() called with deviceHere :: %s", true);
        // TODO: Implementation needed.
    }

    @Override
    public void onSessionInitialized() {
        // Unused
    }

    @Override
    public void onSessionError(BBDeviceController.SessionError sessionError, String s) {
        // Unused
    }

    @Override
    public void onReturnDebugLog(Hashtable<String, Object> hashtable) {
        // Unused
    }
    //endregion

    private class OtaListener extends BbposOTAListener {

        /**
         * Indicates that any callbacks should be treated as occurring as part of the update flow as opposed to simply
         * querying the OTA controller for pieces of information and returning those to the consuming app.
         */
        private boolean mTerminalUpdateFlowInitiated;

        public void setTerminalUpdateFlowInitiated(boolean terminalUpdateFlowInitiated) {
            mTerminalUpdateFlowInitiated = terminalUpdateFlowInitiated;
        }

        @Override
        public void onReturnRemoteKeyInjectionResult(BBDeviceOTAController.OTAResult otaResult, String message) {
            Timber.d("onReturnRemoteKeyInjectionResult() called with otaResult=%s,message = %s", otaResult, message);
            if (otaResult == BBDeviceOTAController.OTAResult.SUCCESS) {
                mTerminalVersionUpdateListener.onTerminalUpdateSuccess();
            } else {
                handleOtaUpdateError(otaResult, message);
            }
        }

        @Override
        public void onReturnRemoteFirmwareUpdateResult(BBDeviceOTAController.OTAResult otaResult, String message) {
            Timber.d("onReturnRemoteFirmwareUpdateResult() called with otaResult=%s,message = %s", otaResult, message);
            if (otaResult == BBDeviceOTAController.OTAResult.SUCCESS) {
                mTerminalVersionUpdateListener.onTerminalUpdateSuccess();
            } else {
                handleOtaUpdateError(otaResult, message);
            }
        }

        @Override
        public void onReturnRemoteConfigUpdateResult(BBDeviceOTAController.OTAResult otaResult, String message) {
            Timber.d("onReturnRemoteConfigUpdateResult() called with otaResult=%s,message = %s", otaResult, message);
            if (otaResult == BBDeviceOTAController.OTAResult.SUCCESS) {
                mTerminalVersionUpdateListener.onTerminalUpdateSuccess();
            } else {
                handleOtaUpdateError(otaResult, message);
            }
        }

        @Override
        public void onReturnOTAProgress(double progress) {
            Timber.d("onReturnOTAProgress() called with progress=%1$,.2f", progress);
            mTerminalVersionUpdateListener.onProgress(progress, null);
        }

        @Override
        public void onReturnTargetVersionResult(BBDeviceOTAController.OTAResult otaResult,
                Hashtable<String, String> hashtable) {
            Timber.d("onReturnTargetVersionResult() called with otaResult=%s,hashtable = %s", otaResult, hashtable);
            if (mTerminalUpdateFlowInitiated) {
                if (otaResult == BBDeviceOTAController.OTAResult.SUCCESS) {
                    mTargetUpdateVersion = mTerminalUpdateType == TerminalUpdateType.FIRMWARE ?
                            hashtable.get(BbposOTAKeys.FIRMWARE_VERSION) :
                            hashtable.get(BbposOTAKeys.TERMINAL_SETTING_VERSION);
                    setRemoteTargetUpdateVersion();
                } else {
                    handleOtaUpdateError(otaResult,
                            "Failed to retrieve target version from TMS server. Aborting terminal update process.");
                }
            } else {
                if (otaResult == BBDeviceOTAController.OTAResult.SUCCESS) {
                    mTargetUpdateVersion = mTerminalUpdateType == TerminalUpdateType.FIRMWARE ?
                            hashtable.get(BbposOTAKeys.FIRMWARE_VERSION) :
                            hashtable.get(BbposOTAKeys.TERMINAL_SETTING_VERSION);
                    mAvailableVersionsListener.onAvailableTerminalVersionsReceived(mTerminalUpdateType,
                            Collections.singletonList(mTargetUpdateVersion));
                } else {
                    handleOtaUpdateError(otaResult,
                            "Failed to retrieve target version from TMS server.");
                }
            }
        }

        @Override
        public void onReturnSetTargetVersionResult(BBDeviceOTAController.OTAResult otaResult, String message) {
            Timber.d("onReturnSetTargetVersionResult() called with otaResult=%s,message=%s", otaResult,
                    message);
            // Update Version Flow
            // 1. Set Target Version
            // 2. Perform Requested Update if successful. Otherwise, return an error.
            if (otaResult == BBDeviceOTAController.OTAResult.SUCCESS) {
                startRemoteTerminalUpdate();
            } else {
                handleOtaUpdateError(otaResult, message);
            }
        }

        private void handleOtaUpdateError(BBDeviceOTAController.OTAResult otaResult, String message) {
            switch (otaResult) {
                case BATTERY_LOW_ERROR:
                    callbackOnTerminalInteractionError(TerminalError.BATTERY_TOO_LOW, message);
                    break;
                case SETUP_ERROR:
                    callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                            message);
                    break;
                case DEVICE_COMM_ERROR:
                case FAILED:
                case STOPPED:
                    callbackOnTerminalInteractionError(TerminalError.DEVICE_COMM_ERROR,
                            message);
                    break;
                case SERVER_COMM_ERROR:
                    callbackOnTerminalInteractionError(TerminalError.SERVER_COMM_ERROR,
                            message);
                    break;
                case NO_UPDATE_REQUIRED:
                    callbackOnTerminalInteractionError(TerminalError.UPDATE_NOT_REQUIRED,
                            message);
            }
        }
    }
}
