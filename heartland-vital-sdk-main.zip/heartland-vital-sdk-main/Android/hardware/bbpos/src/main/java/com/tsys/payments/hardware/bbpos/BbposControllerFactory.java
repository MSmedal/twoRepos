package com.tsys.payments.hardware.bbpos;

import android.content.Context;

import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.terminal.TerminalController;
import com.tsys.payments.library.terminal.TerminalControllerFactory;
import com.tsys.payments.library.terminal.TerminalListener;

import androidx.annotation.Nullable;

import java.util.Objects;

public class BbposControllerFactory implements TerminalControllerFactory {

    @Nullable
    @Override
    public TerminalType[] getSupportedTerminalTypes() {
        return new TerminalType[] {TerminalType.BBPOS_C2X};
    }

    @Nullable
    @Override
    public ConnectionType[] getSupportedConnectionTypes(TerminalType terminalType)
            throws IllegalArgumentException {
        if (terminalType == TerminalType.BBPOS_C2X) {
            return new ConnectionType[] {ConnectionType.BLUETOOTH, ConnectionType.USB};
        } else {
            throw new IllegalArgumentException(
                    "getSupportedConnectionTypes() called with null argument.");
        }
    }

    @Nullable
    @Override
    public TerminalController create(Context context, TerminalConfiguration terminalConfiguration,
            TransactionConfiguration transactionConfiguration, TerminalListener listener)
            throws IllegalArgumentException {
        Objects.requireNonNull(context);
        Objects.requireNonNull(terminalConfiguration);
        Objects.requireNonNull(transactionConfiguration);
        Objects.requireNonNull(listener);

        return new BbposController(context, terminalConfiguration, transactionConfiguration,
                listener);
    }
}
