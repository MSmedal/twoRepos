package com.tsys.payments.hardware.bbpos.constants;

/**
 * Contains keys representing input needed for performing OTA(Over-the-Air) terminal version updates with BBPOS
 */
public final class BbposOTAKeys {
    public static final String VENDOR_ID = "vendorID";
    public static final String APP_ID = "appID";
    public static final String VENDOR_SECRET = "vendorSecret";
    public static final String APP_SECRET = "appSecret";
    public static final String FORCE_UPDATE = "forceUpdate";
    public static final String FIRMWARE_TYPE = "firmwareType";
    public static final String FIRMWARE_VERSION = "firmwareVersion";
    public static final String TARGET_VERSION_TYPE = "targetVersionType";
    public static final String DEVICE_SETTING_VERSION = "deviceSettingVersion";
    public static final String TERMINAL_SETTING_VERSION = "terminalSettingVersion";
}
