package com.tsys.payments.hardware.bbpos.constants;

import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Listing of different formats expected by the BBPOS Card Reader SDK
 */
public final class Formats {
    public static final SimpleDateFormat
            TERMINAL_TIME_FORMAT = new SimpleDateFormat("yyMMddHHmmss", Locale.US);

    private Formats() {
    }
}
