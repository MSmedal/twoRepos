package com.tsys.payments.hardware.bbpos.enums;

/**
 * Indicates the current state of the terminal in terms of the activity being performed in it.
 */
public enum TerminalMode {
    /**
     * Terminal is waiting to be configured or waiting for a transaction to be initiated.
     */
    IDLE,
    /**
     * EMV kernel parameters are being configured. General terminal settings are being configured.
     */
    CONFIGURING,
    /**
     * EMV kernel is configured and now ready for a transaction to begin.
     */
    WAITING_FOR_TRANSACTION,
    /**
     * Terminal is waiting for cardholder action on the card.
     */
    WAITING_FOR_CARD,
    /**
     * A transaction is in progress. Terminal is performing actions associated with MSR and EMV transactions.
     */
    TRANSACTION,
    /**
     * A transaction is in progress and the terminal is waiting for the amounts to be set.
     */
    WAITING_FOR_AMOUNT,
    /**
     * A transaction is in progress and the terminal is waiting for application selection.
     */
    WAITING_FOR_APPLICATION_SELECTION,
    /**
     * A transaction is in progress. Online processing is being performed. Transaction cannot be cancelled at this
     * point.
     */
    PROCESSING
}
