package com.tsys.payments.hardware.bbpos;

import android.text.TextUtils;

import com.bbpos.bbdevice.BBDeviceController;
import com.tsys.payments.hardware.bbpos.model.BbposAuthorizationData;
import com.tsys.payments.hardware.bbpos.model.BbposCardData;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CurrencyCode;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.terminal.domain.TerminalInteractionRequest;
import com.tsys.payments.library.terminal.enums.TerminalAction;
import com.tsys.payments.library.terminal.enums.TerminalInteractionType;
import com.tsys.payments.library.tlv.ConstructedTlvObject;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

import java.util.Hashtable;
import java.util.List;

/**
 * Convert between data models specific to Core SDK and BBPOS Module SDK.
 */
final class BbposConversionHelper {
    private static final int MAX_CURRENCY_CODE_CHARACTERS = 4;

    /**
     * Indicates that the PAN was entered via contact EMV according to ISO-8583. This is one of
     * the possible values of tag {@link EmvTagDescriptor#POS_ENTRY_MODE}.
     */
    static final String PAN_ENTRY_MODE_CONTACT_EMV = "05";
    /**
     * Indicates that the PAN was entered via contactless EMV according to ISO-8583. This is one of
     * the possible values of tag {@link EmvTagDescriptor#POS_ENTRY_MODE}.
     */
    static final String PAN_ENTRY_MODE_CONTACTLESS_EMV = "07";
    /**
     * Indicates that the PAN was entered via contactless magnetic stripe according to ISO-8583.
     * This is one of
     * the possible valuesof tag {@link EmvTagDescriptor#POS_ENTRY_MODE}.
     */
    static final String PAN_ENTRY_MODE_CONTACTLESS_MSR = "91";

    private BbposConversionHelper() {

    }

    /**
     * Returns the currency code as a 4 character string with a leading 0 followed by the currency
     * number for the terminal to consume.
     */
    static String getFormattedCurrencyCode(@NonNull CurrencyCode currencyCode) {
        Timber.d("getFormattedCurrencyCode() called with: currencyCode=[%s]", currencyCode);
        StringBuilder builder = new StringBuilder(currencyCode.currencyCode);
        if (builder.length() > MAX_CURRENCY_CODE_CHARACTERS) {
            return builder.toString().substring(builder.length() - MAX_CURRENCY_CODE_CHARACTERS);
        } else {
            while (builder.length() < MAX_CURRENCY_CODE_CHARACTERS) {
                builder.insert(0, "0");
            }
            return builder.toString();
        }
    }

    /**
     * Convert the payment SDK transaction type {@link TerminalAction} into a {@link
     * BBDeviceController.TransactionType} consumed by the BBPOS terminals.
     */
    @Nullable
    static BBDeviceController.TransactionType getTransactionType(TerminalAction terminalAction) {
        Timber.d("getTransactionType() called.");
        if (terminalAction == null) {
            Timber.d("getTransactionType() :: terminalAction is null");
            return null;
        }

        switch (terminalAction) {
            case TENDER_SERVICES:
                return BBDeviceController.TransactionType.SERVICES;
            case TENDER_REFUND:
                return BBDeviceController.TransactionType.REFUND;
            default:
                return BBDeviceController.TransactionType.GOODS;
        }
    }

    /**
     * Converts card data obtained from the {@link BBDeviceController} via a swipe to a {@link
     * BbposCardData} intermediate card information object used by the {@link BbposController}.
     */
    static BbposCardData convertTerminalDataMapToCardData(@NonNull
            Hashtable<String, String> terminalData) {
        Timber.d("convertTerminalDataMapToCardData() called with: terminalData=[%s]", terminalData);
        BbposCardData cardData = new BbposCardData();

        final String keyMaskedPan = "maskedPAN";
        final String keyCardholderName = "cardholderName";
        final String keyEncryptedTrack1Data = "encTrack1";
        final String keyEncryptedTrack2Data = "encTrack2";
        final String keyEncryptedTrack3Data = "encTrack3";
        final String keyEncryptedTrackData = "encTracks";
        final String keyExpiryDate = "expiryDate";
        final String keyKsn = "ksn";
        final String keyPosEntryMode = "posEntryMode";

        cardData.setMaskedPan(terminalData.get(keyMaskedPan));
        cardData.setCardholderName(terminalData.get(keyCardholderName));
        cardData.setEncryptedTrack1(terminalData.get(keyEncryptedTrack1Data));
        cardData.setEncryptedTrack2(terminalData.get(keyEncryptedTrack2Data));
        cardData.setEncryptedTrack3(terminalData.get(keyEncryptedTrack3Data));
        cardData.setEncryptedTracks(terminalData.get(keyEncryptedTrackData));
        cardData.setExpiryData(terminalData.get(keyExpiryDate));
        cardData.setKsn(terminalData.get(keyKsn));
        cardData.setPosEntryMode(terminalData.get(keyPosEntryMode));
        return cardData;
    }

    /**
     * Converts BBPOS terminal authorization request data to SDK {@link TerminalInteractionRequest}
     * of type {@link TerminalInteractionType#HOST_PROCESSING}
     */
    static TerminalInteractionRequest convertTerminalAuthDataToHostProcessingRequest(@NonNull
            BbposAuthorizationData authorizationData) {
        Timber.d(
                "convertTerminalAuthDataToHostProcessingRequest() called with: authorizationData=[%s]",
                authorizationData);
        TerminalInteractionRequest interactionRequest =
                new TerminalInteractionRequest(TerminalInteractionType.HOST_PROCESSING);
        CardData sdkCardData = new CardData();

        BbposCardData terminalCardData = authorizationData.getCardData();

        if (authorizationData.getIccData() != null) {
            List<TlvObject> tlvObjects = ConstructedTlvObject.parse(authorizationData.getIccData());
            sdkCardData.setEmvTlvData(tlvObjects);

            if (terminalCardData != null) {
                sdkCardData.setTrack2(terminalCardData.getEncryptedTrack2());
                sdkCardData.setKsn(terminalCardData.getKsn());
                sdkCardData.setCardholderName(terminalCardData.getCardholderName());

                if (!TextUtils.isEmpty(terminalCardData.getMaskedPan())) {
                    sdkCardData.setPan(terminalCardData.getMaskedPan());
                } else {
                    sdkCardData.setPan(extractMaskedPanFromTlv(tlvObjects));
                }
            } else {
                sdkCardData.setPan(extractMaskedPanFromTlv(tlvObjects));
            }

            TlvObject posEntryMode = TlvUtils.findTlv(EmvTagDescriptor.POS_ENTRY_MODE, tlvObjects);
            if (posEntryMode == null) {
                sdkCardData.setCardDataSource(CardDataSourceType.SCR);
            } else {
                sdkCardData.setCardDataSource(getCardDataSourceTypeFromTlv(posEntryMode));
            }

            interactionRequest.setCardData(sdkCardData);
        } else {
            if (authorizationData.getFallbackCondition() != null) {
                sdkCardData.setFallbackReason(authorizationData.getFallbackCondition());
                sdkCardData.setCardDataSource(CardDataSourceType.FALLBACK);
            } else {
                sdkCardData.setCardDataSource(CardDataSourceType.MSR);
            }
            if (terminalCardData != null) {
                sdkCardData.setPan(terminalCardData.getMaskedPan());
                sdkCardData.setCardholderName(terminalCardData.getCardholderName());
                sdkCardData.setPackedEncryptedData(terminalCardData.getEncryptedTracks());
                sdkCardData.setTrack1(terminalCardData.getEncryptedTrack1());
                sdkCardData.setTrack2(terminalCardData.getEncryptedTrack2());
                sdkCardData.setTrack3(terminalCardData.getEncryptedTrack3());

                if (!TextUtils.isEmpty(terminalCardData.getExpiryData())) {
                    sdkCardData.setExpirationDate(terminalCardData.getExpiryData().substring(2) +
                            terminalCardData.getExpiryData().substring(0, 2));
                }
                sdkCardData.setKsn(terminalCardData.getKsn());
            }
        }

        sdkCardData.setCvv2(authorizationData.getCvm());
        sdkCardData.setLastChipRead(authorizationData.getLastChipRead());
        interactionRequest.setCardData(sdkCardData);
        return interactionRequest;
    }

    @Nullable
    static String extractMaskedPanFromTlv(List<TlvObject> tlvObjects) {
        TlvObject maskedPan =
                TlvUtils.findTlv(EmvTagDescriptor.BBPOS_MASKED_PAN, tlvObjects);
        if (maskedPan != null) {
            return maskedPan.getValueAsHexString(false);
        }

        return null;
    }

    /**
     * Extract the entry mode corresponding to the terminal interface that performed the
     * transaction.
     * This entry mode is mapped in the TLV object with tag
     * {@link com.tsys.payments.library.tlv.EmvTagDescriptor#POS_ENTRY_MODE}.
     *
     * @param posEntryMode {@link TlvObject} with tag descriptor {@link
     * com.tsys.payments.library.tlv.EmvTagDescriptor#POS_ENTRY_MODE}.
     */
    @Nullable
    static CardDataSourceType getCardDataSourceTypeFromTlv(@Nullable TlvObject posEntryMode) {
        if (posEntryMode == null) {
            return null;
        } else if (posEntryMode.getTagDescriptor() != EmvTagDescriptor.POS_ENTRY_MODE) {
            return null;
        } else {
            String value = posEntryMode.getValueAsHexString(false);
            if (PAN_ENTRY_MODE_CONTACT_EMV.equals(value)) {
                return CardDataSourceType.SCR;
            } else if (PAN_ENTRY_MODE_CONTACTLESS_EMV.equals(value)) {
                return CardDataSourceType.CONTACTLESS_EMV;
            } else if (PAN_ENTRY_MODE_CONTACTLESS_MSR.equals(value)) {
                return CardDataSourceType.CONTACTLESS_MSR;
            } else {
                return null;
            }
        }
    }

    /**
     * Returns a string concatenation of the tags {@link com.tsys.payments.library.tlv.EmvTagDescriptor#AUTHORIZATION_RESPONSE_CODE},
     * {@link com.tsys.payments.library.tlv.EmvTagDescriptor#ISSUER_AUTHENTICATION_DATA} and {@link
     * com.tsys.payments.library.tlv.EmvTagDescriptor#ISSUER_SCRIPT_TEMPLATE_1}
     * or {@link com.tsys.payments.library.tlv.EmvTagDescriptor#ISSUER_SCRIPT_TEMPLATE_2} depending
     * on which issuer script is present. Only 1 issuer script type will be present at any time.
     * This result is consumed by the terminal after online authorization has occurred and a
     * response is received from the payment gateway.
     *
     * @param gatewayResponse {@link GatewayResponse} for payment processing.
     * @return {@link String} representing the EMV online processing result.
     */
    static String getOnlineEmvProcessingResult(GatewayResponse gatewayResponse) {
        Timber.d("getOnlineEmvProcessingResult() called with: gatewayResponse=[%s]",
                gatewayResponse);
        StringBuilder builder = new StringBuilder();

        if (!TextUtils.isEmpty(gatewayResponse.getEmvIssuerAuthCode())) {
            builder.append(gatewayResponse.getEmvIssuerAuthCode());
        }
        if (!TextUtils.isEmpty(gatewayResponse.getEmvIssuerAuthenticationData())) {
            builder.append(gatewayResponse.getEmvIssuerAuthenticationData());
        }
        if (!TextUtils.isEmpty(gatewayResponse.getEmvIssuerScripts())) {
            builder.append(gatewayResponse.getEmvIssuerScripts());
        }

        return builder.toString();
    }
}
