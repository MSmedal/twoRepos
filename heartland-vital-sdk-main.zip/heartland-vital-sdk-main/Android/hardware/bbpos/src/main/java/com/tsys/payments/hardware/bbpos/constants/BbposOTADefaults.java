package com.tsys.payments.hardware.bbpos.constants;

import com.bbpos.bbdevice.ota.BBDeviceOTAController;

public final class BbposOTADefaults {
    /**
     * Default value to supply for key {@link BbposOTAKeys#FIRMWARE_TYPE}
     */
    public static final BBDeviceOTAController.FirmwareType FIRMWARE_TYPE =
            BBDeviceOTAController.FirmwareType.MAIN_PROCESSOR;

    /**
     * Default value to supply for key {@link BbposOTAKeys#VENDOR_ID}
     */
    public static final String VENDOR_ID = "bbpos1";

    /**
     * Default value to supply for key {@link BbposOTAKeys#VENDOR_SECRET}
     */
    public static final String VENDOR_SECRET = "bbpos1";

    /**
     * Default value to supply for key {@link BbposOTAKeys#FORCE_UPDATE}
     */
    public static final boolean FORCE_UPDATE = true;

    /**
     * Default value to supply for key {@link BbposOTAKeys#APP_ID}
     */
    public static final String APP_ID = "bbpos2";

    /**
     * Default value to supply for key {@link BbposOTAKeys#APP_SECRET}
     */
    public static final String APP_SECRET = "bbpos2";
}
