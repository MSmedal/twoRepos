package com.tsys.payments.hardware.bbpos;

import com.bbpos.bbdevice.ota.BBDeviceOTAController;
import java.util.Hashtable;
import java.util.List;

/**
 * Base class for OTA Listener implementations. This class should be extended so that only necessary overrides are
 * implemented on an as-needed basis to reduce clutter of unused callbacks.
 */
class BbposOTAListener implements BBDeviceOTAController.BBDeviceOTAControllerListener {

    @Override
    public void onReturnRemoteKeyInjectionResult(BBDeviceOTAController.OTAResult otaResult, String s) {
        // Implement as needed
    }

    @Override
    public void onReturnRemoteFirmwareUpdateResult(BBDeviceOTAController.OTAResult otaResult, String s) {
        // Implement as needed
    }

    @Override
    public void onReturnRemoteConfigUpdateResult(BBDeviceOTAController.OTAResult otaResult, String s) {
        // Implement as needed
    }

    @Override
    public void onReturnLocalFirmwareUpdateResult(BBDeviceOTAController.OTAResult otaResult, String s) {
        // Implement as needed
    }

    @Override
    public void onReturnLocalConfigUpdateResult(BBDeviceOTAController.OTAResult otaResult, String s) {
        // Implement as needed
    }

    @Override
    public void onReturnOTAProgress(double v) {
        // Implement as needed
    }

    @Override
    public void onReturnTargetVersionResult(BBDeviceOTAController.OTAResult otaResult,
            Hashtable<String, String> hashtable) {
        // Implement as needed
    }

    @Override
    public void onReturnTargetVersionListResult(BBDeviceOTAController.OTAResult otaResult,
            List<Hashtable<String, String>> list, String s) {
        // Implement as needed
    }

    @Override
    public void onReturnSetTargetVersionResult(BBDeviceOTAController.OTAResult otaResult, String s) {
        // Implement as needed
    }

    @Override
    public void onReturnOTADebugLog(Hashtable<String, Object> hashtable) {

    }

    //    @Override
//    public void onReturnOTADebugLog(Hashtable<String, Object> hashtable) {
//
//    }
}
