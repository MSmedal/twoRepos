package com.tsys.payments.hardware.bbpos.constants;

import com.bbpos.bbdevice.BBDeviceController;
import com.tsys.payments.library.tlv.EmvTagDescriptor;

import java.util.Hashtable;

/**
 * Keys used for different terminal methods.
 */
public final class Keys {

    private Keys() {

    }

    /**
     * Keys for getDevinceInfo() result map. See {@link BBDeviceController#getDeviceInfo()} and
     * {@link BBDeviceController.BBDeviceControllerListener#onReturnDeviceInfo(Hashtable)}
     */
    public static final class DeviceInfo {

        private DeviceInfo() {

        }

        /**
         * Battery voltage.
         */
        public static final String BATTERY_LEVEL = "batteryLevel";

        /**
         * Battery percentage.
         */
        public static final String BATTERY_PERCENTAGE = "batteryPercentage";

        /**
         * BBPOS ID.
         */
        public static final String BID = "bID";

        /**
         * Product ID.
         */
        public static final String PRODUCT_ID = "productID";

        /**
         * Serial number of the device.
         */
        public static final String SERIAL_NUMBER = "serialNumber";

        /**
         * Unique Chip ID.
         */
        public static final String UID = "uid";

        /**
         * Hardware version.
         */
        public static final String HARDWARE_VERSION = "hardwareVersion";

        /**
         * Firmware version.
         */
        public static final String FIRMWARE_VERSION = "firmwareVersion";
    }

    /**
     * Keys for startEmv input map. See {@link BBDeviceController#startEmv(Hashtable)}
     */
    public static final class StartEmv {

        private StartEmv() {

        }

        /**
         * Indicate whether to force transaction to go online. See {@link BBDeviceController.EmvOption}.
         */
        public static final String EMV_OPTION = "emvOption";

        /**
         * Indicate which check card mode to use. See {@link BBDeviceController.CheckCardMode}.
         */
        public static final String CHECK_CARD_MODE = "checkCardMode";

        /**
         * The terminal time, in YYMMDDHHmmss format. Must be entered for devices without keypad.
         */
        public static final String TERMINAL_TIME = "terminalTime";

        /**
         * Indicate the type of financial transaction. See {@link BBDeviceController.TransactionType}.
         */
        public static final String TRANSACTION_TYPE = "transactionType";

        /**
         * Indicate the transaction amount. The amount is represented as a string and can have at most one decimal point
         * "." or ",".
         */
        public static final String TRANSACTION_AMOUNT = "amount";

        /**
         * Indicate the cashback amount. The amount is represented as a string and can have at most one decimal point
         * "." or ",".
         */
        public static final String CASHBACK_AMOUNT = "cashbackAmount";

        /**
         * Indicates the 3-digits transaction currency code (e.g. "840" for USD).
         */
        public static final String CURRENCY_CODE = "currencyCode";

        /**
         * If Quick Chip is enabled in firmware config, set True to disable Quick Chip for this transaction.
         * Set False or no such key, firmware will follow the config setting.
         */
        public static final String DISABLE_QUICK_CHIP = "disableQuickChip";

        /**
         * Quick Chip option:
         * 0: No Quick Chip, normal EMV
         * 1: Follow config setting
         * 2: Quick Chip
         */
        public static final String QUICK_CHIP_OPTION = "quickChipOption";

        /**
         * Timeout for the Device to time out on processing
         */
        public static final String ONLINE_PROCESS_TIMEOUT = "onlineProcessTimeout";
    }

    /**
     * Keys for checkCard input table. See {@link BBDeviceController#checkCard(Hashtable)}
     */
    public static final class CheckCard {

        private CheckCard() {

        }

        /**
         * Indicate which check card mode to use. See {@link BBDeviceController.CheckCardMode}
         */
        public static final String MODE = "checkCardMode";

        /**
         * Indicate the check card timeout, in seconds.
         */
        public static final String TIMEOUT = "checkCardTimeout";
    }

    /**
     * Keys for EmvCardData result table. See {@link BBDeviceController#getEmvCardData()}
     */
    public static final class EmvCardData {

        private EmvCardData() {

        }

        /**
         * KSN of key used for tag {@link  EmvTagDescriptor#BBPOS_AAC_TC_DECRYPTION_KSN} data encryption. Corresponds
         * to tag {@link EmvTagDescriptor#BBPOS_AAC_TC_DECRYPTION_KSN}
         */
        public static final String KSN = "C3";

        /**
         * Masked PAN First6/Last4.
         */
        public static final String MASKED_PAN = "maskedPAN";

        /**
         * Cardholder name.
         */
        public static final String CARDHOLDER_NAME = "cardholderName";

        /**
         * Application expiration date.
         */
        public static final String APPLICATION_EXPIRATION_DATE = "5F24";

        /**
         * Issuer country code.
         */
        public static final String ISSUER_COUNTRY_CODE = "5F28";

        /**
         * Application currency code.
         */
        public static final String APPLICATION_CURRENCY_CODE = "9F42";

        /**
         * Serial number.
         */
        public static final String SERIAL_NUMBER = "DF826E";

        /**
         * bID.
         */
        public static final String BID = "DF834F";

        /**
         * Encrypted batch message containing PAN, Track 2 Equivalent Data and Track 1 Discretionary Data.
         */
        public static final String ENCRYPTED_BATCH_DATA = "C5";

        /**
         * Encrypted PAN.
         */
        public static final String PAN = "5A";

        /**
         * Track 2 Equivalent Data.
         */
        public static final String TRACK_2_DATA = "57";

        /**
         * Track 1 Discretionary Data.
         */
        public static final String TRACK_1_DISCRETIONARY_DATA = "9F1F";
    }

    /**
     * Keys for updateAID input table. See {@link BBDeviceController#updateAID(Hashtable)}
     */
    public static final class UpdateAid {

        private UpdateAid() {

        }

        /**
         * The index of the AID to be updated. There will be two values at this entry in the table.
         * The first is the index of the AID on the terminal itself and the one in config.
         */
        public static final String APP_INDEX = "appIndex";

        /**
         * Application Identifier(AID).
         */
        public static final String AID = "aid";

        /**
         * Application Version Number.
         */
        public static final String APP_VERSION = "appVersion";

        /**
         * Contact Terminal Action Code - Default.
         */
        public static final String CONTACT_TAC_DEFAULT = "contactTACDefault";

        /**
         * Contact Terminal Action Code - Denial.
         */
        public static final String CONTACT_TAC_DENIAL = "contactTACDefault";

        /**
         * Contact Terminal Action Code - Online.
         */
        public static final String CONTACT_TAC_ONLINE = "contactTACOnline";

        /**
         * Transaction Certificate Data Object List (TDOL).
         */
        public static final String DEFAULT_TDOL = "defaultTDOL";

        /**
         * Dynamic Data Authentication Data Object List (DDOL).
         */
        public static final String DEFAULT_DDOL = "defaultDDOL";

        /**
         * Contactless Transaction Limit.
         */
        public static final String CONTACTLESS_TRANSACTION_LIMIT = "contactlessTransactionLimit";

        /**
         * Contactless Transaction Limit with ODCV.
         */
        public static final String CONTACTLESS_TRANSACTION_LIMIT_ODCV =
                "contactlessTransactionLimitODCV";

        /**
         * Contactless CVM Required Limit.
         */
        public static final String CONTACTLESS_CVM_REQUIRED_LIMIT = "contactlessCVMRequiredLimit";

        /**
         * Contactless Floor Limit.
         */
        public static final String CONTACTLESS_FLOOR_LIMIT = "contactlessFloorLimit";

        /**
         * Contactless Terminal Action Code - Default.
         */
        public static final String CONTACTLESS_TAC_DEFAULT = "contactlessTACDefault";

        /**
         * Contactless Terminal Action Code - Denial.
         */
        public static final String CONTACTLESS_TAC_DENIAL = "contactlessTACDefault";

        /**
         * Contactless Terminal Action Code - Online.
         */
        public static final String CONTACTLESS_TAC_ONLINE = "contactTACOnline";

        /**
         * Contact Terminal Floor Limit.
         */
        public static final String TERMINAL_FLOOR_LIMIT = "terminalFloorLimit";
    }

    /**
     * Keys for performing OTA update of terminal firmware.
     */
    public static class UpdateFirmware {

        public static final String VENDOR_ID = "vendorID";

        public static final String VENDOR_SECRET = "vendorSecret";

        public static final String APP_ID = "appID";

        public static final String APP_SECRET = "appSecret";

        public static final String FORCE_UPDATE = "forceUpdate";

        public static final String FIRMWARE_UPDATE_URL = "firmwareUpdateServerUrl";
    }
}
