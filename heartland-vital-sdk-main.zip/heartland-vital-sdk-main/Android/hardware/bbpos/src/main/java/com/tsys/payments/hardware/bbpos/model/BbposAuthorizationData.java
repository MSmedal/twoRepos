package com.tsys.payments.hardware.bbpos.model;

import com.tsys.payments.library.enums.FallbackReason;
import com.tsys.payments.library.enums.LastChipRead;

import java.util.Objects;

import androidx.annotation.Nullable;

/**
 * Contains data for performing an authorization in a format sourced from the BBPOS payment
 * terminal.
 */
public class BbposAuthorizationData {
    @Nullable
    private LastChipRead mLastChipRead;
    @Nullable
    private FallbackReason mFallbackCondition;
    @Nullable
    private String mIccData;
    @Nullable
    private BbposCardData mCardData;
    @Nullable
    private String mCvm;
    @Nullable
    private String mSerialNumber;

    @Nullable
    public LastChipRead getLastChipRead() {
        return mLastChipRead;
    }

    public void setLastChipRead(@Nullable LastChipRead lastChipRead) {
        mLastChipRead = lastChipRead;
    }

    @Nullable
    public FallbackReason getFallbackCondition() {
        return mFallbackCondition;
    }

    public void setFallbackCondition(@Nullable FallbackReason fallbackCondition) {
        mFallbackCondition = fallbackCondition;
    }

    @Nullable
    public String getIccData() {
        return mIccData;
    }

    public void setIccData(@Nullable String iccData) {
        mIccData = iccData;
    }

    @Nullable
    public BbposCardData getCardData() {
        return mCardData;
    }

    public void setCardData(@Nullable BbposCardData cardData) {
        mCardData = cardData;
    }

    @Nullable
    public String getCvm() {
        return mCvm;
    }

    public void setCvm(@Nullable String cvm) {
        mCvm = cvm;
    }

    @Nullable
    public String getSerialNumber() {
        return mSerialNumber;
    }

    public void setSerialNumber(@Nullable String serialNumber) {
        mSerialNumber = serialNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BbposAuthorizationData that = (BbposAuthorizationData)o;
        return mLastChipRead == that.mLastChipRead &&
                mFallbackCondition == that.mFallbackCondition &&
                Objects.equals(mIccData, that.mIccData) &&
                Objects.equals(mCardData, that.mCardData) &&
                Objects.equals(mCvm, that.mCvm) &&
                Objects.equals(mSerialNumber, that.mSerialNumber);
    }

    @Override
    public int hashCode() {
        return Objects
                .hash(mLastChipRead, mFallbackCondition, mIccData, mCardData, mCvm, mSerialNumber);
    }

    @Override
    public String toString() {
        return "BbposAuthorizationData{" +
                "\nmLastChipRead=" + mLastChipRead + '\'' +
                ",\n mFallbackCondition=" + mFallbackCondition + '\'' +
                ",\n mIccData='" + mIccData + '\'' +
                ",\n mCardData=" + mCardData + '\'' +
                ",\n mCvm='" + mCvm + '\'' +
                ",\n mSerialNumber='" + mSerialNumber + '\'' +
                '}';
    }
}
