package com.tsys.payments.hardware.ingenico.utils;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.landicorp.util.StringUtil;

public class IngenicoHexHelper {
    @NonNull
    public static byte[] hexStringToByteArray(@NonNull String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) {
            int index = i * 2;
            int v = Integer.parseInt(s.substring(index, index + 2), 16);
            b[i] = (byte)v;
        }
        return b;
    }

    public static String asciiToHex(@NonNull String asciiValue) {
        String result;
        if (TextUtils.isEmpty(asciiValue)) {
            result = "";
        } else {
            result = StringUtil.str2HexStr(asciiValue).replace(" ", "");
        }
        return result;
    }

    public static String hexToString(@NonNull String hexValue) {
        String result;
        if (TextUtils.isEmpty(hexValue)) {
            result = "";
        } else {
            result = StringUtil.hexStr2Str(hexValue);
        }
        return result;
    }

    public static String getHexStrLength(@Nullable Object obj) {
        String result = "00";
        if (obj != null) {
            result = String.format("%02X", obj.toString().length() / 2);
        }
        return result;
    }
}
