package com.tsys.payments.hardware.ingenico;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.roam.roamreaderunifiedapi.DeviceManager;
import com.roam.roamreaderunifiedapi.callback.DeviceResponseHandler;
import com.roam.roamreaderunifiedapi.constants.Command;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.constants.ErrorCode;
import com.roam.roamreaderunifiedapi.constants.FirmwareComponentType;
import com.roam.roamreaderunifiedapi.constants.LanguageCode;
import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.roam.roamreaderunifiedapi.constants.ProgressMessage;
import com.roam.roamreaderunifiedapi.constants.ResponseCode;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;
import com.tsys.payments.library.BuildConfig;
import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.TerminalError;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.utils.LibraryConfigHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.atomic.AtomicBoolean;

import timber.log.Timber;

class IngenicoConfigurationManager {
    private static final String TAG = IngenicoConfigurationManager.class.getName();
    private static final int CONTACTLESS_M_S_TO_TIMEOUT = 30 * 1000;
    private static final String VERSION_KEY = "version";
    private static final String CONFIGURED_DEVICES = "configured_devices";
    private final Set<String> mConfiguredDevicesSerialNumbers = new HashSet<>(5);
    private DeviceManager mDeviceManager;
    private DeviceType mDeviceType;
    @Nullable
    private String mCurrentDeviceSerialNumber = null;

    private IngenicoRpConfiguration mConfiguration;
    private IngenicoMobyConfiguration mMobyConfiguration;
    private TerminalConfiguration mTerminalConfiguration;
    private TransactionConfiguration mTransactionConfiguration;
    private IngenicoDeviceProcessCallbacks mListener;

    private Stack<Command> mMobyCommandStack = new Stack<>();
    private int mCurrPublicKeyIndex = 0;

    private Context mContext;
    private AtomicBoolean mConfigured = new AtomicBoolean(false);

    private ConfigurationResponseHandler mDeviceResponseHandler;
    private MobyDeviceResponseHandler mMobyDeviceResponseHandler;

    IngenicoConfigurationManager(Context context, DeviceType deviceType,
            DeviceManager deviceManager,
            IngenicoRpConfiguration configuration, IngenicoDeviceProcessCallbacks listener) {
        Objects.requireNonNull(context);
        Objects.requireNonNull(configuration);
        Objects.requireNonNull(deviceType);
        Objects.requireNonNull(deviceManager);
        Objects.requireNonNull(listener);

        mContext = context.getApplicationContext();
        mDeviceResponseHandler = new ConfigurationResponseHandler();
        mConfiguration = configuration;
        mDeviceType = deviceType;
        mDeviceManager = deviceManager;
        mListener = listener;
    }

    IngenicoConfigurationManager(Context context, DeviceType deviceType,
            DeviceManager deviceManager,
            IngenicoMobyConfiguration configuration, IngenicoDeviceProcessCallbacks listener) {
        Objects.requireNonNull(context);
        Objects.requireNonNull(configuration);
        Objects.requireNonNull(deviceType);
        Objects.requireNonNull(deviceManager);
        Objects.requireNonNull(listener);

        mContext = context.getApplicationContext();
        mMobyDeviceResponseHandler = new MobyDeviceResponseHandler();
        mMobyConfiguration = configuration;
        mDeviceType = deviceType;
        mDeviceManager = deviceManager;
        mListener = listener;
    }

    public void updateProvision(String provision) {
        mMobyConfiguration.updateProvision(provision);
        mDeviceManager.getConfigurationManager().performJsonProvisioningString(
                mMobyConfiguration.getProvisioningJson(), mMobyDeviceResponseHandler);
    }

    private void configureMobyReader() {
        if (mDeviceType == DeviceType.MOBY5500) {
            executeCommand(Command.ReadCapabilities);
        }
    }

    private void executeCommand(@NonNull Command cmd) {
        Timber.d("executeCommand() called with: cmd = [%s]", cmd);
        switch (cmd) {
            case ReadCapabilities:
                mListener.onExecutingCommand();
                if (mDeviceType == DeviceType.MOBY5500) {
                    mDeviceManager.getConfigurationManager()
                            .getDeviceCapabilities(mMobyDeviceResponseHandler);
                }
                break;
            case GetFirmwareVersion:
                if (mDeviceType == DeviceType.MOBY5500) {
                    mListener.onExecutingCommand();
                    FirmwareComponentType type = FirmwareComponentType.DynamicConfiguration;
                    mDeviceManager.getConfigurationManager().getFirmwareVersion(
                            type, mMobyDeviceResponseHandler);
                }
                break;
            case JsonProvisioning:
                mListener.onExecutingCommand();
                if (mMobyConfiguration.shouldReadJSON()) {
                    mDeviceManager.getConfigurationManager().performJsonProvisioningString(
                            mMobyConfiguration.getProvisioningJson(), mMobyDeviceResponseHandler);
                } else {
                    mListener.onComplete();
                }
                break;
            case SetFirmwareVersion:
                try {
                    JSONObject json = new JSONObject(mMobyConfiguration.getProvisioningJson());
                    JSONArray profile = json.getJSONArray(mMobyConfiguration.getProcessorProfile());
                    String configVersion =
                            profile.getJSONObject(0).getString(mMobyConfiguration.getDynamicStrVersion());
                    mDeviceManager.getConfigurationManager()
                            .setFirmwareVersion(FirmwareComponentType.DynamicConfiguration, configVersion,
                                    mMobyDeviceResponseHandler);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case SubmitAIDsList:
                Timber.d("executeCommand :: Submitting AIDs List from RPConfiguration");
                mListener.onExecutingCommand();
                mDeviceManager.getConfigurationManager().submitAIDList(
                        IngenicoConversionHelper
                                .getContactAids(mTerminalConfiguration.getContactAids()),
                        mDeviceResponseHandler);
                break;
            case SubmitContactlessAIDsList:
                mListener.onExecutingCommand();
                Set<ApplicationIdentifier> contactlessAids = IngenicoConversionHelper
                        .getContactlessAids(mTerminalConfiguration.getContactlessAids());
                mDeviceManager.getConfigurationManager().submitContactlessAIDList(
                        contactlessAids, mDeviceResponseHandler);
                break;
            case ClearPublicKeys:
                mListener.onExecutingCommand();
                mDeviceManager.getConfigurationManager().clearPublicKeys(
                        mDeviceResponseHandler);
                break;
            case ClearAIDsList:
                mListener.onExecutingCommand();
                mDeviceManager.getConfigurationManager().clearAIDSList(
                        mDeviceResponseHandler);
                break;
            case ConfigureAmountDOLData:
                mListener.onExecutingCommand();
                Timber.d("executeCommand :: Configuring Amount DOL Data");
                mDeviceManager.getConfigurationManager().setAmountDOL(
                        mConfiguration.getAmountDolList(), mDeviceResponseHandler);
                break;
            case ConfigureOnlineDOLData:
                mListener.onExecutingCommand();
                Timber.d("executeCommand :: Configuring Online DOL Data");
                mDeviceManager.getConfigurationManager().setOnlineDOL(
                        mConfiguration.getOnlineDolList(), mDeviceResponseHandler);
                break;
            case ConfigureResponseDOLData:
                mListener.onExecutingCommand();
                Timber.d("executeCommand :: Configuring Response DOL Data");
                mDeviceManager.getConfigurationManager().setResponseDOL(
                        mConfiguration.getResponseDolList(), mDeviceResponseHandler);
                break;
            case ConfigureUserInterfaceOptions:
                mListener.onExecutingCommand();
                mDeviceManager.getConfigurationManager()
                        .setUserInterfaceOptions(
                                30, // Card insertion timeout in seconds
                                LanguageCode.ENGLISH,
                                (byte)0x01,
                                (byte)0x01,
                                mDeviceResponseHandler);
                break;
            case ConfigureContactlessOnlineDOLData:
                mListener.onExecutingCommand();

                mDeviceManager.getConfigurationManager().setContactlessOnlineDOL(
                        mConfiguration.getContactlessOnlineDolList(), mDeviceResponseHandler);
                break;
            case ConfigureContactlessResponseDOLData:
                mListener.onExecutingCommand();

                mDeviceManager.getConfigurationManager().setContactlessResponseDOL(
                        mConfiguration.getContactlessResponseDolList(), mDeviceResponseHandler);
                break;
            case ConfigureContactlessTransaction:
                Timber.d("contactlessTransactionOption");
                mListener.onExecutingCommand();
                if (mDeviceType != DeviceType.MOBY5500) {
                    mDeviceManager.getConfigurationManager()
                            .configureContactlessTransactionOptions(
                                    true, // CVM Supported
                                    true, // AMEX Supported
                                    true, // enable Cryptogram17
                                    true, // enable Online Cryptogram
                                    true, // enable Online
                                    true, // enable MagStripe
                                    true, // enable MagChip
                                    true, // enable QVSDC
                                    true, // enable MSD
                                    true,//isDPASEmvSupported
                                    true,//isDPASMsrSupported
                                    CONTACTLESS_M_S_TO_TIMEOUT, // contactlessOutcomeDisplayTime
                                    mDeviceResponseHandler);
                } else {
                    mDeviceManager.getConfigurationManager().configureContactlessTransactionOptions(
                            true, // CVM Supported
                            true, // AMEX Supported
                            true, // enable Cryptogram17
                            true, // enable Online Cryptogram
                            true, // enable Online
                            false, // enable MagStripe
                            true, // enable MagChip
                            true, // enable QVSDC
                            false, // enable MSD
                            true, // isDPASEmvSupported
                            false, // isDPASMsrSupported
                            1 * 1000, // contactlessOutcomeDisplayTime
                            true, // disableDiscoverIssuerScript
                            mMobyDeviceResponseHandler
                    );
                }
                break;
        }
    }

    private void handleConfigurationResponse(@NonNull Command cmd,
            @NonNull Map<Parameter, Object> data) {
        Timber.d("handleConfigurationResponse :: Command = " + cmd + "; Data = " + data);
        switch (cmd) {
            case ClearAIDsList:
                if (mDeviceType != DeviceType.MOBY5500) {
                    executeCommand(Command.SubmitAIDsList);
                }
                break;
            case SubmitAIDsList:
                if (mDeviceType != DeviceType.MOBY5500) {
                    if (isContactlessSupported()) {
                        executeCommand(Command.SubmitContactlessAIDsList);
                    } else {
                        checkAndUpdateConfiguredDeviceSerialNumbers();
                        executeCommand(Command.ClearPublicKeys);
                    }
                }
                break;
            case SubmitContactlessAIDsList:
                if (mDeviceType != DeviceType.MOBY5500) {
                    checkAndUpdateConfiguredDeviceSerialNumbers();
                    executeCommand(Command.ClearPublicKeys);
                }
                break;
            case ClearPublicKeys:
                mCurrPublicKeyIndex = 0;
                if (mDeviceType != DeviceType.MOBY5500) {
                    submitPublicKey();
                }
                break;
            case SubmitPublicKey:
                if (mDeviceType != DeviceType.MOBY5500) {
                    if (mCurrPublicKeyIndex < mConfiguration.getPublicKeyList().size()) {
                        submitPublicKey();
                    } else {
                        executeCommand(Command.ConfigureAmountDOLData);
                    }
                }
                break;
            case ConfigureAmountDOLData:
                executeCommand(Command.ConfigureOnlineDOLData);
                break;
            case ConfigureOnlineDOLData:
                executeCommand(Command.ConfigureResponseDOLData);
                break;
            case ConfigureResponseDOLData:
                executeCommand(Command.ConfigureUserInterfaceOptions);
                break;
            case ConfigureContactlessOnlineDOLData:
                executeCommand(Command.ConfigureContactlessResponseDOLData);
                break;
            case ConfigureContactlessResponseDOLData:
                executeCommand(Command.ConfigureContactlessTransaction);
                break;
            case ConfigureUserInterfaceOptions:
                if (isContactlessSupported()) {
                    executeCommand(Command.ConfigureContactlessOnlineDOLData);
                } else {
                    if (addDeviceSerialNumber(mCurrentDeviceSerialNumber)) {
                        saveConfiguredDevices(mConfiguredDevicesSerialNumbers);
                    }
                    mListener.onComplete();
                }
                break;
            case ConfigureContactlessTransaction:
                if (addDeviceSerialNumber(mCurrentDeviceSerialNumber)) {
                    saveConfiguredDevices(mConfiguredDevicesSerialNumbers);
                }
                mListener.onComplete();
                break;
            default:
                break;
        }
    }

    private void handleDeviceError(Command command) {
        Timber.w("handleDeviceError() called with: command=[%s]", command);
        switch (command) {
            case SubmitContactlessAIDsList:
                executeCommand(Command.ClearPublicKeys);
                break;
            case SubmitPublicKey:
                if (mCurrPublicKeyIndex < mConfiguration.getPublicKeyList().size()) {
                    submitPublicKey();
                } else {
                    executeCommand(Command.ConfigureAmountDOLData);
                }
                break;
            default:
                mListener.onError(TerminalError.CONFIGURATION_ERROR,
                        "Failed to configure the terminal.");
        }
    }

    private void submitPublicKey() {
        mListener.onExecutingCommand();
        mDeviceManager.getConfigurationManager().submitPublicKey(
                mConfiguration.getPublicKeyList().get(mCurrPublicKeyIndex++),
                mDeviceResponseHandler);
    }

    private void checkAndUpdateConfiguredDeviceSerialNumbers() {
        if (mConfiguredDevicesSerialNumbers.contains(mCurrentDeviceSerialNumber)) {
            Timber.d("executeCommand :: Removing Serial Number from set: " +
                    mCurrentDeviceSerialNumber);
            mConfiguredDevicesSerialNumbers.remove(mCurrentDeviceSerialNumber);
            saveConfiguredDevices(mConfiguredDevicesSerialNumbers);
        }
    }

    void configureTerminal(TerminalConfiguration terminalTransactionConfiguration,
            TransactionConfiguration transactionConfiguration) {
        mTerminalConfiguration = terminalTransactionConfiguration;
        mTransactionConfiguration = transactionConfiguration;
        loadConfiguredDevices();
        configureMobyReader();
        if (mDeviceType != DeviceType.MOBY5500) {
            if (!mConfiguredDevicesSerialNumbers.contains(mCurrentDeviceSerialNumber)) {
                configureAids();
            } else {
                mListener.onComplete();
            }
        }
    }

    private void configureAids() {
        executeCommand(Command.ClearAIDsList);
    }

    void configureTransaction() {
        if (mTerminalConfiguration.getTerminalType() != TerminalType.INGENICO_MOBY_5500) {
            mDeviceManager.getConfigurationManager()
                    .setExpectedOnlineDOL(mConfiguration.getOnlineDolList());
            mDeviceManager.getConfigurationManager()
                    .setExpectedAmountDOL(mConfiguration.getAmountDolList());
            mDeviceManager.getConfigurationManager()
                    .setExpectedResponseDOL(mConfiguration.getResponseDolList());
            mDeviceManager.getConfigurationManager()
                    .setExpectedContactlessOnlineDOL(
                            mConfiguration.getContactlessOnlineDolList());
            mDeviceManager.getConfigurationManager()
                    .setExpectedContactlessResponseDOL(
                            mConfiguration.getContactlessResponseDolList());
        } else {
            mDeviceManager.getConfigurationManager()
                    .setExpectedAmountDOL(mMobyConfiguration.getAmountDolList());
            mDeviceManager.getConfigurationManager()
                    .setExpectedContactlessOnlineDOL(
                            mMobyConfiguration.getContactlessOnlineDolList());
            mDeviceManager.getConfigurationManager()
                    .setExpectedContactlessResponseDOL(
                            mMobyConfiguration.getContactlessResponseDolList());
            mDeviceManager.getConfigurationManager()
                    .setExpectedOnlineDOL(
                            mMobyConfiguration.getOnlineDolList());
            mDeviceManager.getConfigurationManager()
                    .setExpectedResponseDOL(mMobyConfiguration.getResponseDolList());
        }
    }

    boolean isContactlessSupported() {
        return mTransactionConfiguration != null &&
                mTransactionConfiguration.isContactlessEnabled() &&
                mTerminalConfiguration.getContactlessAids() != null
                && !mTerminalConfiguration.getContactlessAids().isEmpty() &&
                (mDeviceType == DeviceType.MOBY8500 || mDeviceType == DeviceType.MOBY5500 ||
                        mDeviceType == DeviceType.RP45BT || mDeviceType == DeviceType.RP450c);
    }

    @Nullable
    String getCurrentDeviceSerialNumber() {
        return mCurrentDeviceSerialNumber;
    }

    void setCurrentDeviceSerialNumber(@Nullable String serialNumber) {
        mCurrentDeviceSerialNumber = serialNumber;
    }

    /**
     * @return True if the serial number was added to the set, false if is null or already exists in the set.
     */
    private boolean addDeviceSerialNumber(String serialNumber) {
        if (serialNumber == null) {
            Timber.e(
                    new IllegalArgumentException(
                            "addDeviceSerialNumber :: Serial Number must not be null"));
            return false;
        }
        if (!mConfiguredDevicesSerialNumbers.contains(serialNumber)) {
            mConfiguredDevicesSerialNumbers.add(serialNumber);
            return true;
        } else {
            return false;
        }
    }

    private void saveConfiguredDevices(@NonNull Set<String> configuredDevicesSerialNumbers) {
        if (mContext == null) {
            Timber.w("saveConfiguredDevices :: Context reference is null");
            return;
        }
        mContext.getSharedPreferences(TAG, Context.MODE_PRIVATE)
                .edit()
                .putStringSet(CONFIGURED_DEVICES, configuredDevicesSerialNumbers)
                .putInt(VERSION_KEY, (int)BuildConfig.VERSION_CODE)
                .apply();
    }

    private void loadConfiguredDevices() {
        if (mContext == null) {
            Timber.d("loadConfiguredDevices :: Context reference is null");
            return;
        }
        SharedPreferences prefs = mContext.getSharedPreferences(TAG, Context.MODE_PRIVATE);
        if (prefs.getInt(VERSION_KEY, 0) != BuildConfig.VERSION_CODE) {
            mConfiguredDevicesSerialNumbers.clear();
            saveConfiguredDevices(mConfiguredDevicesSerialNumbers);
            return;
        }
        Set<String> configuredDevices =
                prefs.getStringSet(CONFIGURED_DEVICES, mConfiguredDevicesSerialNumbers);
        for (String element : configuredDevices) {
            // Null serial numbers must not be added to the set (the ROAM SDK will not
            // behave correctly if null values are passed to it)
            if (element != null) {
                mConfiguredDevicesSerialNumbers.add(element);
            }
        }
    }

    private class MobyDeviceResponseHandler implements DeviceResponseHandler {

        @Override
        public void onResponse(Map<Parameter, Object> map) {
            mListener.onWaitingForCommand();
            Command cmd = (Command)map.get(Parameter.Command);
            Timber.d("onResponse() from MobyDeviceResponseHandler" + " Data = "
                    + map.toString() + " Cmd = " + cmd.toString());
            ResponseCode responseCode = (ResponseCode)map.get(Parameter.ResponseCode);
            ErrorCode errorCode = (ErrorCode)map.get(Parameter.ErrorCode);
            if (responseCode == ResponseCode.Error && errorCode != ErrorCode.CardReaderBusy) {
                handleDeviceError(cmd);
            } else {
                Timber.d("CMD to process = %s", cmd.toString());
                switch (cmd) {
                    case ReadCapabilities:
                        String serial = map.get(Parameter.InterfaceDeviceSerialNumber).toString();
                        if (mConfigured.compareAndSet(false, true)) {
                            addDeviceSerialNumber(serial);
                        }
                        executeCommand(Command.GetFirmwareVersion);
                        break;
                    case GetFirmwareVersion:
                        String fileVersionNumber = map.get(Parameter.FirmwareVersion).toString();
                        mMobyConfiguration.setDeviceVersion(fileVersionNumber);
                        executeCommand(Command.JsonProvisioning);
                        break;
                    case JsonProvisioning:
                        if (LibraryConfigHelper.isDebug()) {
                            StringBuilder sb = new StringBuilder();
                            for (Map.Entry<Parameter, Object> e : map.entrySet()) {
                                if (e.getValue() != null) {
                                    sb.append(e.getKey().toString()).append(": ")
                                            .append(e.getValue().toString()).append("\n");
                                }
                            }
                            Timber.d("JSON Provisioning Data: " + sb.toString());
                        }
                        mListener.onComplete();
                        executeCommand(Command.ConfigureContactlessTransaction);
                        break;
                    case ConfigureContactlessTransaction:
                        executeCommand(Command.SetFirmwareVersion);
                        break;
                    default:
                        break;
                }
            }
        }

        @Override
        public void onProgress(ProgressMessage progressMessage, String s) {
            //not used
        }
    }

    private class ConfigurationResponseHandler implements DeviceResponseHandler {

        @Override
        public void onResponse(Map<Parameter, Object> map) {
            mListener.onWaitingForCommand();
            Command cmd = (Command)map.get(Parameter.Command);
            ResponseCode responseCode = (ResponseCode)map.get(Parameter.ResponseCode);
            if (responseCode == ResponseCode.Error) {
                handleDeviceError(cmd);
            } else {
                handleConfigurationResponse(cmd, map);
            }
        }

        @Override
        public void onProgress(ProgressMessage progressMessage, String s) {
            // Unused
        }
    }
}