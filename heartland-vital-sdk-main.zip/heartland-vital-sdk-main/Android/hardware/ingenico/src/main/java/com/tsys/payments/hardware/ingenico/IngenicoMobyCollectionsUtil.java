package com.tsys.payments.hardware.ingenico;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.roam.roamreaderunifiedapi.constants.Command;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;
import com.roam.roamreaderunifiedapi.data.ReaderVersionInfo;
import com.tsys.payments.hardware.ingenico.utils.IngenicoHexHelper;
import com.tsys.payments.hardware.ingenico.utils.IngenicoTlvHelper;
import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.TransactionType;
import com.tsys.payments.library.terminal.domain.TerminalRequest;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import timber.log.Timber;

public class IngenicoMobyCollectionsUtil {
    private static final Parameter EMV_TAG_9F6E_PAYPASS = Parameter.PayPassThirdPartyData;
    private static final Parameter EMV_TAG_DF78 = Parameter.InterfaceDeviceSerialNumber;
    private static final Parameter EMV_TAG_DF79 = Parameter.ContactlessKernelIdentifier;
    //Undocumented RUA value for when tag 5F35 not present in fixed length DOL
    private static final String TAG_5F34_INVALID = "FF";
    private static final EmvTagDescriptor[] CONTACT_ONLINE_TAGS =
            new EmvTagDescriptor[] {EmvTagDescriptor.APPLICATION_IDENTIFIER,
                    EmvTagDescriptor.INGENICO_ENCRYPTED_TRACK,
                    EmvTagDescriptor.INGENICO_KSN,
                    EmvTagDescriptor.TRANSACTION_CURRENCY_CODE,
                    EmvTagDescriptor.PAN_SEQUENCE_NUMBER,
                    EmvTagDescriptor.APPLICATION_INTERCHANGE_PROFILE,
                    EmvTagDescriptor.DEDICATED_FILE_NAME,
                    EmvTagDescriptor.ISSUER_AUTHENTICATION_DATA,
                    EmvTagDescriptor.TERMINAL_VERIFICATION_RESULTS,
                    EmvTagDescriptor.TRANSACTION_DATE,
                    EmvTagDescriptor.TRANSACTION_STATUS_INFORMATION,
                    EmvTagDescriptor.TRANSACTION_TYPE,
                    EmvTagDescriptor.AMOUNT_AUTHORIZED_NUMERIC,
                    EmvTagDescriptor.AMOUNT_OTHER_NUMERIC,
                    EmvTagDescriptor.AID_TERMINAL,
                    EmvTagDescriptor.APPLICATION_USAGE_CONTROL,
                    EmvTagDescriptor.APPLICATION_VERSION_NUMBER,
                    EmvTagDescriptor.APPLICATION_VERSION_NUMBER_TERMINAL,
                    EmvTagDescriptor.ISSUER_ACTION_DEFAULT,
                    EmvTagDescriptor.ISSUER_ACTION_DENIAL,
                    EmvTagDescriptor.ISSUER_ACTION_ONLINE,
                    EmvTagDescriptor.ISSUER_APP_DATA,
                    EmvTagDescriptor.APPLICATION_PREFERRED_NAME,
                    EmvTagDescriptor.APP_LABEL,
                    EmvTagDescriptor.TERMINAL_COUNTRY_CODE,
                    EmvTagDescriptor.IFD_SERIAL_NUMBER,
                    EmvTagDescriptor.TRANSACTION_TIME,
                    EmvTagDescriptor.APPLICATION_CRYPTOGRAM,
                    EmvTagDescriptor.CRYPTOGRAM_INFORMATION_DATA,
                    EmvTagDescriptor.TERMINAL_CAPABILITIES,
                    EmvTagDescriptor.CVM_RESULT,
                    EmvTagDescriptor.TERMINAL_TYPE,
                    EmvTagDescriptor.APPLICATION_TRANSACTION_COUNTER,
                    EmvTagDescriptor.UNPREDICTABLE_NUMBER,
                    EmvTagDescriptor.POS_ENTRY_MODE,
                    EmvTagDescriptor.ADDITIONAL_TERMINAL_CAPABILITIES,
                    EmvTagDescriptor.TRANSACTION_SEQUENCE_NUMBER,
                    EmvTagDescriptor.ICC_DYNAMIC_NUMBER,
                    EmvTagDescriptor.EXPRESSPAY_ENHANCED_TERMINAL_CAPABILITIES,
                    EmvTagDescriptor.ISSUER_COUNTRY_CODE,
                    EmvTagDescriptor.AUTHORIZATION_RESPONSE_CODE,
                    EmvTagDescriptor.APPLICATION_EXPIRATION_DATE,
                    EmvTagDescriptor.TERMINAL_IDENTIFICATION,
                    EmvTagDescriptor.MASTERCARD_TRANSACTION_CATEGORY_CODE
            };
   // private static String mEmvConfigJson;
    private static DeviceType mDeviceType;
    private static Set<Parameter> sContactOnlineTags;

    @NotNull
    static Map<Parameter, Object> getStartTransactionInputMap(TerminalRequest terminalRequest,
            TransactionConfiguration transactionConfiguration, String emvConfig,
            String deviceSerialNumber, DeviceType deviceType) {

        mDeviceType = deviceType;
        Map<Parameter, Object> input = new EnumMap<>(Parameter.class);

        if(TextUtils.isEmpty(emvConfig) || Objects.equals(emvConfig, "")){
            return input;
        }

        //mEmvConfigJson = emvConfig;
        try {
            if (mDeviceType == DeviceType.MOBY5500) {
                JSONObject emvStartParams = new JSONObject(emvConfig);
                //Read the params from the file into map
                for (int i = 0; i < emvStartParams.names().length(); i++) {
                    input.put(Parameter.getEnumFromString(emvStartParams.names().getString(i)),
                            emvStartParams.get(emvStartParams.names().getString(i)));
                }
            }
        } catch (JSONException j) {
            Timber.e(j);
        }

        SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMdd");

        input.put(Parameter.Command, Command.EMVStartTransaction);
        input.put(Parameter.AmountAuthorizedNumeric,
                String.format(Locale.US, "%012d", terminalRequest.getTotalAmount())); // 9F02
        input.put(Parameter.AmountOtherNumeric, String.format(Locale.US, "%012d", 0)); // 9F03
        input.put(Parameter.AmountAuthorizedBinary,
                String.format(Locale.US, "%08X", terminalRequest.getTotalAmount())); // 81
        input.put(Parameter.TransactionDate, dateFormat.format(new Date())); // 9A
        input.put(Parameter.TransactionTime, timeFormat.format(new Date())); // 9F21

        if (terminalRequest != null && terminalRequest.getTransactionType() == TransactionType.REFUND) {
            input.put(Parameter.TransactionType, "20");
        }
        input.put(Parameter.EnableUSQuickChipMode, "01");

        if (transactionConfiguration.isContactlessEnabled()) {
            if (!TextUtils.isEmpty(deviceSerialNumber)) {
                String cleanSerialNumber = cleanSerialNumber(deviceSerialNumber);
                input.put(Parameter.TerminalIdentification,
                        IngenicoHexHelper.asciiToHex(cleanSerialNumber)); // 9F1C
            }
        }
        return input;
    }

    @NonNull
    public static String cleanSerialNumber(@NonNull String rawSerialNumber) {
        if (rawSerialNumber.contains("RP")) {
            String[] splits = rawSerialNumber.split("RP");
            if (splits.length > 1) {
                return splits[1];
            } else {
                return rawSerialNumber;
            }
        } else {
            return rawSerialNumber;
        }
    }

  /*  @NonNull
    static Map<Parameter, Object> getTransactionDataInputMap(@Nullable ApplicationIdentifier
            selectedAid,
            @Nullable String currentAid, @NonNull TerminalConfiguration terminalConfiguration) {
        Map<Parameter, Object> input = new EnumMap<>(Parameter.class);

        try {
            JSONObject json = new JSONObject(mEmvConfigJson);
            JSONObject emvTransDataParams = new JSONObject();

            if (mDeviceType == DeviceType.MOBY5500) {
                emvTransDataParams = json.getJSONObject("RP450EMVTransactionDataParameters");
            }

            for (int i = 0; i < emvTransDataParams.names().length(); i++) {
                input.put(Parameter.getEnumFromString(emvTransDataParams.names().getString(i)),
                        emvTransDataParams.get(emvTransDataParams.names().getString(i)));
            }
        } catch (JSONException j) {
            Timber.e(j);
        }

        input.put(Parameter.Command, Command.EMVTransactionData);
        input.put(Parameter.TerminalActionCodeDefault, "0000000000");
        input.put(Parameter.TerminalActionCodeDenial, "0000000000");
        input.put(Parameter.TerminalActionCodeOnline, "0000000000");
        return input;
    }*/

    @NonNull
    static Map<Parameter, Object> getTransactionStopInputMap() {
        EnumMap<Parameter, Object> input = new EnumMap<>(Parameter.class);
        input.put(Parameter.Command, Command.EMVTransactionStop);
        input.put(Parameter.Command, Command.WaitForCardRemoval);
        return input;
    }

    @NonNull
    static Map<Parameter, Object> getFinalApplicationSelectionInputMap(
            ApplicationIdentifier applicationIdentifier) {
        EnumMap<Parameter, Object> input = new EnumMap<>(Parameter.class);
        input.put(Parameter.Command, Command.EMVFinalApplicationSelection);
        if (applicationIdentifier != null) {
            input.put(Parameter.ApplicationIdentifier, applicationIdentifier.getAID());
        } else {
            input.put(Parameter.ApplicationIdentifier, "A0000000031010");
        }
        return input;
    }

    public static List<String> getOnlineEmvTags(@NonNull Map<Parameter, Object> data,
            @Nullable ReaderVersionInfo readerVersionInfo) {
        Timber.d("getOnlineEmvTags() is called");
        Set<Parameter> tags = getContactOnlineTagSet();
        final Parameter panSequenceNumber =
                IngenicoConversionHelper
                        .getIngenicoTagParameter(EmvTagDescriptor.PAN_SEQUENCE_NUMBER);
        final Parameter issuerAuthData =
                IngenicoConversionHelper
                        .getIngenicoTagParameter(EmvTagDescriptor.ISSUER_AUTHENTICATION_DATA);
        final Parameter transactionCategoryCode =
                IngenicoConversionHelper.getIngenicoTagParameter(
                        EmvTagDescriptor.MASTERCARD_TRANSACTION_CATEGORY_CODE);
        final Parameter formFactorIndicator =
                IngenicoConversionHelper
                        .getIngenicoTagParameter(EmvTagDescriptor.VISA_FORM_FACTOR_INDICATOR);

        List<String> result = new ArrayList<>(tags.size());
        for (Parameter param : tags) {
            if (param == null) continue;
            String dataValue = null;
            if (data.get(param) != null) {
                dataValue = data.get(param).toString();
            }

            String tag = param.getTagString();
            Timber.d("Online Tag: %s", tag);
            if (param == Parameter.ApplicationIdentifier &&
                    (dataValue == null || dataValue.isEmpty())) {
                if (data.get(Parameter.TerminalApplicationIdentifier) != null) {
                    tag = "4F";
                    dataValue = data.get(Parameter.TerminalApplicationIdentifier).toString();
                }
            } else if (param == Parameter.AuthorizationResponseCode) {
                dataValue = "Z1";
            } else if (param == panSequenceNumber && TAG_5F34_INVALID.equalsIgnoreCase(dataValue)) {
                dataValue = "";
            } else if (param == Parameter.TransactionTime) {
                SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss", Locale.US);
                dataValue = timeFormat.format(new Date());
            }

            if (dataValue != null && !dataValue.isEmpty()) {
                switch (param.getTagValueFormat()) {
                    case ALPHABETIC:
                    case ALPHANUMERIC:
                    case ALPHANUMERIC_SPECIALCHARACTERS:
                        dataValue = IngenicoHexHelper.asciiToHex(dataValue.trim());
                        break;
                    default:
                        break;
                }

                if (param == issuerAuthData || param == transactionCategoryCode ||
                        param == formFactorIndicator ||
                        param == EMV_TAG_9F6E_PAYPASS) {
                    if (!dataValue.isEmpty()) {
                        Timber.d("Before Tag and Value added");
                        result.add(IngenicoTlvHelper.getEncodedTlv(tag, dataValue));
                        Timber.d("After Tag and Value added");
                    }
                } else {
                    Timber.d("Before Tag and Value added");
                    result.add(IngenicoTlvHelper.getEncodedTlv(tag, dataValue));
                    Timber.d("After Tag and Value added");
                }
            }
        }
        return result;
    }

    private static Set<Parameter> getContactOnlineTagSet() {
        synchronized (IngenicoRpCollectionsUtil.class) {
            if (sContactOnlineTags == null) {
                sContactOnlineTags = new HashSet<>(45);
                for (EmvTagDescriptor tagDescriptor : CONTACT_ONLINE_TAGS) {
                    sContactOnlineTags
                            .add(IngenicoConversionHelper.getIngenicoTagParameter(tagDescriptor));
                }
                sContactOnlineTags.add(EMV_TAG_9F6E_PAYPASS);
                sContactOnlineTags.add(Parameter.TerminalApplicationIdentifier);
            }
        }
        return sContactOnlineTags;
    }
}