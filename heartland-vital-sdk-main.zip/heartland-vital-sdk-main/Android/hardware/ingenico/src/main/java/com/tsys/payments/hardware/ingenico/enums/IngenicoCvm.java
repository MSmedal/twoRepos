package com.tsys.payments.hardware.ingenico.enums;

public enum IngenicoCvm {
    FAIL_CVM_PROCESSING(new String[] {"00"}),
    PLAINTEXT_PIN_OFFLINE(new String[] {"01"}),
    ENCIPHERED_PIN_VERIFIED_ONLINE(new String[] {"02", "42"}),
    PLAINTEXT_PIN_VERIFIED_OFFLINE_PAPER_SIGNATURE(new String[] {"05", "45"}),
    SIGNATURE(new String[] {"1E", "5E"}),
    NO_CVM(new String[] {"1F", "5F"}),
    UNKNOWN(new String[] {"3F", "7F"});
    private final String[] mValues;

    IngenicoCvm(String[] values) {
        mValues = values;
    }

    public String[] getValues() {
        return mValues;
    }

    public static IngenicoCvm cvmFromString(String value) {
        for (IngenicoCvm cvm : IngenicoCvm.values()) {
            for (String item : cvm.getValues()) {
                if (value.equalsIgnoreCase(item)) {
                    return cvm;
                }
            }
        }
        return UNKNOWN;
    }
}
