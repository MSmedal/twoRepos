package com.tsys.payments.hardware.ingenico.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import timber.log.Timber;

import com.tsys.payments.library.terminal.domain.TerminalRequest;

public class IngenicoTlvHelper {
    private static final String TAG = IngenicoTlvHelper.class.getSimpleName();

    @Nullable
    public static String getTlvTransactionTypeValue(@NonNull TerminalRequest terminalRequest) {
        switch (terminalRequest.getTerminalAction()) {
            case TENDER_GOODS:
            case TENDER_SERVICES:
                return "00";
            case TENDER_REFUND:
                return "20";
            default:
                Timber.w(TAG, "No Transaction Type value found for terminal action:[%s]",
                        terminalRequest.getTerminalAction());
                return null;
        }
    }

    @Nullable
    public static String getEncodedTlv(String tag, String value) {
        return tag + IngenicoHexHelper.getHexStrLength(value) + value;
    }
}
