package com.tsys.payments.hardware.ingenico;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.WorkerThread;
import com.roam.roamreaderunifiedapi.callback.SearchListener;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.data.Device;

import timber.log.Timber;

class IngenicoDeviceSearchListener implements SearchListener {
    private static final String TAG = IngenicoDeviceSearchListener.class.getName();
    private final BluetoothAdapter mBluetoothAdapter;
    private final String mDeviceIdentifier;
    private final IngenicoDeviceSearchResultsListener mSearchResultsListener;
    //  private final Context mContext;
    private Device mFoundDevice;
    private boolean mBonded;
    private static boolean mUSBFound;
    private static boolean mBTFound;

    /**
     * Construct an instance that will be used to query for an Ingenico device whose ientifier matches the passed in
     * identifier.
     *
     * @param deviceIdentifier      Device MAC address.
     * @param searchResultsListener Callback to invoke when a matching device is discovered.
     */
    IngenicoDeviceSearchListener(String deviceIdentifier,
            IngenicoDeviceSearchResultsListener searchResultsListener) {
        mSearchResultsListener = searchResultsListener;
        mDeviceIdentifier = deviceIdentifier;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    @WorkerThread
    @Override
    public void onDeviceDiscovered(@NonNull Device device) {
        Timber.d("onDeviceDiscovered() :: Device[name=" + device.getName() + ", identifier=" +
                device.getIdentifier() + "]");

        if (!mUSBFound && device.getIdentifier().equals(mDeviceIdentifier)) {
            mFoundDevice = device;
            mBTFound = true;
            for (BluetoothDevice foundDevice : mBluetoothAdapter.getBondedDevices()) {
                if (foundDevice.getAddress().equals(mDeviceIdentifier)) {
                    mBonded = true;
                }
            }
        }

        if (!mBTFound && !TextUtils.isEmpty(mDeviceIdentifier) && device
                .getConnectionType() == CommunicationType.Usb) {
            DeviceType deviceType = DeviceType.valueOf(mDeviceIdentifier);
            if (deviceType != null && device.getConnectionType() == CommunicationType.Usb &&
                    device.getDeviceType() == deviceType) {
                mFoundDevice = device;
                mUSBFound = true;
                mSearchResultsListener.onResult(mFoundDevice, false);
            }
        }
    }

    @WorkerThread
    @Override
    public void onDiscoveryComplete() {
        if (mBonded || (mFoundDevice != null && !mUSBFound)) {
            mSearchResultsListener.onResult(mFoundDevice, mBonded);
        }
    }

    @Override
    public String toString() {
        return "DeviceSearchListener{" +
                "mBluetoothAdapter=" + mBluetoothAdapter +
                ", mBondedDevices=" + mBluetoothAdapter.getBondedDevices() +
                ", mFoundDevice=" + mFoundDevice +
                '}';
    }
}
