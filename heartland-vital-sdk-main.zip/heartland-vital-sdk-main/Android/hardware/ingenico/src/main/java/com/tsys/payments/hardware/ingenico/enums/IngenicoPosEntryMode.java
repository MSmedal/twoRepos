package com.tsys.payments.hardware.ingenico.enums;

public enum IngenicoPosEntryMode {
    MANUAL("01"),
    MSR("02"),
    BAR_CODE("03"),
    OCR("04"),
    ICC("05"),
    CONTACTLESS_ICC("07"),
    ICC_FALLBACK_TO_MSR("80"),
    E_COMMERCE("81"),
    /**
     * Complete contents of magnetic stripe, including track 2 data.
     */
    MSR_COMPLETE("90"),
    CONTACTLESS_MSR("91"),
    UNKNOWN("");
    private final String mPosEntryMode;

    IngenicoPosEntryMode(String code) {
        mPosEntryMode = code;
    }

    public static IngenicoPosEntryMode fromCode(String code) {

        for (IngenicoPosEntryMode mode : IngenicoPosEntryMode.values()) {
            if (code.compareTo(mode.mPosEntryMode) == 0) {
                return mode;
            }
        }
        return UNKNOWN;
    }
}
