package com.tsys.payments.hardware.ingenico.utils

import android.os.Build
import android.util.Log
import com.roam.roamreaderunifiedapi.ConfigurationManager
import com.roam.roamreaderunifiedapi.DeviceManager
import com.roam.roamreaderunifiedapi.callback.DeviceResponseHandler
import com.roam.roamreaderunifiedapi.constants.*
import com.roam.roamreaderunifiedapi.data.ReaderVersionInfo
import com.roam.roamreaderunifiedapi.firmwaremanager.TemCommunicationManager
import org.json.JSONException
import org.json.JSONObject
import java.lang.StringBuilder

class ReaderStateHandler(private val deviceManager: DeviceManager, private val sandboxClient: TemCommunicationManager) {
    private val configurationManager: ConfigurationManager = deviceManager.configurationManager
    private val mobileInfoJson: JSONObject = createMobileInfo()

    private var readerStateJson: String? = null
    private var firmwareChecksumInfoJson: JSONObject? = null
    var readerSerialNumber: String? = null
    var readerVersionInfo: ReaderVersionInfo? = null

    private var keyMappingState: KeyMappingState = KeyMappingState.ORIGINAL

    fun readerStateJson(simpleResponseHandler: SimpleResponseHandler<String>) {
        readerStateJson(KeyMappingState.ORIGINAL, simpleResponseHandler)
    }

    fun readerStateJson(keyMappingState: KeyMappingState, handler: SimpleResponseHandler<String>) {
        this.keyMappingState = keyMappingState
        readDeviceCapabilities(handler)
    }

    val isUnsUpdateRequired: Boolean
        get() {
            return sandboxClient.isUpdateAvailable(readerSerialNumber)
        }

    fun doUpdate(): Boolean? {
        deviceManager.enableFirmwareUpdateMode(object : DeviceResponseHandler {
            override fun onResponse(responseData: Map<Parameter, Any>) {
                val responseCode = responseData[Parameter.ResponseCode] as ResponseCode?
                if (responseCode == ResponseCode.Error) {
                    logReaderError(responseData)
//                    lock?.done(false)
                    return
                }
                handleDeviceResponse(responseData, responseData[Parameter.Command] as Command?)
            }

            private fun handleDeviceResponse(
                responseData: Map<Parameter, Any>,
                readerCommandResponse: Command?
            ) {
                when (readerCommandResponse) {
                    Command.UpdateFirmware -> {
//                        lock?.done(true)
                        return
                    }
                    Command.EnableFirmwareUpdateMode -> {
                        deviceManager.updateFirmware(
                            sandboxClient.getUpdateFilePath(
                                readerSerialNumber
                            ), this
                        )
                        return
                    }
                    else -> {
                        Log.e(
                            this.javaClass.simpleName,
                            "Unexpected reader command response '" + readerCommandResponse!!.name + "'"
                        )
//                        lock?.done(false)
                    }
                }
            }

            override fun onProgress(progressMessage: ProgressMessage, additionalMessage: String) {
                logProgress(progressMessage, additionalMessage)
            }
        })
//        return lock?.waitForResult(60 * 1000)
        return null
    }

    private fun readDeviceCapabilities(handler: SimpleResponseHandler<String>) {
        configurationManager.getDeviceCapabilities(
                GetDeviceCapabilitiesHandler {
                    handler.onResponse(readerStateJson)
                }
        )
    }

    private inner class GetDeviceCapabilitiesHandler(val onResponse: (Boolean) -> Unit) : DeviceResponseHandler {
        private var sbReadCapability: StringBuilder? = null
        private var readVersionInfoJson: JSONObject? = null
        private var deviceStatisticsJson: JSONObject? = null
        private var readKeyMappingInfoJson: JSONObject? = null
        private var readCertificateFilesVersionJson: JSONObject? = null
        private val stateJson = JSONObject()
        override fun onResponse(responseData: Map<Parameter, Any>) {
            val responseCode = responseData[Parameter.ResponseCode] as ResponseCode?
            if (responseCode == ResponseCode.Error) {
                logReaderError(responseData)
                onResponse(false)
                return
            }
            handleDeviceResponse(responseData, responseData[Parameter.Command] as Command?)
        }

        override fun onProgress(progressMessage: ProgressMessage, additionalMessage: String) {
            logProgress(progressMessage, additionalMessage)
        }

        private fun handleDeviceResponse(
            responseData: Map<Parameter, Any>,
            readerCommandResponse: Command?
        ) {
            when (readerCommandResponse) {
                Command.ReadCapabilities -> handleReadCapabilitiesResponse(responseData)
                Command.ReadVersion -> handleReadVersionResponse(responseData)
                Command.GetFirmwareChecksumInfo -> handleGetFirmwareChecksumInfoResponse(
                    responseData
                )
                Command.ReadCertificateFilesVersion -> handleReadCertificateFilesVersionResponse(
                    responseData
                )
                Command.ReadKeyMappingInfo -> handleReadKeyMappingResponse(responseData)
                Command.DeviceStatistics -> handleDeviceStatisticsResponse(responseData)
                else -> {
                    Log.e(
                        this.javaClass.simpleName,
                        "Unexpected reader command response '" + readerCommandResponse!!.name + "'"
                    )
                    onResponse(false)
                }
            }
        }

        private fun responseMapToJson(data: Map<Parameter, Any>): String {
            val stringBuilder = StringBuilder()
            stringBuilder.append("{\n")
            for ((key, value) in data) {
                if (value != null) {
                    stringBuilder.append(
                        String.format(
                            "\"%s\": \"%s\",\n",
                            key.toString(),
                            value.toString()
                        )
                    )
                }
            }
            val index: Int = stringBuilder.lastIndexOf(",")
            stringBuilder.replace(index, index + 1, "")
            stringBuilder.append(
                """
                    }
                    
                    """.trimIndent()
            )
            return stringBuilder.toString()
        }

        private fun handleReadCapabilitiesResponse(responseData: Map<Parameter, Any>) {
            sbReadCapability = StringBuilder()
            sbReadCapability!!.append(",\"TerminalCapabilities\": \"")
                .append(responseData[Parameter.TerminalCapabilities]).append("\",\n")
            sbReadCapability!!.append("\"InterfaceDeviceSerialNumber\": \"")
                .append(responseData[Parameter.InterfaceDeviceSerialNumber]).append("\"\n }")
            configurationManager.readVersion(this)
            readerSerialNumber = responseData[Parameter.InterfaceDeviceSerialNumber].toString()
        }

        private fun handleReadVersionResponse(responseData: Map<Parameter, Any>) {
            val readerVersionStringBuilder = StringBuilder()
            if (responseData.containsKey(Parameter.ReaderVersionInfo)) {
                readerVersionStringBuilder.append(responseData[Parameter.ReaderVersionInfo].toString())
                readerVersionInfo = responseData[Parameter.ReaderVersionInfo] as ReaderVersionInfo?
            } else if (responseData.containsKey(Parameter.ReaderVersion)) {
                readerVersionStringBuilder.append(responseData[Parameter.ReaderVersion].toString())
            }
            val index = readerVersionStringBuilder.lastIndexOf("}")
            readerVersionStringBuilder.replace(index, index + 1, sbReadCapability.toString())
            try {
                readVersionInfoJson = JSONObject(readerVersionStringBuilder.toString())
                stateJson.put("ReaderVersionInfo", readVersionInfoJson)
            } catch (e: JSONException) {
                e.printStackTrace()
                onResponse(false)
                return
            }
            configurationManager.getFirmwareChecksumInfo(FirmwareChecksumType.StaticSoftware, this)
        }

        private fun handleGetFirmwareChecksumInfoResponse(responseData: Map<Parameter, Any>) {
            try {
                firmwareChecksumInfoJson =
                    JSONObject(responseData[Parameter.FirmwareChecksum].toString())
                stateJson.put("FirmwareChecksumInfo", firmwareChecksumInfoJson)
            } catch (e: JSONException) {
                e.printStackTrace()
                onResponse(false)
                return
            }
            configurationManager.readCertificateFilesVersion(this)
        }

        private fun handleReadCertificateFilesVersionResponse(responseData: Map<Parameter, Any>) {
            try {
                readCertificateFilesVersionJson =
                    JSONObject(responseData[Parameter.CertificateFilesVersionInfo].toString())
                stateJson.put("CertificateFilesVersionInfo", readCertificateFilesVersionJson)
            } catch (e: JSONException) {
                e.printStackTrace()
                onResponse(false)
                return
            }
            configurationManager.readKeyMappingInfo(this)
        }

        private fun handleReadKeyMappingResponse(responseData: Map<Parameter, Any>) {
            try {
                readKeyMappingInfoJson = when (keyMappingState) {
                    KeyMappingState.ORIGINAL -> {
                        JSONObject(responseData[Parameter.KeyMappingInfo].toString())
                    }
                    KeyMappingState.STUB_1 -> {
                        JSONObject("{\"dukpt_keys\":[{\"ksn\":\":FFFFFF00060000000000\"," +
                                "\"key_name\":\":2015-K-F01-ED00\",\"encrypted_value\":\":AE002F3EF2FB9B624F2644ECB0D43529\"}," +
                                "{\"ksn\":\":FFFFFF00080000000000\",\"key_name\":\":2015-K-F03-BD00\"," +
                                "\"encrypted_value\":\":8BAE75AD1AF8FCB733AEAF97944E5B9C\"}]}")
                    }
                    KeyMappingState.STUB_2 -> {
                        JSONObject("{\"dukpt_keys\":[{\"ksn\":\":FFFFFF00560000000000\"," +
                                "\"key_name\":\":2015-K-F51-ED00\",\"encrypted_value\":\":12345678901234567890123456789012\"}," +
                                "{\"ksn\":\":FFFFFF00580000000000\",\"key_name\":\":2015-K-F53-BD00\"," +
                                "\"encrypted_value\":\":ABCDEFGHIJKLMNOPABCDEFGHIJKLMNOP\"}]}")
                    }
                }
                stateJson.put("KeyMappingInfo", readKeyMappingInfoJson)
            } catch (e: JSONException) {
                e.printStackTrace()
                onResponse(false)
                return
            }
            deviceManager.getDeviceStatistics(this)
        }

        private fun handleDeviceStatisticsResponse(responseData: Map<Parameter, Any>) {
            try {
                deviceStatisticsJson = JSONObject(responseMapToJson(responseData))
                stateJson.put("DeviceStatistics", deviceStatisticsJson)
                stateJson.put("MobileInfo", mobileInfoJson)
                readerStateJson = stateJson.toString()
                onResponse(true)
            } catch (e: JSONException) {
                e.printStackTrace()
                onResponse(false)
            }
        }
    }

    private fun logReaderError(data: Map<Parameter, Any>) {
        val errorCode = data[Parameter.ErrorCode] as ErrorCode?
        val errorMessageBuilder = StringBuilder()
        if (errorCode != null) {
            errorMessageBuilder
                .append("ErrorCode : ")
                .append(errorCode.toString())
                .append("\n")
        }
        if (data[Parameter.ErrorDetails] != null) {
            errorMessageBuilder
                .append("RoamReaderErrorDetails : ")
                .append(data[Parameter.ErrorDetails].toString())
                .append("\n")
        }
        Log.e(this.javaClass.simpleName, errorMessageBuilder.toString())
    }

    private fun logProgress(message: ProgressMessage, additionalMessage: String) {
        Log.i(
            this.javaClass.simpleName,
            "\n Progress Message :$message $additionalMessage\n"
        )
    }

    private fun createMobileInfo(): JSONObject {
        val mobileInfoJson = JSONObject()
        try {
            mobileInfoJson.put("OS", "Android")
            mobileInfoJson.put("MobileModel", Build.MODEL)
            mobileInfoJson.put("MobileSdkVersion", Build.VERSION.SDK_INT)
            mobileInfoJson.put("MobileManufacturer", Build.MANUFACTURER)
            mobileInfoJson.put("TerminalId", "20118RP11424637")
            mobileInfoJson.put("ApplicationID", "ApplicationId")
            mobileInfoJson.put("ApplicationVersionName", "1.0")
            mobileInfoJson.put("ApplicationVersionCode", "1")
        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return mobileInfoJson
    }

}