package com.tsys.payments.hardware.ingenico;

import android.util.Pair;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.roam.roamreaderunifiedapi.DeviceManager;
import com.roam.roamreaderunifiedapi.RoamReaderUnifiedAPI;
import com.roam.roamreaderunifiedapi.callback.DeviceResponseHandler;
import com.roam.roamreaderunifiedapi.constants.Command;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.roam.roamreaderunifiedapi.constants.ProgressMessage;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;
import com.tsys.payments.hardware.ingenico.enums.IngenicoCvm;
import com.tsys.payments.library.domain.AidConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.CvmResult;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.terminal.enums.TerminalStatus;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Utility class for converting helper objects between RUA SDK and Core Payment Library
 */
class IngenicoConversionHelper {
    /**
     * Indicates that the PAN was entered via contact EMV according to ISO-8583. This is one of the possible values of
     * tag {@link EmvTagDescriptor#POS_ENTRY_MODE}.
     */
    static final String PAN_ENTRY_MODE_CONTACT_EMV = "05";
    /**
     * Indicates that the PAN was entered via contactless EMV according to ISO-8583. This is one of the possible values
     * of tag {@link EmvTagDescriptor#POS_ENTRY_MODE}.
     */
    static final String PAN_ENTRY_MODE_CONTACTLESS_EMV = "07";
    /**
     * Indicates that the PAN was entered via contactless magnetic stripe according to ISO-8583. This is one of the
     * possible valuesof tag {@link EmvTagDescriptor#POS_ENTRY_MODE}.
     */
    static final String PAN_ENTRY_MODE_CONTACTLESS_MSR = "91";
    private static final String CHIP_ERROR = "C009";
    private static final String ICC_SWIPE_DETECTED_ERROR = "C00C";

    /**
     * Converts a Core Payment Library device {@link ConnectionType} to a {@link CommunicationType} recognized by the
     * RUA SDK.
     *
     * @return {@link CommunicationType} consumed by RUA SDK.
     */
    @Nullable
    static CommunicationType getCorrespondingCommunicationType(@NonNull ConnectionType connectionType) {
        switch (connectionType) {
            case BLUETOOTH:
                return CommunicationType.Bluetooth;
            case AUDIO_JACK:
                return CommunicationType.AudioJack;
            case USB:
                return CommunicationType.Usb;
            default:
                return null;
        }
    }

    /**
     * Converts a Core Payment Library {@link TerminalType} to the corresponding device type recognized by the RUA SDK.
     *
     * @return {@link DeviceType} representing the RUA device.
     */
    @Nullable
    static DeviceType getCorrespondingDeviceType(@NonNull TerminalType terminalType) {
        switch (terminalType) {
            case INGENICO_RP350:
                return DeviceType.RP350x;
            case INGENICO_RP45BT:
                return DeviceType.RP45BT;
            case INGENICO_RP450C:
                return DeviceType.RP450c;
            case INGENICO_MOBY_3000:
            case INGENICO_MOBY_3000_PROPAY:
                return DeviceType.MOBY3000;
            case INGENICO_MOBY_5500:
                return DeviceType.MOBY5500;
            case INGENICO_MOBY_8500:
                return DeviceType.MOBY8500;
            case ROAM_G5X_TSYS_DECRYPTION:
                return DeviceType.G4x;
            default:
                return null;
        }
    }

    /**
     * Converts the {@link Integer} representation of the {@link AidConfiguration#getPriorityIndex()} to a formatted
     * {@link String} consumed by the Ingenico {@link DeviceManager}.
     */
    @Nullable
    static String getFormattedPriorityIndex(@Nullable Integer priorityIndex) {
        if (priorityIndex == null) return null;
        return String.format("%02X", priorityIndex);
    }

    /**
     * Converts the {@link Long} representation of the {@link AidConfiguration#getFloorLimit()} to a formatted {@link
     * String} consumable by the Ingenico {@link DeviceManager}.
     */
    @Nullable
    static String getFormattedFloorLimit(@Nullable Long floorLimit) {
        if (floorLimit == null) return null;
        return String.format("%08X", floorLimit);
    }

    /**
     * Converts the {@link Long} representation of the transaction threshold value. {@link String} consumable by the
     * Ingenico {@link DeviceManager}.
     */
    @Nullable
    static String getFormattedTransactionThresholdValue(@Nullable Long thresholdValue) {
        if (thresholdValue == null) return null;
        return String.format("%08X", thresholdValue);
    }

    /**
     * Converts the {@link Long} representation of the {@link AidConfiguration#getTransactionLimit()} to a formatted
     * {@link String} consumable by the Ingenico {@link DeviceManager}.
     */
    @Nullable
    static String getFormattedTransactionLimit(@Nullable Long transactionLimit) {
        if (transactionLimit == null) return null;
        return String.format("%08X", transactionLimit);
    }

    /**
     * Converts the {@link Long} representation of the {@link AidConfiguration#getCvmLimit()} to a formatted {@link
     * String} consumable by the Ingenico {@link DeviceManager}.
     */
    @Nullable
    static String getFormattedCvmLimit(@Nullable Long cvmLimit) {
        if (cvmLimit == null) return null;
        return String.format("%08X", cvmLimit);
    }

    /**
     * Returns a {@link Pair<DeviceType,DeviceManager>} containing the Ingenico SDK device type and device manager based
     * on the {@link TerminalType} passed in.
     *
     * @param terminalType {@link TerminalType} representing the device type mapping in the core payments SDK.
     */
    @NonNull
    static Pair<DeviceType, DeviceManager> getIngenicoDeviceSetup(TerminalType terminalType) {
        switch (terminalType) {
            case INGENICO_RP350:
                return new Pair<>(DeviceType.RP350x,
                        RoamReaderUnifiedAPI.getDeviceManager(DeviceType.RP350x));
            case INGENICO_RP450C:
                return new Pair<>(DeviceType.RP450c,
                        RoamReaderUnifiedAPI.getDeviceManager(DeviceType.RP450c));
            case INGENICO_RP45BT:
                return new Pair<>(DeviceType.RP45BT,
                        RoamReaderUnifiedAPI.getDeviceManager(DeviceType.RP45BT));
            case ROAM_G5X_TSYS_DECRYPTION:
                return new Pair<>(DeviceType.G4x,
                        RoamReaderUnifiedAPI.getDeviceManager(DeviceType.G4x));
            case INGENICO_MOBY_3000:
            case INGENICO_MOBY_3000_PROPAY:
                return new Pair<>(DeviceType.MOBY3000,
                        RoamReaderUnifiedAPI.getDeviceManager(DeviceType.MOBY3000));
            case INGENICO_MOBY_5500:
                return new Pair<>(DeviceType.MOBY5500,
                        RoamReaderUnifiedAPI.getDeviceManager(DeviceType.MOBY5500));
            case INGENICO_MOBY_8500:
                return new Pair<>(DeviceType.MOBY8500,
                        RoamReaderUnifiedAPI.getDeviceManager(DeviceType.MOBY8500));
            default:
                throw new IllegalArgumentException(
                        String.format("Swiper type:%s is not supported", terminalType));
        }
    }

    /**
     * Returns a terminal status enumeration based on the progress message provided by the Ingenico SDK.
     *
     * @param progressMessage {@link ProgressMessage} returned by the Ingenico SDK in {@link
     *                        DeviceResponseHandler#onProgress(ProgressMessage, String)}.
     * @param description     {@link String} Describing the {@link ProgressMessage} returned in {@link
     *                        DeviceResponseHandler#onProgress(ProgressMessage, String)}
     * @return {@link TerminalStatus} mapping corresponding to a {@link ProgressMessage}.
     */
    @Nullable
    static TerminalStatus getCorrespondingTerminalStatus(ProgressMessage progressMessage, String description) {
        switch (progressMessage) {
            case ApplicationSelectionStarted:
            case DecodingStarted:
            case ApplicationSelectionCompleted:
            case Authorizing:
            case Unknown:
            case CommandSent:
                return getConfigurationCommandTerminalStatus(progressMessage, description);
            case DeviceBusy:
                // TODO: Pending.
                break;
            case CardErrorRemoveCard:
                return TerminalStatus.CARD_READ_ERROR;
            case CardReadOkRemoveCard:
                // TODO: Pending.
                break;
            case CardInserted:
            case SwipeDetected:
            case TapDetected:
                return TerminalStatus.CARD_DETECTED;
            case ErrorReadingContactlessCard:
            case PresentCardAgain:
            case SwipeErrorReswipeMagStripe:
            case ReinsertCard:
                return TerminalStatus.BAD_READ_DETECTED;
            case ICCErrorSwipeCard:
                return TerminalStatus.TECHNICAL_FALLBACK_INITIATED;
            case MultipleContactlessCardsDetected:
                return TerminalStatus.MULTIPLE_CARDS_DETECTED;
            case ContactlessCardStillInField:
                return TerminalStatus.CONTACTLESS_CARD_STILL_IN_FIELD;
            case ContactlessInterfaceFailedTryContact:
                return TerminalStatus.CONTACTLESS_INTERFACE_FAILED_TRY_CONTACT;
            case PleaseInsertCard:
                if (ICC_SWIPE_DETECTED_ERROR.equals(description)) {
                    return TerminalStatus.ICC_SWIPE_DETECTED;
                } else {
                    return TerminalStatus.WAITING_FOR_CARD;
                }
            case InsertOrSwipeCard:
            case WaitingforCardSwipe:
                return TerminalStatus.WAITING_FOR_CARD;
            case ProcessingDoNotRemoveCard:
                return TerminalStatus.DO_NOT_REMOVE_CARD;
            case ContactlessTransactionRevertedToContact:
                // TODO:Pending.
                break;
            case NotAcceptedRemoveCard:
            case NotAuthorized:
                // Transaction should be restarted.
                return TerminalStatus.REMOVE_CARD;
            case PleaseRemoveCard:
                if (description.equals(CHIP_ERROR)) {
                    return TerminalStatus.BAD_READ_DETECTED;
                } else {
                    return TerminalStatus.REMOVE_CARD;
                }
            case RemoveCard:
            case CancelledRemoveCard:
            case TransactionVoidRemoveCard:
                return TerminalStatus.REMOVE_CARD;
            case WaitingforDevice:
                // TODO: Pending.
                break;
            case UpdatingFirmware:
                // TODO: Pending.
                //                String[] progressData = description.split("/");
                //                if (progressData.length == 2) {
                //                    mCallbacks.onFirmwareUpdateProgress(Integer.valueOf(progressData[0]),
                //                            Integer.valueOf(progressData[1]));
                //                }
                break;
            case PleaseSeePhone:
                return TerminalStatus.SEE_PHONE;
        }

        return null;
    }

    /**
     * Extract the entry mode corresponding to the terminal interface that performed the transaction. This entry mode is
     * mapped in the TLV object with tag {@link com.tsys.payments.library.tlv.EmvTagDescriptor#POS_ENTRY_MODE}.
     *
     * @param posEntryMode {@link TlvObject} with tag descriptor {@link com.tsys.payments.library.tlv.EmvTagDescriptor#POS_ENTRY_MODE}.
     */
    @Nullable
    static CardDataSourceType getCardDataSource(@Nullable String posEntryMode) {
        if (posEntryMode == null) {
            return null;
        }

        if (PAN_ENTRY_MODE_CONTACT_EMV.equals(posEntryMode)) {
            return CardDataSourceType.SCR;
        } else if (PAN_ENTRY_MODE_CONTACTLESS_EMV.equals(posEntryMode)) {
            return CardDataSourceType.CONTACTLESS_EMV;
        } else if (PAN_ENTRY_MODE_CONTACTLESS_MSR.equals(posEntryMode)) {
            return CardDataSourceType.CONTACTLESS_MSR;
        } else {
            return null;
        }
    }

    @Nullable
    private static TerminalStatus getConfigurationCommandTerminalStatus(ProgressMessage progressMessage,
            String description) {
        if (progressMessage == ProgressMessage.CommandSent && description != null) {
            if (description.contains(Command.ClearAIDsList.toString()) ||
                    description.contains(Command.SubmitAIDsList.toString()) ||
                    description.contains(Command.ClearPublicKeys.toString()) ||
                    description.contains(Command.SubmitPublicKey.toString()) ||
                    description.contains(Command.ConfigureAmountDOLData.toString()) ||
                    description.contains(Command.ConfigureContactlessOnlineDOLData.toString()) ||
                    description.contains(Command.ConfigureContactlessResponseDOLData.toString()) ||
                    description.contains(Command.ConfigureOnlineDOLData.toString()) ||
                    description.contains(Command.ConfigureResponseDOLData.toString())
                    || description.contains(Command.ConfigureUserInterfaceOptions.toString())) {
                return TerminalStatus.CONFIGURING;
            }
        }
        return null;
    }

    /**
     * Converts the SDK representation of a list of Contact Application Identifiers(AID's) into a format required by the
     * Ingenico SDK.
     *
     * @param sdkAids {@link List<AidConfiguration>} of contact AID's.
     * @return {@link Set<ApplicationIdentifier>} containing list of contact AID's in a representation consumed by the
     * Ingenico SDK.
     */
    @NonNull
    static Set<ApplicationIdentifier> getContactAids(@NonNull List<AidConfiguration> sdkAids) {
        Set<ApplicationIdentifier> aidsSet = new HashSet<>();
        for (AidConfiguration configuration : sdkAids) {
            aidsSet.add(new ApplicationIdentifier(
                    configuration.getAid().getRid(), configuration.getAid().getPix(),
                    configuration.getTerminalAppVersion(),
                    configuration.getLowestSupportedIccAppVersion(),
                    getFormattedPriorityIndex(configuration.getPriorityIndex()),
                    configuration.getApplicationSelectionFlags()
            ));
        }
        return aidsSet;
    }

    /**
     * Converts the SDK representation of a list of Contactless Application Identifiers(AID's) into a format required by
     * the Ingenico SDK.
     *
     * @param sdkAids {@link List<AidConfiguration>} of contactless AID's.
     * @return {@link Set<ApplicationIdentifier>} containing list of contactless AID's in a representation consumed by
     * the Ingenico SDK.
     */
    @NonNull
    static Set<ApplicationIdentifier> getContactlessAids(@NonNull List<AidConfiguration> sdkAids) {
        Set<ApplicationIdentifier> aidsSet = new HashSet<>();
        for (AidConfiguration configuration : sdkAids) {
            aidsSet.add(new ApplicationIdentifier(
                    configuration.getAid().getRid(), configuration.getAid().getPix(),
                    configuration.getTerminalAppVersion(), configuration.getLowestSupportedIccAppVersion(),
                    IngenicoConversionHelper.getFormattedPriorityIndex(configuration.getPriorityIndex()),
                    configuration.getApplicationSelectionFlags(),
                    IngenicoConversionHelper.getFormattedFloorLimit(configuration.getFloorLimit()),
                    IngenicoConversionHelper.getFormattedCvmLimit(configuration.getCvmLimit()),
                    IngenicoConversionHelper.getFormattedTransactionLimit(configuration.getTransactionLimit()),
                    configuration.getTerminalCapabilities(),
                    configuration.getTlvData()
            ));
        }
        return aidsSet;
    }

    /**
     * Converts the Core SDK representation of the CVM Result from the Ingenico type.
     *
     * @param cvm {@link IngenicoCvm} derives from the {@link Parameter#CardholderVerificationMethodResult} returned by
     *            the RUA SDK.
     * @return {@link CvmResult} representing the Core SDK value.
     */
    @NonNull
    static CvmResult getCvmResultFromIngenico(@NonNull IngenicoCvm cvm) {
        switch (cvm) {
            case PLAINTEXT_PIN_OFFLINE:
                return CvmResult.PIN_OFFLINE_PLAIN;
            case ENCIPHERED_PIN_VERIFIED_ONLINE:
                return CvmResult.PIN_ONLINE;
            case PLAINTEXT_PIN_VERIFIED_OFFLINE_PAPER_SIGNATURE:
            case SIGNATURE:
                return CvmResult.SIGNATURE_REQUIRED;
            default:
                return CvmResult.NOT_AVAILABLE;
        }
    }

    /**
     * Returns the Ingenico SDK mapping for a given {@link EmvTagDescriptor}.
     *
     * @param tagDescriptor {@link EmvTagDescriptor} representation of an EMV tag.
     * @return {@link Parameter} mapping corresponding to the tag descriptor.
     */
    @Nullable
    static Parameter getIngenicoTagParameter(@NonNull EmvTagDescriptor tagDescriptor) {
        switch (tagDescriptor) {
            case ISSUER_IDENTIFICATION_NUMBER:
                return Parameter.IssuerIdentificationNumber;
            case APPLICATION_IDENTIFIER:
                return Parameter.ApplicationIdentifier;
            case APP_LABEL:
                return Parameter.ApplicationLabel;
            case TRACK_1:
                return Parameter.Track1Data;
            case TRACK_2_EQUIVALENT_DATA:
                return Parameter.Track2EquivalentData;
            case PAN:
                return Parameter.PAN;
            case CARDHOLDER_NAME:
                return Parameter.CardHolderName;
            case APPLICATION_EXPIRATION_DATE:
                return Parameter.ApplicationExpirationDate;
            case APPLICATION_EFFECTIVE_DATE:
                return Parameter.ApplicationEffectiveDate;
            case ISSUER_COUNTRY_CODE:
                return Parameter.IssuerCountryCode;
            case TRANSACTION_CURRENCY_CODE:
                return Parameter.TransactionCurrencyCode;
            case LANGUAGE_PREFERENCE:
                return Parameter.LanguagePreference;
            case SERVICE_CODE:
                return Parameter.ServiceCode;
            case PAN_SEQUENCE_NUMBER:
                return Parameter.PANSequenceNumber;
            case TRANSACTION_CURRENCY_EXPONENT:
                return Parameter.TransactionCurrencyExponent;
            case ISSUER_URL:
                return Parameter.IssuerURL;
            case INTERNATION_BANK_ACCOUNT_NUMBER:
                return Parameter.InternationalBankAccountNumber;
            case BANK_IDENTIFIER_CODE:
                return Parameter.BankIndentifierCode;
            case ISSUER_COUNTRY_CODE_ALPHA_2:
                return Parameter.IssuerCountryCodeAlpha2;
            case ISSUER_COUNTRY_CODE_ALPHA_3:
                return Parameter.IssuerCountryCodeAlpha3;
            case APPLICATION_TEMPLATE:
                return Parameter.ApplicationTemplate;
            case FILE_CONTROL_INFORMATION_TEMPLATE:
                return Parameter.FileControlInformationTemplate;
            case ISSUER_SCRIPT_TEMPLATE_1:
                return Parameter.IssuerScript1;
            case ISSUER_SCRIPT_TEMPLATE_2:
                return Parameter.IssuerScript2;
            case DIRECTORY_DISCRETIONARY_TEMPLATE:
                return Parameter.DirectoryDiscretionaryTemplate;
            case RESPONSE_MESSAGE_TEMPLATE_FORMAT_1:
                return Parameter.ResponseMessageTemplateFormat1;
            case RESPONSE_MESSAGE_TEMPLATE_FORMAT_2:
                return Parameter.ResponseMessageTemplateFormat2;
            case AMOUNT_AUTHORIZED_BINARY:
                return Parameter.AmountAuthorizedBinary;
            case APPLICATION_INTERCHANGE_PROFILE:
                return Parameter.ApplicationInterchangeProfile;
            case DEDICATED_FILE_NAME:
                return Parameter.DedicatedFileName;
            case ISSUER_SCRIPT_COMMAND:
                return Parameter.IssuerScriptCommand;
            case APPLICATION_PRIORITY_INDICATOR:
                return Parameter.ApplicationPriorityIndicator;
            case SHORT_FILE_IDENTIFIER:
                return Parameter.ShortFileIndicator;
            case AUTHORIZATION_CODE:
                return Parameter.AuthorizationCode;
            case AUTHORIZATION_RESPONSE_CODE:
                return Parameter.AuthorizationResponseCode;
            case CARD_RISK_MANAGEMENT_DATA_OBJECT_LIST_1:
                return Parameter.CardRiskManagementDataObjectList1;
            case CARD_RISK_MANAGEMENT_DATA_OBJECT_LIST_2:
                return Parameter.CardRiskManagementDataObjectList2;
            case CARD_VERIFICATION_METHOD_LIST:
                return Parameter.CardholderVerificationMethodList;
            case CA_PUBLIC_KEY_INDEX:
                return Parameter.CertificationAuthorityPublicKeyIndex;
            case ISSUER_PUBLIC_KEY_CERTIFICATE:
                return Parameter.IssuerPublicKeyCertificate;
            case ISSUER_AUTHENTICATION_DATA:
                return Parameter.IssuerAuthenticationData;
            case ISSUER_PUBLIC_KEY_REMAINDER:
                return Parameter.IssuerPublicKeyRemainder;
            case SIGNED_STATIC_APP_DATA:
                return Parameter.SignedStaticApplicationData;
            case APPLICATION_FILE_LOCATOR:
                return Parameter.ApplicationFileLocator;
            case TERMINAL_VERIFICATION_RESULTS:
                return Parameter.TerminalVerificationResults;
            case TRANSACTION_CERTIFICATE_DATA_OBJECT_LIST:
                return Parameter.TransactionCertificateDataObjectList;
            case TRANSACTION_CERTIFICATE_HASH_VALUE:
                return Parameter.TransactionCertificateHashValue;
            case TRANSACTION_DATE:
                return Parameter.TransactionDate;
            case TRANSACTION_STATUS_INFORMATION:
                return Parameter.TransactionStatusInformation;
            case TRANSACTION_TYPE:
                return Parameter.TransactionType;
            case DIRECTORY_DEFINITION_FILE_NAME:
                return Parameter.DirectoryDefinitionFile;
            case ACQUIRER_ID:
                return Parameter.AcquirerIdentifier;
            case AMOUNT_AUTHORIZED_NUMERIC:
                return Parameter.AmountAuthorizedNumeric;
            case AMOUNT_OTHER_NUMERIC:
                return Parameter.AmountOtherNumeric;
            case AMOUNT_OTHER_BINARY:
                return Parameter.AmountOtherBinary;
            case APPLICATION_DISCRETIONARY_DATA:
                return Parameter.ApplicationDiscretionaryData;
            case APPLICATION_USAGE_CONTROL:
                return Parameter.ApplicationUsageControl;
            case APPLICATION_VERSION_NUMBER:
                return Parameter.ApplicationVersionNumber;
            case APPLICATION_VERSION_NUMBER_TERMINAL:
                return Parameter.TerminalApplicationVersionNumber;
            case CARDHOLDER_NAME_EXTENDED:
                return Parameter.CardholderNameExtended;
            case ISSUER_ACTION_DEFAULT:
                return Parameter.IssuerActionCodeDefault;
            case ISSUER_ACTION_DENIAL:
                return Parameter.IssuerActionCodeDenial;
            case ISSUER_ACTION_ONLINE:
                return Parameter.IssuerActionCodeOnline;
            case ISSUER_APP_DATA:
                return Parameter.IssuerApplicationData;
            case ISSUER_CODE_TABLE_INDEX:
                return Parameter.IssuerCodeTableIndex;
            case APPLICATION_PREFERRED_NAME:
                return Parameter.ApplicationPreferredName;
            case LAST_ONLINE_APPLICATION_TRANSACTION_COUNTER_REGISTER:
                return Parameter.LastOnlineApplicationTransactionCounterRegister;
            case LOWER_CONSECUTIVE_OFFLINE_LIMIT:
                return Parameter.LowerConsecutiveOfflineLimit;
            case MERCHANT_CATEGORY_CODE:
                return Parameter.MerchantCategoryCode;
            case MERCHANT_IDENTIFIER:
                return Parameter.MerchantIdentifier;
            case ISSUER_SCRIPT_IDENTIFIER:
                return Parameter.IssuerScriptIdentifier;
            case TERMINAL_COUNTRY_CODE:
                return Parameter.TerminalCountryCode;
            case TERMINAL_FLOOR_LIMIT:
                return Parameter.TerminalFloorLimit;
            case TERMINAL_IDENTIFICATION:
                return Parameter.TerminalIdentification;
            case TERMINAL_RISK_MANAGEMENT_DATA:
                return Parameter.TerminalRiskManagementData;
            case IFD_SERIAL_NUMBER:
                return Parameter.InterfaceDeviceSerialNumber;
            case TRACK_1_DISCRETIONARY_DATA:
                return Parameter.Track1DiscretionaryData;
            case TRACK_2_DISCRETIONARY_DATA:
                return Parameter.Track2DiscretionaryData;
            case TRANSACTION_TIME:
                return Parameter.TransactionTime;
            case UPPER_CONSECUTIVE_OFFLINE_LIMIT:
                return Parameter.UpperConsecutiveOfflineLimit;
            case APPLICATION_CRYPTOGRAM:
                return Parameter.ApplicationCryptogram;
            case CRYPTOGRAM_INFORMATION_DATA:
                return Parameter.CryptogramInformationData;
            case ICC_PIN_ENCIPHERMENT_PUBLIC_KEY_CERTIFICATE:
                return Parameter.ICCPINEnciphermentPublicKeyCertificate;
            case ICC_PIN_ENCIPHERMENT_PUBLIC_KEY_EXPONENT:
                return Parameter.ICCPINEnciphermentPublicKeyExponent;
            case ICC_PIN_ENCIPHERMENT_PUBLIC_KEY_REMAINDER:
                return Parameter.ICCPINEnciphermentPublicKeyRemainder;
            case ISSUER_PUBLIC_KEY_EXPONENT:
                return Parameter.IssuerPublicKeyExponent;
            case TERMINAL_CAPABILITIES:
                return Parameter.TerminalCapabilities;
            case CVM_RESULT:
                return Parameter.CardholderVerificationMethodResult;
            case TERMINAL_TYPE:
                return Parameter.TerminalType;
            case APPLICATION_TRANSACTION_COUNTER:
                return Parameter.ApplicationTransactionCounter;
            case UNPREDICTABLE_NUMBER:
                return Parameter.UnpredictableNumber;
            case PROCESSING_OPTIONS_DOL:
                return Parameter.ProcessingOptionsDataObjectList;
            case POS_ENTRY_MODE:
                return Parameter.POSEntryMode;
            case AMOUNT_REFERENCE_CURRENCY:
                return Parameter.AmountReferenceCurrency;
            case APP_REFERENCE_CURRENCY_CODE:
                return Parameter.ApplicationReferenceCurrency;
            case TRANSACTION_REFERENCE_CURRENCY_CODE:
                return Parameter.TransactionReferenceCurrency;
            case TRANSACTION_REFERENCE_CURRENCY_EXPONENT:
                return Parameter.TransactionReferenceCurrencyExponent;
            case ADDITIONAL_TERMINAL_CAPABILITIES:
                return Parameter.AdditionalTerminalCapabilities;
            case TRANSACTION_SEQUENCE_NUMBER:
                return Parameter.TransactionSequenceCounter;
            case APPLICATION_CURRENCY_CODE:
                return Parameter.ApplicationCurrencyCode;
            case APPLICATION_REFERENCE_CURRENCY_EXPONENT:
                return Parameter.ApplicationReferenceCurrencyExponent;
            case APPLICATION_CURRENCY_EXPONENT:
                return Parameter.ApplicationCurrencyExponent;
            case DATA_AUTHENTICATION_CODE:
                return Parameter.DataAuthenticationCode;
            case ICC_PUBLIC_KEY_CERTIFICATE:
                return Parameter.ICCPublicKeyCertificate;
            case ICC_PUBLIC_KEY_EXPONENT:
                return Parameter.ICCPublicKeyExponent;
            case ICC_PUBLIC_KEY_REMAINDER:
                return Parameter.ICCPublicKeyRemainder;
            case DYNAMIC_DATA_OBJECT_LIST:
                return Parameter.DynamicDataAuthenticationDataObjectList;
            case STATIC_DATA_AUTHENTICATION_TAG_LIST:
                return Parameter.StaticDataAuthenticationTagList;
            case SIGNED_DYNAMIC_APP_DATA:
                return Parameter.SignedDynamicApplicationData;
            case ICC_DYNAMIC_NUMBER:
                return Parameter.ICCDynamicNumber;
            case MASTERCARD_TRANSACTION_CATEGORY_CODE:
                return Parameter.TransactionCategoryCode;
            case LOG_ENTRY:
                return Parameter.LogEntry;
            case MERCHANT_NAME_AND_LOCATION:
                return Parameter.MerchantNameLocation;
            case LOG_FORMAT:
                return Parameter.LogFormat;
            case VISA_FORM_FACTOR_INDICATOR:
                return Parameter.FormFactorIndicator;
            case TRACK_2_DATA_CONTACTLESS:
                return Parameter.Track2DataContactless;
            case CUSTOMER_EXCLUSIVE_DATA:
                return Parameter.CustomerExclusiveData;
            case FCI_ISSUER_DISCRETIONARY_DATA:
                return Parameter.FileControlInformationIssuerDiscretionaryData;
            case EXPRESSPAY_ENHANCED_TERMINAL_CAPABILITIES:
                return Parameter.PayPassThirdPartyData;
            case INGENICO_KSN:
                return Parameter.KSN;
            case INGENICO_ENCRYPTED_TRACK:
                return Parameter.EncryptedTrack;
            default:
                return null;
        }
    }
}
