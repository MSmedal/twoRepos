package com.tsys.payments.hardware.ingenico;

import android.content.Context;

import com.roam.roamreaderunifiedapi.DeviceManager;
import com.roam.roamreaderunifiedapi.callback.SearchListener;
import com.roam.roamreaderunifiedapi.data.Device;

/**
 * Process results returned by RUA internal device search. See {@link  DeviceManager#searchDevices(Context, Boolean,
 * SearchListener)}
 */
interface IngenicoDeviceSearchResultsListener {
    void onResult(Device searchResult, boolean bonded);
}
