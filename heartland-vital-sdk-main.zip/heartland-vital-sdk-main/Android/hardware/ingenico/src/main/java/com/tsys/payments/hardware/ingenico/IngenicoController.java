package com.tsys.payments.hardware.ingenico;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Environment;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.ingenico.ruadeviceservice.DeviceService;
import com.ingenico.temlibrary.config.Ntpt3Config;
import com.landicorp.util.StringUtil;
import com.roam.roamreaderunifiedapi.DeviceManager;
import com.roam.roamreaderunifiedapi.RoamReaderUnifiedAPI;
import com.roam.roamreaderunifiedapi.callback.AudioJackPairingListenerWithDevice;
import com.roam.roamreaderunifiedapi.callback.DeviceResponseHandler;
import com.roam.roamreaderunifiedapi.callback.DeviceStatusHandler;
import com.roam.roamreaderunifiedapi.callback.LedPairingCallback;
import com.roam.roamreaderunifiedapi.callback.LedPairingConfirmationCallback;
import com.roam.roamreaderunifiedapi.constants.Command;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.constants.ErrorCode;
import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.roam.roamreaderunifiedapi.constants.ProgressMessage;
import com.roam.roamreaderunifiedapi.constants.ResponseCode;
import com.roam.roamreaderunifiedapi.constants.ResponseType;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;
import com.roam.roamreaderunifiedapi.data.Device;
import com.roam.roamreaderunifiedapi.data.LedSequence;
import com.roam.roamreaderunifiedapi.data.ReaderVersionInfo;
import com.roam.roamreaderunifiedapi.firmwaremanager.TemCommunicationManager;
import com.roam.roamreaderunifiedapi.magstripereaders.G4XDeviceManager;
import com.roam.roamreaderunifiedapi.utils.EMVTagHelper;
import com.tsys.payments.hardware.ingenico.enums.IngenicoCvm;
import com.tsys.payments.hardware.ingenico.enums.IngenicoEmvCode;
import com.tsys.payments.hardware.ingenico.enums.IngenicoPosEntryMode;
import com.tsys.payments.hardware.ingenico.utils.IngenicoHexHelper;
import com.tsys.payments.hardware.ingenico.utils.ReaderStateHandler;
import com.tsys.payments.hardware.ingenico.utils.SimpleResponseHandler;
import com.tsys.payments.library.domain.CardData;
import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.enums.CardType;
import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.CvmResult;
import com.tsys.payments.library.enums.EncryptionType;
import com.tsys.payments.library.enums.ErrorType;
import com.tsys.payments.library.enums.FallbackReason;
import com.tsys.payments.library.enums.TerminalError;
import com.tsys.payments.library.enums.TerminalSettingType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.enums.TerminalUpdateType;
import com.tsys.payments.library.enums.TransactionType;
import com.tsys.payments.library.exceptions.Error;
import com.tsys.payments.library.gateway.domain.GatewayResponse;
import com.tsys.payments.library.terminal.AvailableVersionsListener;
import com.tsys.payments.library.terminal.TerminalController;
import com.tsys.payments.library.terminal.TerminalListener;
import com.tsys.payments.library.terminal.TerminalReadSettingListener;
import com.tsys.payments.library.terminal.TerminalUpdateSettingListener;
import com.tsys.payments.library.terminal.UpdateListener;
import com.tsys.payments.library.terminal.domain.TerminalInteractionRequest;
import com.tsys.payments.library.terminal.domain.TerminalInteractionResult;
import com.tsys.payments.library.terminal.domain.TerminalRequest;
import com.tsys.payments.library.terminal.domain.TerminalResponse;
import com.tsys.payments.library.terminal.enums.TerminalAction;
import com.tsys.payments.library.terminal.enums.TerminalDecisionType;
import com.tsys.payments.library.terminal.enums.TerminalInteractionType;
import com.tsys.payments.library.terminal.enums.TerminalStatus;
import com.tsys.payments.library.tlv.ConstructedTlvObject;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import com.tsys.payments.library.tlv.TlvObject;
import com.tsys.payments.library.tlv.TlvObjectBuilder;
import com.tsys.payments.library.utils.ByteUtils;
import com.tsys.payments.library.utils.CreditCardHelper;
import com.tsys.payments.library.utils.LibraryConfigHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;
import static android.content.Context.BIND_AUTO_CREATE;

import timber.log.Timber;

class IngenicoController implements TerminalController, DeviceResponseHandler {
    private static final String TAG = IngenicoController.class.getSimpleName();
    private static final int MAX_DIP_RETRY_ATTEMPTS = 3;
    /**
     * Duration for RUA's embedded bluetooth device search process.
     */
    private static final long DEVICE_SEARCH_DURATION = 3000L;
    /**
     * Duration to wait after a transaction completes before showing the result to the user.
     */
    private static final long TRANSACTION_RESULT_DELAY_DURATION = 2000L;

    /**
     * Duration to keep the results of the previous transaction on the display before resetting to the home screen.
     */
    private static final long TRANSACTION_RESULT_DISPLAY_DURATION = 2000;

    /**
     * Duration in seconds to delay before the terminal goes into Energy Saver mode after the last communication. 60
     * seconds is the default value used by the RUA SDK. For reference purposes this default is initialized using the
     * standard default.
     */
    private static final Integer ENERGY_MODE_DELAY = 60;

    /**
     * Duration in seconds until the reader shuts off after going into Energy Saver mode, if no further commands are
     * received. Setting the shutdown to 0 means the reader will never turn off.
     */
    private static final Integer SHUTDOWN_DELAY = 0;
    private static final String AAC = "00";

    private static final String APPLICATION_ID = "com.heartlandpaymentsystems.sdk";
    private static final String APP_VERSION = "1.3.6";

    public static final String SERVICE_BOUND =
            "com.roamreaderunifiedapi.firmwareupdateapplication.sample.SERVICE_BOUND";

    @NonNull
    private final DeviceType mDeviceType;
    @NonNull
    private final AudioJackPairingListenerWithDevice mAudioJackPairingListener;
    @Nullable
    private final DeviceResponseHandler mDeviceResponseHandler = this;
    @NonNull
    private final DeviceStatusHandler mDeviceStatusHandler;
    private String CID;
    @Nullable
    private Context mContext;
    @Nullable
    private Device mDevice;

    @Nullable
    private List<ApplicationIdentifier> mAvailableAids = null;
    private DeviceService mDeviceService;
    private DeviceManager mDeviceManager;
    private TemCommunicationManager mTemCommunicationManager;
    private ReaderStateHandler mApiWrapper;
    private String mReaderStateJson;
    private String mReaderSerialNumber;
    private Boolean mIsUpdateAvailable;
    private String mDeviceGroupName;
    private String mTemIp = LibraryConfigHelper.isDebug() ? "temterminalsnar01.preprod.icloud.ingenico.com" :
            "temterminalsnar02.icloud.ingenico.com";
    private Integer mTemPort = 7047;
    private String mProvisionUrl = LibraryConfigHelper.isDebug() ? "https://github.com/hps/Moby-5500-Config/blob/main/provisionTest.json?raw=true" :
            "https://github.com/hps/Moby-5500-Config/blob/main/provisionProd.json?raw=true";
    private AvailableVersionsListener mAvailableVersionsListener;
    private TerminalUpdateType mTerminalUpdateType;
    private UpdateListener mTerminalVersionUpdateListener;
    private boolean mIsServiceBound;
    private DeviceStatusHandler mStatusHandler = new DeviceStatusHandlerImpl();
    private String mCachedConfigVersion;
    private String mCachedConfig;

    @Nullable
    private IngenicoConfigurationManager mConfigProcManager;
    @Nullable
    private IngenicoDeviceInfoManager mDeviceInfoManager;
    @Nullable
    private ApplicationIdentifier mSelectedAid = null;
    @Nullable
    private String mCurrentAid = null;

    @Nullable
    private ReaderVersionInfo mReaderVersionInfo = null;

    private int mRequestDipCount = 1;

    private TerminalConfiguration mTerminalConfiguration;

    private TransactionConfiguration mTransactionConfiguration;

    private TerminalListener mTerminalListener;

    private IngenicoRpConfiguration mRpConfiguration;
    private IngenicoMobyConfiguration mMobyConfiguration;

    private TerminalConfiguration mTerminalTransactionConfiguration;

    private TerminalAction mTerminalAction;

    private TransactionType mTransactionType;
    private TerminalRequest mTerminalRequest;
    private CardData mCardData;
    private CardData mHostRequestCardData;
    private CardDataSourceType mDataSource;

    private TerminalInfo mTerminalInfo;

    private boolean mReversalRequired;

    private boolean mDeviceProcessing;
    private boolean mConnected;
    private boolean mUserConfirmationForHostProcessingEnabled;
    private boolean mSendStopCommandAfterOnlineProcessingRequested;
    private boolean mUpdatingProvision;

    private AtomicBoolean mAwaitingCancelCommandResponse = new AtomicBoolean(false);

    IngenicoController(Context context, TerminalConfiguration terminalConfiguration,
            TransactionConfiguration transactionConfiguration, TerminalListener listener) {
        mTerminalConfiguration = terminalConfiguration;
        mTransactionConfiguration = transactionConfiguration;
        mUserConfirmationForHostProcessingEnabled =
                mTransactionConfiguration.isUserConfirmationForHostProcessingEnabled();
        mTerminalListener = listener;
        mContext = context.getApplicationContext();

        //use the moby Ingenico Configuration for Moby devices.
        if (mTerminalConfiguration.getTerminalType() == TerminalType.INGENICO_MOBY_5500) {
            mMobyConfiguration = new IngenicoMobyConfiguration(mContext);
        } else {
            mRpConfiguration = new IngenicoRpConfiguration();
        }

        Timber.d("Constructing new IngenicoController instance");

        Pair<DeviceType, DeviceManager> ingenicoDeviceConfig =
                IngenicoConversionHelper
                        .getIngenicoDeviceSetup(terminalConfiguration.getTerminalType());
        mDeviceType = ingenicoDeviceConfig.first;
        mDeviceManager = ingenicoDeviceConfig.second;
        mConfigProcManager = mTerminalConfiguration.getTerminalType() != TerminalType.INGENICO_MOBY_5500 ?
                new IngenicoConfigurationManager(context, mDeviceType, mDeviceManager,
                        mRpConfiguration,
                        new ConfigProcessManagerListenerImpl()) :
                new IngenicoConfigurationManager(context, mDeviceType, mDeviceManager,
                        mMobyConfiguration, new ConfigProcessManagerListenerImpl());
        mDeviceStatusHandler = new DeviceStatusListener();
        mAudioJackPairingListener = new IngenicoPairingListener(mTerminalListener, mDeviceManager);

        RoamReaderUnifiedAPI.setProductionMode(!LibraryConfigHelper.isDebug());
        RoamReaderUnifiedAPI.enableDebugLogging(LibraryConfigHelper.isDebug());

        if (mTerminalConfiguration.getPort() != null) {
            mTemPort = mTerminalConfiguration.getPort();
        }
    }

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Log.i(TAG, "Service connected");
            DeviceService.ServiceBinder binder =
                    (DeviceService.ServiceBinder) iBinder;
            mDeviceService = binder.getService();
            Log.i(TAG, "Registering handler");
            mDeviceService.registerStatusHandler(mStatusHandler);
            mIsServiceBound = true;
            Intent broadcastIntent = new Intent(SERVICE_BOUND);
            mContext.sendBroadcast(broadcastIntent);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.i(TAG, "Service disconnected");
            mIsServiceBound = false;
        }
    };

    private void bindService() {
        if (!mIsServiceBound) {
            Log.i(TAG, "Binding to service");
            Intent intent = new Intent(mContext, DeviceService.class);
            mContext.startService(intent);
            mContext.bindService(intent, serviceConnection, BIND_AUTO_CREATE);
        } else {
            Log.i(TAG, "Already bound to service, registering handler");
            mDeviceService.registerStatusHandler(mStatusHandler);
        }
    }

    class DeviceStatusHandlerImpl implements DeviceStatusHandler {
        @Override
        public void onConnected() {

        }

        @Override
        public void onDisconnected() {

        }

        @Override
        public void onError(String s) {

        }
    }

    private void findDevices() {
        Timber.d("findDevices() called.");
        //Bluetooth first pass will send deviceIdentifier as empty as it does a Broadcast
        //On the second pass the mac address should be passed in the sethost.
        String deviceIdentifier = mTerminalConfiguration.getHost();

        //USB only check this once
        if (mTerminalConfiguration.getConnectionType() == ConnectionType.USB &&
                mTerminalConfiguration.getTerminalType() == TerminalType.INGENICO_MOBY_5500) {
            Pair<DeviceType, DeviceManager> deviceType =
                    IngenicoConversionHelper
                            .getIngenicoDeviceSetup(mTerminalConfiguration.getTerminalType());
            deviceIdentifier = deviceType.first.toString();
        }

        IngenicoDeviceSearchListener deviceSearchListener =
                new IngenicoDeviceSearchListener(deviceIdentifier,
                        new IngenicoDeviceSearchResultsListener() {
                            @Override
                            public void onResult(Device device, boolean bonded) {
                                onDeviceFound(device, bonded);
                            }
                        });
        if (mTerminalConfiguration.getConnectionType() != ConnectionType.USB) {
            mDeviceManager.searchDevices(mContext, true, DEVICE_SEARCH_DURATION, deviceSearchListener);
        } else {
            mDeviceManager.searchDevices(mContext, false, deviceSearchListener);
        }
    }

    private void onDeviceFound(Device device, boolean bonded) {
        Timber.d("onDeviceFound() called with: device = [%s], bonded = [%s]", device, bonded);

        if (device != null) {
            mDevice = device;
            if (bonded ||
                    mTerminalConfiguration.getTerminalType() != TerminalType.INGENICO_RP450C) {
                if (mDeviceProcessing) {
                    Timber.d(
                            "A request to activate the discovered device will not be sent because a terminal command is in progress.");
                } else {
                    activateDevice();
                }
            } else {
                mDeviceManager.requestPairing(mAudioJackPairingListener);
            }
        } else {
            callbackOnTerminalInteractionError(
                    TerminalError.INITIALIZATION_ERROR,
                    "Unable to locate bluetooth device.");
        }
    }

    private void activateDevice() {
        Timber.d("activateDevice() called.");
        Objects.requireNonNull(mDevice);

        DeviceType deviceType =
                IngenicoConversionHelper
                        .getCorrespondingDeviceType(mTerminalConfiguration.getTerminalType());
        if (deviceType == null) {
            Timber.e(
                    new IllegalArgumentException(
                            "Invalid argument! TerminalType = " +
                                    mTerminalConfiguration.getTerminalType()));
        }
        CommunicationType communicationType =
                IngenicoConversionHelper.getCorrespondingCommunicationType(
                        mTerminalConfiguration.getConnectionType());
        if (communicationType == null) {
            Timber.e(new IllegalArgumentException(
                    "Invalid argument! ConnectionType = " +
                            mTerminalConfiguration.getConnectionType()));
        }

        Device device = new Device(deviceType, communicationType, mDevice.getName(),
                mDevice.getIdentifier());
        Timber.d(
                "activateDevice: Invoking ROAM " + mDeviceManager + " method: activateDevice");
        // The activate function has been benchmarked, and only takes a couple milliseconds to execute
        mDeviceProcessing = true;
        mDeviceManager.getConfigurationManager().activateDevice(device);
        if (mContext == null) {
            Timber.w("activateDevice() :: Context reference is null");
            callbackOnTerminalDisconnected();
            return;
        }

        initializeDeviceManager();
    }

    @Override
    public void connect() {
        Timber.d("connect() called.");
        if (mConnected) {
            if (mDeviceProcessing) {
                Timber.d("Terminal is connected. Device is busy processing a command.");
            } else {
                callbackOnTerminalConnected();
            }
        } else if (mDeviceProcessing) {
            /* This means that a call was made to activate the device.
               This is the only time mDeviceProcessing will be true before connection has been
               established. */
            Timber.d("Terminal is currently processing another command and awaiting a response");
            return;
        } else if (mTerminalConfiguration.getConnectionType() == ConnectionType.BLUETOOTH ||
                mTerminalConfiguration.getConnectionType() == ConnectionType.USB) {
            Timber.d("Connection type is [%s]. Finding devices...",
                    mTerminalConfiguration.getConnectionType());
            findDevices();
        } else {
            Timber.d("Device search not required. Initializing device manager...");
            initializeDeviceManager();
        }
    }

    @Override
    public void disconnect() {
        Timber.d("disconnect() called.");
        if (mDeviceManager != null) {
            mDeviceProcessing = false;
            mDeviceManager.release();
        } else {
            mContext = null;
        }
    }

    @Override
    public void updateTerminalSetting(TerminalSettingType terminalSettingsType, String terminalSettingsValue,
            TerminalUpdateSettingListener terminalUpdateSettingListener) {
        Timber.d("updateTerminalSetting() called but not supported by %s.", TAG);

        if (terminalUpdateSettingListener != null) {
            terminalUpdateSettingListener.onError(new Error() {
                @Override
                public ErrorType getType() {
                    return ErrorType.TERMINAL_ERROR;
                }

                @Override
                public String getMessage() {
                    return "Update terminal settings not supported.";
                }
            });
        }
    }

    @Override
    public void readTerminalSetting(TerminalSettingType terminalSettingsType,
            TerminalReadSettingListener terminalReadSettingListener) {
        Timber.d("readTerminalSetting() called but not supported by %s.", TAG);

        if (terminalReadSettingListener != null) {
            terminalReadSettingListener.onError(new Error() {
                @Override
                public ErrorType getType() {
                    return ErrorType.TERMINAL_ERROR;
                }

                @Override
                public String getMessage() {
                    return "Read terminal settings not supported.";
                }
            });
        }
    }

    @Override
    public void getAvailableTerminalVersions(@NonNull TerminalUpdateType terminalUpdateType,
            @Nullable Map<String, String> credentials, @NonNull AvailableVersionsListener availableVersionsListener) {
        Timber.d("getAvailableTerminalVersions() called with terminalUpdateType=%s", terminalUpdateType);

        mAvailableVersionsListener = availableVersionsListener;
        mTerminalUpdateType = terminalUpdateType;

        if (terminalUpdateType != TerminalUpdateType.FIRMWARE) {
            //read the file from github
            if (terminalUpdateType == TerminalUpdateType.KERNEL) {
                downloadConfigFile(mProvisionUrl);
            }
            return;
        }

        bindService();

        //STEP 1 -initialize the tem manager
        mTemCommunicationManager = mDeviceManager.getTemCommunicationManager();
        mApiWrapper = new ReaderStateHandler(mDeviceManager, mTemCommunicationManager);
        mApiWrapper.readerStateJson(new SimpleResponseHandler<String>() {
            @Override
            public void onResponse(String result) {
                Timber.d("readerStateJson response = %s", result);
                mReaderStateJson = result;
                mReaderSerialNumber = mApiWrapper.getReaderSerialNumber();
                mReaderVersionInfo = mApiWrapper.getReaderVersionInfo();

                Timber.d("Ntpt3Config IP = %s, Port = %d", mTemIp, mTemPort);

                Ntpt3Config ntpt3Config = Ntpt3Config.builder()
                        .applicationId(APPLICATION_ID)
                        .applicationVersion(APP_VERSION)
                        .ip(mTemIp)
                        .port(mTemPort)
                        .authorizedActivities(7)
                        .offlineInstallMode(0)
                        .callingMethod(1)
                        .SSL(0)
                        .certClient("")
                        .keyClient("")
                        .certServ("")
                        .contractNumber("0")
                        .build();

                mTemCommunicationManager.initialize(
                        new DeviceResponseHandler() {

                            @Override
                            public void onResponse(Map<Parameter, Object> map) {
                                //Step 2 - init the reader context
                                mTemCommunicationManager.initializeReaderContext(
                                        new DeviceResponseHandler() {

                                            @Override
                                            public void onResponse(Map<Parameter, Object> map) {
                                                //Step 3 - poll for updates
                                                mTemCommunicationManager.pollForUpdates(new DeviceResponseHandler(){

                                                    @Override
                                                    public void onResponse(Map<Parameter, Object> responseData) {
                                                        ResponseCode response = (ResponseCode) responseData.get(Parameter.ResponseCode);
                                                        String ret = "Response: " + response;
                                                        if (response == ResponseCode.Error) {
                                                            ret += "\nTEM error code: " + responseData.get(Parameter.ErrorDetails);
                                                        }
                                                        mIsUpdateAvailable = mTemCommunicationManager.isUpdateAvailable(mReaderSerialNumber);
                                                        Timber.d("pollForUpdates isUpdateAvailable = %b", mIsUpdateAvailable);
                                                        mDeviceGroupName = mTemCommunicationManager.getRkiFileName(mReaderSerialNumber);
                                                        Timber.d("pollForUpdates RKI DeviceGroupName = %s", mDeviceGroupName);

                                                        //Step 4 - notify the listener
                                                        if (mIsUpdateAvailable) {
                                                            mAvailableVersionsListener.onAvailableTerminalVersionsReceived(
                                                                    mTerminalUpdateType,
                                                                    Collections.singletonList("Update available"));
                                                        } else {
                                                            mAvailableVersionsListener.onTerminalVersionInfoError(TerminalError.UPDATE_NOT_REQUIRED, "No update available");
                                                        }
                                                    }

                                                    @Override
                                                    public void onProgress(ProgressMessage message, String additionalMessage) {
                                                        Log.i(TAG, "onProgress : " + message.name() + ", " + additionalMessage);
                                                        if(additionalMessage.startsWith("Failed")) {
                                                            mAvailableVersionsListener.onTerminalVersionInfoError(TerminalError.SERVER_COMM_ERROR, "Error polling for update");
                                                        }
                                                    }
                                                });
                                            }

                                            @Override
                                            public void onProgress(ProgressMessage progressMessage, String s) {

                                            }
                                        },
                                        mReaderStateJson);
                            }

                            @Override
                            public void onProgress(ProgressMessage progressMessage, String s) {

                            }
                        },
                        mApiWrapper.getReaderSerialNumber(),
                        mContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath(),//getApplicationInfo().dataDir,
                        ntpt3Config
                );


            }

            @Override
            public void onProgress(String result) {
            }
        });
    }

    /**
     * Download to cache the latest provision file from the specified URL.
     * @param url The URL of the provision file.
     */
    private void downloadConfigFile(String url) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //get the latest config from the url
                    HttpURLConnection con = (HttpURLConnection)(new URL(url)).openConnection();
                    con.setRequestMethod("GET");

                    InputStream is = con.getInputStream();

                    int bufferSize = 1024;
                    char[] buffer = new char[bufferSize];
                    StringBuilder out = new StringBuilder();
                    Reader in = new InputStreamReader(is);
                    for (int numRead; (numRead = in.read(buffer, 0, buffer.length)) > 0; ) {
                        out.append(buffer, 0, numRead);
                    }
                    String configString = out.toString();
                    is.close();

                    //compare version with current
                    JSONObject configJson = new JSONObject(configString);
                    JSONArray arr = (JSONArray)configJson.get("firmware_id");
                    String latestVersion = null;
                    if (arr.length() > 0) {
                        latestVersion = arr.getString(0);
                    } else {
                        mAvailableVersionsListener.onTerminalVersionInfoError(TerminalError.UPDATE_NOT_REQUIRED, "No update available");
                        return;
                    }
                    latestVersion = LibraryConfigHelper.isDebug() ? latestVersion.concat("D") : latestVersion.concat("P");
                    String currentVersion = mMobyConfiguration.getCurrentProvisionVersion();
                    if (!latestVersion.equals(currentVersion)) {
                        mCachedConfigVersion = latestVersion;
                        mCachedConfig = configString;
                        mAvailableVersionsListener.onAvailableTerminalVersionsReceived(mTerminalUpdateType, Collections.singletonList(latestVersion));
                    } else {
                        mAvailableVersionsListener.onTerminalVersionInfoError(TerminalError.UPDATE_NOT_REQUIRED, "No update available");
                    }
                }catch(Exception e) {
                    e.printStackTrace();
                    mAvailableVersionsListener.onTerminalVersionInfoError(TerminalError.SERVER_COMM_ERROR, e.getMessage());
                }
            }
        });
        thread.start();
    }

    private void downloadFirmware() {
        String updatePath = mTemCommunicationManager.getUpdateFilePath(mReaderSerialNumber);
        Timber.d("downloadFirmware = %s", updatePath);

        updateFirmware(updatePath, new DeviceResponseHandler() {
            @Override
            public void onResponse(Map<Parameter, Object> responseData) {
                ResponseCode response = (ResponseCode) responseData.get(Parameter.ResponseCode);
                String ret = "Response: " + response;
                if (response == ResponseCode.Error) {
                    ret += "\nTEM error code: " + responseData.get(Parameter.ErrorDetails);
                    mTerminalVersionUpdateListener.onTerminalUpdateError(TerminalError.GENERAL_ERROR, ret);
                } else {
                    mTerminalVersionUpdateListener.onTerminalUpdateSuccess();
                }

            }

            @Override
            public void onProgress(ProgressMessage message, String additionalMessage) {
                Log.i(TAG, "onProgress : " + message.name() + ", " + additionalMessage);
                if(!additionalMessage.startsWith("Failed")) {
                    String[] values = additionalMessage.split("/");
                    if(values.length == 2){
                        try{
                            int percent = Integer.parseInt(values[0]) * 100 / Integer.parseInt(values[1]);
                            Timber.d("downloadFirmware onProgress = %d", percent);
                            mTerminalVersionUpdateListener.onProgress((double)percent, message.name());
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                    }else {
                        //ignore for now, as long as it doesn't affect the download/install
                    }
                }

            }
        });
    }

    private void updateProvision(String configJson) {
        mUpdatingProvision = true;
        mConfigProcManager.updateProvision(configJson);
    }

    private void updateFirmware(String path, DeviceResponseHandler handler) {
        Timber.d("updateFirmware path = %s", path);
        mDeviceManager.updateFirmware(path, 1, handler);
    }

    @Override
    public void updateTerminal(@NonNull TerminalUpdateType terminalUpdateType,
            @Nullable Map<String, String> credentials, @Nullable String version,
            @NonNull UpdateListener updateListener) {
        Timber.d("updateTerminal() called with terminalUpdateType=%s, credentials=%s, version=%s",
                terminalUpdateType, credentials, version);
        mTerminalVersionUpdateListener = updateListener;

        if (terminalUpdateType == TerminalUpdateType.KERNEL) {
            if (version.equals(mCachedConfigVersion)) {
                updateProvision(mCachedConfig);
            } else {
                mTerminalVersionUpdateListener.onTerminalUpdateError(TerminalError.INVALID_REQUEST, "Version does not match expected.");
            }
        } else if (terminalUpdateType == TerminalUpdateType.FIRMWARE) {
            if (mIsUpdateAvailable) {
                downloadFirmware();
            } else {
                mTerminalVersionUpdateListener.onTerminalUpdateError(TerminalError.UPDATE_NOT_REQUIRED,
                        "No update available");
            }
        }
    }

    @Override
    public void sendRequest(TerminalRequest terminalRequest) {
        Timber.d("sendRequest() called with: terminalRequest=[%s]", terminalRequest);
        mTerminalAction = terminalRequest.getTerminalAction();
        mTransactionType = terminalRequest.getTransactionType();
        mTerminalRequest = terminalRequest;
        if (mTerminalAction == TerminalAction.SETUP) {
            Timber.d("Terminal Action is SETUP. Performing terminal configuration...");
            mTerminalTransactionConfiguration = terminalRequest.getTerminalConfiguration();
            configureTerminal(mTerminalTransactionConfiguration);
        } else if (mTerminalAction == TerminalAction.INFO) {
            getDeviceInfo();
        } else if (mTerminalAction == TerminalAction.TENDER_GOODS ||
                mTerminalAction == TerminalAction.TENDER_SERVICES
                || mTerminalAction == TerminalAction.TENDER_REFUND) {
            proceedWithStartTenderTransaction();
        } else if (mTerminalAction == TerminalAction.START_CARD) {
            proceedWithStartCard();
        } else {
            Timber.e("Unsupported terminal action in: terminalRequest=[%s]", terminalRequest);
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    String.format("Unsupported terminal action=[%s]", mTerminalAction));
        }
    }

    private void configureTerminal(TerminalConfiguration terminalTransactionConfiguration) {
        Timber.d("configureTerminal() called with: transactionConfiguration=[%s]",
                terminalTransactionConfiguration);
        Objects.requireNonNull(mConfigProcManager);
        mConfigProcManager
                .configureTerminal(terminalTransactionConfiguration, mTransactionConfiguration);
    }

    private void getDeviceInfo() {
        if (!mConnected) {
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                    "The device info cannot be retrieved. The terminal is not connected.");
        } else if (mDeviceProcessing) {
            if (mTerminalConfiguration.getTerminalType() != TerminalType.INGENICO_MOBY_5500) {
                callbackOnTerminalInteractionError(TerminalError.GENERAL_ERROR,
                        "The device is busy. The device info cannot be retrieved.");
            } else {
                if (mTerminalInfo != null && TextUtils.isEmpty(mTerminalInfo.getAppVersion())) {
                    mTerminalInfo.setAppVersion(mMobyConfiguration.getProvisionVersion());
                }
                callbackOnTerminalInfo(mTerminalInfo);
            }
        } else {
            mDeviceInfoManager = new IngenicoDeviceInfoManager(mDeviceManager, false);
            mDeviceInfoManager.getDeviceInfo(new DeviceInfoCallbacksImpl());
        }
    }

    /**
     * Start the reader to get the HPS gift card data
     */
    private void proceedWithStartCard() {
        Timber.d("proceedWithStartCard");
        if (isDeviceEmvCapable()) {
            Objects.requireNonNull(mConfigProcManager);
            mConfigProcManager.configureTransaction();
            sendFinalConfirmationResult(true);
        }
    }

    private void proceedWithStartTenderTransaction() {
        Timber.d("proceedWithStartTenderTransaction() called.");
        if (isDeviceEmvCapable()) {
            Objects.requireNonNull(mConfigProcManager);
            mConfigProcManager.configureTransaction();
            TerminalInteractionRequest request =
                    new TerminalInteractionRequest(
                            TerminalInteractionType.FINAL_AMOUNT_CONFIRMATION);
            request.setFinalAmount(mTerminalRequest.getTotalAmount());
            callbackOnTerminalInteractionRequest(request);
        } else {
            // No need to confirm the final amount for G4X and similar devices
            sendFinalConfirmationResult(true);
        }
    }

    /**
     * {@link DeviceManager#initialize(Context, DeviceStatusHandler)} attempts to connect to the device.
     */
    private void initializeDeviceManager() {
        Timber.d("initializeDeviceManager() called.");
        mDeviceProcessing = true;
        final String initializationFailureMessage = "The terminal could not be initialized.";

        if (mContext == null) {
            Timber.d("initializeDeviceManager :: Context reference is null");
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                    initializationFailureMessage);
            callbackOnTerminalDisconnected();
            return;
        }
        if (mDeviceManager == null) {
            Timber.d("initializeDeviceManager :: DeviceManager reference is null");
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                    initializationFailureMessage);
            callbackOnTerminalDisconnected();
            return;
        }
        Timber.d("initializeDeviceManager:: Attempting to initialize ROAM " +
                mDeviceManager);
        if (mTerminalConfiguration.getTerminalType() == TerminalType.INGENICO_MOBY_5500 &&
                mTerminalConfiguration.getConnectionType() == ConnectionType.BLUETOOTH) {
            final LedPairingCallback ledPairingCallback = new LedPairingCallback() {
                @Override
                public void confirmLedSequence(List<LedSequence> list,
                        LedPairingConfirmationCallback ledPairingConfirmationCallback) {
                    // ledPairingConfirmationCallback.confirm();
                    if (mTerminalConfiguration.getPairingListener() != null) {
                        mTerminalConfiguration.getPairingListener()
                                .onLedPairSequence(list, ledPairingConfirmationCallback);
                    }
                }

                @Override
                public void notSupported() {
                    if (mTerminalConfiguration.getPairingListener() != null) {
                        mTerminalConfiguration.getPairingListener().onNotSupported();
                    }
                    Timber.d("initializeDeviceManager :: LedPairingCallback -> notSupported");
                }

                @Override
                public void success() {
                    if (mTerminalConfiguration.getPairingListener() != null) {
                        mTerminalConfiguration.getPairingListener().onSuccess();
                    }
                    Timber.d("initializeDeviceManager :: LedPairingCallback -> success");
                }

                @Override
                public void fail() {
                    if (mTerminalConfiguration.getPairingListener() != null) {
                        mTerminalConfiguration.getPairingListener().onFail();
                    }
                    Timber.d("initializeDeviceManager :: LedPairingCallback -> fail");
                }

                @Override
                public void canceled() {
                    if (mTerminalConfiguration.getPairingListener() != null) {
                        mTerminalConfiguration.getPairingListener().onCanceled();
                    }
                    Timber.d("initializeDeviceManager :: LedPairingCallback -> canceled");
                }
            };
            Timber.d("initializeDeviceManager :: DeviceManager initialized Bluetooth? " +
                    mDeviceManager
                            .initialize(mContext, true, mDeviceStatusHandler, ledPairingCallback));
        } else if (mTerminalConfiguration.getTerminalType() == TerminalType.INGENICO_MOBY_5500 &&
                mTerminalConfiguration.getConnectionType() == ConnectionType.USB) {
            Timber.d("initializeDeviceManager :: DeviceManager initialized USB? " +
                    mDeviceManager.initialize(mContext, true, mDeviceStatusHandler));
        } else {
            Timber.d("initializeDeviceManager :: DeviceManager initialized? " +
                    mDeviceManager.initialize(mContext, mDeviceStatusHandler));
        }
    }

    @Override
    public void sendTerminalInteractionResult(TerminalInteractionResult terminalInteractionResult) {
        Timber.d(
                "sendTerminalInteractionResult() called with: terminalInteractionResult=[%s]",
                terminalInteractionResult);
        if (terminalInteractionResult.getInteractionType() != null) {
            switch (terminalInteractionResult.getInteractionType()) {
                case HOST_PROCESSING:
                    sendOnlineProcessingResult(terminalInteractionResult);
                    break;
                case EMV_APPLICATION_SELECTION:
                    sendApplicationSelectionResult(
                            terminalInteractionResult.getSelectedApplicationIndex());
                    break;
                case FINAL_AMOUNT_CONFIRMATION:
                    sendFinalConfirmationResult(
                            terminalInteractionResult.getFinalAmountConfirmed());
                    break;
                case REQUEST_PROCEED_HOST_PROCESSING:
                    sendRequestHostProcessing();
                    break;
            }
        } else {
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "Invalid interaction " +
                            "type requested.");
        }
    }

    private void sendRequestHostProcessing() {
        Timber.d("sendRequestHostProcessing() called");
        requestHostProcessing(mHostRequestCardData);
        if (mSendStopCommandAfterOnlineProcessingRequested) {
            // No more terminal interaction needed once the transaction is sent online
            executeCommand(Command.EMVTransactionStop, this);
        }
    }

    @Override
    public void cancel() {
        Timber.d("cancel() called");
        if (mDeviceManager == null) {
            /* Send the cancel notification immediately. No device manager exists so there are
               no current actions to cancel. */

            dispatchCancelTransactionResponse();
            resetFields();
        } else if (!mConnected) {
            /* Verify that the device type is one that is bluetooth capable and cancel any
               in progress device searches. No attempt should be made to connect if cancel
                is called this early on. */
            if (mDeviceType == DeviceType.MOBY8500 || mDeviceType == DeviceType.MOBY5500 ||
                    mDeviceType == DeviceType.MOBY3000 || mDeviceType == DeviceType.RP45BT) {
                mDeviceManager.cancelSearch();
            }
            dispatchCancelTransactionResponse();
            resetFields();
        } else {
            // Device is connected and in some state of fulfilling a card request.
            if (mDeviceProcessing) {
                /* Cancel the last command. EmvTransactionStop will be issued following the
                   response to the cancellation attempt. Cancel last command, if successful, will
                   return a response indicating the command that was cancelled with error code
                   CommandCancelledUponReceiptOfACancelWaitCommand
                   Ex. LandiCommandHandler::onError::Command::EMVStartTransaction::errorCode::
                   CommandCancelledUponReceiptOfACancelWaitCommand::message::Error Message: 8E0B
                   Once this response is received, the cancel response is sent in
                   dispatchCancelTransactionResponse()
                   */
                mAwaitingCancelCommandResponse.set(true);
                mDeviceManager.getTransactionManager().cancelLastCommand();
            } else {
                // Terminal is idle and waiting for the next command.
                dispatchCancelTransactionResponse();
                executeCommand(Command.EMVTransactionStop, this);
                resetFields();
            }
        }
    }

    private void dispatchCancelTransactionResponse() {
        TerminalResponse response = new TerminalResponse(
                mTerminalRequest == null ? TerminalAction.SETUP :
                        mTerminalRequest.getTerminalAction());
        response.setTerminalDecisionType(TerminalDecisionType.TRANSACTION_CANCELLED);
        callbackOnTerminalResponse(response);
    }

    private void sendApplicationSelectionResult(int index) {
        Timber.d("sendApplicationSelectionResult() called with: index=[%d].", index);
        if (mAvailableAids == null || mAvailableAids.isEmpty() || index < 0 ||
                index >= mAvailableAids.size()) {
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "Invalid Application Selection");
            disconnect();
            return;
        }

        mSelectedAid = mAvailableAids.get(index);
        mDeviceManager.getTransactionManager()
                .sendCommand(IngenicoRpCollectionsUtil
                                .getFinalApplicationSelectionInputMap(mSelectedAid),
                        mDeviceResponseHandler);
    }

    private void sendFinalConfirmationResult(boolean confirmed) {
        Timber.d("sendFinalConfirmationResult invoked; amount = " +
                mTerminalRequest.getTotalAmount() + "; confirmed = " + confirmed);

        if (!mConnected) {
            /* Confirming the amount leads to the EmvStartTransaction command being sent. If the
               terminal disconnected, an error should be sent indicating that the transaction cannot
               proceed because the device is disconnected. Previously, the command would be sent
               to a disconnected device, causing errors. */
            Timber.w("Terminal disconnected before the transaction could be initiated.");
            callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                    "The terminal is not connected.");
        } else if ((confirmed
                && mTerminalRequest.getTotalAmount() != null
                && (mTerminalRequest.getTotalAmount() > 0
                || mTerminalRequest.getTransactionType() == TransactionType.TOKENIZE))
                || (confirmed && mTerminalRequest.getTransactionType() == TransactionType.SVA)) {

            if (!isDeviceEmvCapable()) {
                if (mDeviceManager instanceof G4XDeviceManager) {
                    ((G4XDeviceManager)mDeviceManager)
                            .waitForMagneticCardSwipe(mDeviceResponseHandler);
                } else {
                    Timber.e("Unrecognized device manager: %s. Cannot proceed with non-EMV reader.",
                            mDeviceManager);
                    callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                            "Unsupported card reader.");
                }
            } else {
                Objects.requireNonNull(mConfigProcManager);
                Map<Parameter, Object> startTransactionMap = null;
                if (mDeviceType == DeviceType.MOBY5500) {

                    String configJson = mMobyConfiguration.getEmvTransConfigsJSON();
                    if(TextUtils.isEmpty(configJson)){
                        callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                                "Invalid or empty configuration file.");
                    } else {
                        startTransactionMap = IngenicoMobyCollectionsUtil
                                .getStartTransactionInputMap(mTerminalRequest, mTransactionConfiguration,
                                        configJson,
                                        mConfigProcManager.getCurrentDeviceSerialNumber(), mDeviceType);
                    }
                } else {
                    mDeviceManager.getConfigurationManager()
                            .setExpectedAmountDOL(mRpConfiguration.getAmountDolList());
                    mDeviceManager.getConfigurationManager()
                            .setExpectedContactlessOnlineDOL(
                                    mRpConfiguration.getContactlessOnlineDolList());
                    mDeviceManager.getConfigurationManager()
                            .setExpectedContactlessResponseDOL(
                                    mRpConfiguration.getContactlessResponseDolList());
                    startTransactionMap = IngenicoRpCollectionsUtil
                            .getStartTransactionInputMap(mTerminalRequest, mTransactionConfiguration,
                                    mConfigProcManager.getCurrentDeviceSerialNumber(), mDeviceType);
                }

                Timber.d(
                        "sendFinalConfirmationResult :: sending command to DeviceManager: " +
                                startTransactionMap);
                mDeviceProcessing = true;
                try {
                    mDeviceManager.getTransactionManager()
                            .sendCommand(startTransactionMap, mDeviceResponseHandler);
                } catch (Exception e){
                    callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                            "Configuration is not set");
                }
            }
        } else {
             /*EmvTransactionStop never needs to be explicitly sent here since the EmvStartTransaction
             command was not sent. If EmvTransactionStop is sent without an EmvStartTransaction
             command having been sent earlier, the DeviceResponseHandler's onResponse() callback
             is not fired. So the SDK never knows when the device finished processing the
             EmvTransactionStop command.  Logically, there's no need to send stop if start was
             never sent in the first place. The SDK will think that a command is being processed
             when in fact it's not since a response was never sent in the above scenario. */
            TerminalResponse terminalResponse =
                    new TerminalResponse(mTerminalRequest.getTerminalAction());
            terminalResponse.setTerminalDecisionType(TerminalDecisionType.TRANSACTION_CANCELLED);
            callbackOnTerminalResponse(terminalResponse);
            resetFields();
        }
    }

    private void sendOnlineProcessingResult(TerminalInteractionResult result) {
        Timber.d("sendOnlineProcessingResult() called with: result=[%s].", result);
        GatewayResponse response = result.getGatewayResponse();

        if (response.getCardDataSourceType() == CardDataSourceType.SCR ||
                response.getCardDataSourceType() == CardDataSourceType.CONTACTLESS_EMV) {
            handleHostResponse(response);
        } else {
            callbackOnTerminalInteractionError(TerminalError.INVALID_REQUEST,
                    "The terminal is unable to complete" +
                            " processing of the transaction.");
            Timber.w(
                    "Terminal processing not available for host responses to transactions performed with Card Data Sourced from: [%s]",
                    response.getCardDataSourceType());
        }
    }

    private void handleHostResponse(GatewayResponse hostResponse) {
        Timber.d("handleHostResponse() called with: hostResponse=[%s]", hostResponse);
        mReversalRequired = hostResponse.isApproved() || hostResponse.isGatewayTimeout();

        if (mDeviceType == DeviceType.MOBY5500) {
            if (!TextUtils.isEmpty(hostResponse.getEmvIssuerAuthenticationData())) {
                TlvObjectBuilder builder;
                byte[] issuerAuthDataBytes = ByteUtils.hexStringToByteArray(
                        hostResponse.getEmvIssuerAuthenticationData());
                if (issuerAuthDataBytes != null) {
                    builder = TlvObjectBuilder.create(EmvTagDescriptor.ISSUER_AUTHENTICATION_DATA);
                    builder.setValue(issuerAuthDataBytes);
                    if (mCardData.getEmvTlvData() == null) {
                        mCardData.setEmvTlvData(new ArrayList<TlvObject>());
                    }
                    mCardData.getEmvTlvData().add(builder.build());
                }
            }
            TerminalResponse terminalResponse =
                    new TerminalResponse(mTerminalRequest.getTerminalAction());
            if (hostResponse.isGatewayTimeout()) {
                terminalResponse.setTerminalDecisionType(TerminalDecisionType.REVERSAL_REQUIRED);
            } else {
                terminalResponse.setTerminalDecisionType(hostResponse.isApproved() ?
                        TerminalDecisionType.APPROVED_ONLINE : TerminalDecisionType.DECLINED_ONLINE);
            }
            terminalResponse.setCardData(mCardData);
            callbackOnTerminalResponse(terminalResponse);
        } else {
            final String authCode = hostResponse.getAuthCode();
            List<TlvObject> tlvObjects;

            String authorizationResponseCode = null;
            if (!TextUtils.isEmpty(hostResponse.getEmvIssuerAuthCode())) {
                tlvObjects = ConstructedTlvObject.parse(hostResponse.getEmvIssuerAuthCode());
                if (tlvObjects != null && !tlvObjects.isEmpty()) {
                    authorizationResponseCode = tlvObjects.get(0).getValueAsHexString(false);
                }
            }
            String issuerAuthorizationData = null;
            if (!TextUtils.isEmpty(hostResponse.getEmvIssuerAuthenticationData())) {
                tlvObjects = ConstructedTlvObject.parse(hostResponse.getEmvIssuerAuthenticationData());
                if (tlvObjects != null && !tlvObjects.isEmpty()) {
                    issuerAuthorizationData = tlvObjects.get(0).getValueAsHexString(false);
                }
            }

            String issuerScriptTemplate1 = null;
            String issuerScriptTemplate2 = null;
            if (!TextUtils.isEmpty(hostResponse.getEmvIssuerScripts())) {
                tlvObjects = ConstructedTlvObject.parse(hostResponse.getEmvIssuerScripts());
                if (tlvObjects != null && !tlvObjects.isEmpty()) {
                    TlvObject issuerScript = tlvObjects.get(0);
                    String issuerScriptValue =
                            ByteUtils.bytesToHex(issuerScript.getInnerTlvsAsByteArray(), false);
                    if (issuerScript.getTagDescriptor() == EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_1) {
                        issuerScriptTemplate1 = issuerScriptValue;
                    } else {
                        issuerScriptTemplate2 = issuerScriptValue;
                    }
                }
            }

            EnumMap<Parameter, Object> input = new EnumMap<>(Parameter.class);
            if (!TextUtils.isEmpty(authCode)) {
                input.put(Parameter.AuthorizationCode, IngenicoHexHelper.asciiToHex(authCode));
            }
            input.put(Parameter.Command, Command.EMVCompleteTransaction);
            input.put(Parameter.ResultofOnlineProcess, "01");
            if (TextUtils.isEmpty(authorizationResponseCode)) {
                if (hostResponse.isApproved()) {
                    input.put(Parameter.AuthorizationResponseCode,
                            IngenicoEmvCode.AUTHORIZATION_RESPONSE_CODE_APPROVED.code);
                } else if ((hostResponse.isError() && hostResponse.isGatewayTimeout()) ||
                        !TextUtils.isEmpty(issuerAuthorizationData)) {
                    input.put(Parameter.AuthorizationResponseCode,
                            IngenicoEmvCode.AUTHORIZATION_RESPONSE_CODE_DECLINED.code);
                    if (mDeviceType == DeviceType.RP350x) {
                        input.put(Parameter.AuthorizationCode,
                                IngenicoEmvCode.AUTHORIZATION_RESPONSE_CODE_HOST_PROCESSING_ERROR_RP350.code);
                    }
                } else {
                    input.put(Parameter.ResultofOnlineProcess, "02");
                    input.put(Parameter.AuthorizationResponseCode,
                            IngenicoEmvCode.AUTHORIZATION_RESPONSE_CODE_UNABLE_TO_GO_ONLINE.code);
                }
            } else {
                input.put(Parameter.AuthorizationResponseCode, authorizationResponseCode);
            }

            if (!TextUtils.isEmpty(issuerAuthorizationData)) {
                input.put(Parameter.IssuerAuthenticationData, issuerAuthorizationData);
            }
            if (!TextUtils.isEmpty(issuerScriptTemplate1)) {
                input.put(Parameter.IssuerScript1, issuerScriptTemplate1);
            }
            if (!TextUtils.isEmpty(issuerScriptTemplate2)) {
                input.put(Parameter.IssuerScript2, issuerScriptTemplate2);
            }
            Objects.requireNonNull(mConfigProcManager);
            if (mTransactionConfiguration.isContactlessEnabled() &&
                    mConfigProcManager.isContactlessSupported()) {
                input.put(Parameter.AuthorizationResponseCodeList,
                        IngenicoEmvCode.AUTHORIZATION_RESPONSE_CODE_LIST_CONTACTLESS.code); // DF16
            }
            mDeviceProcessing = true;
            mDeviceManager.getTransactionManager().sendCommand(input, mDeviceResponseHandler);
        }
    }

    private void executeCommand(@NonNull Command cmd, DeviceResponseHandler handler) {
        Timber.d("executeCommand :: Command = " + cmd);
        switch (cmd) {
            case GenerateBeep:
                mDeviceProcessing = true;
                mDeviceManager.getConfigurationManager()
                        .generateBeep(handler);
                break;
            case EMVTransactionData:
                if (mTerminalTransactionConfiguration == null) {
                    callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                            "Terminal configuration missing. This request cannot be completed.");
                } else {
                    mDeviceProcessing = true;
                    if (mDeviceType != DeviceType.MOBY5500) {
                        mDeviceManager.getTransactionManager().sendCommand(
                                IngenicoRpCollectionsUtil
                                        .getTransactionDataInputMap(mSelectedAid, mCurrentAid,
                                                mTerminalTransactionConfiguration),
                                handler);
                    }
                }
                break;
            case EMVFinalApplicationSelection:
                if (mAvailableAids != null && !mAvailableAids.isEmpty()) {
                    mDeviceProcessing = true;
                    if (mDeviceType != DeviceType.MOBY5500) {
                        mDeviceManager
                                .getTransactionManager()
                                .sendCommand(
                                        IngenicoRpCollectionsUtil
                                                .getFinalApplicationSelectionInputMap(
                                                        mAvailableAids.get(0)),
                                        handler);
                    } else {
                        mDeviceManager
                                .getTransactionManager().sendCommand(
                                        IngenicoMobyCollectionsUtil
                                                .getFinalApplicationSelectionInputMap(
                                                        mAvailableAids.get(0)), handler);
                    }
                }
                break;
            case EMVTransactionStop:
                mDeviceProcessing = false;
                if (isDeviceEmvCapable()) {
                    if (mDeviceType != DeviceType.MOBY5500) {
                        mDeviceManager.getTransactionManager().sendCommand(
                                IngenicoRpCollectionsUtil.getTransactionStopInputMap(), handler);
                    } else {
                        mDeviceManager.getTransactionManager().sendCommand(
                                IngenicoMobyCollectionsUtil.getTransactionStopInputMap(), handler);
                    }
                }
                break;
            case WaitForMagneticCardSwipe:
                mDeviceProcessing = true;
                mDeviceManager.getTransactionManager()
                        .waitForMagneticCardSwipe(mDeviceResponseHandler);
                break;
            case StopWaitingForMagneticCardSwipe:
                mDeviceProcessing = true;
                mDeviceManager.getTransactionManager().stopWaitingForMagneticCardSwipe();
                break;
            case ReadVersion:
                mDeviceProcessing = true;
                mDeviceManager.getConfigurationManager().readVersion(mDeviceResponseHandler);
                break;
            default:
                break;
        }
    }

    @Override
    public void onResponse(Map<Parameter, Object> map) {
        Timber.d("onResponse() called with: map=[%s]", map);
        mDeviceProcessing = false;
        Command cmd = (Command)map.get(Parameter.Command);
        ResponseCode responseCode = (ResponseCode)map.get(Parameter.ResponseCode);
        ResponseType responseType = (ResponseType)map.get(Parameter.ResponseType);
        if (responseCode == ResponseCode.Error) {
            handleDeviceErrorResponse(map, cmd, responseType);
        } else {
            handleDeviceResponseUpdate(map);
            handleDeviceResponse(map, cmd, responseType);
        }
    }

    private void handleDeviceResponseUpdate(@NonNull Map<Parameter, Object> data) {
        if (data.get(Parameter.EncryptedTrack) == null) {
            if (data.get(Parameter.RoamEncryptedEMVdata) != null) {
                data.put(Parameter.EncryptedTrack, data.get(Parameter.RoamEncryptedEMVdata));
            }
        }

        if (data.get(Parameter.KSN) != null) {
            String ksn = String.valueOf(data.get(Parameter.KSN));
            if (ksn.length() > 20) {
                ksn = ksn.substring(0, 20);
                data.put(Parameter.KSN, ksn);
            }
        }
    }

    private void handleDeviceResponse(@NonNull Map<Parameter, Object> data, @NonNull Command cmd,
            @NonNull ResponseType responseType) {
        Timber.d("handleDeviceResponse() called with: data=[%s], cmd=[%s], responseType=[%s]",
                data, cmd, responseType);
        switch (cmd) {
            case EnergySaverModeTime:
                if (mTerminalConfiguration != null &&
                        mTerminalConfiguration.getShutdownDelay() != null) {
                    mDeviceProcessing = true;
                    mDeviceManager.getConfigurationManager()
                            .setShutDownModeTime(mTerminalConfiguration.getShutdownDelay(),
                                    mDeviceResponseHandler);
                } else {
                    callbackOnTerminalConnected();
                }
                break;
            case ShutDownModeTime:
                callbackOnTerminalConnected();
                break;
            case DisplayControl:
                // Needed since the Display Control commands shouldn't in any way impact transaction
                // state. Previously it would default to handleEmvTransactionResponse() when
                // this command responded. It is always called when using the 8500 so it's
                // important to handle it separately so transaction state is not affected.
                break;
            case RawCommand:
            case ResetDevice:
                if (mTerminalConfiguration != null && mTerminalInfo != null) {
                    mTerminalInfo.setTerminalType(mTerminalInfo.getTerminalType());
                }
                callbackOnTerminalConnected();
                break;
            default:
                if (mDeviceType == DeviceType.MOBY5500 && cmd == Command.EMVTransactionStop) {
                    return;
                } else {
                    handleEmvTransactionResponse(data, cmd, responseType);
                }
                break;
        }
    }

    private void handleDeviceErrorResponse(@NonNull Map<Parameter, Object> data,
            @NonNull Command cmd,
            ResponseType responseType) {
        Timber.d("handleDeviceErrorResponse() called with: data=[%s], cmd=[%s], responseType=[%s]",
                data, cmd, responseType);
        ErrorCode errorCode = (ErrorCode)data.get(Parameter.ErrorCode);
        String errorMessage = (String)data.get(Parameter.ErrorDetails);
        if (errorCode != null && TextUtils.isEmpty(errorMessage)) {
            errorMessage = errorCode.getValue();
        } else {
            errorMessage = "Device Error";
        }

        if (errorCode != null && errorCode == ErrorCode.BatteryTooLowError) {
            callbackOnTerminalInteractionError(TerminalError.BATTERY_TOO_LOW, "Low battery.");
        } else {
            switch (cmd) {
                case ReadCapabilities:
                    callbackOnTerminalInteractionError(TerminalError.INITIALIZATION_ERROR,
                            "Unable to determine card reader capabilities.");
                    break;
                case BatteryInfo:
                    mDeviceProcessing = true;
                    mDeviceManager.getConfigurationManager().readVersion(mDeviceResponseHandler);
                    break;
                case WaitForMagneticCardSwipe:
                    if (errorCode == ErrorCode.G4X_DECODE_SWIPE_FAIL) {
                        callbackOnTerminalStatusUpdated(TerminalStatus.BAD_READ_DETECTED);
                        ((G4XDeviceManager)mDeviceManager)
                                .waitForMagneticCardSwipe(mDeviceResponseHandler);
                        return;
                    }
                    break;
                case EMVStartTransaction:
                    if (errorCode != null) {
                        switch (errorCode) {
                            case ApplicationBlocked:
                            case CardInterfaceGeneralError:
                            case NoMutuallySupportedAIDs:
                            case TimeoutExpired:
                            case NonEMVCardOrCardError:
                            case CardBlocked:
                                callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                                        errorCode.name());
                                break;
                            case CommandCancelledUponReceiptOfACancelWaitCommand:
                                dispatchCancelTransactionResponse();
                                break;
                            default:
                                callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                                        "An error occurred while attempting to process the card.");
                                break;
                        }
                    } else {
                        callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                                "Unknown transaction error.");
                    }
                    executeCommand(Command.EMVTransactionStop, this);
                    break;
                case EMVTransactionData:
                    if (errorCode != null) {
                        switch (errorCode) {
                            case RSAKeyNotFound:
                            case CardExpired:
                                handleEmvTransactionResponse(data, cmd, responseType);
                                break;
                            case CommandCancelledUponReceiptOfACancelWaitCommand:
                                dispatchCancelTransactionResponse();
                                break;
                            default:
                                callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                                        "");
                                executeCommand(Command.EMVTransactionStop, this);
                                break;
                        }
                    }
                    break;
                case EMVCompleteTransaction:
                    mReversalRequired = true;
                    if (errorCode != null) {
                        switch (errorCode) {
                            case ApplicationBlocked:
                            case CardBlocked:
                            case NonEMVCardOrCardError:
                            case UnknownError:
                                mReversalRequired = false;
                                callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                                        "The terminal could not" +
                                                " complete the transaction due to an error[" +
                                                errorCode.name() + "].");
                                break;
                        }
                    }
                    if (mReversalRequired) {
                        TerminalResponse terminalResponse =
                                new TerminalResponse(mTerminalRequest.getTerminalAction());
                        terminalResponse
                                .setTerminalDecisionType(TerminalDecisionType.REVERSAL_REQUIRED);
                        terminalResponse.setCardData(new CardData());
                        terminalResponse.getCardData().setEmvTlvData(mCardData.getEmvTlvData());
                        callbackOnTerminalResponse(terminalResponse);
                    }
                    break;
                case EMVFinalApplicationSelection:
                    Timber.d(
                            "ErrorCode: " + errorCode + " errorMessage: " + errorMessage);
                    callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                            "An error occurred while attempting to use the selected payment application.");
                    executeCommand(Command.EMVTransactionStop, this);
                    break;
                default:
                    callbackOnTerminalInteractionError(TerminalError.GENERAL_ERROR,
                            errorMessage == null ?
                                    "The terminal is unable to perform the requested action." :
                                    errorMessage);
                    break;
            }
        }
    }

    public void setCardData(@NonNull CardData cardData) {
        mCardData = cardData;
    }

    private void handleEmvTransactionResponse(@NonNull Map<Parameter, Object> data,
            @NonNull Command cmd,
            @NonNull ResponseType responseType) {
        Timber.d(
                "handleEmvTransactionResponse :: Command = " + cmd + "; Data = " + data);
        mCardData = new CardData();
        mCardData.setEncryptionType(EncryptionType.TDES);

        mDataSource = IngenicoConversionHelper.getCardDataSource((String)data.get(Parameter.POSEntryMode));
        if (mDataSource == null) {
            // Handle EMV Transaction Response is called multiple times. The correct DataSource
            // is determined before the final time this is called. As a result, it should only
            // default to SCR if it's already null. Otherwise, use the known value.
            //Check the ResponseType to make sure it is passing the correct source type
            if (data.get(Parameter.CardType) == com.roam.roamreaderunifiedapi.constants.CardType.ContactlessEMV) {
                mCardData.setCardDataSource(CardDataSourceType.CONTACTLESS_EMV);
            } else {
                mCardData.setCardDataSource(CardDataSourceType.SCR);
            }
        } else {
            mCardData.setCardDataSource(mDataSource);
        }
        if (data.get(Parameter.Command) == Command.WaitForMagneticCardSwipe
                || responseType == ResponseType.MAGNETIC_CARD_DATA) {
            mCardData.setCardDataSource(CardDataSourceType.MSR);

            //if the device is moby no need to parse the card data here.
            // this already handled in the MSR Response.
            if (mDeviceType == DeviceType.MOBY5500) {
                if (CreditCardHelper.typeFromPan(String.valueOf(data.get(Parameter.PAN)))
                        == CardType.HPS_GIFT) {
                    handleMsrGiftCard(data, mCardData);
                } else {
                    handleMsrResponse(data, mCardData);
                }
                return;
            }
        }
        if (data.get(Parameter.EncryptedTrack) != null) {
            mCardData.setEncryptedData(String.valueOf(data.get(Parameter.EncryptedTrack)));
        }
        if (data.get(Parameter.PackedEncryptedTrack) != null) {
            mCardData.setPackedEncryptedData(
                    String.valueOf(data.get(Parameter.PackedEncryptedTrack)));
        }

        if (data.get(Parameter.CardHolderName) != null &&
                data.get(Parameter.CardHolderName) instanceof String) {
            mCardData.setCardholderName((String)data.get(Parameter.CardHolderName));
        }
        // TLV data does not need to be examined for MSR transactions.
        if (mCardData.getCardDataSource() == CardDataSourceType.CONTACTLESS_EMV
                || mCardData.getCardDataSource() == CardDataSourceType.SCR
                || mCardData.getCardDataSource() == CardDataSourceType.CONTACTLESS_MSR) {
            mCardData.setEmvTlvData(getTlvObjectList(data, mCardData.getCardDataSource()));
        }
        mCardData.setKsn((String)data.get(Parameter.KSN));
        String value = String.valueOf(data.get(Parameter.CardholderVerificationMethodResult));
        if (!TextUtils.isEmpty(value) && value.length() == 6) {
            mCardData.setCvmResult(IngenicoConversionHelper
                    .getCvmResultFromIngenico(IngenicoCvm.cvmFromString(value.substring(0, 2))));
        } else {
            mCardData.setCvmResult(CvmResult.NOT_AVAILABLE);
        }

        if (data.containsKey(Parameter.RedactedCardNumber) &&
                data.get(Parameter.RedactedCardNumber) != null) {
            mCardData.setPan((String)data.get(Parameter.RedactedCardNumber));
        } else if (data.containsKey(Parameter.PAN) &&
                data.get(Parameter.PAN) != null &&
                !TextUtils.isEmpty((String)data.get(Parameter.PAN))) {
            mCardData.setPan(((String)data.get(Parameter.PAN)).replace("[^\\d]", ""));
        }

        // TLV data does not need to be examined for MSR transactions.
        if (mCardData.getCardDataSource() != CardDataSourceType.FALLBACK
                && mCardData.getCardDataSource() != CardDataSourceType.MSR) {
            if (!TextUtils.isEmpty(mCardData.getKsn())) {
                TlvObjectBuilder builder =
                        TlvObjectBuilder.create(EmvTagDescriptor.INGENICO_KSN);
                byte[] ksnBytes = ByteUtils.hexStringToByteArray(mCardData.getKsn());
                if (ksnBytes != null) {
                    builder.setValue(ksnBytes);
                }
                mCardData.getEmvTlvData().add(builder.build());
            }

            if (mDeviceType != DeviceType.MOBY5500) {
                if (!TextUtils.isEmpty(mCardData.getEncryptedData())) {
                    TlvObjectBuilder builder =
                            TlvObjectBuilder.create(EmvTagDescriptor.INGENICO_ENCRYPTED_TRACK);

                    byte[] encryptedTrackBytes =
                            ByteUtils.hexStringToByteArray(mCardData.getEncryptedData());
                    if (encryptedTrackBytes != null) {
                        builder.setValue(encryptedTrackBytes);
                    }
                    mCardData.getEmvTlvData().add(builder.build());
                }
            }
        }

        switch (cmd) {
            case WaitForMagneticCardSwipe:
                handleMsrResponse(data, mCardData);
                break;
            case EMVStartTransaction:
                handleEmvStartTransactionResponse(data, responseType, mCardData);
                break;
            case EMVFinalApplicationSelection:
                if (mDeviceType != DeviceType.MOBY5500) {
                    executeCommand(Command.EMVTransactionData, this);
                } else {
                    executeCommand(Command.EMVTransactionStop, this);
                    handleQuickChipResponse(data, mCardData);
                }
                break;
            case EMVTransactionData:
                if (mTerminalAction != null && mTerminalAction == TerminalAction.TENDER_REFUND) {
                    requestHostProcessing(mCardData);
                } else {
                    handleEmvTransactionDataResponse(data, mCardData);
                }
                break;
            case EMVCompleteTransaction:
                handleEmvCompleteTransactionResponse(data, responseType, mCardData);
                break;
            case EMVTransactionStop:
                if (mDataSource == CardDataSourceType.SCR) {
                    callbackOnTerminalStatusUpdated(TerminalStatus.REMOVE_CARD);
                }

                // The Transaction Stop command may indicate the end of the transaction processing
                // state, including EMV and standard card swipes. A callback to the UI is not necessary
                // (previously, this would fire the onDeviceHere callback, which would trigger the UI
                // to start preparing for another EMV transaction), because the UI should already know
                // whether the device is here or ready, at this point.
                if (mTerminalConfiguration != null &&
                        mTerminalConfiguration.getTerminalType() ==
                                TerminalType.INGENICO_MOBY_8500) {
                    scheduleReturnToHomeScreen();
                }
                resetFields();
                break;
            default:
                break;
        }
    }

    private void handleEmvStartTransactionResponse(@NonNull Map<Parameter, Object> data,
            @NonNull ResponseType responseType,
            @NonNull CardData cardSwipeData) {
        Timber.d("handleEmvStartTransactionResponse() called with: data=[%s], responseType=[%s], cardSwipeData=[%s]",
                data, responseType, cardSwipeData);
        mCurrentAid =
                data.get(Parameter.ApplicationIdentifier) != null ?
                        (String)data.get(Parameter.ApplicationIdentifier) :
                        (String)data.get(Parameter.TerminalApplicationIdentifier);
        switch (responseType) {
            case CONTACTLESS_AMOUNT_DOL:
                mDataSource = CardDataSourceType.CONTACTLESS_EMV;
                executeCommand(Command.EMVTransactionData, this);
                break;
            case CONTACTLESS_ONLINE_DOL:
                mDataSource = CardDataSourceType.CONTACTLESS_EMV;
                cardSwipeData.setCardDataSource(CardDataSourceType.CONTACTLESS_EMV);
                if (mDeviceType != DeviceType.MOBY5500) {
                    handleContactlessOnlineDol(data, cardSwipeData);
                } else {
                    executeCommand(Command.EMVTransactionStop, this);
                    handleQuickChipResponse(data, cardSwipeData);
                }
                break;
            case CONTACTLESS_RESPONSE_DOL:
                if (mDeviceType == DeviceType.MOBY5500) {
                    mDataSource = CardDataSourceType.CONTACTLESS_EMV;
                    cardSwipeData.setCardDataSource(CardDataSourceType.CONTACTLESS_EMV);
                    executeCommand(Command.EMVTransactionStop, this);
                    handleQuickChipResponse(data, cardSwipeData);
                } else {
                    mDataSource = CardDataSourceType.MSR;
                    cardSwipeData.setCardDataSource(CardDataSourceType.MSR);
                    handleResponseDol(data, cardSwipeData);
                }
                break;
            case CONTACT_RESPONSE_DOL:
                mDataSource = CardDataSourceType.SCR;
                cardSwipeData.setCardDataSource(CardDataSourceType.SCR);
                handleResponseDol(data, cardSwipeData);
                break;
            case CONTACT_AMOUNT_DOL:
                mDataSource = CardDataSourceType.SCR;
                executeCommand(Command.EMVTransactionData, this);
                break;
            case MAGNETIC_CARD_DATA:
                mDataSource = CardDataSourceType.MSR;
                // send online auth request
                cardSwipeData.setCardDataSource(CardDataSourceType.MSR);
                handleMsrResponse(data, cardSwipeData);
                break;
            case LIST_OF_AIDS:
                mDataSource = CardDataSourceType.SCR;
                handleAidListResponse(data);
                break;
            case CONTACT_QUICK_CHIP_RESPONSE_DOL:
                if (mDeviceType == DeviceType.MOBY5500) {
                    mDataSource = CardDataSourceType.SCR;
                    cardSwipeData.setCardDataSource(CardDataSourceType.SCR);
                    executeCommand(Command.EMVTransactionStop, this);
                    handleQuickChipResponse(data, cardSwipeData);
                }
            case UNKNOWN:
                break;
            default:
                if (mDeviceType != DeviceType.MOBY5500) {
                    executeCommand(Command.EMVTransactionData, this);
                }
                break;
        }
    }

    private void handleQuickChipResponse(@NonNull Map<Parameter, Object> data,
            @NonNull CardData cardSwipeData) {
        Timber.d("handleQuickChipResponse() called with data=[%s]", new Object[] {data});

        IngenicoPosEntryMode entryMode =
                IngenicoPosEntryMode.fromCode((String)data.get(Parameter.POSEntryMode));
        CardDataSourceType cardDataSourceType = CardDataSourceType.SCR;
        switch (entryMode) {
            case MSR:
            case MSR_COMPLETE:
                cardDataSourceType = CardDataSourceType.MSR;
                break;
            case ICC:
                cardDataSourceType = CardDataSourceType.SCR;
                break;
            case CONTACTLESS_ICC:
                cardDataSourceType = CardDataSourceType.CONTACTLESS_EMV;
                break;
            case ICC_FALLBACK_TO_MSR:
                cardDataSourceType = CardDataSourceType.FALLBACK;
                break;
            default:
                if (data.get(Parameter.CardType) ==
                        com.roam.roamreaderunifiedapi.constants.CardType.ContactlessEMV) {
                    cardDataSourceType = CardDataSourceType.CONTACTLESS_EMV;
                } else if (data.get(Parameter.CardType) ==
                        com.roam.roamreaderunifiedapi.constants.CardType.MagneticStripe) {
                    cardDataSourceType = CardDataSourceType.MSR;
                }
                break;
        }

        if(mDeviceType == DeviceType.MOBY5500){
            if (AAC.equals(data.get(Parameter.CryptogramInformationData))
                    && mTransactionType != TransactionType.REFUND) {
                callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                        "Decline, Service is not allowed.");
                return;
            }
        } else {
            if (AAC.equals(data.get(Parameter.CryptogramInformationData))) {
                callbackOnTerminalInteractionError(TerminalError.TRANSACTION_ERROR,
                        "Decline, Service is not allowed.");
                return;
            }
        }


        cardSwipeData.setCardDataSource(cardDataSourceType);

        if (data.get(Parameter.CardHolderName) != null &&
                data.get(Parameter.CardHolderName) instanceof String) {
            cardSwipeData.setCardholderName((String)data.get(Parameter.CardHolderName));
        }

        if (cardSwipeData.getEmvTlvData() == null) {
            List<TlvObject> tlvObjects = new ArrayList<>();
            for (String tag : IngenicoMobyCollectionsUtil.getOnlineEmvTags(data, mReaderVersionInfo)) {
                tlvObjects.add(ConstructedTlvObject.parse(tag).get(0));
            }
            cardSwipeData.setEmvTlvData(tlvObjects);
        }

        if (cardSwipeData.getCardholderName() == null && cardSwipeData.getEmvTlvData() != null) {
            List<TlvObject> tlvObjects = cardSwipeData.getEmvTlvData();
            for (TlvObject tlv : tlvObjects) {
                if (tlv.getTag() == EmvTagDescriptor.CARDHOLDER_NAME.asBerTag()) {
                    if (!TextUtils.isEmpty(tlv.getValue().toString())) {
                        cardSwipeData.setCardholderName(IngenicoHexHelper
                                .hexToString(tlv.getValue().toString()));
                    }
                    break;
                }
            }
        }

        if (cardSwipeData.getEncryptedData() == null) {
            cardSwipeData.setEncryptedData((String)data.get(Parameter.EncryptedTrack));
        }

        if (!mUserConfirmationForHostProcessingEnabled) {
            requestHostProcessing(cardSwipeData);
        } else {
            mHostRequestCardData = cardSwipeData;
            requestHostProcessingConfirmation();
        }
    }

    private void handleMsrGiftCard(@NonNull Map<Parameter, Object> data,
            @NonNull CardData cardSwipeData) {
        Timber.d("handleMsrGiftCard() called with: data=[" + data + "]");
        try {
            cardSwipeData.setPan(String.valueOf(data.get(Parameter.PAN)));

            String expirationDate = (String)data.get(Parameter.CardExpDate);
            if (!TextUtils.isEmpty(expirationDate)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyMM", Locale.US);
                Date date = dateFormat.parse((String)data.get(Parameter.CardExpDate));
                StringBuilder dateBuilder = new StringBuilder();
                SimpleDateFormat month = new SimpleDateFormat("MM", Locale.US);
                dateBuilder.append(month.format(date));
                SimpleDateFormat year = new SimpleDateFormat("yy", Locale.US);
                dateBuilder.append(year.format(date));
                cardSwipeData.setExpirationDate(dateBuilder.toString());
            }

            TerminalResponse terminalResponse = new TerminalResponse(TerminalAction.START_CARD);
            terminalResponse.setTerminalDecisionType(TerminalDecisionType.APPROVED_OFFLINE);
            terminalResponse.setCardData(cardSwipeData);
            callbackOnTerminalResponse(terminalResponse);
        } catch (ParseException e) {
            Timber.e(e);
        }
    }

    private void handleMsrResponse(@NonNull Map<Parameter, Object> data,
            @NonNull CardData cardSwipeData) {
        Timber.d("handleMsrResponse() called with: data=[" + data + "]");
        try {
            String expirationDate = (String)data.get(Parameter.CardExpDate);
            if (!TextUtils.isEmpty(expirationDate)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyMM", Locale.US);
                Date date = dateFormat.parse((String)data.get(Parameter.CardExpDate));
                StringBuilder dateBuilder = new StringBuilder();
                SimpleDateFormat month = new SimpleDateFormat("MM", Locale.US);
                dateBuilder.append(month.format(date));
                SimpleDateFormat year = new SimpleDateFormat("yy", Locale.US);
                dateBuilder.append(year.format(date));
                cardSwipeData.setExpirationDate(dateBuilder.toString());
            }
        } catch (ParseException e) {
            Timber.e(e);
        }
        cardSwipeData.setCardholderName((String)data.get(Parameter.CardHolderName));
        cardSwipeData.setCvmResult(CvmResult.NOT_AVAILABLE);
        cardSwipeData.setPan((String)data.get(Parameter.RedactedCardNumber));

        if (data.get(Parameter.Track2Data) != null) {
            String track2 =
                    String.valueOf(StringUtil.hexStr2Str((String)data.get(Parameter.Track2Data)));
            if (!TextUtils.isEmpty(track2)) {
                String[] track2Data = track2.split("=");
                if (track2Data.length > 1 && track2Data[1].length() >= 5) {
                    // The set of data after the first separator contains the expiration date, service code,
                    // and discretionary data. The service code immediately follows the expiration date.
                    String serviceCode = track2Data[1].substring(4);
                    // A first digit of 2 in the service code indicates that the card contains an ICC.
                    if (serviceCode.startsWith("2") || serviceCode.startsWith("6")) {
                        mDataSource = CardDataSourceType.FALLBACK;
                        cardSwipeData.setCardDataSource(CardDataSourceType.FALLBACK);
                        Timber.d(
                                "handleMsrResponse(): mRequestDipCount=[" + mRequestDipCount + "]");

                        if (mRequestDipCount < MAX_DIP_RETRY_ATTEMPTS) {
                            cardSwipeData.setFallbackReason(FallbackReason.EMPTY_CANDIDATE_LIST);
                        } else {
                            cardSwipeData.setFallbackReason(FallbackReason.ICC_ERROR);
                        }
                    }
                }
            }
        }

        if (data.get(Parameter.KSN) != null) {
            cardSwipeData.setKsn(data.get(Parameter.KSN).toString());
        }
        // Note: RUA Parameter map returns both a Base-64 encoded value mapped to Parameter.EncryptedTrack and
        // Parameter.PackedEncryptedTrack. The proper value to use with the KSN is Parameter.PackedEncryptedTrack.
        if (data.get(Parameter.PackedEncryptedTrack) != null) {
            cardSwipeData
                    .setPackedEncryptedData(data.get(Parameter.PackedEncryptedTrack).toString());
        }

        if (data.get(Parameter.EncryptedTrack) != null) {
            cardSwipeData.setEncryptedData(data.get(Parameter.EncryptedTrack).toString());
        }

        //Moby 5500 has the encrypted track2 as the encrypted track.
        //This data is what we send to portico.
        if (mDeviceType != DeviceType.MOBY5500) {
            cardSwipeData.setTrack1((String)data.get(Parameter.EncryptedTrack));
            cardSwipeData.setTrack2((String)data.get(Parameter.Track2Data));
            cardSwipeData.setTrack3((String)data.get(Parameter.Track3Data));
        } else {
            cardSwipeData.setTrack2((String)data.get(Parameter.EncryptedTrack));
        }

        if (!mUserConfirmationForHostProcessingEnabled) {
            requestHostProcessing(cardSwipeData);
            executeCommand(Command.EMVTransactionStop, this);
        } else {
            mHostRequestCardData = cardSwipeData;
            mSendStopCommandAfterOnlineProcessingRequested = true;
            requestHostProcessingConfirmation();
        }
    }

    private void handleAidListResponse(@NonNull Map<Parameter, Object> data) {
        Timber.d("handleAidListResponse() called with: data=[%s]", data);
        Collection<?> list = (Collection<?>)data
                .get(Parameter.ListOfApplicationIdentifiers);
        if (list != null) {
            mAvailableAids = new ArrayList<>(list.size());
            for (Object aid : list) {
                if (aid instanceof ApplicationIdentifier) {
                    mAvailableAids.add((ApplicationIdentifier)aid);
                }
            }

            if (mAvailableAids.size() > 1) {
                Collections.sort(mAvailableAids, (a1, a2) ->
                        Integer.compare(Integer.parseInt(a1.getPriorityIndex()),
                                Integer.parseInt(a2.getPriorityIndex())));
            }

            String[] aids = new String[mAvailableAids.size()];
            int count = 0;
            for (ApplicationIdentifier aid : mAvailableAids) {
                aids[count++] = aid.getApplicationLabel();
            }

            TerminalInteractionRequest selectAidsRequest =
                    new TerminalInteractionRequest(
                            TerminalInteractionType.EMV_APPLICATION_SELECTION);
            selectAidsRequest.setApplicationNames(aids);
            callbackOnTerminalInteractionRequest(selectAidsRequest);
        }
    }

    private void handleResponseDol(@NonNull Map<Parameter, Object> data,
            @NonNull CardData cardSwipeData) {
        Timber.d("handleResponseDol() called with: data=[%s]", data);
        EMVTagHelper.CryptogramInformationData cid = EMVTagHelper
                .getCryptogramInformationDataEnum((String)data
                        .get(Parameter.CryptogramInformationData));
        String payPassOutcomeValue = (String)data.get(Parameter.PayPassTransactionOutcome);
        String terminalDecision =
                (String)data.get(Parameter.TerminalDecisionafterGenerateAC);
        /*
         * PayPassTransactionOutcome Possible Values,
         * 01 = Approved
         * 02 = Online Request
         * 03 = Declined
         * 04 = Try Another Interface
         * 05 = End Application
         */
        if (payPassOutcomeValue != null &&
                (payPassOutcomeValue.equals("03") || payPassOutcomeValue.equals("04"))) {
            //Restart transaction and ask to use other interface
            executeCommand(Command.EMVTransactionStop, this);
        } else {
            if (cid == null) {
                handleTerminalDecision(terminalDecision, cardSwipeData);
            } else {
                handleCryptogramInformationData(cid,
                        terminalDecision, cardSwipeData,
                        (ResponseType)data.get(Parameter.ResponseType));
            }
        }
    }

    private void handleTerminalDecision(@NonNull String terminalDecisionValue,
            CardData cardSwipeData) {
        Timber.d("handleTerminalDecision() called with: terminalDecisionValue=[%s]",
                terminalDecisionValue);
        switch (terminalDecisionValue) {
            case "01":
                // Skip CompleteTransaction

                returnSwiperResult(TerminalDecisionType.APPROVED_OFFLINE, cardSwipeData);
                /*
                This command does not need to be issued after receiving the response of a tap
                transaction because the card is no longer present. Issuing the command when the
                interface is no longer available can cause an extended delay in receiving a response,
                leaving to a device busy state.
                 */
                if (cardSwipeData.getCardDataSource() != CardDataSourceType.CONTACTLESS_EMV) {
                    executeCommand(Command.EMVTransactionStop, this);
                }
                break;
            case "00":
                // Skip CompleteTransaction
                returnSwiperResult(TerminalDecisionType.DECLINED_OFFLINE, cardSwipeData);
                /*
                This command does not need to be issued after receiving the response of a tap
                transaction because the card is no longer present. Issuing the command when the
                interface is no longer available can cause an extended delay in receiving a response,
                leaving to a device busy state.
                 */
                if (cardSwipeData.getCardDataSource() != CardDataSourceType.CONTACTLESS_EMV) {
                    executeCommand(Command.EMVTransactionStop, this);
                }
                break;
            default:
                break;
        }
    }

    private void handleCryptogramInformationData(
            @NonNull EMVTagHelper.CryptogramInformationData cid,
            @NonNull String terminalDecisionValue, CardData cardSwipeData,
            ResponseType responseType) {
        Timber.d(
                "handleCryptogramInformationData() called with: cid=[%s], terminalDecisionValue=[%s], responseType=[%s]",
                cid, terminalDecisionValue, responseType);
        switch (cid) {
            case ARQC:
                if (responseType == ResponseType.CONTACT_ONLINE_DOL ||
                        responseType == ResponseType.CONTACTLESS_ONLINE_DOL) {

                    executeCommand(Command.EMVCompleteTransaction, this);
                    if (!mUserConfirmationForHostProcessingEnabled) {
                        requestHostProcessing(cardSwipeData);
                    } else {
                        mHostRequestCardData = cardSwipeData;
                        requestHostProcessingConfirmation();
                    }
                } else {
                    // Skip CompleteTransaction

                    returnSwiperResult(TerminalDecisionType.DECLINED_OFFLINE, cardSwipeData);
                    executeCommand(Command.EMVTransactionStop, this);
                }
                break;
            case INVALID:
                handleTerminalDecision(terminalDecisionValue, cardSwipeData);
                break;
            case RFU:
                break;
            case AAC:
                // Skip CompleteTransaction
                if (mTransactionType == TransactionType.REFUND) {

                    returnSwiperResult(TerminalDecisionType.APPROVED_ONLINE, cardSwipeData);
                } else {

                    returnSwiperResult(TerminalDecisionType.DECLINED_OFFLINE, cardSwipeData);
                }
                executeCommand(Command.EMVTransactionStop, this);
                break;
            case TC:
                // Skip CompleteTransaction

                returnSwiperResult(TerminalDecisionType.APPROVED_OFFLINE, cardSwipeData);
                executeCommand(Command.EMVTransactionStop, this);
                break;
        }
    }

    private void returnSwiperResult(@NonNull TerminalDecisionType terminalDecisionType,
            @Nullable CardData cardSwipeData) {
        Timber.d("returnSwiperResult() called with: terminalDecisionType=[%s]",
                terminalDecisionType);
        mRequestDipCount = 1;
        TerminalResponse terminalResponse =
                new TerminalResponse(mTerminalRequest.getTerminalAction());
        terminalResponse.setTerminalDecisionType(terminalDecisionType);
        terminalResponse.setCardData(cardSwipeData);
        callbackOnTerminalResponse(terminalResponse);
    }

    private void handleContactlessOnlineDol(@NonNull Map<Parameter, Object> data,
            @NonNull CardData cardSwipeData) {
        Timber.d("handleContactlessOnlineDol() called with: data=[%s]", data);
        IngenicoPosEntryMode entryMode =
                IngenicoPosEntryMode.fromCode((String)data.get(Parameter.POSEntryMode));
        CardDataSourceType cardDataSourceType = CardDataSourceType.CONTACTLESS_EMV;
        switch (entryMode) {
            case MANUAL:
                break;
            case MSR:
            case MSR_COMPLETE:
                cardDataSourceType = CardDataSourceType.MSR;
                break;
            case ICC:
                cardDataSourceType = CardDataSourceType.SCR;
                break;
            case CONTACTLESS_ICC:
                cardDataSourceType = CardDataSourceType.CONTACTLESS_EMV;
                break;
            case ICC_FALLBACK_TO_MSR:
                cardDataSourceType = CardDataSourceType.FALLBACK;
                break;
            case E_COMMERCE:
                cardDataSourceType = CardDataSourceType.INTERNET;
                break;
            case CONTACTLESS_MSR:
                cardDataSourceType = CardDataSourceType.CONTACTLESS_MSR;
                break;
        }
        cardSwipeData.setCardDataSource(cardDataSourceType);
        cardSwipeData.setKsn(String.valueOf(data.get(Parameter.KSN)));

        if (data.get(Parameter.CardHolderName) != null &&
                data.get(Parameter.CardHolderName) instanceof String) {
            cardSwipeData.setCardholderName((String)data.get(Parameter.CardHolderName));
        }
        List<TlvObject> tlvObjects = new ArrayList<>();
        for (String tag : IngenicoRpCollectionsUtil
                .getOnlineEmvTags(data, mReaderVersionInfo, cardDataSourceType)) {
            tlvObjects.add(ConstructedTlvObject.parse(tag).get(0));
        }

        cardSwipeData.setEmvTlvData(tlvObjects);
        cardSwipeData.setEncryptedData(String.valueOf(data.get(Parameter.EncryptedTrack)));
        if (!mUserConfirmationForHostProcessingEnabled) {
            requestHostProcessing(cardSwipeData);
        } else {
            mHostRequestCardData = cardSwipeData;
            requestHostProcessingConfirmation();
        }
    }

    private void handleEmvTransactionDataResponse(@NonNull Map<Parameter, Object> data,
            @NonNull CardData cardSwipeData) {
        Timber.d("handleEmvTransactionDataResponse() called with: data=[%s]", data);
        // The encrypted track data contains the online DOL list
        // in the EMV Transaction data command response.
        // In order to read the online DOL list, the encrypted
        // data needs to be sent HSM for decryption which
        // returns the plain text data in TLV format.
        if (data.get(Parameter.ResponseType) != null && data.get(Parameter.ResponseType).equals(
                ResponseType.CONTACT_RESPONSE_DOL)) {
            EMVTagHelper.CryptogramInformationData cid = EMVTagHelper
                    .getCryptogramInformationDataEnum((String)data
                            .get(Parameter.CryptogramInformationData));
            String terminalDecision = (String)data.get(Parameter.TerminalDecisionafterGenerateAC);
            if (cid == null) {
                handleTerminalDecision(terminalDecision, cardSwipeData);
            } else {
                handleCryptogramInformationData(cid, terminalDecision, cardSwipeData,
                        (ResponseType)data.get(Parameter.ResponseType));
            }
        } else {
            if (!mUserConfirmationForHostProcessingEnabled) {
                requestHostProcessing(cardSwipeData);
            } else {
                mHostRequestCardData = cardSwipeData;
                requestHostProcessingConfirmation();
            }
        }
    }

    private void handleEmvCompleteTransactionResponse(@NonNull Map<Parameter, Object> data,
            @NonNull ResponseType responseType, CardData cardSwipeData) {
        Timber.d("handleEmvCompleteTransactionResponse() called with: data=[%s], responseType=[%s]",
                data, responseType);
        EMVTagHelper.CryptogramInformationData cid = EMVTagHelper.getCryptogramInformationDataEnum(
                (String)data.get(Parameter.CryptogramInformationData));
        String terminalDecision = (String)data.get(Parameter.TerminalDecisionafterGenerateAC);
        switch (responseType) {
            case CONTACT_RESPONSE_DOL:
                if (cid == null) {
                    handleTerminalDecisionEmvCompleteTransaction(terminalDecision, cardSwipeData);
                } else {
                    handleCidAfterCompleteTransaction(cid, cardSwipeData, terminalDecision);
                }
                break;
            case CONTACT_ONLINE_DOL:
            case CONTACTLESS_ONLINE_DOL:
            case CONTACTLESS_RESPONSE_DOL:
                handleTerminalDecisionEmvCompleteTransaction(terminalDecision, cardSwipeData);
                break;
            default:
                break;
        }
    }

    private void handleTerminalDecisionEmvCompleteTransaction(@NonNull String terminalDecisionValue,
            CardData cardSwipeData) {
        Timber.d("handleTerminalDecisionEmvCompleteTransaction() called with: terminalDecisionValue=[%s]",
                terminalDecisionValue);
        switch (terminalDecisionValue) {
            case "01":
                returnSwiperResult(TerminalDecisionType.APPROVED_ONLINE, cardSwipeData);
                /*
                This command does not need to be issued after receiving the response of a tap
                transaction because the card is no longer present. Issuing the command when the
                interface is no longer available can cause an extended delay in receiving a response,
                leaving to a device busy state.
                 */
                if (cardSwipeData.getCardDataSource() != CardDataSourceType.CONTACTLESS_EMV) {
                    executeCommand(Command.EMVTransactionStop, this);
                }
                break;
            case "00":
                // Skip CompleteTransaction

                returnSwiperResult(TerminalDecisionType.DECLINED_ONLINE, cardSwipeData);
                /*
                This command does not need to be issued after receiving the response of a tap
                transaction because the card is no longer present. Issuing the command when the
                interface is no longer available can cause an extended delay in receiving a response,
                leaving to a device busy state.
                 */
                if (cardSwipeData.getCardDataSource() != CardDataSourceType.CONTACTLESS_EMV) {
                    executeCommand(Command.EMVTransactionStop, this);
                }
                break;
            default:
                break;
        }
    }

    private void handleCidAfterCompleteTransaction(
            @NonNull EMVTagHelper.CryptogramInformationData cid, @Nullable
            CardData cardData, @NonNull String terminalDecisionValue) {
        Timber.d("handleCidAfterCompleteTransaction() called with: cid=[%s], terminalDecisionValue=[%s]",
                cid, terminalDecisionValue);
        // Skip CompleteTransaction
        switch (cid) {
            case ARQC:
                handleTerminalDecisionEmvCompleteTransaction(terminalDecisionValue, cardData);
                break;
            case INVALID:
                handleTerminalDecisionEmvCompleteTransaction(terminalDecisionValue, cardData);
                break;
            case RFU:
                break;
            case AAC:
                executeCommand(Command.EMVTransactionStop, this);
                // Added delay to assure remove and reversal messages are shown properly
                if (mReversalRequired) {
                    scheduleReturnResult(TerminalDecisionType.REVERSAL_REQUIRED, null);
                } else {
                    scheduleReturnResult(TerminalDecisionType.DECLINED_ONLINE, null);
                }
                break;
            case TC:
                // Skip CompleteTransaction
                scheduleReturnResult(TerminalDecisionType.APPROVED_ONLINE, cardData);
                executeCommand(Command.EMVTransactionStop, this);
                break;
        }
    }

    private void scheduleReturnResult(@NonNull final TerminalDecisionType terminalDecisionType,
            @Nullable final CardData cardData) {
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                returnSwiperResult(terminalDecisionType, cardData);
            }
        }, TRANSACTION_RESULT_DELAY_DURATION);
    }

    private void scheduleReturnToHomeScreen() {
        Timber.d("scheduleReturnToHomeScreen() called");
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {

                if (mDeviceManager != null) {
                    Timber.d("DeviceManager instance present...");
                    if (mDeviceManager.getConfigurationManager() != null) {
                        Timber.d("DeviceManager Config Manager instance present...");
                        if (mDeviceManager.getConfigurationManager().getDisplayControl() != null) {
                            Timber.d(
                                    "Device Manager Config Manager Display Controls are available. Returning to home " +
                                            "screen.");
                            mDeviceProcessing = true;
                            mDeviceManager.getConfigurationManager().getDisplayControl()
                                    .returnToHomeScreen(IngenicoController.this);
                        } else {
                            Timber.w("Display controls not available");
                        }
                    } else {
                        Timber.w("Config Manager is not initialized.");
                    }
                } else {
                    Timber.w("Device Manager not initialized.");
                }
            }
        }, TRANSACTION_RESULT_DISPLAY_DURATION);
    }

    /**
     * Reset the fields that should always be new upon fresh connection or transaction requests. This method should be
     * called when a response is received from the EmvTransactionStop command since that signals the end of the current
     * transaction session.
     */
    private void resetFields() {
        Timber.d("resetFields() called.");
        mRequestDipCount = 1;
        mAvailableAids = null;
        mSelectedAid = null;
        mCurrentAid = null;
        mTerminalAction = null;
        mTransactionType = null;
        mCardData = null;
        mDataSource = null;
        mReversalRequired = false;
        mDeviceProcessing = false;
        mAwaitingCancelCommandResponse.set(false);
        mHostRequestCardData = null;
        mSendStopCommandAfterOnlineProcessingRequested = false;
    }

    @Override
    public void onProgress(ProgressMessage progressMessage, String description) {
        Timber.d(
                "onProgress() called with: progressMessage=[" + progressMessage +
                        "], description=[" + description +
                        "]");
        if (progressMessage == ProgressMessage.PleaseRemoveCard) {
            mRequestDipCount++;
            Timber.d(
                    "onProgress() incremented Dip Count: dipCount=[" + mRequestDipCount + "]");
        }

        TerminalStatus status = IngenicoConversionHelper
                .getCorrespondingTerminalStatus(progressMessage, description);

        // If status is null, it's returned from a progress message that can be ignored.
        if (status != null) {
            /*if (status == TerminalStatus.REMOVE_CARD) return;*/
            callbackOnTerminalStatusUpdated(status);
        }
    }

    private boolean isDeviceTypeMismatch() {
        boolean deviceMatched = false;
        if (mReaderVersionInfo != null) {
            String resolvedHardwareType = mReaderVersionInfo.getHardwareType();
            Timber.d("isDeviceTypeMismatch() -> SDK resolved hardware type = " +
                    resolvedHardwareType);

            if (mDeviceType == DeviceType.MOBY3000) {
                // Need to make an exception for "Moby-3000" swiper devices,
                // because the ROAM SDK uses inconsistent naming conventions for this swiper.
                deviceMatched = resolvedHardwareType.contains("MOB");
            } else if (mDeviceType == DeviceType.MOBY8500) {
                // Need to make an exception for "Moby-8500" swiper devices,
                // because the ROAM SDK is NOT returning any useful information for this swiper.
                deviceMatched = true;
            } else if (mDeviceType == DeviceType.RP45BT) {
                // Need to make an exception for "RP45-BT" swiper devices,
                // because the ROAM SDK does NOT have any strings defined for this swiper.
                deviceMatched = resolvedHardwareType.contains("RP45");
            } else {
                // Use the ROAM SDK method to determine if a valid device is selected
                deviceMatched = mDeviceType.matchesHardwareType(resolvedHardwareType);
            }
        }

        Timber.d("isDeviceTypeMismatch() -> returning with result: device match = %s", deviceMatched);
        return !deviceMatched;
    }

    private List<TlvObject> getTlvObjectList(Map<Parameter, Object> data,
            CardDataSourceType cardDataSourceType) {
        Timber.d("getTlvObjectList() called with: data=[%s], cardDataSourceType=[%s]",
                data, cardDataSourceType);
        List<TlvObject> tlvObjects = new ArrayList<>();
        if (mDeviceType != DeviceType.MOBY5500) {
            for (String tag : IngenicoRpCollectionsUtil
                    .getOnlineEmvTags(data, mReaderVersionInfo, cardDataSourceType)) {
                tlvObjects.add(ConstructedTlvObject.parse(tag).get(0));
            }
        } else {
            for (String tag : IngenicoMobyCollectionsUtil
                    .getOnlineEmvTags(data, mReaderVersionInfo)) {
                tlvObjects.add(ConstructedTlvObject.parse(tag).get(0));
            }
        }
        return tlvObjects;
    }

    private void requestHostProcessing(CardData cardData) {
        Timber.d("requestHostProcessing() called.");
        TerminalInteractionRequest terminalInteractionRequest =
                new TerminalInteractionRequest(TerminalInteractionType.HOST_PROCESSING);
        terminalInteractionRequest.setCardData(cardData);
        callbackOnTerminalInteractionRequest(terminalInteractionRequest);

        //update status to processing
        callbackOnTerminalStatusUpdated(TerminalStatus.PROCESSING);
    }

    private void callbackOnTerminalDisconnected() {
        Timber.d("callbackOnTerminalDisconnected() called.");
        mTerminalListener.onDisconnected();
    }

    private void callbackOnTerminalConnected() {
        Timber.d("callbackOnTerminalConnected() called.");
        mTerminalListener.onConnected(mTerminalInfo);
    }

    private void callbackOnTerminalInfo(final TerminalInfo terminalInfo) {
        Timber.d("callbackOnTerminalDeviceInfo() called with: terminalInfo=[%s]",
                terminalInfo);
        mTerminalListener.onTerminalInfo(terminalInfo);
    }

    private void callbackOnTerminalStatusUpdated(final TerminalStatus status) {
        Timber.d("callbackOnTerminalStatusUpdated() called with: status=[%s]", status);
        mTerminalListener.onTerminalStatusUpdate(status);
    }

    private void callbackOnTerminalInteractionRequest(final TerminalInteractionRequest request) {
        Timber.d("callbackOnTerminalInteractionRequest() called with: request=[%s]",
                request);
        mTerminalListener.onTerminalInteractionRequested(request);
    }

    private void callbackOnTerminalResponse(final TerminalResponse terminalResponse) {
        Timber.d("callbackOnTerminalResponse() called with: terminalResponse=[%s]",
                terminalResponse);
        mTerminalListener.onTerminalResponseReceived(terminalResponse);
    }

    private void callbackOnTerminalInteractionError(final TerminalError errorType,
            final String error) {
        Timber.d("callbackOnTerminalInteractionError() called with: errorType=[%s]", errorType);
        mTerminalListener.onError(errorType, error);
    }

    private boolean isDeviceEmvCapable() {
        return mTerminalConfiguration != null && mTerminalConfiguration.getTerminalType() != null
                && mTerminalConfiguration.getTerminalType().emvCapable;
    }

    private void requestHostProcessingConfirmation() {
        TerminalInteractionRequest request = new TerminalInteractionRequest(
                TerminalInteractionType.REQUEST_PROCEED_HOST_PROCESSING);
        request.setCardData(mHostRequestCardData);
        callbackOnTerminalInteractionRequest(request);
    }

    private class DeviceStatusListener implements DeviceStatusHandler {

        @Override
        public void onConnected() {
            /*
             onConnected() is now fired after all of the terminal information is populated. This requires issuing
             commands for the serial number, battery status and app version number. The getDeviceCapabilities() call
             kicks this process off.
              */
            mConnected = true;
            mDeviceProcessing = false;

               /*
                Some hardware information needs to be known at the time of initial setup. Therefore.
                a call is made here to get the required terminal info. An anonymous class is used
                here instead of DeviceInfoCallbacksImpl since getting the device info at this point
                is part of the terminal setup flow. DeviceInfoCallbacksImpl is used when a dedicated
                action is requested to retrieve the device info. Non-emv capable basic MSR-only terminals
                do not support device info retrieval commands.
                */
            if (!isDeviceEmvCapable()) {
                mTerminalInfo = new TerminalInfo();
                mTerminalInfo.setTerminalType(mTerminalConfiguration.getTerminalType());
                callbackOnTerminalConnected();
            } else {
                getTerminalInfo();
            }
        }

        private void getTerminalInfo() {
            Timber.w("getTerminalInfo() called.");
            mDeviceInfoManager = new IngenicoDeviceInfoManager(mDeviceManager, true);
            mDeviceInfoManager.getDeviceInfo(
                    new IngenicoDeviceInfoManager.IngenicoDeviceInfoProcessCallbacks() {
                        @Override
                        public void onTerminalInfo(TerminalInfo terminalInfo) {
                            Timber.d("onTerminalInfo() called with: terminalInfo=[%s]",
                                    terminalInfo);
                            terminalInfo.setTerminalType(mTerminalConfiguration.getTerminalType());
                            mTerminalInfo = terminalInfo;
                            if (mConfigProcManager != null) {
                                mConfigProcManager.setCurrentDeviceSerialNumber(
                                        mTerminalInfo.getSerialNumber());
                            }
                        }

                        @Override
                        public void onReaderVersionInfo(ReaderVersionInfo readerVersionInfo) {
                            Timber.d("onReaderVersionInfo() called with: readerVersionInfo=[%s]",
                                    readerVersionInfo);
                            mReaderVersionInfo = readerVersionInfo;
                        }

                        @Override
                        public void onExecutingCommand() {
                            Timber.d("onExecutingCommand() called.");
                            mDeviceProcessing = true;
                        }

                        @Override
                        public void onWaitingForCommand() {
                            Timber.d("onWaitingForCommand() called.");
                            mDeviceProcessing = false;
                        }

                        @Override
                        public void onComplete() {
                            Timber.d("onComplete() called.");
                            setupTerminalTimeouts();
                        }

                        @Override
                        public void onError(TerminalError errorType, String error) {
                            Timber.d("onError() called with: errorType=[%s], error=[%s]", errorType,
                                    error);
                            callbackOnTerminalInteractionError(errorType, error);
                        }
                    });
        }

        private void setupTerminalTimeouts() {
            Timber.w("setupTerminalTimeouts() called.");
            if (mTerminalConfiguration != null &&
                    mTerminalConfiguration.getEnergySaverModeDelay() != null) {
                mDeviceProcessing = true;
                mDeviceManager.getConfigurationManager()
                        .setEnergySaverModeTime(
                                mTerminalConfiguration.getEnergySaverModeDelay(),
                                mDeviceResponseHandler);
            } else if (mTerminalConfiguration != null &&
                    mTerminalConfiguration.getShutdownDelay() != null) {
                mDeviceProcessing = true;
                mDeviceManager.getConfigurationManager()
                        .setShutDownModeTime(mTerminalConfiguration.getShutdownDelay(),
                                mDeviceResponseHandler);
            } else {
                callbackOnTerminalConnected();
            }
        }

        @Override
        public void onDisconnected() {
            Timber.d("onDisconnected: ");
            /*
             If an error occurs when initializing the device through mDeviceManager.initialize(),
             onDisconnected() will be be triggered followed by a subsequent onError(). Instead
             of firing a callback that the terminal was disconnected since it never connected,
             the error callback will indicate that a disconnect error occurred along with the
             error message.
              */
            mConnected = false;

            /*
             If a command is not currently in flight, RUA SDK will not broadcast a follow-up
             error and onDisconnected() call be triggered. IF a command is in flight, a proper
             error will be returned by the RUA SDK.
              */
            mTerminalListener.onDisconnected();
            mDeviceProcessing = false;
        }

        @Override
        public void onError(String s) {
            mDeviceProcessing = false;
            Timber.d("onError= [%s]", s);
            String error;
            if (!mConnected) {
                error = "Terminal disconnected. The request could not be processed.";
            } else {
                error = "An error was encountered while processing the " +
                        "request.";
            }
            mTerminalListener
                    .onError(TerminalError.GENERAL_ERROR, error);
        }
    }

    private class ConfigProcessManagerListenerImpl implements
            IngenicoDeviceProcessCallbacks {

        @Override
        public void onComplete() {
            if (mUpdatingProvision) {
                mUpdatingProvision = false;
                mTerminalVersionUpdateListener.onTerminalUpdateSuccess();
            } else {
                TerminalResponse configResponse = new TerminalResponse(TerminalAction.SETUP);
                callbackOnTerminalResponse(configResponse);
            }
            mDeviceProcessing = false;
        }

        @Override
        public void onExecutingCommand() {
            mDeviceProcessing = true;
        }

        @Override
        public void onWaitingForCommand() {
            mDeviceProcessing = false;
        }

        @Override
        public void onError(TerminalError errorType, String error) {
            callbackOnTerminalInteractionError(errorType, error);
            if (mUpdatingProvision) {
                mUpdatingProvision = false;
                mTerminalVersionUpdateListener.onTerminalUpdateError(TerminalError.CONFIGURATION_ERROR,
                        "Error occurred during provision update.");
            }
        }
    }

    private class DeviceInfoCallbacksImpl
            implements IngenicoDeviceInfoManager.IngenicoDeviceInfoProcessCallbacks {

        @Override
        public void onTerminalInfo(TerminalInfo terminalInfo) {
            Timber.d("onTerminalInfo() called with: terminalInfo=[%s]", terminalInfo);

            if (mTerminalConfiguration != null) {
                terminalInfo.setTerminalType(mTerminalConfiguration.getTerminalType());
                Timber.d("onTerminalInfo() called with terminalType: terminalInfo=[%s]",
                        terminalInfo);
            }
            mTerminalInfo = terminalInfo;
        }

        @Override
        public void onReaderVersionInfo(ReaderVersionInfo readerVersionInfo) {
            Timber.d("onReaderVersionInfo() called with: readerVersionInfo=[%s]",
                    readerVersionInfo);
            mReaderVersionInfo = readerVersionInfo;
        }

        @Override
        public void onExecutingCommand() {
            Timber.d("onExecutingCommand() called.");
            mDeviceProcessing = true;
        }

        @Override
        public void onWaitingForCommand() {
            Timber.d("onWaitingForCommand() called.");
            mDeviceProcessing = false;
        }

        @Override
        public void onComplete() {
            Timber.d("onComplete() called.");
            if (mTerminalConfiguration.getTerminalType() == TerminalType.INGENICO_MOBY_5500 &&
                    mMobyConfiguration != null) {
                mTerminalInfo.setAppVersion(mMobyConfiguration.getProvisionVersion());
            }
            callbackOnTerminalInfo(mTerminalInfo);
        }

        @Override
        public void onError(TerminalError errorType, String error) {
            Timber.d("onError() called with: errorType=[%s], error=[%s]", errorType, error);
            callbackOnTerminalInteractionError(errorType, error);
        }
    }
}
