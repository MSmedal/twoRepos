package com.tsys.payments.hardware.ingenico.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class IngenicoCurrencyHelper {

    private static DecimalFormat sCurrencyFormatter;
    private static DecimalFormat sCurrencyFormatterNoSymbol;
    private static String sCurrencySymbol;
    private static int sMaxCurrencyPrecision;
    private static int sMaxCalculationPrecision;
    private static int sRoundingStyle;

    static {
        sCurrencyFormatter = (DecimalFormat)NumberFormat.getCurrencyInstance();
        sCurrencySymbol = sCurrencyFormatter.getCurrency().getSymbol();
        sCurrencyFormatter.setNegativePrefix('(' + sCurrencySymbol);
        sCurrencyFormatter.setNegativeSuffix(")");

        sCurrencyFormatterNoSymbol = (DecimalFormat)NumberFormat.getCurrencyInstance();
        sCurrencyFormatterNoSymbol.setNegativePrefix("(");
        sCurrencyFormatterNoSymbol.setNegativeSuffix(")");
        DecimalFormatSymbols noSymbolFormatSymbol = sCurrencyFormatter.getDecimalFormatSymbols();
        noSymbolFormatSymbol.setCurrencySymbol("");
        sCurrencyFormatterNoSymbol.setDecimalFormatSymbols(noSymbolFormatSymbol);

        sMaxCurrencyPrecision = sCurrencyFormatter.getMaximumFractionDigits();
        sMaxCalculationPrecision = 10;
        sRoundingStyle = BigDecimal.ROUND_HALF_EVEN;
    }

    public static int getMaxCurrencyPrecision() {
        return sMaxCurrencyPrecision;
    }

    public static int getMaxCalculationPrecision() {
        return sMaxCalculationPrecision;
    }

    public static int getRoundingStyle() {
        return sRoundingStyle;
    }

    @Nullable
    public static BigDecimal roundForCalculation(@Nullable BigDecimal amount) {
        if (amount == null) {
            return null;
        }
        return amount.setScale(sMaxCurrencyPrecision, sRoundingStyle);
    }

    @Nullable
    public static String formatForDisplay(boolean showSymbol, @Nullable BigDecimal amount) {
        if (amount == null) {
            return null;
        }
        synchronized (IngenicoCurrencyHelper.class) {
            if (showSymbol) {
                return sCurrencyFormatter.format(roundForCalculation(amount));
            } else {
                return sCurrencyFormatterNoSymbol.format(roundForCalculation(amount));
            }
        }
    }

    @Nullable
    public static String formatForCommunication(@Nullable BigDecimal amount) {
        if (amount == null) {
            return null;
        }
        return roundForCalculation(amount).toString();
    }

    @NonNull
    public static BigDecimal string2Decimal(@NonNull String amountString) {
        if (amountString.trim().startsWith("(") && amountString.trim().endsWith(")")) {
            return new BigDecimal(clearFormatting(amountString)).negate();
        } else {
            return new BigDecimal(clearFormatting(amountString));
        }
    }

    @NonNull
    public static String clearFormatting(@NonNull String amountString) {
        return amountString.replaceAll("[^\\d.-]", "");
    }

    public static String getSymbol() {
        return sCurrencySymbol;
    }

    @Nullable
    public static List<BigDecimal> getSplitByAmountTotals(@Nullable BigDecimal totalDue, int splitWays) {
        if (totalDue == null) {
            return null;
        }
        int amountInCents = totalDue.multiply(new BigDecimal(100)).intValueExact();
        int lowValue = amountInCents / splitWays;
        int highValue = lowValue + 1;
        int numberOfHighValues = amountInCents % splitWays;
        int numberOfLowValues = splitWays - numberOfHighValues;

        String highValueString = (highValue / 100) + "." + String.format("%02d", highValue % 100);
        String lowValueString = (lowValue / 100) + "." + String.format("%02d", lowValue % 100);

        List<BigDecimal> splitList = new ArrayList<BigDecimal>();
        for (int i = 0; i < numberOfHighValues; i++) {
            splitList.add(new BigDecimal(highValueString));
        }
        for (int i = 0; i < numberOfLowValues; i++) {
            splitList.add(new BigDecimal(lowValueString));
        }

        return splitList;
    }
}
