package com.tsys.payments.hardware.ingenico.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.text.TextUtils;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import static com.tsys.payments.library.utils.LibraryConfigHelper.isDebug;

import timber.log.Timber;

public class IngenicoJSONParser {
    private final Context mContext;
    private final String SHARED_PREF_NAME = "mobyConfig";
    private final String CONFIG_FILE_SHARED = "configFile";
    private final String PROVISION_VERSION_SHARED = "provisionVersion";
    private final String PROVISION_JSON_FILE = "provisionJson";
    private final String STORED_ENVIRONMENT = "storedEnvironment";
    private final String IS_NEW_JSON = "isNewJson";
    private String mProvisionJson;
    private String mEmvConfigJson;
    private String version;
    private String mDeviceFileVersion;
    private SharedPreferences emvConfigSharePref;

    public IngenicoJSONParser(Context context) {
        mContext = context;
        mEmvConfigJson = readJson(SharedType.CONFIG);
    }

    public void reInit(String provisionJson) {
        ProvisionJson(provisionJson);
        mProvisionJson = readJson(SharedType.PROVISION_FILE);
    }

    /**
     * Reset the provision and config files.
     */
    public void resetDeviceSettings() {
        removeSharedPreference();
        mEmvConfigJson = null;
        getEmvConfigJson();
        getProvisionJSON();
    }

    /**
     * Save data to SharedPreference
     *
     * @param type
     * @param value
     */
    private void saveToSharedPreference(SharedType type, String value) {
        emvConfigSharePref = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = emvConfigSharePref.edit();
        switch (type) {
            case CONFIG:
                try {
                    JSONObject json = new JSONObject(value);
                    String config = json.getJSONObject("RP450EMVStartTransactionParameters").toString();

                    if (!TextUtils.isEmpty(config)) {
                        emvConfigSharePref.edit().remove(CONFIG_FILE_SHARED).commit();
                        editor.putString(CONFIG_FILE_SHARED, config);
                    }
                } catch (JSONException e) {
                    Timber.e(e);
                }
                break;
            case PROVISION_FILE:
                editor.putString(PROVISION_JSON_FILE, value.replace("\r", ""));
                break;
            case VERSION:
                emvConfigSharePref.edit().remove(PROVISION_VERSION_SHARED).commit();
                editor.putString(PROVISION_VERSION_SHARED, value);
                break;
            case ENVIRONMENT:
                emvConfigSharePref.edit().remove(STORED_ENVIRONMENT).commit();
                editor.putString(STORED_ENVIRONMENT, value);
                break;
        }
        editor.commit();
    }

    /**
     * Save data to SharedPreference
     *
     * @param type
     * @param value
     */
    private void saveToSharedPreferenceBoolean(SharedType type, boolean value) {
        emvConfigSharePref = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = emvConfigSharePref.edit();
        switch (type) {
            case IS_NEW_JSON:
                editor.putBoolean(IS_NEW_JSON, value);
                break;
        }
        editor.commit();
    }

    private String readSharedPreference(SharedType type) {
        emvConfigSharePref = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        switch (type) {
            case CONFIG:
                return emvConfigSharePref.getString(CONFIG_FILE_SHARED, "");
            case PROVISION_FILE:
                return emvConfigSharePref.getString(PROVISION_JSON_FILE, "");
            case VERSION:
                if (TextUtils.isEmpty(emvConfigSharePref.getString
                        (PROVISION_VERSION_SHARED, ""))) {
                    loadJSONFiles(isDebug() ? "provisionTest.json"
                            : "provisionProd.json", true);
                }
                return emvConfigSharePref.getString(PROVISION_VERSION_SHARED, "");
            case ENVIRONMENT:
                return emvConfigSharePref.getString(STORED_ENVIRONMENT, "");
            default:
                return "";
        }
    }

    private boolean readSharedPreferenceBoolean(SharedType type) {
        emvConfigSharePref = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        switch (type) {
            case IS_NEW_JSON:
                return emvConfigSharePref.getBoolean(IS_NEW_JSON, false);
            default:
                return false;
        }
    }

    private void removeSharedPreference() {
        emvConfigSharePref = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        emvConfigSharePref.edit().clear().apply();
    }

    /**
     * Get the provision Json
     *
     * @return
     */
    public String getProvisionJSON() {
        if (mProvisionJson == null) {
            mProvisionJson = readJson(SharedType.PROVISION_FILE);
        }
        return mProvisionJson;
    }

    private String readJson(SharedType Type) {
        switch (Type) {
            case PROVISION_FILE:
                String json = readSharedPreference(Type);
                if (TextUtils.isEmpty(json)) {
                    loadJSONFiles(isDebug() ? "provisionTest.json"
                            : "provisionProd.json", true);
                    json = readSharedPreference(Type);
                }
                return json;
            case CONFIG:
                String config = readSharedPreference(Type);
                if (TextUtils.isEmpty(config)) {
                    saveToSharedPreference(Type, loadJSONFiles("EMVConfigs.json", false));
                    config = readSharedPreference(Type);
                } else {
                    if (config.contains("RP450ContactAIDs")) {
                        saveToSharedPreference(Type, loadJSONFiles("EMVConfigs.json", false));
                        config = readSharedPreference(Type);
                    }
                }
                return config;
            default:
                return "";
        }
    }

    /**
     * Get the Emv Configuration Json with the Transaction params
     *
     * @return
     */
    public String getEmvConfigJson() {
        if (mEmvConfigJson == null) {
            mEmvConfigJson = readJson(SharedType.CONFIG);
        }
        return mEmvConfigJson;
    }

    /**
     * Get the Process Profile Config List from Provision Json
     *
     * @return
     */
    public String getProcessorProfile() {
        return "processor_profile_config_list";
    }

    public String getDOLsTag() {
        return "dols";
    }

    /**
     * Get the Dynamic Config Version
     *
     * @return
     */
    public String getDynamicStrVersion() {
        return "dynamic_conf_cust_str_ver";
    }

    /**
     * Return Provisioning Version of the file
     *
     * @return
     */
    public String getProvisionVersion() {
        String version = readSharedPreference(SharedType.VERSION);
        try {
            JSONObject json = new JSONObject(readSharedPreference(SharedType.PROVISION_FILE));
            String env = json.getString("name").split(":")[0];
            if (!TextUtils.isEmpty(env) && env.equalsIgnoreCase("PROD")) {
                return version.concat("P");
            } else if (!TextUtils.isEmpty(env) && env.equalsIgnoreCase("DEV")) {
                return version.concat("D");
            } else {
                return version.concat("DF");
            }
        } catch (Exception e) {
            return version;
        }
    }

    private void ProvisionJson(String rawString) {
        try {
            saveToSharedPreference(SharedType.PROVISION_FILE, rawString);
            saveToSharedPreference(SharedType.ENVIRONMENT, getEnvironmentType().toString());
            JSONObject obj = new JSONObject(rawString);
            JSONArray arr = (JSONArray)obj.get("firmware_id");
            if (arr.length() > 0) {
                version = arr.getString(0);
                saveToSharedPreference(SharedType.VERSION, version);
            }
        } catch (Exception ex) {
            Timber.e(ex);
        }
    }

    /**
     * Set the version of the from the device of the JSON file
     *
     * @param deviceFileVersion
     */
    public void setDeviceVersion(String deviceFileVersion) {
        mDeviceFileVersion = deviceFileVersion;

        String storedVersion = readSharedPreference(SharedType.VERSION);
        String environment = readSharedPreference(SharedType.ENVIRONMENT);
        EnvironmentType env;
        if (environment == null || environment.isEmpty()) {
            env = getEnvironmentType();
            saveToSharedPreference(SharedType.ENVIRONMENT, env.toString());
        } else {
            env = EnvironmentType.valueOf(readSharedPreference(SharedType.ENVIRONMENT));
        }

        if (env != getEnvironmentType()) {
            resetDeviceSettings();
        }
    }

    /**
     * isDebug is set base on the environment.
     *
     * @return
     */
    private EnvironmentType getEnvironmentType() {
        return isDebug() ? EnvironmentType.TEST : EnvironmentType.PROD;
    }

    /**
     * Determine if the device should read a new json file.
     *
     * @return
     */
    public boolean ShouldReadJSON() {
        boolean isNewJson = readSharedPreferenceBoolean(SharedType.IS_NEW_JSON);
        saveToSharedPreferenceBoolean(SharedType.IS_NEW_JSON, false);
        return isNewJson;
    }

    /**
     * Load the EmvConfigs.json file from the assets. This allow us to push the emvconfigs file to the app
     *
     * @return
     */
    // region
    private String loadJSONFiles(String fileName, boolean deepParse) {
        Timber.d("loadJSONFromAsset() called.");
        String json = null;

        try {
            AssetManager assetManager = mContext.getAssets();
            InputStream is = assetManager.open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            Timber.d("loadJSONFromAsset() file load successfully.");
            json = new String(buffer, StandardCharsets.UTF_8);
            if (deepParse) {
                ProvisionJson(json);
                saveToSharedPreferenceBoolean(SharedType.IS_NEW_JSON, true);
            }
        } catch (IOException ex) {
            Timber.e(ex);
            return null;
        }
        return json;
    }

    private Long Number(String str) {
        if (TextUtils.isEmpty(str)) {
            return 0L;
        }

        try {
            String clean = str.replaceAll("[^0-9]", "");
            return Long.parseLong(clean);
        } catch (Exception e) {
            return 0L;
        }
    }
    //endregion

    enum SharedType {
        CONFIG,
        VERSION,
        PROVISION_FILE,
        ENVIRONMENT,
        IS_NEW_JSON
    }

    enum EnvironmentType {
        TEST,
        PROD
    }
}