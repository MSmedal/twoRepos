package com.tsys.payments.hardware.ingenico;

import android.content.Context;
import androidx.annotation.Nullable;
import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.ConnectionType;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.terminal.TerminalController;
import com.tsys.payments.library.terminal.TerminalControllerFactory;
import com.tsys.payments.library.terminal.TerminalListener;
import java.util.Objects;

public class IngenicoControllerFactory implements TerminalControllerFactory {
    @Nullable
    @Override
    public TerminalType[] getSupportedTerminalTypes() {
        return new TerminalType[] {TerminalType.INGENICO_MOBY_3000, TerminalType.INGENICO_MOBY_5500,
                TerminalType.INGENICO_MOBY_8500, TerminalType.INGENICO_MOBY_3000_PROPAY, TerminalType.INGENICO_RP45BT,
                TerminalType.INGENICO_RP350, TerminalType.ROAM_G5X_TSYS_DECRYPTION, TerminalType.INGENICO_RP450C};
    }

    @Nullable
    @Override
    public ConnectionType[] getSupportedConnectionTypes(TerminalType terminalType)
            throws IllegalArgumentException {
        if (terminalType != null) {
            switch (terminalType) {
                case INGENICO_RP450C:
                    return new ConnectionType[] {ConnectionType.AUDIO_JACK,
                            ConnectionType.BLUETOOTH};
                case ROAM_G5X_TSYS_DECRYPTION:
                case INGENICO_RP350:
                    return new ConnectionType[] {ConnectionType.AUDIO_JACK};
                case INGENICO_RP45BT:
                case INGENICO_MOBY_3000_PROPAY:
                    return new ConnectionType[] {ConnectionType.BLUETOOTH};
                case INGENICO_MOBY_3000:
                case INGENICO_MOBY_5500:
                case INGENICO_MOBY_8500:
                    return new ConnectionType[] {ConnectionType.BLUETOOTH, ConnectionType.USB};
                default:
                    throw new IllegalArgumentException(
                            "getSupportedConnectionTypes() called with unsupported terminal = [" +
                                    terminalType + "].");
            }
        } else {
            throw new IllegalArgumentException(
                    "getSupportedConnectionTypes() called with null argument.");
        }
    }

    @Nullable
    @Override
    public TerminalController create(Context context, TerminalConfiguration terminalConfiguration,
            TransactionConfiguration transactionConfiguration, TerminalListener listener)
            throws IllegalArgumentException {
        Objects.requireNonNull(context);
        Objects.requireNonNull(terminalConfiguration);
        Objects.requireNonNull(transactionConfiguration);
        Objects.requireNonNull(listener);

        return new IngenicoController(context.getApplicationContext(), terminalConfiguration,
                transactionConfiguration,
                listener);
    }
}
