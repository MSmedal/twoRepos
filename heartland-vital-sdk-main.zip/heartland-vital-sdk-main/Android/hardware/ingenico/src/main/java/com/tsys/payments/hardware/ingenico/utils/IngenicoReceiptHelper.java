package com.tsys.payments.hardware.ingenico.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.tsys.payments.hardware.ingenico.enums.IngenicoSwiperResult;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class IngenicoReceiptHelper {
    private static final int CHARACTERS_PER_LINE = 38;
    private static final String RECEIPT_TAB = "\n  ";
    private static final Parameter[] RECEIPT_PARAMETERS =
            {Parameter.CardHolderName, Parameter.CardholderVerificationMethodResult, Parameter.ApplicationLabel,
                    Parameter.ApplicationIdentifier,
                    Parameter.ApplicationCryptogram, Parameter.ApplicationTransactionCounter,
                    Parameter.AmountAuthorizedNumeric, Parameter.TerminalVerificationResults};

    @Nullable
    public static String getReceipt(@Nullable Map<Parameter, Object> emvDataMap, @NonNull IngenicoSwiperResult result) {
        List<String> receiptItems = new ArrayList<>(emvDataMap != null ? emvDataMap.size() : 3);
        List<Parameter> receiptParametersList = Arrays.asList(RECEIPT_PARAMETERS);
        receiptItems.add(getAdjustedString("\n-----Receipt-----\n"));
        if (emvDataMap != null) {
            for (Map.Entry<Parameter, Object> entry : emvDataMap.entrySet()) {
                if (receiptParametersList.contains(entry.getKey())) {
                    switch (entry.getKey()) {
                        case AmountAuthorizedNumeric:
                            BigDecimal value = BigDecimal
                                    .valueOf(Double.valueOf(entry.getValue().toString()) * StrictMath.pow(10.0, -2.0));
                            receiptItems.add(getAdjustedString("\nAmount\n"));
                            receiptItems.add(getAdjustedString(IngenicoCurrencyHelper.formatForDisplay(false, value)));
                            break;
                        default:
                            receiptItems.add(getAdjustedString("\n" + entry.getKey().name() + "\n"));
                            receiptItems.add(getAdjustedString(entry.getValue().toString()));
                            break;
                    }
                }
            }
        }
        receiptItems.add(getAdjustedString("\nTransaction Result\n" + result.name()));
        receiptItems.add(getAdjustedString("\n-----------------"));
        return buildReceipt(receiptItems);
    }

    private static String buildReceipt(List<String> receiptItems) {
        StringBuilder stringBuilder = new StringBuilder(receiptItems.size() * CHARACTERS_PER_LINE);
        for (String item : receiptItems) {
            stringBuilder.append(item);
        }
        return stringBuilder.toString();
    }

    @NonNull
    private static String getAdjustedString(String receiptLineItem) {
        StringBuilder sb = new StringBuilder(receiptLineItem.length());
        int length = receiptLineItem.length();
        for (int i = 0; i < length; i++) {
            if (shouldBreakAtIndex(i, length)) {
                sb.append(RECEIPT_TAB);
            }
            sb.append(receiptLineItem.charAt(i));
        }
        return sb.toString();
    }

    private static boolean shouldBreakAtIndex(int index, int receiptLineItemLength) {
        boolean indexNotZero = index != 0;
        boolean itemLengthLargerThanLimit = receiptLineItemLength > CHARACTERS_PER_LINE;
        boolean indexAtLineBreak = index % CHARACTERS_PER_LINE == 0;
        return indexNotZero && itemLengthLargerThanLimit && indexAtLineBreak;
    }
}
