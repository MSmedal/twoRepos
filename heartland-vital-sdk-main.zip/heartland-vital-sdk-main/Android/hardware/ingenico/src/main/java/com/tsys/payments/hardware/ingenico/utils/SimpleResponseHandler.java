package com.tsys.payments.hardware.ingenico.utils;

public interface SimpleResponseHandler <T> {
    public void onResponse(T result);
    public void onProgress(T result);
}
