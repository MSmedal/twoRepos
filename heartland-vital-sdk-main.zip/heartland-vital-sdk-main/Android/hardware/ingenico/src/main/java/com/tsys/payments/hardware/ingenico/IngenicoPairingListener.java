package com.tsys.payments.hardware.ingenico;

import com.roam.roamreaderunifiedapi.DeviceManager;
import com.roam.roamreaderunifiedapi.callback.AudioJackPairingListenerWithDevice;
import com.roam.roamreaderunifiedapi.data.Device;
import com.tsys.payments.library.terminal.TerminalListener;

import timber.log.Timber;

public final class IngenicoPairingListener implements AudioJackPairingListenerWithDevice {
    private static final String TAG = IngenicoPairingListener.class.getSimpleName();
    private final TerminalListener mTerminalListener;
    private final DeviceManager mDeviceManager;

    IngenicoPairingListener(TerminalListener terminalListener, DeviceManager deviceManager) {
        mTerminalListener = terminalListener;
        mDeviceManager = deviceManager;
    }

    @Override
    public void onPairConfirmation(String s, String s1, Device device) {
        Timber.d("onPairConfirmation: ");
        mDeviceManager.confirmPairing(true);
    }

    @Override
    public void onPairSucceeded(Device device) {
        Timber.d("onPairSucceeded: ");
        mDeviceManager.getConfigurationManager().activateDevice(device);
    }

    @Override
    public final void onPairNotSupported() {
        Timber.d("onPairNotSupported: ");
    }

    @Override
    public final void onPairFailed() {
        Timber.d("onPairFailed: ");
    }
}
