package com.tsys.payments.hardware.ingenico;

import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;
import com.roam.roamreaderunifiedapi.data.PublicKey;
import com.tsys.payments.hardware.ingenico.utils.IngenicoJSONParser;
import com.tsys.payments.library.utils.LibraryConfigHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import timber.log.Timber;

public class IngenicoMobyConfiguration {
    @Nullable
    private Context mContext;
    private String mEmvTransConfigs;
    private String mEmvDeviceConfigs;
    private String mProvisioningJson;
    private List<PublicKey> publicKeyList;
    private IngenicoJSONParser configJson;

    IngenicoMobyConfiguration(Context context) {
        mContext = context;

        configJson = new IngenicoJSONParser(context);
        if (mEmvTransConfigs == null) {
            mEmvTransConfigs = configJson.getEmvConfigJson();
        }
    }

    public String getCurrentProvisionVersion() {
        return configJson.getProvisionVersion();
    }

    public void updateProvision(String provision) {
        configJson.reInit(provision);
        mProvisioningJson = configJson.getProvisionJSON();
    }

    /**
     * Load the public keys from the EmvConfigs.json
     *
     * @return
     */
    private List<PublicKey> getPublicKeys() {
        Timber.d("getPublicKeys() called.");
        List<PublicKey> publicKeyList = new ArrayList();
        try {
            JSONObject json = new JSONObject(mEmvTransConfigs);
            JSONArray publicKeyArray = json.getJSONArray("PublicKeys");
            for (int i = 0; i < publicKeyArray.length(); i++) {
                JSONObject publicKeyJson = publicKeyArray.getJSONObject(i);
                publicKeyList.add(new PublicKey(
                        publicKeyJson.getString("rid"),
                        publicKeyJson.getString("CAPublicKeyIndex"),
                        publicKeyJson.getString("PublicKey"),
                        publicKeyJson.getString("ExponentOfPublicKey"),
                        publicKeyJson.getString("Checksum")));
            }
        } catch (JSONException e) {
            Timber.e(e);
        }
        return publicKeyList;
    }

    /**
     * Get the Amount Data Object list
     *
     * @return
     */
    public List<Parameter> getAmountDolList() {
        Timber.d("getAmountDolList() called.");
        List<Parameter> amountDolList = new ArrayList();
        try {
            JSONArray amountDolArray = getDol(DOLTYPE.AMOUNT);
            for (int i = 0; i < amountDolArray.length(); i++) {
                amountDolList.add(Parameter.getEnumFromString(amountDolArray.getString(i)));
            }
        } catch (JSONException e) {
            Timber.e(e);
        }
        return amountDolList;
    }

    //Data Object List
    private JSONArray getDol(DOLTYPE doltype) {
        try {
            configJson = configJson == null ? new IngenicoJSONParser(mContext)
                    : configJson;
            JSONObject json = new JSONObject(configJson.getProvisionJSON());
            JSONArray profile = json.getJSONArray(configJson.getProcessorProfile());
            JSONObject allDOLs = profile.getJSONObject(0)
                    .getJSONObject(configJson.getDOLsTag());

            switch (doltype) {
                case AMOUNT:
                    return allDOLs.getJSONArray("Amount");
                case CONTACT_ONLINE:
                    return allDOLs.getJSONArray("Online");
                case CONTACT_RESPONSE:
                    return allDOLs.getJSONArray("Response");
                case CONTACTLESS_ONLINE:
                    return allDOLs.getJSONArray("ContactlessOnline");
                case CONTACTLESS_RESPONSE:
                    return allDOLs.getJSONArray("ContactlessResponse");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new JSONArray();
    }

    /**
     * Get the Online Data Object List
     *
     * @return
     */
    public List<Parameter> getOnlineDolList() {
        Timber.d("getOnlineDolList() called.");
        List<Parameter> onlineDolList = new ArrayList();
        try {
            JSONArray onlineDolArray = getDol(DOLTYPE.CONTACT_ONLINE);
            for (int i = 0; i < onlineDolArray.length(); i++) {
                onlineDolList.add(Parameter.getEnumFromString(onlineDolArray.getString(i)));
            }
        } catch (JSONException e) {
            Timber.e(e);
        }
        return onlineDolList;
    }

    /**
     * Get the Response Data Object List
     *
     * @return
     */
    public List<Parameter> getResponseDolList() {
        List<Parameter> responseDolList = new ArrayList();
        try {
            JSONArray responseDolArray = getDol(DOLTYPE.CONTACT_RESPONSE);
            for (int i = 0; i < responseDolArray.length(); i++) {
                responseDolList.add(Parameter.getEnumFromString(responseDolArray.getString(i)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return responseDolList;
    }

    /**
     * Get the Contactless Online Data Object List
     *
     * @return
     */
    public List<Parameter> getContactlessOnlineDolList() {
        Timber.d("getContactlessOnlineDolList() called");
        List<Parameter> contactlessOnlineDolList = new ArrayList();
        try {
            JSONArray contactlessOnlineDolArray = getDol(DOLTYPE.CONTACTLESS_ONLINE);
            for (int i = 0; i < contactlessOnlineDolArray.length(); i++) {
                contactlessOnlineDolList.add(Parameter.getEnumFromString(contactlessOnlineDolArray.getString(i)));
            }
        } catch (JSONException e) {
            Timber.e(e);
        }
        return contactlessOnlineDolList;
    }

    /**
     * Get the Contactless Response Data Object List
     *
     * @return
     */
    public List<Parameter> getContactlessResponseDolList() {
        Timber.d("getContactlessResponseDolList() called");
        List<Parameter> contactlessResponseDolList = new ArrayList();
        try {
            JSONArray contactlessResponseDolArray = getDol(DOLTYPE.CONTACTLESS_RESPONSE);
            for (int i = 0; i < contactlessResponseDolArray.length(); i++) {
                contactlessResponseDolList.add(Parameter.getEnumFromString(contactlessResponseDolArray.getString(i)));
            }
        } catch (JSONException e) {
            Timber.e(e);
        }
        return contactlessResponseDolList;
    }

    /**
     * Get the set of contact AID with TLV Data
     *
     * @return
     */
    public Set<ApplicationIdentifier> getContactAIDWithTLVData() {
        Set<ApplicationIdentifier> sContactAIDWithTLVData = new HashSet<>();
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000003",
                "1010",
                "008C",
                "008C",
                "00",
                "01",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000003",
                "2010",
                "008C",
                "008C",
                "00",
                "01",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000003",
                "3010",
                "008C",
                "008C",
                "00",
                "01",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000098",
                "0840",
                "008C",
                "008C",
                "00",
                "03",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000004",
                "1010",
                "0002",
                "0002",
                "00",
                "01",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000004",
                "3060",
                "0002",
                "0002",
                "00",
                "01",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000004",
                "2203",
                "0002",
                "0002",
                "00",
                "03",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000152",
                "3010",
                "0001",
                "0001",
                "00",
                "01",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A000000152",
                "4010",
                "0001",
                "0001",
                "00",
                "03",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A00000002501",
                "0801",
                "0001",
                "0001",
                "00",
                "01",
                "9F3303E0F8C8DF82320101"
        ));
        sContactAIDWithTLVData.add(new ApplicationIdentifier(
                "A00000002501",
                "0802",
                "0001",
                "0001",
                "00",
                "01",
                "9F3303E0F8C8DF82320101"
        ));
        return sContactAIDWithTLVData;
    }

    /**
     * Get the set of Contact AID's
     *
     * @return
     */
    public Set<ApplicationIdentifier> getContactAids() {
        Timber.d("getContactAID() called");
        Set<ApplicationIdentifier> contactAID = new HashSet();
        try {
            JSONObject json = new JSONObject(mEmvDeviceConfigs);
            JSONArray contactAIDArray = json.getJSONArray("RP450ContactAIDs");//RP450ContactAIDs
            for (int i = 0; i < contactAIDArray.length(); i++) {
                JSONObject contactAIDJson = contactAIDArray.getJSONObject(i);
                contactAID.add(new ApplicationIdentifier(
                        contactAIDJson.getString("rid"),
                        contactAIDJson.getString("pix"),
                        contactAIDJson.getString("terminal_application_version"),
                        contactAIDJson.getString("lowest_supported_icc_application_version"),
                        contactAIDJson.getString("priority_index"),
                        contactAIDJson.getString("application_selection_flags")
                ));
            }
        } catch (JSONException e) {
            Timber.e(e);
        }
        return contactAID;
    }

    public Set<ApplicationIdentifier> getContactlessAID() {
        Set<ApplicationIdentifier> contactlessAIDSet = new HashSet();
        try {
            JSONObject json = new JSONObject(mEmvDeviceConfigs);
            JSONArray contactlessAIDArray = new JSONArray();
            contactlessAIDArray = json.getJSONArray("RP450ContactlessAIDs");//RP450ContactlessAIDs

            for (int i = 0; i < contactlessAIDArray.length(); i++) {
                JSONObject contactlessAIDJson = contactlessAIDArray.getJSONObject(i);
                contactlessAIDSet.add(new ApplicationIdentifier(
                                contactlessAIDJson.getString("rid"),
                                contactlessAIDJson.getString("pix"),
                                contactlessAIDJson.getString("terminal_application_version"),
                                contactlessAIDJson.getString("lowest_supported_icc_application_version"),
                                contactlessAIDJson.getString("priority_index"),
                                contactlessAIDJson.getString("application_selection_flags"),
                                contactlessAIDJson.getString("floor_limit"),
                                contactlessAIDJson.getString("cvm_limit"),
                                contactlessAIDJson.getString("txn_limit"),
                                contactlessAIDJson.getString("term_caps"),
                                contactlessAIDJson.getString("tlv_data")
                        )
                );
            }
        } catch (JSONException e) {
            Timber.e(e);
        }
        return contactlessAIDSet;
    }

    /**
     * Get the Emv Transaction Config file
     *
     * @return
     */
    public String getEmvTransConfigsJSON() {
        if (TextUtils.isEmpty(mEmvTransConfigs)) {
            configJson = configJson == null ? new IngenicoJSONParser(mContext) : configJson;
            mEmvTransConfigs = configJson.getEmvConfigJson();
        }
        return mEmvTransConfigs;
    }

    /**
     * Get the Process Profile Config List from Provision Json
     *
     * @return
     */
    public String getProcessorProfile() {
        configJson = configJson == null ? new IngenicoJSONParser(mContext) : configJson;
        return configJson.getProcessorProfile();
    }

    /**
     * Get the Dynamic Config Version
     *
     * @return
     */
    public String getDynamicStrVersion() {
        configJson = configJson == null ? new IngenicoJSONParser(mContext) : configJson;
        return configJson.getDynamicStrVersion();
    }

    /**
     * Get the entire provisioning Json
     *
     * @return
     */
    public String getProvisioningJson() {
        if (TextUtils.isEmpty(mProvisioningJson)) {
            configJson = configJson == null ? new IngenicoJSONParser(mContext) : configJson;
            mProvisioningJson = configJson.getProvisionJSON();
        }
        return mProvisioningJson;
    }

    /**
     * Set the device version number
     *
     * @param version
     */
    public void setDeviceVersion(String version) {
        if (configJson == null) {
            configJson = new IngenicoJSONParser(mContext);
        }
        configJson.setDeviceVersion(version);
    }

    /**
     * Get the Provisioning Version
     *
     * @return
     */
    public String getProvisionVersion() {
        if (configJson == null) {
            configJson = new IngenicoJSONParser(mContext);
        }
        return configJson.getProvisionVersion();
    }

    /**
     * Determine if the device should read the JSON file.
     *
     * @return
     */
    public boolean shouldReadJSON() {
        if (configJson == null) {
            configJson = new IngenicoJSONParser(mContext);
        }
        return configJson.ShouldReadJSON();
    }

    enum DOLTYPE {
        AMOUNT,
        CONTACTLESS_ONLINE,
        CONTACTLESS_RESPONSE,
        CONTACT_ONLINE,
        CONTACT_RESPONSE
    }
}
