package com.tsys.payments.hardware.ingenico;

import com.tsys.payments.library.enums.TerminalError;

/**
 * Super-interface for callbacks that fire in response to different process flows that occur on
 * the terminal. An example process flow would be configuring the terminal or retrieving terminal
 * information. These processes typically involve multiple commands being issued to complete the
 * process.
 */
interface IngenicoDeviceProcessCallbacks {
    void onExecutingCommand();

    void onWaitingForCommand();

    void onComplete();

    void onError(TerminalError errorType, String error);
}
