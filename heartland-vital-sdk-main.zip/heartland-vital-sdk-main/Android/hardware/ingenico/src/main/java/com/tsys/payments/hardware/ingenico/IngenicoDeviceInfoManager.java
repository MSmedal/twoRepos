package com.tsys.payments.hardware.ingenico;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.roam.roamreaderunifiedapi.DeviceManager;
import com.roam.roamreaderunifiedapi.callback.DeviceResponseHandler;
import com.roam.roamreaderunifiedapi.constants.Command;
import com.roam.roamreaderunifiedapi.constants.ErrorCode;
import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.roam.roamreaderunifiedapi.constants.ProgressMessage;
import com.roam.roamreaderunifiedapi.constants.ResponseCode;
import com.roam.roamreaderunifiedapi.constants.ResponseType;
import com.roam.roamreaderunifiedapi.data.FileVersionInfo;
import com.roam.roamreaderunifiedapi.data.ReaderVersionInfo;
import com.tsys.payments.library.domain.TerminalInfo;
import com.tsys.payments.library.enums.TerminalError;
import java.util.List;
import java.util.Map;

import timber.log.Timber;

/**
 * Manages querying information about the terminal, including serial number and battery level information.
 */
class IngenicoDeviceInfoManager {

    private static TerminalInfo mTerminalInfo;
    private DeviceManager mDeviceManager;
    @Nullable
    private IngenicoDeviceInfoProcessCallbacks mListener;
    private DeviceInfoResponseHandler mDeviceInfoResponseHandler;
    private boolean mOnlyBatteryStatusRequired;

    /**
     * @param isDeviceSetup: used to track if a terminal connection is already established and a request to setup a new
     *                       terminal is made.
     */
    IngenicoDeviceInfoManager(@NonNull DeviceManager deviceManager, boolean isDeviceSetup) {
        mDeviceManager = deviceManager;

        if (mTerminalInfo == null || isDeviceSetup) {
            mTerminalInfo = new TerminalInfo();
        }
    }

    void getDeviceInfo(@NonNull IngenicoDeviceInfoProcessCallbacks callbacks) {
        Timber.d("getDeviceInfo() called.");
        mListener = callbacks;
        if (mDeviceManager == null) {
            Timber.d("Device manager is null. Cannot retrieve device info.");
            mListener.onError(TerminalError.INITIALIZATION_ERROR,
                    "Device info cannot be retrieved at this time. Check to ensure that " +
                            "the device is connected.");
        } else {
            mDeviceInfoResponseHandler = new DeviceInfoResponseHandler();
            if (isNewTerminalConnRequest()) { // New connection request.
                Timber.d(
                        "Terminal Info fields are null. Retrieving device capabilities from device manager");
                mListener.onExecutingCommand();
                mDeviceManager.getConfigurationManager()
                        .getDeviceCapabilities(mDeviceInfoResponseHandler);
            } else { // Connection already established, only battery status is required.
                Timber.d(
                        "Terminal connection already established. Retrieving only battery status");
                mOnlyBatteryStatusRequired = true;
                mDeviceManager.getBatteryStatus(mDeviceInfoResponseHandler);
            }
        }
    }

    private void handleDeviceInfoResponse(@NonNull Map<Parameter, Object> data,
            @NonNull Command cmd,
            @NonNull ResponseType responseType) {
        Timber.d("handleDeviceInfoResponse() called with: data=[%s], cmd=[%s], responseType=[%s]",
                data, cmd, responseType);
        switch (cmd) {
            case ReadCapabilities:
                if (data.get(Parameter.InterfaceDeviceSerialNumber) != null) {
                    mTerminalInfo.setSerialNumber(
                            (String)data.get(Parameter.InterfaceDeviceSerialNumber));
                    Timber.d("Retrieved serial number [%s]", mTerminalInfo.getSerialNumber());
                }

                if (mListener != null) {
                    mListener.onExecutingCommand();
                } else {
                    Timber.w(
                            "mListener is null. Callback indicating that a command is in progress cannot be fired.");
                }
                mDeviceManager.getBatteryStatus(mDeviceInfoResponseHandler);
                break;
            case ReadVersion:
                if (data.get(Parameter.ReaderVersionInfo) != null) {
                    ReaderVersionInfo readerVersionInfo =
                            (ReaderVersionInfo)data.get(Parameter.ReaderVersionInfo);
                    mTerminalInfo.setKernelVersion(readerVersionInfo.getEmvKernelVersion());
                    Timber.d("Retrieved app version [%s]", mTerminalInfo.getAppVersion());

                    mTerminalInfo.setFirmwareVersion(extractFirmwareVersion(readerVersionInfo));
                    Timber.d("Retrieved firmware version [%s]", mTerminalInfo.getFirmwareVersion());

                    mTerminalInfo.setModel(readerVersionInfo.getHardwareType());
                    Timber.d("Retrieved model [%s]", mTerminalInfo.getModel());

                  /*  mTerminalInfo.setSerialNumber(readerVersionInfo.getProductSerialNumber());
                    Timber.d("Retrieved serial number [%s]", mTerminalInfo.getSerialNumber());*/

                    mTerminalInfo.setManufacturer("Ingenico");
                    Timber.d("Retrieved manufacturer [%s]", mTerminalInfo.getManufacturer());

                    if (mListener != null) {
                        mListener.onReaderVersionInfo(readerVersionInfo);
                    } else {
                        Timber.w(
                                "mListener is null. Callback indicating that ReaderVersionInfo was retrieved cannot be fired.");
                    }
                }
                if (mListener != null) {
                    mListener.onTerminalInfo(mTerminalInfo);
                    mListener.onComplete();
                } else {
                    Timber.w(
                            "mListener is null. Callback indicating that device info retrieval process is complete cannot be fired.");
                }
                mListener = null;
                break;
            case BatteryInfo:
                if (data.get(Parameter.BatteryLevel) != null) {
                    mTerminalInfo.setBatteryLevel((Integer)data.get(Parameter.BatteryLevel));
                    Timber.d("Retrieved battery status [%s]", mTerminalInfo.getBatteryLevel());
                }
                if (mOnlyBatteryStatusRequired) {
                    returnBatteryStatusOnly();
                } else {
                    if (mListener != null) {
                        mListener.onExecutingCommand();
                    } else {
                        Timber.w(
                                "mListener is null. Callback indicating that a command is in progress cannot be fired.");
                    }
                    mDeviceManager.getConfigurationManager()
                            .readVersion(mDeviceInfoResponseHandler);
                }
                break;
        }
    }

    @Nullable
    private String extractFirmwareVersion(ReaderVersionInfo readerVersionInfo) {
        // Firmware version extraction
        List<FileVersionInfo> versionInfos = readerVersionInfo.getUserFileVersions();
        if (versionInfos != null && !versionInfos.isEmpty()) {
            FileVersionInfo info = versionInfos.get(0);
            if (info != null) {
                if (!TextUtils.isEmpty(info.verFlag) &&
                        !TextUtils.isEmpty(info.version)) {
                    final String majorVersion = info.version;
                    final String minorVersion = info.verFlag;

                    StringBuilder versionBuilder = new StringBuilder();
                    if (majorVersion.length() >= 2) {
                        versionBuilder.append(majorVersion
                                .substring(majorVersion.length() - 2));
                    } else {
                        versionBuilder.append(majorVersion);
                    }
                    versionBuilder.append(".");
                    versionBuilder.append(minorVersion);

                    return versionBuilder.toString();
                }
            }
        }

        return null;
    }

    private void handleDeviceErrorResponse(@NonNull Map<Parameter, Object> data,
            @NonNull Command cmd,
            ResponseType responseType) {
        Timber.d("handleDeviceErrorResponse() called with: data=[%s], cmd=[%s], responseType=[%s]",
                data, cmd, responseType);
        ErrorCode errorCode = (ErrorCode)data.get(Parameter.ErrorCode);
        String errorMessage = (String)data.get(Parameter.ErrorDetails);
        if (errorCode != null && TextUtils.isEmpty(errorMessage)) {
            errorMessage = errorCode.getValue();
        } else {
            errorMessage = "Device Error";
        }

        if (ErrorCode.BatteryTooLowError == errorCode) {
            Timber.d("Terminal battery level too low [%s]", errorMessage);
            if (mListener != null) {
                mListener.onError(TerminalError.BATTERY_TOO_LOW, "Low battery.");
            } else {
                Timber.w(
                        "mListener is null. Callback indicating that battery is too low cannot be fired.");
            }
        } else {
            switch (cmd) {
                case ReadCapabilities:
                    Timber.d("Could not retrieve terminal capabilities [%s]", errorMessage);
                    if (mListener != null) {
                        mListener.onError(TerminalError.INITIALIZATION_ERROR,
                                "Unable to determine card reader capabilities.");
                    } else {
                        Timber.w(
                                "mListener is null. Callback indicating ReadCapabilities command failed cannot be fired.");
                    }
                    break;
                case BatteryInfo:
                    Timber.d("Could not retrieve terminal battery status [%s]", errorMessage);
                    if (mOnlyBatteryStatusRequired) {
                        returnTerminalErrorStatus(errorMessage);
                    } else {
                        if (mListener != null) {
                            mListener.onExecutingCommand();
                        } else {
                            Timber.w(
                                    "mListener is null. Callback indicating that a command is in progress cannot be fired.");
                        }
                        mDeviceManager.getConfigurationManager()
                                .readVersion(mDeviceInfoResponseHandler);
                    }
                    break;
                default:
                    Timber.d("Could not retrieve terminal info [%s]", errorMessage);
                    returnTerminalErrorStatus(errorMessage);
                    break;
            }
        }
        mListener = null;
    }

    /**
     * These values will always be null for a new terminal connection request.
     */
    private boolean isNewTerminalConnRequest() {
        return mTerminalInfo.getSerialNumber() == null ||
                mTerminalInfo.getAppVersion() == null ||
                mTerminalInfo.getBatteryLevel() == null;
    }

    /**
     * During an initial connection to a card reader, below commands would have already been sent, {@link
     * Command#ReadCapabilities}, {@link Command#ReadVersion}.
     * <p>
     * Prior to every transaction, the current {@link TerminalInfo} is already loaded, and only battery status is
     * required, which is retrieved using {@link Command#BatteryInfo}.
     */
    private void returnBatteryStatusOnly() {
        if (mListener != null) {
            mListener.onTerminalInfo(mTerminalInfo);
            mListener.onComplete();
        } else {
            Timber.w(
                    "mListener is null. Callback indicating battery status cannot be fired.");
        }
        mListener = null;
    }

    private void returnTerminalErrorStatus(@Nullable String errorMessage) {
        if (mListener != null) {
            if (errorMessage == null) {
                mListener.onError(TerminalError.GENERAL_ERROR,
                        "The terminal is unable to perform the requested action.");
            } else {
                mListener.onError(TerminalError.GENERAL_ERROR, errorMessage);
            }
        } else {
            Timber.w(
                    "mListener is null. Callback indicating an error occurred cannot be fired.");
        }
    }

    interface IngenicoDeviceInfoProcessCallbacks extends IngenicoDeviceProcessCallbacks {

        void onTerminalInfo(TerminalInfo terminalInfo);

        void onReaderVersionInfo(ReaderVersionInfo readerVersionInfo);
    }

    private class DeviceInfoResponseHandler implements DeviceResponseHandler {

        @Override
        public void onResponse(Map<Parameter, Object> map) {
            Timber.d("onResponse() called with: map=[%s]", map);
            if (mListener != null) {
                mListener.onWaitingForCommand();
            } else {
                Timber.w(
                        "mListener is null. Callback indicating that the terminal is ready to receive new commands cannot be fired.");
            }
            Command cmd = (Command)map.get(Parameter.Command);
            ResponseCode responseCode = (ResponseCode)map.get(Parameter.ResponseCode);
            ResponseType responseType = (ResponseType)map.get(Parameter.ResponseType);
            if (responseCode == ResponseCode.Error) {
                handleDeviceErrorResponse(map, cmd, responseType);
            } else {
                handleDeviceInfoResponse(map, cmd, responseType);
            }
        }

        @Override
        public void onProgress(ProgressMessage progressMessage, String description) {
            Timber.d(
                    "onProgress() called with: progressMessage=[" + progressMessage +
                            "], description=[" + description +
                            "]");
        }
    }
}
