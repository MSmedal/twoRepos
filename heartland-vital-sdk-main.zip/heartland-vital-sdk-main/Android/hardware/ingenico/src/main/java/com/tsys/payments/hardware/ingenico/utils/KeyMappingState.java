package com.tsys.payments.hardware.ingenico.utils;

public enum KeyMappingState {
    ORIGINAL,
    STUB_1,
    STUB_2
}
