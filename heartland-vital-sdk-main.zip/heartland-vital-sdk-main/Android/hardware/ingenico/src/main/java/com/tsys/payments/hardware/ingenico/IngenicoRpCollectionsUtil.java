package com.tsys.payments.hardware.ingenico;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.roam.roamreaderunifiedapi.constants.Command;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;
import com.roam.roamreaderunifiedapi.data.ReaderVersionInfo;
import com.tsys.payments.hardware.ingenico.utils.IngenicoHexHelper;
import com.tsys.payments.hardware.ingenico.utils.IngenicoTlvHelper;
import com.tsys.payments.library.domain.TerminalActionCodes;
import com.tsys.payments.library.domain.TerminalConfiguration;
import com.tsys.payments.library.domain.TransactionConfiguration;
import com.tsys.payments.library.enums.CardDataSourceType;
import com.tsys.payments.library.terminal.domain.TerminalRequest;
import com.tsys.payments.library.terminal.enums.TerminalAction;
import com.tsys.payments.library.tlv.EmvTagDescriptor;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import timber.log.Timber;

class IngenicoRpCollectionsUtil {
    private static final String TAG = IngenicoRpCollectionsUtil.class.getName();
    private static final Parameter EMV_TAG_9F5B = Parameter.IssuerScriptResults;
    private static final Parameter EMV_TAG_9F6E_PAYPASS = Parameter.PayPassThirdPartyData;
    private static final Parameter EMV_TAG_DF78 = Parameter.InterfaceDeviceSerialNumber;
    private static final Parameter EMV_TAG_DF79 = Parameter.ContactlessKernelIdentifier;
    private static final Parameter EMV_TAG_CO = Parameter.EncryptedIsoPinBlock;
    private static final int P2_FIELD_BITMASK_ALL_NFC_OFF = 0x1A;
    //Undocumented RUA value for when tag 5F35 not present in fixed length DOL
    private static final String TAG_5F34_INVALID = "FF";
    private static final EmvTagDescriptor[] CONTACT_ONLINE_TAGS =
            new EmvTagDescriptor[] {EmvTagDescriptor.APPLICATION_IDENTIFIER,
                    EmvTagDescriptor.TRACK_2_EQUIVALENT_DATA,
                    EmvTagDescriptor.TRANSACTION_CURRENCY_CODE,
                    EmvTagDescriptor.LANGUAGE_PREFERENCE,
                    EmvTagDescriptor.PAN_SEQUENCE_NUMBER, EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_1,
                    EmvTagDescriptor.ISSUER_SCRIPT_TEMPLATE_2,
                    EmvTagDescriptor.APPLICATION_INTERCHANGE_PROFILE,
                    EmvTagDescriptor.DEDICATED_FILE_NAME,
                    EmvTagDescriptor.ISSUER_AUTHENTICATION_DATA,
                    EmvTagDescriptor.TERMINAL_VERIFICATION_RESULTS,
                    EmvTagDescriptor.TRANSACTION_DATE,
                    EmvTagDescriptor.TRANSACTION_STATUS_INFORMATION,
                    EmvTagDescriptor.TRANSACTION_TYPE,
                    EmvTagDescriptor.AMOUNT_AUTHORIZED_NUMERIC,
                    EmvTagDescriptor.AMOUNT_OTHER_NUMERIC,
                    EmvTagDescriptor.AID_TERMINAL, EmvTagDescriptor.APPLICATION_USAGE_CONTROL,
                    EmvTagDescriptor.APPLICATION_VERSION_NUMBER_TERMINAL,
                    EmvTagDescriptor.ISSUER_ACTION_DEFAULT, EmvTagDescriptor.ISSUER_ACTION_DENIAL,
                    EmvTagDescriptor.ISSUER_ACTION_ONLINE, EmvTagDescriptor.ISSUER_APP_DATA,
                    EmvTagDescriptor.ISSUER_CODE_TABLE_INDEX,
                    EmvTagDescriptor.APPLICATION_PREFERRED_NAME,
                    EmvTagDescriptor.APP_LABEL, EmvTagDescriptor.TERMINAL_COUNTRY_CODE,
                    EmvTagDescriptor.IFD_SERIAL_NUMBER, EmvTagDescriptor.TRANSACTION_TIME,
                    EmvTagDescriptor.APPLICATION_CRYPTOGRAM,
                    EmvTagDescriptor.CRYPTOGRAM_INFORMATION_DATA,
                    EmvTagDescriptor.TERMINAL_CAPABILITIES, EmvTagDescriptor.PAN,
                    EmvTagDescriptor.CVM_RESULT, EmvTagDescriptor.TERMINAL_TYPE,
                    EmvTagDescriptor.APPLICATION_TRANSACTION_COUNTER,
                    EmvTagDescriptor.UNPREDICTABLE_NUMBER,
                    EmvTagDescriptor.PROCESSING_OPTIONS_DOL, EmvTagDescriptor.POS_ENTRY_MODE,
                    EmvTagDescriptor.ADDITIONAL_TERMINAL_CAPABILITIES,
                    EmvTagDescriptor.TRANSACTION_SEQUENCE_NUMBER,
                    EmvTagDescriptor.ICC_DYNAMIC_NUMBER,
                    EmvTagDescriptor.MASTERCARD_TRANSACTION_CATEGORY_CODE,
                    EmvTagDescriptor.TERMINAL_OPTION_STATUS,
                    EmvTagDescriptor.TRACK_2_DATA_CONTACTLESS,
                    EmvTagDescriptor.EXPRESSPAY_ENHANCED_TERMINAL_CAPABILITIES,
                    EmvTagDescriptor.CUSTOMER_EXCLUSIVE_DATA,
            };
    private static final EmvTagDescriptor[] CONTACTLESS_MSR_TAGS = new EmvTagDescriptor[] {
            EmvTagDescriptor.AID_TERMINAL, EmvTagDescriptor.APPLICATION_IDENTIFIER,
            EmvTagDescriptor.TERMINAL_VERIFICATION_RESULTS, EmvTagDescriptor.
            APPLICATION_PREFERRED_NAME, EmvTagDescriptor.APP_LABEL,
            EmvTagDescriptor.EXPRESSPAY_ENHANCED_TERMINAL_CAPABILITIES};
    private static Set<Parameter> sTsysContactOnlineTagSet;
    private static Set<Parameter> sTsysContactlessMsrOnlineTagSet;

    @NonNull
    static Map<Parameter, Object> getStartTransactionInputMap(TerminalRequest terminalRequest,
            TransactionConfiguration transactionConfiguration, String deviceSerialNumber,
            DeviceType deviceType) {
        SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss", Locale.US);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMdd", Locale.US);
        Map<Parameter, Object> input = new EnumMap<>(Parameter.class);
        input.put(Parameter.Command, Command.EMVStartTransaction);
        input.put(Parameter.DefaultValueForDDOL, "9F3704"); // DF15
        input.put(Parameter.Maximumtargetpercentage, "00");
        input.put(Parameter.AdditionalTerminalCapabilities, "6000008001"); // 9F40
        input.put(Parameter.AuthorizationResponseCodeList,
                "59315A3159325A3259335A333030303530313034"); // DF16
        input.put(Parameter.AmountAuthorizedNumeric,
                String.format(Locale.US, "%012d", terminalRequest.getTotalAmount())); // 9F02
        input.put(Parameter.AmountOtherNumeric, String.format(Locale.US, "%012d", 0)); // 9F03
        input.put(Parameter.AmountAuthorizedBinary,
                String.format(Locale.US, "%08X", terminalRequest.getTotalAmount())); // 81
        input.put(Parameter.AmountOtherBinary, String.format(Locale.US, "%08X", 0)); // 9F04
        input.put(Parameter.TransactionCurrencyExponent, "02"); //5F36 Transaction Currency Exponent
        input.put(Parameter.TransactionDate, dateFormat.format(new Date())); // 9A
        input.put(Parameter.TerminalCountryCode, "0840"); // 9F1A - 0840 for USD
        input.put(Parameter.TransactionTime, timeFormat.format(new Date())); // 9F21
        input.put(Parameter.TerminalCapabilities, "6028C8"); // 9F33
        input.put(Parameter.TerminalType, "22"); // 9F35
        input.put(Parameter.TerminalFloorLimit,
                IngenicoConversionHelper.getFormattedFloorLimit(0l)); // force online
        input.put(Parameter.ThresholdValue,
                IngenicoConversionHelper.getFormattedTransactionThresholdValue(0l));
        input.put(Parameter.TerminalRiskManagementData, "0000000000000000");
        input.put(Parameter.TargetPercentage, "00");
        if (terminalRequest.getTerminalAction() == TerminalAction.TENDER_REFUND) {
            input.put(Parameter.GenerateACControl, "02");
        }
        String transactionType = IngenicoTlvHelper.getTlvTransactionTypeValue(terminalRequest);
        if (!TextUtils.isEmpty(transactionType)) {
            input.put(Parameter.TransactionType, transactionType); // 9C
        }
        input.put(Parameter.TransactionCurrencyCode,
                transactionConfiguration.getCurrencyCode().currencyCode);
        input.put(Parameter.POSEntryMode, "00"); // 9F39
        input.put(Parameter.CardTransactionQualifiers, "B3004000"); // 9F66
        input.put(Parameter.ExtraProgressMessageFlag, "01");
        if (transactionConfiguration.isContactlessEnabled()) {
            if (!TextUtils.isEmpty(deviceSerialNumber)) {
                String cleanSerialNumber = cleanSerialNumber(deviceSerialNumber);
                input.put(Parameter.TerminalIdentification,
                        IngenicoHexHelper.asciiToHex(cleanSerialNumber)); // 9F1C
            }
            input.put(Parameter.OverallContactlessTransactionLimit, "05F5E0FF");//DF65
        } else if (deviceType == DeviceType.RP450c) {
            input.put(Parameter.P2Field,
                    String.format(Locale.US, "%02X", P2_FIELD_BITMASK_ALL_NFC_OFF));
        }

        return input;
    }

    @NonNull
    private static String cleanSerialNumber(@NonNull String rawSerialNumber) {
        if (rawSerialNumber.contains("RP")) {
            String[] splits = rawSerialNumber.split("RP");
            if (splits.length > 1) {
                return splits[1];
            } else {
                return rawSerialNumber;
            }
        } else {
            return rawSerialNumber;
        }
    }

    @NonNull
    static Map<Parameter, Object> getTransactionDataInputMap(@Nullable ApplicationIdentifier
            selectedAid,
            @Nullable String currentAid, @NonNull TerminalConfiguration terminalConfiguration) {
        Map<Parameter, Object> input = new EnumMap<>(
                Parameter.class);
        input.put(Parameter.Command, Command.EMVTransactionData);
        input.put(Parameter.TerminalFloorLimit,
                IngenicoConversionHelper.getFormattedFloorLimit(0l)); // force online
        input.put(Parameter.ThresholdValue,
                IngenicoConversionHelper.getFormattedTransactionThresholdValue(0l));
        input.put(Parameter.TargetPercentage, "00");
        input.put(Parameter.Maximumtargetpercentage, "00");
        String aid = null;
        if (selectedAid != null) {
            aid = selectedAid.getAID();
        } else if (currentAid != null) {
            aid = currentAid;
        }

        // If the map doesn't include the current AID, check if current AID contains any
        // of the AIDs in map. EG: current AID = A000000003101004 contains A0000000031010
        Map<String, TerminalActionCodes> tacMap = terminalConfiguration.getTacMap();
        TerminalActionCodes currentTac = null;
        if (tacMap != null) {
            if (tacMap.containsKey(aid)) {
                for (String tempAid : tacMap.keySet()) {
                    if (aid != null && aid.toLowerCase().contains(tempAid.toLowerCase())) {
                        aid = tempAid;
                    }
                }
            }

            currentTac = tacMap.get(aid);
        }

        if (currentTac == null) {
            Timber.w(
                    "A valid Terminal Action Code map was not found for: terminalConfiguration=[%s],aid=[%s]. Falling back to generic map.",
                    terminalConfiguration, aid);
            currentTac = getGenericTac();
        }

        input.put(Parameter.TerminalActionCodeDefault, currentTac.getDefaultTac());
        input.put(Parameter.TerminalActionCodeDenial, currentTac.getDenialTac());
        input.put(Parameter.TerminalActionCodeOnline, currentTac.getOnlineTac());

        return input;
    }

    private static TerminalActionCodes getGenericTac() {
        return new TerminalActionCodes(
                "DC4000A800",
                "0010000000",
                "DC4004F800");
    }

    @NonNull
    public static Map<Parameter, Object> getFinalApplicationSelectionInputMap(
            @Nullable ApplicationIdentifier applicationIdentifier) {
        Map<Parameter, Object> input = new EnumMap<>(Parameter.class);
        input.put(Parameter.Command, Command.EMVFinalApplicationSelection);
        if (applicationIdentifier != null) {
            input.put(Parameter.ApplicationIdentifier, applicationIdentifier.getAID());
        } else {
            input.put(Parameter.ApplicationIdentifier, "A0000000031010");
        }
        return input;
    }

    @NonNull
    static Map<Parameter, Object> getTransactionStopInputMap() {
        Map<Parameter, Object> input = new EnumMap<>(
                Parameter.class);
        input.put(Parameter.Command, Command.EMVTransactionStop);

        return input;
    }

    @NonNull
    public static List<String> getOnlineEmvTags(@NonNull Map<Parameter, Object> data,
            @Nullable ReaderVersionInfo readerVersionInfo,
            @NonNull CardDataSourceType cardDataSourceType) {
        Set<Parameter> tags =
                cardDataSourceType == CardDataSourceType.CONTACTLESS_MSR ?
                        getTsysContactlessMsrOnlineTagSet() :
                        getTsysContactOnlineTagSet();
        final Parameter panSequenceNumber =
                IngenicoConversionHelper
                        .getIngenicoTagParameter(EmvTagDescriptor.PAN_SEQUENCE_NUMBER);
        final Parameter issuerAuthData =
                IngenicoConversionHelper
                        .getIngenicoTagParameter(EmvTagDescriptor.ISSUER_AUTHENTICATION_DATA);
        final Parameter transactionCategoryCode =
                IngenicoConversionHelper.getIngenicoTagParameter(
                        EmvTagDescriptor.MASTERCARD_TRANSACTION_CATEGORY_CODE);
        final Parameter formFactorIndicator =
                IngenicoConversionHelper
                        .getIngenicoTagParameter(EmvTagDescriptor.VISA_FORM_FACTOR_INDICATOR);

        List<String> result = new ArrayList<>(tags.size());
        for (Parameter param : tags) {
            if (param == null) continue;
            String dataValue = null;
            if (data.get(param) != null) {
                dataValue = data.get(param).toString();
            }
            String tag = param.getTagString();
            if (param == EMV_TAG_DF78) {
                tag = "DF78";
                String productSerialNumber = "";
                if (TextUtils.isEmpty(dataValue)) {
                    dataValue = readerVersionInfo != null ?
                            readerVersionInfo.getProductSerialNumber() != null ?
                                    readerVersionInfo.getProductSerialNumber().trim() :
                                    productSerialNumber :
                            productSerialNumber;
                }
            }
            if (param == EMV_TAG_DF79) {
                tag = "DF79";
                if (dataValue == null || dataValue.isEmpty()) {
                    dataValue = readerVersionInfo != null ?
                            readerVersionInfo.getEmvKernelVersion().trim() : "";
                }
            } else if (param == panSequenceNumber && TAG_5F34_INVALID.equalsIgnoreCase(dataValue)) {
                dataValue = "";
            }

            if (dataValue != null) {
                switch (param.getTagValueFormat()) {
                    case ALPHABETIC:
                    case ALPHANUMERIC:
                    case ALPHANUMERIC_SPECIALCHARACTERS:
                        dataValue = IngenicoHexHelper.asciiToHex(dataValue.trim());
                        break;
                    default:
                        break;
                }
                if (param == issuerAuthData || param == transactionCategoryCode ||
                        param == formFactorIndicator ||
                        param == EMV_TAG_9F6E_PAYPASS) {
                    if (!dataValue.isEmpty()) {
                        result.add(IngenicoTlvHelper.getEncodedTlv(tag, dataValue));
                    }
                } else {
                    result.add(IngenicoTlvHelper.getEncodedTlv(tag, dataValue));
                }
            }
        }

        return result;
    }

    @NonNull
    private static Set<Parameter> getTsysContactlessMsrOnlineTagSet() {

        synchronized (IngenicoRpCollectionsUtil.class) {
            if (sTsysContactlessMsrOnlineTagSet == null) {
                sTsysContactlessMsrOnlineTagSet = new HashSet<>(45);
                for (EmvTagDescriptor tagDescriptor : CONTACTLESS_MSR_TAGS) {
                    sTsysContactlessMsrOnlineTagSet
                            .add(IngenicoConversionHelper.getIngenicoTagParameter(tagDescriptor));
                }
                sTsysContactlessMsrOnlineTagSet.add(EMV_TAG_9F6E_PAYPASS);
            }
        }
        return sTsysContactlessMsrOnlineTagSet;
    }

    @NonNull
    private static Set<Parameter> getTsysContactOnlineTagSet() {

        synchronized (IngenicoRpCollectionsUtil.class) {
            if (sTsysContactOnlineTagSet == null) {
                sTsysContactOnlineTagSet = new HashSet<>(45);
                for (EmvTagDescriptor tagDescriptor : CONTACT_ONLINE_TAGS) {
                    sTsysContactOnlineTagSet
                            .add(IngenicoConversionHelper.getIngenicoTagParameter(tagDescriptor));
                }

                sTsysContactOnlineTagSet.add(EMV_TAG_CO);
                sTsysContactOnlineTagSet.add(EMV_TAG_9F5B);
                sTsysContactOnlineTagSet.add(EMV_TAG_DF78);
                sTsysContactOnlineTagSet.add(EMV_TAG_DF79);
                sTsysContactOnlineTagSet.add(EMV_TAG_9F6E_PAYPASS);
            }
        }
        return sTsysContactOnlineTagSet;
    }
}
