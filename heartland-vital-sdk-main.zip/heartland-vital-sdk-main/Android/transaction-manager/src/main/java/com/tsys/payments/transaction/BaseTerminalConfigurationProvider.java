package com.tsys.payments.transaction;

import android.content.Context;
import android.content.res.AssetManager;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tsys.payments.library.domain.AidConfiguration;
import com.tsys.payments.library.domain.TerminalActionCodes;
import com.tsys.payments.library.enums.TerminalType;
import com.tsys.payments.library.gateway.enums.GatewayType;
import com.tsys.payments.library.terminal.TerminalConfigurationProvider;
import com.tsys.payments.library.terminal.TerminalConfigurationProviderListener;

import androidx.annotation.NonNull;
import timber.log.Timber;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

abstract class BaseTerminalConfigurationProvider implements TerminalConfigurationProvider {
    private static final String TAG = BaseTerminalConfigurationProvider.class.getName();
    private static final String PROPERTY_KEY_CONTACT_AIDS = "contact_aids";
    private static final String PROPERTY_KEY_CONTACTLESS_AIDS = "contactless_aids";

    protected TerminalConfigurationProviderListener mListener;
    protected List<AidConfiguration> mContactAids;
    protected List<AidConfiguration> mContactlessAids;
    protected Map<String, TerminalActionCodes> mTacMap;

    protected String getPropertiesFileName(@NonNull TerminalType terminalType,
            @NonNull GatewayType gatewayType) {
        return (gatewayType.name() + "_" + terminalType.name() + ".properties").toLowerCase();
    }

    protected void loadProperties(@NonNull Context context, String fileName) {
        Properties properties = new Properties();
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open(fileName);
            properties.load(inputStream);
        } catch (IOException e) {
            Timber.e(e);
            mListener.onError("Unable to load configuration file=[" + fileName + "]");
            return;
        }

        Type aidsListType = new TypeToken<List<AidConfiguration>>() {
        }.getType();

        String contactAids = properties.getProperty(PROPERTY_KEY_CONTACT_AIDS);
        if (!TextUtils.isEmpty(contactAids)) {
            mContactAids = new Gson().fromJson(contactAids, aidsListType);
        }
        String contactlessAids = properties.getProperty(PROPERTY_KEY_CONTACTLESS_AIDS);
        if (!TextUtils.isEmpty(contactlessAids)) {
            mContactlessAids = new Gson().fromJson(contactlessAids, aidsListType);
        }

        mTacMap = new HashMap<>();
        for (AidConfiguration config : mContactAids) {
            if (config.getTerminalActionCodes() != null) {
                mTacMap.put(config.getAid().getFullIdentifier(), config.getTerminalActionCodes());
            }
        }

        mListener.onConfigurationLoaded();
    }
}
